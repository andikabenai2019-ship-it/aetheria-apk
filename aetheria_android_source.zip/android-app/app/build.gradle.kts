import java.io.ByteArrayInputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.spec.RSAPrivateCrtKeySpec
import java.util.Base64

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val currentApkVersionName = "31.2.0-ULTRA-FINISHING-PRO"
val currentApkVersionCode = 312

// Permanent RSA-2048 & X.509 Developer Certificate for Rangga Winata (AETHERIA // RW-14).
// Constructed via pure Java standard cryptography so every GitHub Actions build on Linux
// produces the exact same APK signature forever (enabling in-place APK updates without uninstalling).
val normalizedKeystoreFile = file("aetheria_signing.p12")
val ksPassword = "aetheria14"
val ksAlias = "aetheria"
var hasPermanentKeystore = false

try {
    val dec = Base64.getDecoder()
    val modB64 = "qPcdZHRoMl1QOipysziau58DbMmP37FpQMfNKjTf7dF2Bu1qV5frt7Xk0f2T8eNClqzOd7TWOjVwOMhHz3uCyxzzni20XHKz+Xq3GFF80SWg7Q8O9A7voYSfL3YACUMpPe4sEgB+giDd0Gp6BpFo7NaPRnkDKfESFutwieaQUDdiVIl4UkKyry/cO2kdrkp/5cOQZ0eMOh53OnQ3jHGwbspSFXBukoc0ZlfjybgwJgildS0KV4wEZCE3BpycpnCibbX2ELNpWDfCyB+cAY2JmqiUMtoxeD8UkONe9WiG/23Xc8nOhjqAK28+GEtlMss2+wPjpxCnL9tUat3OaFw8EQ=="
    val expB64 = "AQAB"
    val dB64 = "HzF34KrI7btia0qY4FNr5YVmuXfAsvhqyQXZ75fRW3NXCdJc1oz6fHD9LHNXE8nz6iM+/sSI5DgnXqRC9aAEtoDCzQn9CTA336/zC29HzsjWm80y4oW7YaM9TCLJwOwAOim1QyGKOXXd3XM60emYaFj4HHeMyPpzb33Jyfuh2t0B5DkYL/QPG3XsFiYdLjhsnsBHvz3gjXDywpL8BkIXC4Bs+PL0uoyxmkUgEFZt4MzpHlKlo7HkoJ7mAMdpRoR8IZ9TeEUkw9gLWUXBQk3CA74BPTbDpNCWN3VHJsHF/6rv6yKNevrWSEcTF/bJMbVzoZCFDHW6uqiA4Mlj+LkBHQ=="
    val pB64 = "zx5H/hqxskctjzARflZTZLLExWn/5nXwo70bSf/Wpx87jYI4Ooe9mYyjhNBcUQcVGWr25iE2Ecu/yANOohVJAkNm2cR+BvhIhqhCHh9nIiCo3SOrcZ+HxZ64By2PVOfHETE96d4O7OHVpDa6192KFslIGJAeN4nD2y6Iwwr9rgM="
    val qB64 = "0Neyj/eekCXjH1xrH7Tx/TwTEtrMjNWlQ12917VQCxNZ3GRVTa0GKHeDMOFljsaz3F/zqVCaiZ2d6dND8sg3CWK1aUgne3K6P8ylQvnjyiaG8PHw7S1zugInpfuVTWYm4OBL2o2LtxtcS9jD4UJoz/skB5U/mSII7RhQdUMRy1s="
    val dpB64 = "AcxYgatHqa2Whqy7KiajuLcYoEIoV57khPdqWj0fZvoNcVAVHuT4z3F6JfgNJSLzmvHjzOGy73qeYqUstJmMtblSFkfvdC4Jqymg0VQieBhifvEFVwo0ipGzNVS+7tTIVKzhxbsI1COt0CwteRxSS5pZxuTRblgC3E9OHqtkwnM="
    val dqB64 = "xQea+WR+fjSgcMf6cPF/lJCG1jUC4qP1xPa90rLGj4x0LQ+jwyLIOol2hjlAXVFuAy2rbkQTaF4By8Z7xqPJ+NrdmDRwu3Dj8qkaCXREykVK7ir0SG+nTQgXa+tNUrZbW7GBHvKHq/ruOsiJFQ5YYE/qEBVo6QpJLZbQ4bCjKx0="
    val qInvB64 = "X8wEpacYswr6d3w5oAeA4HJU9LCxr7AGy3i8os2QQE+yi6kSwGGZP2Ay+Zmng/yU5Z2C32LV+iklPHwbyM92kXVwzzr0EcQbi1GeyqsPOVVrB7YwzDAtoq2hmX8+q0kKo6KgCVbA4xL/uX1376PJRClc+sp9R2novOEtQQSnLQI="
    val certB64 = "MIIDPDCCAiSgAwIBAgIIcXmYrfomWZwwDQYJKoZIhvcNAQELBQAwXTELMAkGA1UEBhMCSUQxHTAbBgNVBAoTFFNvdmVyZWlnbiBRdWFudHVtIE9TMRcwFQYDVQQLEw5BRVRIRVJJQSBSVy0xNDEWMBQGA1UEAxMNUmFuZ2dhIFdpbmF0YTAgFw0yNjEwMjMxNjEyMjVaGA8yMDU2MTAyNDE2MTIyNVowXTELMAkGA1UEBhMCSUQxHTAbBgNVBAoTFFNvdmVyZWlnbiBRdWFudHVtIE9TMRcwFQYDVQQLEw5BRVRIRVJJQSBSVy0xNDEWMBQGA1UEAxMNUmFuZ2dhIFdpbmF0YTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKj3HWR0aDJdUDoqcrM4mrufA2zJj9+xaUDHzSo03+3RdgbtaleX67e15NH9k/HjQpaszne01jo1cDjIR897gssc854ttFxys/l6txhRfNEloO0PDvQO76GEny92AAlDKT3uLBIAfoIg3dBqegaRaOzWj0Z5AynxEhbrcInmkFA3YlSJeFJCsq8v3DtpHa5Kf+XDkGdHjDoedzp0N4xxsG7KUhVwbpKHNGZX48m4MCYIpXUtCleMBGQhNwacnKZwom219hCzaVg3wsgfnAGNiZqolDLaMXg/FJDjXvVohv9t13PJzoY6gCtvPhhLZTLLNvsD46cQpy/bVGrdzmhcPBECAwEAATANBgkqhkiG9w0BAQsFAAOCAQEALiHBAzoHdEdwHutt0qRLwxVQY546fhAf5HchfNKRECvcT/BMs1WuNRKsU9eRz1q8HkPDLykk+tIEJoT01sXHwhAdtrCyx2jqq9TmiSnCFiEsXA3fUDSXcqUgRZltXCVntnCLUIROkKeNbZ/atuQ2cj2dwiRdarZstvWm6qX5FWaDdfqQrz+5nqkw+rb4FRgWd81SOCy4rn74EqIMRG5WmjmRFEs70rhW0NaiTsOC9qn2f3ZxW7XasE2BtVKRN81r8LiioxfXMp51nN/mMHgrH43CF8YU/4wOGvAaXApv58G1FPvN+aR9N1DycQ+NoThEv6NRbEdEbu92Shv59SZpvA=="

    val keySpec = RSAPrivateCrtKeySpec(
        BigInteger(1, dec.decode(modB64)),
        BigInteger(1, dec.decode(expB64)),
        BigInteger(1, dec.decode(dB64)),
        BigInteger(1, dec.decode(pB64)),
        BigInteger(1, dec.decode(qB64)),
        BigInteger(1, dec.decode(dpB64)),
        BigInteger(1, dec.decode(dqB64)),
        BigInteger(1, dec.decode(qInvB64))
    )
    val privKey = KeyFactory.getInstance("RSA").generatePrivate(keySpec)
    val cert = CertificateFactory.getInstance("X.509")
        .generateCertificate(ByteArrayInputStream(dec.decode(certB64)))
    val passChars = ksPassword.toCharArray()
    val ks = KeyStore.getInstance("PKCS12")
    ks.load(null, passChars)
    ks.setKeyEntry(ksAlias, privKey, passChars, arrayOf(cert))
    normalizedKeystoreFile.outputStream().use { ks.store(it, passChars) }
    hasPermanentKeystore = normalizedKeystoreFile.exists()
} catch (_: Throwable) {
    hasPermanentKeystore = false
}

// Write a clear version badge to GitHub Actions Step Summary so the user always sees the exact version built
try {
    val summaryPath = System.getenv("GITHUB_STEP_SUMMARY")
    if (!summaryPath.isNullOrBlank()) {
        File(summaryPath).appendText(
            """
            ### 🚀 AETHERIA // RW-14 Build Summary
            - **Versi APK Terbaru:** `v$currentApkVersionName` (Version Code: `$currentApkVersionCode`)
            - **Sertifikat Permanen RW-14:** `${if (hasPermanentKeystore) "AKTIF (Bisa Update Langsung Tanpa Hapus APK Lama)" else "Default"}`
            - **Architect:** `Rangga Winata (NMID: ID1026619104999)`
            """.trimIndent() + "\n"
        )
    }
} catch (_: Throwable) {
}

android {
    namespace = "com.example.masterpieceoptimizer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.masterpieceoptimizer"
        minSdk = 24
        targetSdk = 34
        versionCode = currentApkVersionCode
        versionName = currentApkVersionName

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        getByName("debug") {
            if (hasPermanentKeystore) {
                storeFile = normalizedKeystoreFile
                storePassword = ksPassword
                keyAlias = ksAlias
                keyPassword = ksPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ""
            isDebuggable = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.02.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Official RikkaApps Shizuku API (https://github.com/RikkaApps/Shizuku-API)
    val shizukuVersion = "13.1.5"
    implementation("dev.rikka.shizuku:api:$shizukuVersion")
    implementation("dev.rikka.shizuku:provider:$shizukuVersion")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
