import java.security.KeyStore

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Normalize permanent PKCS#12 developer certificate so every GitHub Actions build uses
// the exact same signature forever (allowing seamless Play-Store-style in-place APK updates).
val rawP12File = file("aetheria_release.p12")
val normalizedKeystoreFile = file("aetheria_signing.p12")
val ksPassword = "aetheria14"
val ksAlias = "aetheria"
var hasPermanentKeystore = false

if (rawP12File.exists()) {
    try {
        val passChars = ksPassword.toCharArray()
        val srcKs = KeyStore.getInstance("PKCS12")
        rawP12File.inputStream().use { srcKs.load(it, passChars) }
        val aliases = srcKs.aliases()
        if (aliases.hasMoreElements()) {
            val firstAlias = aliases.nextElement()
            val privKey = srcKs.getKey(firstAlias, passChars)
            val certChain = srcKs.getCertificateChain(firstAlias)
            val dstKs = KeyStore.getInstance("PKCS12")
            dstKs.load(null, passChars)
            dstKs.setKeyEntry(ksAlias, privKey, passChars, certChain)
            normalizedKeystoreFile.outputStream().use { dstKs.store(it, passChars) }
            hasPermanentKeystore = normalizedKeystoreFile.exists()
        }
    } catch (_: Throwable) {
        hasPermanentKeystore = false
    }
}

android {
    namespace = "com.example.masterpieceoptimizer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.masterpieceoptimizer"
        minSdk = 24
        targetSdk = 34
        versionCode = 285
        versionName = "28.5.0-3D-HD-SOVEREIGN"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        getByName("debug") {
            if (hasPermanentKeystore) {
                storeFile = normalizedKeystoreFile
                storePassword = ksPassword
                keyAlias = ksAlias
                keyPassword = ksPassword
                enableV1Signing = true
                enableV2Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ""
            isDebuggable = true
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.02.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Official RikkaApps Shizuku API (https://github.com/RikkaApps/Shizuku-API)
    val shizukuVersion = "13.1.5"
    implementation("dev.rikka.shizuku:api:$shizukuVersion")
    implementation("dev.rikka.shizuku:provider:$shizukuVersion")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
