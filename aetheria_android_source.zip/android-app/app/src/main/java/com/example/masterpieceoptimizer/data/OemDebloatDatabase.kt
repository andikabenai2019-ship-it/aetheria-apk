package com.example.masterpieceoptimizer.data

import android.content.pm.PackageManager
import android.os.Build
import com.example.masterpieceoptimizer.hardware.OemBrand
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

enum class DebloatRiskLevel(val label: String) {
    SAFE("AMAN DIBEKUKAN (Iklan & Bloatware)"),
    CAUTION("HATI-HATI (Limiter / Sistem OEM)")
}

data class DebloatPackageItem(
    val packageName: String,
    val appName: String,
    val brand: OemBrand,
    val category: String,
    val riskLevel: DebloatRiskLevel,
    val description: String,
    val isInstalled: Boolean = false,
    val isDisabled: Boolean = false,
    val isProtectedByCombo: Boolean = false
)

/**
 * AETHERIA CATEGORIZED MULTI-OEM DEBLOATER & IMMORTAL WHITELIST DATABASE (v30.0)
 * - Hard-blocks WhatsApp & Instagram from EVER being disabled, killed, or restricted!
 * - Protects OEM Phone Master packages when Quad-Combo Phone Master mode is active.
 */
object OemDebloatDatabase {

    /**
     * IMMORTAL PROTECTED APPS:
     * Per explicit user directive ("khusus wa dan ig jangan di off kan yaa"),
     * WhatsApp, WhatsApp Business, and Instagram are permanently protected across ALL modules.
     */
    val IMMORTAL_PROTECTED_PACKAGES: Set<String> = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.instagram.android"
    )

    val PHONE_MASTER_PACKAGES: Set<String> = setOf(
        "com.transsion.phonemaster",
        "com.transsion.phonemanager",
        "com.miui.securitycenter",
        "com.miui.cleanmaster",
        "com.coloros.phonemanager",
        "com.oplus.phonemanager",
        "com.oneplus.security",
        "com.iqoo.secure",
        "com.vivo.imanager",
        "com.samsung.android.lool",
        "com.samsung.android.sm_cn",
        "com.asus.mobilemanager"
    )

    fun isImmortalProtected(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        val clean = packageName.trim().lowercase(Locale.ROOT)
        return IMMORTAL_PROTECTED_PACKAGES.any { it.lowercase(Locale.ROOT) == clean }
    }

    val builtInPackages: List<DebloatPackageItem> = listOf(
        // =====================================================================
        // 1. INFINIX / TECNO / ITEL (XOS & HiOS - Transsion)
        // =====================================================================
        DebloatPackageItem(
            packageName = "com.transsion.plat.appupdate",
            appName = "Palm Store",
            brand = OemBrand.INFINIX_TECNO_ITEL,
            category = "Toko Aplikasi & Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Toko aplikasi bawaan XOS/HiOS yang sering memunculkan iklan rekomendasi dan update paksa di latar belakang."
        ),
        DebloatPackageItem(
            packageName = "com.transsion.ahagames",
            appName = "Aha Games",
            brand = OemBrand.INFINIX_TECNO_ITEL,
            category = "Toko Aplikasi & Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Portal game bawaan Infinix/TECNO yang rutin mengirimkan iklan pop-up dan menguras RAM."
        ),
        DebloatPackageItem(
            packageName = "com.transsion.magazine",
            appName = "XOS Magazine Lockscreen",
            brand = OemBrand.INFINIX_TECNO_ITEL,
            category = "Layanan Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Layanan kunci layar dinamis yang terus mengunduh berita & iklan di latar belakang."
        ),
        DebloatPackageItem(
            packageName = "com.transsion.statisticalsales",
            appName = "Transsion Statistical Telemetry",
            brand = OemBrand.INFINIX_TECNO_ITEL,
            category = "Telemetri & Analitik",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Pelacak statistik penggunaan perangkat yang mengirim analitik ke server pabrik."
        ),
        DebloatPackageItem(
            packageName = "com.talpa.share",
            appName = "XShare",
            brand = OemBrand.INFINIX_TECNO_ITEL,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Aplikasi berbagi file bawaan yang berjalan di latar belakang; aman dibekukan jika memakai Quick Share."
        ),
        DebloatPackageItem(
            packageName = "com.transsion.carlcare",
            appName = "Carlcare Service",
            brand = OemBrand.INFINIX_TECNO_ITEL,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Aplikasi pusat promosi servis & garansi bawaan Transsion."
        ),
        DebloatPackageItem(
            packageName = "com.transsion.phonemaster",
            appName = "Phone Master (XOS System Manager)",
            brand = OemBrand.INFINIX_TECNO_ITEL,
            category = "Quad-Combo Phone Master",
            riskLevel = DebloatRiskLevel.CAUTION,
            description = "TERHUBUNG KE QUAD-COMBO AETHERIA! Biarkan AKTIF agar fitur Combo AETHERIA + Phone Master bekerja maksimal."
        ),

        // =====================================================================
        // 2. XIAOMI / POCO / REDMI (MIUI & HyperOS)
        // =====================================================================
        DebloatPackageItem(
            packageName = "com.miui.msa.global",
            appName = "MSA (MIUI / HyperOS System Ads)",
            brand = OemBrand.XIAOMI_POCO_REDMI,
            category = "Layanan Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Mesin utama penyuplai iklan di aplikasi sistem MIUI & HyperOS. Sangat disarankan dibekukan."
        ),
        DebloatPackageItem(
            packageName = "com.miui.analytics",
            appName = "Xiaomi Analytics",
            brand = OemBrand.XIAOMI_POCO_REDMI,
            category = "Telemetri & Analitik",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Pelacak aktivitas pengguna yang terus berjalan di RAM dan mengirim laporan analitik."
        ),
        DebloatPackageItem(
            packageName = "com.xiaomi.mipicks",
            appName = "GetApps (Mi App Store)",
            brand = OemBrand.XIAOMI_POCO_REDMI,
            category = "Toko Aplikasi & Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Toko aplikasi bawaan Xiaomi yang memunculkan notifikasi promosi setiap hari."
        ),
        DebloatPackageItem(
            packageName = "com.mi.globalbrowser",
            appName = "Mi Browser",
            brand = OemBrand.XIAOMI_POCO_REDMI,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Browser bawaan yang memuat umpan berita & notifikasi iklan latar belakang."
        ),
        DebloatPackageItem(
            packageName = "com.bsp.catchlog",
            appName = "CatchLog Diagnostics",
            brand = OemBrand.XIAOMI_POCO_REDMI,
            category = "Telemetri & Analitik",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Pencatat log sistem latar belakang yang membebani I/O penyimpanan internal."
        ),
        DebloatPackageItem(
            packageName = "com.xiaomi.joyose",
            appName = "Joyose (Cloud Thermal & FPS Limiter)",
            brand = OemBrand.XIAOMI_POCO_REDMI,
            category = "Limiter Performa",
            riskLevel = DebloatRiskLevel.CAUTION,
            description = "Pembatas FPS thermal Xiaomi saat HP hangat. Gunakan fan cooler eksternal jika menonaktifkan layanan ini."
        ),

        // =====================================================================
        // 3. SAMSUNG (OneUI)
        // =====================================================================
        DebloatPackageItem(
            packageName = "com.aura.oobe.samsung",
            appName = "AppCloud (IronSource Sponsor)",
            brand = OemBrand.SAMSUNG,
            category = "Toko Aplikasi & Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Layanan rekomendasi instalasi aplikasi sponsor pada seri Galaxy A & M."
        ),
        DebloatPackageItem(
            packageName = "com.samsung.android.app.spage",
            appName = "Samsung Free / Samsung Daily",
            brand = OemBrand.SAMSUNG,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Panel berita & game instan di layar beranda kiri yang memakan RAM."
        ),
        DebloatPackageItem(
            packageName = "com.samsung.android.rubin.app",
            appName = "Customization Service",
            brand = OemBrand.SAMSUNG,
            category = "Telemetri & Analitik",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Pemantau kebiasaan pengguna untuk rekomendasi iklan terpersonalisasi."
        ),
        DebloatPackageItem(
            packageName = "com.samsung.android.game.gos",
            appName = "Game Optimizing Service (GOS)",
            brand = OemBrand.SAMSUNG,
            category = "Limiter Performa",
            riskLevel = DebloatRiskLevel.CAUTION,
            description = "Pembatas resolusi & clock CPU/GPU Samsung saat bermain game berat."
        ),
        DebloatPackageItem(
            packageName = "com.samsung.android.game.gametools",
            appName = "Samsung Game Booster Limiter",
            brand = OemBrand.SAMSUNG,
            category = "Limiter Performa",
            riskLevel = DebloatRiskLevel.CAUTION,
            description = "Komponen pendamping GOS; biarkan aktif jika ingin dipakai bersama Quad-Combo."
        ),

        // =====================================================================
        // 4. OPPO / REALME / ONEPLUS (ColorOS / RealmeUI / OxygenOS)
        // =====================================================================
        DebloatPackageItem(
            packageName = "com.heytap.market",
            appName = "App Market (HeyTap)",
            brand = OemBrand.OPPO_REALME_ONEPLUS,
            category = "Toko Aplikasi & Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Toko aplikasi bawaan yang sering memunculkan iklan saat menginstal aplikasi baru."
        ),
        DebloatPackageItem(
            packageName = "com.heytap.browser",
            appName = "HeyTap Internet Browser",
            brand = OemBrand.OPPO_REALME_ONEPLUS,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Browser bawaan ColorOS/RealmeUI dengan umpan berita & iklan latar belakang."
        ),
        DebloatPackageItem(
            packageName = "com.glance.internet",
            appName = "Glance Lockscreen Ads",
            brand = OemBrand.OPPO_REALME_ONEPLUS,
            category = "Layanan Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Kunci layar iklan interaktif yang terus berjalan dan menguras kuota data."
        ),
        DebloatPackageItem(
            packageName = "com.nearme.statistics.rom",
            appName = "User Experience Program",
            brand = OemBrand.OPPO_REALME_ONEPLUS,
            category = "Telemetri & Analitik",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Layanan pengumpul statistik dan telemetri sistem ColorOS/RealmeUI."
        ),
        DebloatPackageItem(
            packageName = "com.coloros.athena",
            appName = "Athena (Aggressive Memory Killer)",
            brand = OemBrand.OPPO_REALME_ONEPLUS,
            category = "Limiter Performa",
            riskLevel = DebloatRiskLevel.CAUTION,
            description = "Layanan yang menutup paksa aplikasi latar secara kejam. Bekukan agar WA/Multitasking anti-reload."
        ),

        // =====================================================================
        // 5. VIVO / IQOO (FuntouchOS & OriginOS)
        // =====================================================================
        DebloatPackageItem(
            packageName = "com.vivo.appstore",
            appName = "V-Appstore",
            brand = OemBrand.VIVO_IQOO,
            category = "Toko Aplikasi & Iklan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Toko aplikasi bawaan Vivo yang sering mengirimkan notifikasi promosi harian."
        ),
        DebloatPackageItem(
            packageName = "com.vivo.browser",
            appName = "Vivo Browser",
            brand = OemBrand.VIVO_IQOO,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Browser bawaan dengan notifikasi berita yang berjalan di latar belakang."
        ),
        DebloatPackageItem(
            packageName = "com.vivo.easyshare",
            appName = "EasyShare",
            brand = OemBrand.VIVO_IQOO,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Aplikasi transfer file bawaan Vivo."
        ),
        DebloatPackageItem(
            packageName = "com.vivo.pem",
            appName = "Vivo Power Engine Manager (PEM)",
            brand = OemBrand.VIVO_IQOO,
            category = "Limiter Performa",
            riskLevel = DebloatRiskLevel.CAUTION,
            description = "Pengatur daya & batas suhu FuntouchOS yang dapat menurunkan frame rate game."
        ),

        // =====================================================================
        // 6. UNIVERSAL ANDROID / GOOGLE / META BLOATWARE (Semua Merek)
        // =====================================================================
        DebloatPackageItem(
            packageName = "com.android.traceur",
            appName = "System Tracing",
            brand = OemBrand.OTHER,
            category = "Telemetri & Analitik",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Perekam jejak sistem debugging pengembang yang tidak dibutuhkan pengguna harian."
        ),
        DebloatPackageItem(
            packageName = "com.google.android.apps.wellbeing",
            appName = "Digital Wellbeing",
            brand = OemBrand.OTHER,
            category = "Telemetri & Analitik",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Pemantau waktu layar yang terus mencatat setiap aktivitas buka-tutup aplikasi di latar."
        ),
        DebloatPackageItem(
            packageName = "com.google.android.printservice.recommendation",
            appName = "Print Service Recommendation",
            brand = OemBrand.OTHER,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Pemindai printer jaringan terus-menerus yang memakan RAM di latar belakang."
        ),
        DebloatPackageItem(
            packageName = "com.facebook.services",
            appName = "Meta App Services (Bloatware Prainstal)",
            brand = OemBrand.OTHER,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Layanan latar belakang Facebook prainstal pabrik (BUKAN Instagram/WA). Aman dibekukan."
        ),
        DebloatPackageItem(
            packageName = "com.facebook.appmanager",
            appName = "Meta App Manager (Updater Prainstal)",
            brand = OemBrand.OTHER,
            category = "Bloatware Bawaan",
            riskLevel = DebloatRiskLevel.SAFE,
            description = "Updater tersembunyi pabrik (Instagram & WhatsApp tetap 100% aman dan tidak tersentuh!)."
        )
    )

    suspend fun scanInstalledPackages(
        pm: PackageManager,
        quadComboActive: Boolean
    ): List<DebloatPackageItem> = withContext(Dispatchers.IO) {
        builtInPackages
            .filterNot { isImmortalProtected(it.packageName) }
            .map { item ->
                val isComboProtected = quadComboActive && item.packageName in PHONE_MASTER_PACKAGES
                try {
                    val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getApplicationInfo(item.packageName, PackageManager.ApplicationInfoFlags.of(0))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getApplicationInfo(item.packageName, 0)
                    }
                    item.copy(
                        isInstalled = true,
                        isDisabled = !appInfo.enabled,
                        isProtectedByCombo = isComboProtected
                    )
                } catch (_: PackageManager.NameNotFoundException) {
                    item.copy(
                        isInstalled = false,
                        isDisabled = false,
                        isProtectedByCombo = isComboProtected
                    )
                } catch (_: Throwable) {
                    item.copy(
                        isInstalled = false,
                        isDisabled = false,
                        isProtectedByCombo = isComboProtected
                    )
                }
            }
    }

    fun exportDatabaseToJson(items: List<DebloatPackageItem> = builtInPackages): String {
        val array = JSONArray()
        for (item in items) {
            if (isImmortalProtected(item.packageName)) continue
            val obj = JSONObject().apply {
                put("packageName", item.packageName)
                put("appName", item.appName)
                put("brand", item.brand.name)
                put("category", item.category)
                put("riskLevel", item.riskLevel.name)
                put("description", item.description)
            }
            array.put(obj)
        }
        return array.toString(2)
    }

    fun parseCustomDatabaseFromJson(jsonString: String): List<DebloatPackageItem> {
        val result = mutableListOf<DebloatPackageItem>()
        val array = JSONArray(jsonString)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val pkg = obj.getString("packageName").trim()
            // Hard block WhatsApp & Instagram even if imported via external JSON!
            if (isImmortalProtected(pkg)) continue
            val brandEnum = runCatching { OemBrand.valueOf(obj.getString("brand")) }.getOrDefault(OemBrand.OTHER)
            val riskEnum = runCatching { DebloatRiskLevel.valueOf(obj.getString("riskLevel")) }.getOrDefault(DebloatRiskLevel.SAFE)
            result.add(
                DebloatPackageItem(
                    packageName = pkg,
                    appName = obj.getString("appName"),
                    brand = brandEnum,
                    category = obj.optString("category", "Custom"),
                    riskLevel = riskEnum,
                    description = obj.optString("description", "")
                )
            )
        }
        return result
    }
}
