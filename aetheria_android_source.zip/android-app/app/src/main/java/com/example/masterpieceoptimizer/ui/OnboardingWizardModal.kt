package com.example.masterpieceoptimizer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.masterpieceoptimizer.core.ShizukuDiagnostics
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.theme.AlertRose
import com.example.masterpieceoptimizer.ui.theme.AlertRoseDeep
import com.example.masterpieceoptimizer.ui.theme.CardInnerBg
import com.example.masterpieceoptimizer.ui.theme.CardInnerBottom
import com.example.masterpieceoptimizer.ui.theme.CyberViolet
import com.example.masterpieceoptimizer.ui.theme.CyberVioletDeep
import com.example.masterpieceoptimizer.ui.theme.Extruded3dConsoleCard
import com.example.masterpieceoptimizer.ui.theme.IceCyan
import com.example.masterpieceoptimizer.ui.theme.IceCyanDeep
import com.example.masterpieceoptimizer.ui.theme.QuantumEmerald
import com.example.masterpieceoptimizer.ui.theme.QuantumEmeraldDeep
import com.example.masterpieceoptimizer.ui.theme.SovereignGold
import com.example.masterpieceoptimizer.ui.theme.SovereignGoldDeep
import com.example.masterpieceoptimizer.ui.theme.Tactile3dPushButton
import com.example.masterpieceoptimizer.ui.theme.TextPrimary
import com.example.masterpieceoptimizer.ui.theme.TextSecondary
import kotlinx.coroutines.delay

/**
 * Interactive 3D Dual-Path Onboarding & Permission Wizard (Shizuku + Brevent + Mandiri).
 * Solves connection issues across all Android 8–16 phones (Xiaomi/HyperOS, Infinix/TECNO, OPPO/Realme, Vivo, Samsung).
 */
@Composable
fun DualPathOnboardingWizardDialog(
    diag: ShizukuDiagnostics,
    shizukuManager: ShizukuBridgeManager,
    onRefreshStatus: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTab by remember {
        mutableStateOf(if (diag.breventAppInstalled && !diag.shizukuAppInstalled) 1 else 0)
    }
    var copiedNotice by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 18.dp)
        ) {
            Extruded3dConsoleCard(
                accentColor = if (diag.isReady) QuantumEmerald else IceCyan,
                secondaryAccent = SovereignGold,
                isHighlightedActive = diag.isReady
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "🔗 PANDUAN DUAL-JALUR: SHIZUKU + BREVENT (v30.0)",
                        color = SovereignGold,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Jika Shizuku susah nyambung di suatu HP, gunakan JALUR 2 (BREVENT 1-KLIK)! Keduanya sama-sama membuka 100% fitur UID 2000 tanpa Root.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Live Bridge Status Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (diag.isReady) Color(0xFF062C1E) else Color(0xFF151E36)
                            )
                            .border(
                                width = 1.4.dp,
                                color = if (diag.isReady) QuantumEmerald else SovereignGold,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = diag.activeBridgeMode.badgeLabel,
                                color = if (diag.isReady) QuantumEmerald else SovereignGold,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            )
                            Text(
                                text = diag.diagnosticMessage,
                                color = TextPrimary,
                                fontSize = 10.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2-Tab Selector: Jalur 1 Shizuku vs Jalur 2 Brevent
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (selectedTab == 0) Brush.horizontalGradient(listOf(QuantumEmerald.copy(alpha = 0.28f), CardInnerBg))
                                    else Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
                                )
                                .border(
                                    width = if (selectedTab == 0) 1.8.dp else 1.dp,
                                    color = if (selectedTab == 0) QuantumEmerald else IceCyan.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedTab = 0 }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🟢 JALUR 1: SHIZUKU",
                                color = if (selectedTab == 0) QuantumEmerald else TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 10.5.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (selectedTab == 1) Brush.horizontalGradient(listOf(CyberViolet.copy(alpha = 0.32f), CardInnerBg))
                                    else Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
                                )
                                .border(
                                    width = if (selectedTab == 1) 1.8.dp else 1.dp,
                                    color = if (selectedTab == 1) CyberViolet else IceCyan.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedTab = 1 }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🟣 JALUR 2: BREVENT",
                                color = if (selectedTab == 1) CyberViolet else TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                fontSize = 10.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (selectedTab == 0) {
                        // TAB 1: SHIZUKU STEP-BY-STEP
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                                .border(1.dp, QuantumEmerald.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "Langkah Cepat Menghubungkan Shizuku:",
                                color = QuantumEmerald,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.5.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "1️⃣ Ketuk 'Buka Opsi Pengembang' -> nyalakan 'Proses Debug Nirkabel (Wireless Debugging)'.\n" +
                                    "2️⃣ Ketuk 'Buka / Instal Shizuku' -> pilih Pair (masukkan 6 angka kode pairing dari notifikasi) -> ketuk Start.\n" +
                                    "3️⃣ Kembali ke AETHERIA -> ketuk 'Minta Izin Shizuku' -> pilih 'Allow all the time'.",
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Tactile3dPushButton(
                                    text = "⚙️ Opsi Pengembang",
                                    onClick = { shizukuManager.openDeveloperOptions() },
                                    modifier = Modifier.weight(1f),
                                    faceColor = IceCyan,
                                    deepBaseColor = IceCyanDeep,
                                    textColor = Color(0xFF02131C),
                                    fontSizeSp = 10f
                                )
                                Tactile3dPushButton(
                                    text = if (diag.shizukuAppInstalled) "🚀 Buka Shizuku" else "📥 Instal Shizuku",
                                    onClick = { shizukuManager.openShizukuOrPlayStore() },
                                    modifier = Modifier.weight(1f),
                                    faceColor = SovereignGold,
                                    deepBaseColor = SovereignGoldDeep,
                                    textColor = Color(0xFF1A0F00),
                                    fontSizeSp = 10f
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Tactile3dPushButton(
                                text = if (diag.isShizukuReady) "✅ SHIZUKU SUDAH TERHUBUNG PENUH!" else "🔑 Minta Izin Shizuku Resmi & Cek Koneksi",
                                onClick = {
                                    shizukuManager.requestPermissionSafely()
                                    onRefreshStatus()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                faceColor = QuantumEmerald,
                                deepBaseColor = QuantumEmeraldDeep,
                                textColor = Color(0xFF021A10),
                                fontSizeSp = 11f
                            )
                        }
                    } else {
                        // TAB 2: BREVENT 1-CLICK BRIDGE
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                                .border(1.dp, CyberViolet.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "🟣 Solusi Ampuh Jika Shizuku Gagal Nyambung (Jalur Brevent / LADB):",
                                color = CyberViolet,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.5.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "1️⃣ Pasang & buka aplikasi Brevent dari Play Store, lalu hubungkan Wireless Debugging.\n" +
                                    "2️⃣ Ketuk tombol 'Salin Kode & Buka Brevent' di bawah.\n" +
                                    "3️⃣ Di aplikasi Brevent, buka menu garis tiga (≡) -> pilih 'Exec Command' -> Tempel (Paste) & Jalankan!\n" +
                                    "4️⃣ Dalam 2 detik daemon UID 2000 + izin WRITE_SECURE_SETTINGS langsung aktif 100%!",
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF040914))
                                    .border(1.dp, CyberViolet.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                                    .padding(9.dp)
                            ) {
                                Text(
                                    text = shizukuManager.getBreventActivationCommand(),
                                    color = QuantumEmerald,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp
                                )
                            }

                            if (copiedNotice) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "✅ Kode aktivasi Brevent berhasil disalin ke Clipboard! Tempel di Brevent -> Exec Command.",
                                    color = QuantumEmerald,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Tactile3dPushButton(
                                text = if (diag.breventAppInstalled) "📋 Salin Kode & Buka Brevent Sekarang" else "📋 Salin Kode & Instal Brevent (Play Store)",
                                onClick = {
                                    copiedNotice = true
                                    shizukuManager.copyBreventCommandAndOpenApp(openAppAfterCopy = true)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                faceColor = CyberViolet,
                                deepBaseColor = CyberVioletDeep,
                                textColor = Color.White,
                                fontSizeSp = 11f
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Tactile3dPushButton(
                                    text = "📋 Salin Kode Saja",
                                    onClick = {
                                        copiedNotice = true
                                        shizukuManager.copyBreventCommandAndOpenApp(openAppAfterCopy = false)
                                    },
                                    modifier = Modifier.weight(1f),
                                    faceColor = SovereignGold,
                                    deepBaseColor = SovereignGoldDeep,
                                    textColor = Color(0xFF1A0F00),
                                    fontSizeSp = 10f
                                )
                                Tactile3dPushButton(
                                    text = "↻ Cek Brevent",
                                    onClick = onRefreshStatus,
                                    modifier = Modifier.weight(1f),
                                    faceColor = IceCyan,
                                    deepBaseColor = IceCyanDeep,
                                    textColor = Color(0xFF02131C),
                                    fontSizeSp = 10f
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Brand-Specific Connection Fix Box (Why friend's phone failed to connect!)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF161124))
                            .border(1.dp, SovereignGold.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "💡 Rahasia Kenapa HP Teman Kadang Gagal Nyambung Shizuku:",
                            color = SovereignGold,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• HP Xiaomi / POCO / Redmi (MIUI & HyperOS): WAJIB nyalakan sakelar kedua bernama 'Debugging USB (Setelan Keamanan)' di Opsi Pengembang!\n" +
                                "• HP OPPO / Realme / OnePlus: Geser Opsi Pengembang paling bawah lalu nyalakan 'Matikan Pemantauan Izin (Disable Permission Monitoring)'.\n" +
                                "• HP Infinix / TECNO / Vivo / Samsung: Nyalakan hotspot/Wi-Fi saat proses Pairing 5 detik pertama; setelah tersambung, Wi-Fi boleh dimatikan!",
                            color = TextSecondary,
                            fontSize = 10.2.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Tactile3dPushButton(
                        text = if (diag.isReady) "✅ Lanjut Masuk Konsol 3D AETHERIA (Terhubung!)" else "⚡ Lanjut Masuk AETHERIA (Mode Mandiri / Atur Nanti)",
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        faceColor = if (diag.isReady) QuantumEmerald else IceCyan,
                        deepBaseColor = if (diag.isReady) QuantumEmeraldDeep else IceCyanDeep,
                        textColor = Color(0xFF021512),
                        fontSizeSp = 11f
                    )
                }
            }
        }
    }
}

/**
 * 15-Second Safe Display Guard Dialog!
 * Automatically executes `wm size reset && wm density reset` if the user does not tap
 * "PERTAHANKAN" within 15 seconds, preventing unreadable or oversized DPI lockouts 100%.
 */
@Composable
fun SafeDisplayConfirmDialog(
    appliedDpiLabel: String,
    timeoutSeconds: Int = 15,
    onKeepChanges: () -> Unit,
    onAutoOrManualRevert: () -> Unit
) {
    var timeLeft by remember { mutableStateOf(timeoutSeconds) }

    LaunchedEffect(appliedDpiLabel) {
        timeLeft = timeoutSeconds
        while (timeLeft > 0) {
            delay(1_000L)
            timeLeft -= 1
        }
        onAutoOrManualRevert()
    }

    Dialog(
        onDismissRequest = { /* Prevent accidental outside tap */ },
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
        ) {
            Extruded3dConsoleCard(
                accentColor = AlertRose,
                secondaryAccent = SovereignGold,
                isHighlightedActive = false
            ) {
                Text(
                    text = "🛡️ PELINDUNG LAYAR AMAN (15-SECOND FAIL-SAFE)",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.5.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Pengaturan layar baru ($appliedDpiLabel) telah diterapkan.\n" +
                        "Apakah tampilan layar terlihat jelas dan bisa disentuh normal?",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF280B18))
                        .border(1.5.dp, AlertRose, RoundedCornerShape(14.dp))
                        .padding(vertical = 10.dp, horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "⏱️ OTOMATIS KEMBALI NORMAL DALAM: $timeLeft DETIK",
                        color = AlertRose,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Tactile3dPushButton(
                    text = "✅ PERTAHANKAN PENGATURAN INI",
                    onClick = onKeepChanges,
                    modifier = Modifier.fillMaxWidth(),
                    faceColor = QuantumEmerald,
                    deepBaseColor = QuantumEmeraldDeep,
                    textColor = Color(0xFF021A10),
                    fontSizeSp = 11.5f
                )

                Spacer(modifier = Modifier.height(8.dp))

                Tactile3dPushButton(
                    text = "↩️ BATALKAN & PULIHKAN DPI PABRIK SEKARANG",
                    onClick = onAutoOrManualRevert,
                    modifier = Modifier.fillMaxWidth(),
                    faceColor = AlertRose,
                    deepBaseColor = AlertRoseDeep,
                    textColor = Color.White,
                    fontSizeSp = 11f
                )
            }
        }
    }
}
