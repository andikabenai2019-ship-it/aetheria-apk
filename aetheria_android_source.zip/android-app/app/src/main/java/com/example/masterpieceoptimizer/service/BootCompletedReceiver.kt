package com.example.masterpieceoptimizer.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * AETHERIA REBOOT & POWER-OFF AUTO-RESET RECEIVER (v30.0)
 * Fixes the exact bug reported by the user:
 * - Clearing Recent Apps keeps all toggles ON (same kernel boot_id).
 * - Restarting or powering off the phone triggers ACTION_BOOT_COMPLETED -> automatically resets
 *   all persistent Android settings & UI switches back to Factory Default!
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val appCtx = context.applicationContext
                    val bridge = ShizukuBridgeManager(appCtx)
                    val repo = GameDetectionRepository(appCtx)
                    val resetPerformed = bridge.checkAndHandleNewBootSession(forceFromBootBroadcast = true)
                    if (resetPerformed || bridge.isAutoResetOnRebootEnabled()) {
                        repo.resetAutomationPrefsOnReboot()
                    } else if (repo.isAutoSwitchEnabledPref()) {
                        AutoSwitchEngineService.start(appCtx)
                    }
                } catch (_: Throwable) {
                } finally {
                    runCatching { pendingResult.finish() }
                }
            }
        }
    }
}
