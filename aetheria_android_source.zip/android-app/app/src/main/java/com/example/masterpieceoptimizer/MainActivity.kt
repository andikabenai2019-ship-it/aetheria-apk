package com.example.masterpieceoptimizer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.masterpieceoptimizer.core.DeviceTelemetryRepository
import com.example.masterpieceoptimizer.service.GameDetectionRepository
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.AetheriaRootScreen
import com.example.masterpieceoptimizer.ui.theme.AetheriaTheme
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull

/**
 * AETHERIA MAIN ACTIVITY (v30.0 QUANTUM 3D OMNI)
 * - Verifies Kernel Boot-ID session before first Compose frame so post-reboot / post-shutdown launches
 *   always reflect Factory Default reset, while clearing Recent Apps preserves all active toggles 100%!
 * - Manages Dual-Bridge (Shizuku + Brevent) lifecycle cleanly across Activity states.
 */
class MainActivity : ComponentActivity() {

    private lateinit var shizukuBridgeManager: ShizukuBridgeManager
    private lateinit var telemetryRepository: DeviceTelemetryRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shizukuBridgeManager = ShizukuBridgeManager(applicationContext)
        telemetryRepository = DeviceTelemetryRepository(applicationContext)
        shizukuBridgeManager.registerLifecycle()

        // Synchronous <1.5s Kernel Boot-ID check before Compose reads initial UI states:
        // Ensures 100% Reboot Auto-Reset even on OEM ROMs that block background BOOT_COMPLETED broadcasts!
        runBlocking {
            val wasResetOnNewBoot = withTimeoutOrNull(1500L) {
                shizukuBridgeManager.checkAndHandleNewBootSession(forceFromBootBroadcast = false)
            } ?: false
            if (wasResetOnNewBoot) {
                GameDetectionRepository(applicationContext).resetAutomationPrefsOnReboot()
            }
        }

        setContent {
            AetheriaTheme {
                AetheriaRootScreen(
                    shizukuManager = shizukuBridgeManager,
                    telemetryRepo = telemetryRepository
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        shizukuBridgeManager.refreshDiagnostics()
    }

    override fun onDestroy() {
        shizukuBridgeManager.unregisterLifecycle()
        super.onDestroy()
    }
}
