package com.example.masterpieceoptimizer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.masterpieceoptimizer.core.DeviceTelemetryRepository
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.AetheriaRootScreen
import com.example.masterpieceoptimizer.ui.theme.AetheriaTheme

/**
 * AETHERIA MAIN ACTIVITY
 * Manages Shizuku binder & permission lifecycle cleanly across Android Activity states.
 */
class MainActivity : ComponentActivity() {

    private lateinit var shizukuBridgeManager: ShizukuBridgeManager
    private lateinit var telemetryRepository: DeviceTelemetryRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shizukuBridgeManager = ShizukuBridgeManager(applicationContext)
        telemetryRepository = DeviceTelemetryRepository(applicationContext)
        shizukuBridgeManager.registerLifecycle()

        setContent {
            AetheriaTheme {
                AetheriaRootScreen(
                    shizukuManager = shizukuBridgeManager,
                    telemetryRepo = telemetryRepository
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        shizukuBridgeManager.refreshDiagnostics()
    }

    override fun onDestroy() {
        shizukuBridgeManager.unregisterLifecycle()
        super.onDestroy()
    }
}
