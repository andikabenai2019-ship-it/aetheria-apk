package com.example.masterpieceoptimizer.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.masterpieceoptimizer.hardware.HardwareDetector
import com.example.masterpieceoptimizer.hardware.OemBrand
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * AETHERIA 3D FLOATING GAMING HUD & PRECISION CROSSHAIR OVERLAY SERVICE (v30.0)
 * - Displays Real-Time FPS, Frame-Time (ms), Battery Temp (°C), Live Wattage,
 *   1-Tap Quick RAM Boost (WA/IG safe!), and Optional Center Crosshair Aim Assist!
 * - Auto-grants SYSTEM_ALERT_WINDOW when Shizuku or Brevent is active.
 */
class FloatingHudOverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "aetheria_floating_hud_v300"
        const val NOTIFICATION_ID = 1431
        const val ACTION_START = "com.example.masterpieceoptimizer.action.START_HUD"
        const val ACTION_STOP = "com.example.masterpieceoptimizer.action.STOP_HUD"
        const val ACTION_TOGGLE_CROSSHAIR = "com.example.masterpieceoptimizer.action.TOGGLE_CROSSHAIR"

        suspend fun ensureOverlayPermissionOrOpenSettings(
            context: Context,
            bridgeManager: ShizukuBridgeManager
        ): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)) {
                return true
            }
            bridgeManager.autoGrantPermissionsViaShellIfPossible()
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)) {
                return true
            }
            runCatching {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            return false
        }

        fun start(context: Context) {
            val intent = Intent(context, FloatingHudOverlayService::class.java).apply {
                action = ACTION_START
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingHudOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching { context.startService(intent) }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private lateinit var bridgeManager: ShizukuBridgeManager
    private lateinit var gameRepo: GameDetectionRepository

    private var hudRootView: View? = null
    private var crosshairView: View? = null
    private var statsTextView: TextView? = null
    private var crosshairActive: Boolean = false

    private var frameCounter = 0
    private var lastFpsTimestampNs = 0L
    private var currentFps = 60
    private var currentFrameMs = 16.6
    private var choreographerRunning = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!choreographerRunning) return
            frameCounter++
            if (lastFpsTimestampNs == 0L) {
                lastFpsTimestampNs = frameTimeNanos
            } else {
                val elapsedNs = frameTimeNanos - lastFpsTimestampNs
                if (elapsedNs >= 1_000_000_000L) {
                    val fps = ((frameCounter * 1_000_000_000.0) / elapsedNs).roundToInt().coerceIn(1, 240)
                    currentFps = fps
                    currentFrameMs = ((1000.0 / fps.toDouble()) * 10.0).roundToInt() / 10.0
                    frameCounter = 0
                    lastFpsTimestampNs = frameTimeNanos
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        bridgeManager = ShizukuBridgeManager(applicationContext)
        gameRepo = GameDetectionRepository(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                gameRepo.setFloatingHudEnabledPref(false)
                removeOverlays()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } else {
                    @Suppress("DEPRECATION")
                    stopForeground(true)
                }
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_CROSSHAIR -> {
                toggleCrosshairOverlay()
                return START_STICKY
            }
        }

        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notif)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        gameRepo.setFloatingHudEnabledPref(true)
        if (hudRootView == null) {
            attachHudWindow()
            startLiveTelemetryTicker()
        }
        return START_STICKY
    }

    private fun attachHudWindow() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 110
        }

        val bgDrawable = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#EE102244"), Color.parseColor("#EE040914"))
        ).apply {
            cornerRadius = dpToPx(14f)
            setStroke(dpToPx(1.5f).toInt().coerceAtLeast(2), Color.parseColor("#00FFA3"))
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bgDrawable
            setPadding(dpToPx(10f).toInt(), dpToPx(6f).toInt(), dpToPx(10f).toInt(), dpToPx(6f).toInt())
        }

        val tvStats = TextView(this).apply {
            text = "⚡ 60 FPS · 16.6ms · 34°C"
            setTextColor(Color.parseColor("#00FFA3"))
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        }
        statsTextView = tvStats

        val btnBoost = buildChipButton("⚡Boost", "#FFC857", "#1A0F00") {
            scope.launch(Dispatchers.IO) {
                bridgeManager.runLocalNativeCleanup()
                if (bridgeManager.refreshDiagnostics().isShellUid2000Ready) {
                    bridgeManager.executePrivilegedShell("pm trim-caches 2048M >/dev/null 2>&1", timeoutSec = 4L)
                }
            }
            tvStats.text = "🚀 RAM BOOSTED (WA/IG AMAN!)"
        }

        val btnAim = buildChipButton("🎯Aim", "#00F2FE", "#02121A") {
            toggleCrosshairOverlay()
        }

        val btnClose = buildChipButton("✕", "#FF3B6B", "#FFFFFF") {
            stop(applicationContext)
        }

        container.addView(tvStats)
        container.addView(btnBoost)
        container.addView(btnAim)
        container.addView(btnClose)

        // Smooth drag gesture support
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).roundToInt()
                    params.y = initialY + (event.rawY - touchY).roundToInt()
                    runCatching { windowManager.updateViewLayout(container, params) }
                    true
                }
                else -> false
            }
        }

        runCatching {
            windowManager.addView(container, params)
            hudRootView = container
            choreographerRunning = true
            Choreographer.getInstance().postFrameCallback(frameCallback)
        }
    }

    private fun buildChipButton(
        label: String,
        bgHex: String,
        fgHex: String,
        onClick: () -> Unit
    ): TextView {
        val chipBg = GradientDrawable().apply {
            setColor(Color.parseColor(bgHex))
            cornerRadius = dpToPx(8f)
        }
        return TextView(this).apply {
            text = label
            setTextColor(Color.parseColor(fgHex))
            typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
            background = chipBg
            setPadding(dpToPx(7f).toInt(), dpToPx(3f).toInt(), dpToPx(7f).toInt(), dpToPx(3f).toInt())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dpToPx(6f).toInt()
            }
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun toggleCrosshairOverlay() {
        if (crosshairActive) {
            crosshairView?.let { v -> runCatching { windowManager.removeView(v) } }
            crosshairView = null
            crosshairActive = false
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val reticle = TextView(this).apply {
            text = "✛"
            setTextColor(Color.parseColor("#00FFA3"))
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        }

        runCatching {
            windowManager.addView(reticle, params)
            crosshairView = reticle
            crosshairActive = true
        }
    }

    private fun startLiveTelemetryTicker() {
        scope.launch {
            while (isActive) {
                val batt = runCatching {
                    HardwareDetector.inspectBatteryHealth(applicationContext, OemBrand.OTHER)
                }.getOrNull()
                val tempStr = "${batt?.temperatureC ?: 34.0}°C"
                val wattStr = "${batt?.realTimeWattageW ?: 0.0}W"
                statsTextView?.text = "⚡ ${currentFps}FPS · ${currentFrameMs}ms · $tempStr · $wattStr"
                delay(1_200L)
            }
        }
    }

    private fun removeOverlays() {
        choreographerRunning = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        hudRootView?.let { v -> runCatching { windowManager.removeView(v) } }
        hudRootView = null
        crosshairView?.let { v -> runCatching { windowManager.removeView(v) } }
        crosshairView = null
        crosshairActive = false
    }

    private fun dpToPx(dp: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AETHERIA Floating Gaming HUD",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AETHERIA 3D Floating Gaming HUD Aktif")
            .setContentText("Menampilkan FPS, Frame-Time, Suhu, Quick Boost & Crosshair")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        removeOverlays()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
