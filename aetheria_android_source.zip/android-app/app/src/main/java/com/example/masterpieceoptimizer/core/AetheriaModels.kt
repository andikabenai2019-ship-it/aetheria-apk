package com.example.masterpieceoptimizer.core

import com.example.masterpieceoptimizer.hardware.DeviceSpecs

/**
 * AETHERIA CORE DATA MODELS & VALIDATORS (v31.0 OMNI MASTER PRO EDITION)
 * Architect: Rangga Winata (kerambir14@ · QRIS NMID: ID1026619104999 · A01)
 */
object AetheriaIdentity {
    const val APP_NAME = "AETHERIA // RW-14 QUANTUM OS"
    const val VERSION = "31.1.0-SAFE-DISPLAY-PRO"
    const val VERSION_CODE = 311
    const val ARCHITECT = "Rangga Winata"
    const val LAUNCHER_CODE = "kerambir14@"
    const val QRIS_MERCHANT = "RANGGA WINATA"
    const val QRIS_NMID = "ID1026619104999"
    const val QRIS_TID = "A01"
    const val QRIS_PRINTED_BY = "93600914"
    const val WA_CHANNEL_URL = "https://whatsapp.com/channel/0029Vb9AvLD8V0tsVOnjuU2n"
    const val GITHUB_REPO = "andikabenai2019-ship-it/aetheria-apk"
    const val GITHUB_RELEASES_URL = "https://github.com/andikabenai2019-ship-it/aetheria-apk/releases"
    const val GITHUB_ACTIONS_URL = "https://github.com/andikabenai2019-ship-it/aetheria-apk/actions"
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val BREVENT_PACKAGE = "me.piebridge.brevent"
    const val LADB_PACKAGE = "com.draco.ladb"
    const val QUTE_PACKAGE = "com.ddm.qute"
    const val TERMUX_PACKAGE = "com.termux"
    const val BUGJAEGER_PACKAGE = "eu.sisik.hackendebug"
    const val REMOTE_ADB_PACKAGE = "com.cgutman.androidremotedebugger"
    const val AXMANAGER_PACKAGE = "frb.axeron.manager"
    const val DHIZUKU_PACKAGE = "com.rosan.dhizuku"
    const val MAGISK_PACKAGE = "com.topjohnwu.magisk"
    const val KERNELSU_PACKAGE = "me.weishu.kernelsu"
    const val APATCH_PACKAGE = "me.bmax.apatch"

    val ALL_PUBG_PACKAGES = listOf(
        "com.tencent.ig",
        "com.pubg.imobile",
        "com.pubg.krmobile",
        "com.vng.pubgmobile"
    )

    val HD_MEDIA_STORY_PACKAGES = listOf(
        "com.whatsapp" to "WhatsApp Status & HD Media",
        "com.whatsapp.w4b" to "WhatsApp Business HD",
        "com.instagram.android" to "Instagram Story & Reels HD",
        "com.zhiliaoapp.musically" to "TikTok Global 1080p/60FPS",
        "com.ss.android.ugc.trill" to "TikTok Asia 1080p/60FPS",
        "org.telegram.messenger" to "Telegram Ultra Upload/Download",
        "com.facebook.katana" to "Facebook Story & Video HD",
        "com.google.android.youtube" to "YouTube Shorts & 4K Stream"
    )

    /**
     * IMMORTAL PROTECTED PACKAGES:
     * WhatsApp, WhatsApp Business, and Instagram must NEVER be disabled, frozen,
     * background-killed, or firewall-blocked under any mode.
     */
    val IMMORTAL_PROTECTED_PACKAGES = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.instagram.android"
    )

    val DEFAULT_WHITELIST_OPTIONS = listOf(
        "com.whatsapp" to "WhatsApp (Wajib Aktif / Immortal)",
        "com.whatsapp.w4b" to "WA Business (Wajib Aktif / Immortal)",
        "com.instagram.android" to "Instagram (Wajib Aktif / Immortal)",
        "com.discord" to "Discord (Voice Mabar)",
        "org.telegram.messenger" to "Telegram",
        "com.spotify.music" to "Spotify Music"
    )

    val KNOWN_POPULAR_GAMES = listOf(
        "com.mobile.legends" to "Mobile Legends: Bang Bang",
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX",
        "com.tencent.ig" to "PUBG Mobile Global",
        "com.pubg.krmobile" to "PUBG Mobile KR",
        "com.vng.pubgmobile" to "PUBG Mobile VN",
        "com.miHoYo.GenshinImpact" to "Genshin Impact",
        "com.HoYoverse.hkrpgoversea" to "Honkai: Star Rail",
        "com.HoYoverse.Nap" to "Zenless Zone Zero",
        "com.levelinfinite.sgameGlobal" to "Honor of Kings (HOK)",
        "com.garena.game.codm" to "Call of Duty: Mobile",
        "com.activision.callofduty.warzone" to "Call of Duty: Warzone",
        "com.roblox.client" to "Roblox",
        "jp.konami.pesam" to "eFootball™",
        "com.ea.gp.fifamobile" to "EA SPORTS FC™ Mobile",
        "com.proximabeta.mf.uamo" to "Arena Breakout",
        "com.kitkagames.fallbuddies" to "Stumble Guys",
        "com.mojang.minecraftpe" to "Minecraft",
        "com.supercell.clashofclans" to "Clash of Clans",
        "com.supercell.brawlstars" to "Brawl Stars",
        "com.kurogame.wutheringwaves.global" to "Wuthering Waves",
        "com.carxtech.sr" to "CarX Street",
        "com.maleo.bussimulatorid" to "Bus Simulator Indonesia (BUSSID)"
    )

    val DAILY_SOCIAL_PACKAGES = listOf(
        "com.zhiliaoapp.musically" to "TikTok Global",
        "com.ss.android.ugc.trill" to "TikTok Asia",
        "com.instagram.android" to "Instagram & Reels",
        "com.whatsapp" to "WhatsApp Messenger",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "com.google.android.youtube" to "YouTube",
        "com.shopee.id" to "Shopee",
        "com.tokopedia.tkpd" to "Tokopedia",
        "com.android.chrome" to "Google Chrome"
    )

    val OEM_AD_BLOAT_PACKAGES = listOf(
        "com.miui.msa.global",
        "com.miui.analytics",
        "com.xiaomi.mipicks",
        "com.transsion.aha",
        "com.transsion.ahagames",
        "com.palm.store",
        "com.transsion.plat.appupdate",
        "com.heytap.habit.analysis",
        "com.heytap.market",
        "com.glance.internet",
        "com.vivo.magazine",
        "com.vivo.appfilter",
        "com.samsung.android.rubin.app",
        "com.aura.oobe.samsung"
    )

    val KNOWN_AD_SDK_ACTIVITIES = listOf(
        "com.google.android.gms.ads.AdActivity",
        "com.unity3d.services.ads.adunit.AdUnitActivity",
        "com.unity3d.ads.adunit.AdUnitActivity",
        "com.facebook.ads.AudienceNetworkActivity",
        "com.applovin.adview.AppLovinFullscreenActivity",
        "com.ironsource.sdk.controller.ControllerActivity",
        "com.vungle.warren.ui.VungleActivity",
        "com.bytedance.sdk.openadsdk.activity.TTFullScreenVideoActivity"
    )

    val GAME_PING_TARGETS = listOf(
        Triple("MLBB / Moonton SG", "1.1.1.1", 443),
        Triple("PUBG / Honor of Kings", "119.29.29.29", 80),
        Triple("Free Fire / Garena", "8.8.8.8", 443),
        Triple("Roblox / Genshin Cloud", "1.0.0.1", 443),
        Triple("Google Gaming Edge", "8.8.4.4", 443)
    )

    val SCAM_APK_KEYWORDS = listOf(
        "undangan", "nikah", "kurir", "jne", "j&t", "jnt", "sicepat",
        "paket", "resi", "tilang", "etle", "polisi", "pajak", "djp",
        "bpjs", "dana_kaget", "slot", "gacor", "zeus", "pragmatic", "judol"
    )
}

enum class ActiveProfileMode(val title: String) {
    NONE("Standar"),
    DAILY_SMOOTH("Mode Harian (Daily Smooth)"),
    GAMING_MAX("Mode Gaming Maksimal (Max Performance)"),
    BATTERY_SAVER("Mode Hemat Ekstrem (Battery Saver)")
}

enum class ShellBridgeMode(val badgeLabel: String) {
    SHIZUKU_UID2000("🟢 JALUR 1: SHIZUKU AKTIF (UID 2000)"),
    BREVENT_UID2000("🟣 JALUR 2-4: BREVENT / LADB / OTG / AXMANAGER (UID 2000)"),
    ROOT_SU_UID0("🔴 JALUR 5: ROOT / KERNELSU / MAGISK (UID 0)"),
    WRITE_SECURE_DIRECT("🔵 JALUR 6A: IZIN SISTEM PERMANEN (TANPA APK LUAR)"),
    WRITE_SYSTEM_DIRECT("🩵 JALUR 6B: IZIN WRITE_SETTINGS LANGSUNG HP"),
    LOCAL_MANDIRI("⚡ MODE MANDIRI (OFFLINE / ONLINE)")
}

enum class StackableModeCategory(val title: String) {
    PERFORMANCE("🔥 KELOMPOK PERFORMA & TURNAMEN"),
    BATTERY_COOL("❄️🔋 KELOMPOK HEMAT BATERAI, PENDINGIN & CHARGING")
}

enum class StackableMode(
    val key: String,
    val title: String,
    val subtitle: String,
    val category: StackableModeCategory
) {
    ESPORTS_PRO(
        key = "stack_esports_pro",
        title = "🏆 E-Sports Ultimate Pro",
        subtitle = "Vulkan SkiaVK + Kontrol 150ms + Penstabil Bingkai + Dual-Net.",
        category = StackableModeCategory.PERFORMANCE
    ),
    QUAD_COMBO(
        key = "stack_quad_combo",
        title = "🔥 Quad-Combo Master Sync",
        subtitle = "Gabung sistem AETHERIA + Phone Master + XArena/Game Boost + Bridge.",
        category = StackableModeCategory.PERFORMANCE
    ),
    GAMING_120HZ(
        key = "stack_gaming_120hz",
        title = "🚀 Hyper Gaming 120Hz",
        subtitle = "Kunci Peak Refresh Rate 120Hz + Power HAL Max + Zero-Blur 0.25x.",
        category = StackableModeCategory.PERFORMANCE
    ),
    PRO_AIM_TOUCH(
        key = "stack_pro_aim",
        title = "🎯 Ultra Touch & Aim Precision",
        subtitle = "Polling Sentuh 240Hz + Pointer Speed + Anti-Mistouch Tepi.",
        category = StackableModeCategory.PERFORMANCE
    ),
    SMART_COOL(
        key = "stack_smart_cool",
        title = "❄️ Tenang / Smart Cool-Boost",
        subtitle = "Turunkan panas mesin (>40°C -> Adem) + Thermal Guard (WA/IG aman).",
        category = StackableModeCategory.BATTERY_COOL
    ),
    BATTERY_SAVER(
        key = "stack_battery_saver",
        title = "🔋 Ultra Battery Saver & Deep Doze",
        subtitle = "Hemat baterai ekstrem, Deep Doze latar, BLE/Haptic OFF (WA/IG hidup).",
        category = StackableModeCategory.BATTERY_COOL
    ),
    TURBO_CHARGE(
        key = "stack_turbo_charge",
        title = "⚡ Turbo Fast Charging Pro",
        subtitle = "Percepat pengisian baterai & tekan panas saat HP sedang di-cas.",
        category = StackableModeCategory.BATTERY_COOL
    ),
    DAILY_SMOOTH(
        key = "stack_daily_smooth",
        title = "🌿 Daily Smooth Kuota-Safe",
        subtitle = "Responsif harian, anti-reload aplikasi, internet kuota 4G/5G lancar.",
        category = StackableModeCategory.BATTERY_COOL
    )
}

enum class FpsUnlockPreset(val fps: Int, val label: String) {
    FPS_60(60, "60 FPS Stabil"),
    FPS_90(90, "90 FPS Extreme+"),
    FPS_120(120, "120 FPS Ultra"),
    FPS_144(144, "144 FPS Max Panel")
}

enum class GfxRenderQuality(val downscaleRatio: Float, val label: String) {
    SMOOTH_075(0.75f, "Smooth FPS (0.75x)"),
    BALANCED_085(0.85f, "Balanced HD (0.85x)"),
    HD_NATIVE_100(1.00f, "HD Native (1.0x)"),
    ULTRA_HDR_SKIAVK(1.00f, "HDR Crisp + SkiaVK")
}

data class DiscoveredApkFile(
    val fileName: String,
    val fullPath: String,
    val folderLabel: String,
    val sizeMb: Double,
    val appLabel: String,
    val packageName: String,
    val versionName: String,
    val lastModifiedMs: Long
)

data class PingServerResult(
    val serverName: String,
    val host: String,
    val latencyMs: Int,
    val statusBadge: String
)

data class DetectedGameApp(
    val packageName: String,
    val appName: String,
    val isInstalled: Boolean,
    val categoryLabel: String
)

data class OemGameBoosterInfo(
    val boosterName: String,
    val brandFamily: String,
    val detectedPackage: String?,
    val isDetectedOnDevice: Boolean,
    val syncDescription: String,
    val oemSettingsSpecs: List<SettingSpec>
)

data class OemPhoneMasterInfo(
    val managerName: String,
    val brandFamily: String,
    val detectedPackage: String?,
    val isDetectedOnDevice: Boolean,
    val syncDescription: String
)

data class UpdateCheckResult(
    val hasNewerRelease: Boolean,
    val currentVersion: String,
    val latestVersion: String,
    val statusMessage: String,
    val downloadUrl: String
)

object DeviceTierAdvisor {
    fun classifyTier(ramTotalMb: Long, cpuCores: Int): Pair<String, String> {
        val ramGb = ramTotalMb / 1024.0
        return when {
            ramGb <= 4.5 || cpuCores <= 4 -> Pair(
                "TIER 1: ENTRY / HP KENTANG RESCUE",
                "Rekomendasi: Aktifkan Smart Cool-Boost + Mode Game Ultra Potato 0.75x + Virtual RAM eMMC OFF."
            )
            ramGb <= 8.5 -> Pair(
                "TIER 2: MID-RANGE / DAILY & E-SPORTS",
                "Rekomendasi: Aktifkan Quad-Combo + Phantom Process Killer OFF (WA/IG Anti-Reload) + Downscale 0.85x."
            )
            else -> Pair(
                "TIER 3: FLAGSHIP / ULTRA PERFORMANCE",
                "Rekomendasi: Aktifkan Quad-Combo + Native 1.00x + Layar 120Hz/144Hz + LDAC Hi-Res Audio."
            )
        }
    }
}

enum class CapabilityTier(val label: String) {
    NATIVE("NATIVE"),
    SHIZUKU_REQUIRED("SHIZUKU / BREVENT"),
    UNSUPPORTED("UNSUPPORTED")
}

sealed class ShizukuConnectionState(val code: String, val displayTitle: String) {
    object NotInstalled : ShizukuConnectionState(
        "SHIZUKU_NOT_INSTALLED",
        "Shizuku Belum Terpasang (Bisa Pakai Jalur Brevent!)"
    )
    object ServiceNotRunning : ShizukuConnectionState(
        "SERVICE_NOT_RUNNING",
        "Layanan Shizuku Belum Berjalan"
    )
    object PermissionRequired : ShizukuConnectionState(
        "PERMISSION_REQUIRED",
        "Izin AETHERIA Belum Diberikan"
    )
    data class PermissionDenied(val shouldShowRationale: Boolean) : ShizukuConnectionState(
        "PERMISSION_DENIED",
        "Izin Shizuku Ditolak"
    )
    data class Ready(val uid: Int, val serviceVersion: Int, val isRoot: Boolean) : ShizukuConnectionState(
        "READY",
        "Shizuku Terhubung Penuh (uid=$uid · v$serviceVersion)"
    )
}

data class ShizukuDiagnostics(
    val state: ShizukuConnectionState,
    val shizukuAppInstalled: Boolean,
    val binderAlive: Boolean,
    val permissionGranted: Boolean,
    val uid: Int?,
    val serviceVersion: Int?,
    val lastCheckedTime: String,
    val diagnosticMessage: String,
    val recoverySteps: List<String>,
    val reconnectAttempts: Int = 0,
    val breventAppInstalled: Boolean = false,
    val breventBridgeActive: Boolean = false,
    val writeSecureSettingsGranted: Boolean = false,
    val activeBridgeMode: ShellBridgeMode = ShellBridgeMode.LOCAL_MANDIRI,
    val breventActivationCommand: String = "",
    val ladbAppInstalled: Boolean = false,
    val bugjaegerOtgInstalled: Boolean = false,
    val axManagerInstalled: Boolean = false,
    val rootSuAvailable: Boolean = false,
    val writeSystemSettingsGranted: Boolean = false,
    val universalAdbGrantCommand: String = ""
) {
    val isShizukuReady: Boolean get() = state is ShizukuConnectionState.Ready
    val isShellUid2000Ready: Boolean get() = isShizukuReady || breventBridgeActive || rootSuAvailable
    val isReady: Boolean get() = isShellUid2000Ready || writeSecureSettingsGranted || writeSystemSettingsGranted
}

data class FeatureCapability(
    val id: String,
    val title: String,
    val tier: CapabilityTier,
    val available: Boolean,
    val reason: String
)

data class VerificationRecord(
    val feature: String,
    val parameter: String,
    val beforeValue: String,
    val targetValue: String,
    val actualValue: String,
    val exitCode: Int,
    val verified: Boolean,
    val badge: String,
    val detail: String
)

data class SettingSpec(
    val namespace: String,
    val key: String,
    val targetValue: String,
    val label: String,
    val detail: String
)

enum class SystemProfile(
    val id: String,
    val title: String,
    val subtitle: String,
    val specs: List<SettingSpec>
) {
    BALANCED(
        id = "Balanced",
        title = "Balanced (Seimbang Standar Pabrik)",
        subtitle = "Refresh rate adaptif 60–120Hz, skala animasi 1.0x standar, touch 400ms.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "60.0", "Min Refresh Rate Adaptif", "60Hz bawah"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate Adaptif", "120Hz atas"),
            SettingSpec("global", "window_animation_scale", "1.0", "Skala Animasi Jendela", "1.0x standar"),
            SettingSpec("global", "transition_animation_scale", "1.0", "Skala Transisi Jendela", "1.0x standar"),
            SettingSpec("global", "animator_duration_scale", "1.0", "Durasi Animator", "1.0x standar"),
            SettingSpec("global", "disable_window_blurs", "0", "Efek Blur Standar", "Aktif"),
            SettingSpec("secure", "long_press_timeout", "400", "Touch Long-Press Timeout", "400ms standar")
        )
    ),
    GAMING(
        id = "Gaming",
        title = "Gaming (Responsivitas & Anti-Stutter)",
        subtitle = "Target 120Hz min/peak, GPU Zero-Blur ON, skala animasi 0.5x, touch 180ms.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "120.0", "Target Min Refresh Rate 120Hz", "Menahan layar di 120Hz"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Target Peak Refresh Rate 120Hz", "Batas atas 120Hz"),
            SettingSpec("global", "disable_window_blurs", "1", "GPU Zero-Blur Compositor", "Meringankan beban render GPU"),
            SettingSpec("global", "window_animation_scale", "0.5", "Skala Animasi 0.5x", "Transisi cepat"),
            SettingSpec("secure", "long_press_timeout", "180", "Touch Timeout 180ms", "Respons sentuh cepat"),
            SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Reduksi Wi-Fi Scan Lag", "Menjaga kestabilan ping")
        )
    ),
    ESPORT_ULTIMATE_PRO(
        id = "E-Sports Ultimate Pro",
        title = "🏆 E-Sports Ultimate Pro (Turnamen & Kompetitif)",
        subtitle = "Vulkan SkiaVK + Kontrol 150ms + Penstabilan Bingkai + Akselerasi Jaringan Ganda.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "120.0", "Kunci Frame Rate 120Hz", "Penstabilan bingkai turnamen"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Frame Rate 120Hz", "Cegah drop Hz saat teamfight"),
            SettingSpec("global", "disable_window_blurs", "1", "GPU Zero-Blur Compositor", "100% fokus render grafis game"),
            SettingSpec("global", "window_animation_scale", "0.25", "Animasi Instan 0.25x", "Respons sistem ultra-cepat"),
            SettingSpec("global", "transition_animation_scale", "0.25", "Transisi Instan 0.25x", "Perpindahan frame instan"),
            SettingSpec("secure", "long_press_timeout", "150", "Kontrol Sentuh Pro 150ms", "Input matriks ultra-presisi"),
            SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Akselerasi Jaringan Game", "Matikan scan Wi-Fi pemicu lonjakan ping"),
            SettingSpec("global", "mobile_data_always_on", "1", "Akselerasi Saluran Ganda", "Siaga Wi-Fi + Data Seluler simultan")
        )
    ),
    SMART_COOL_BOOST(
        id = "Smart Cool-Boost",
        title = "⚖️ Smart Cool-Boost (Boost CPU + GPU + Pendingin Seimbang)",
        subtitle = "Boost performa CPU & GPU sambil mengaktifkan pendingin otomatis (WA & IG tetap dilindungi!).",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "90.0", "Refresh Rate Stabil 90Hz/120Hz", "Halus tanpa membakar daya"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate 120Hz", "Responsif saat dibutuhkan"),
            SettingSpec("global", "disable_window_blurs", "1", "Boost GPU (Bebas Beban Blur)", "Turunkan suhu GPU 3–5°C"),
            SettingSpec("global", "window_animation_scale", "0.5", "Boost CPU & UI 0.5x", "Kerja CPU lebih ringan"),
            SettingSpec("global", "cached_apps_freezer", "enabled", "Pendingin Otomatis (Freeze Latar)", "Bekukan aplikasi pemanas mesin"),
            SettingSpec("global", "ble_scan_always_enabled", "0", "Pendingin Radio Latar", "Matikan pemindaian BLE pasif"),
            SettingSpec("secure", "long_press_timeout", "180", "Kontrol Responsif 180ms", "Sentuhan tetap gesit")
        )
    ),
    BATTERY_SAVER(
        id = "Battery Saver",
        title = "Battery Saver (Penghemat Daya & Deep Doze)",
        subtitle = "Kunci 60Hz hemat daya, GPU Zero-Blur ON, getar Haptic OFF, BLE scan OFF.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "60.0", "Kunci Min Refresh Rate 60Hz", "Hemat daya layar"),
            SettingSpec("system", "peak_refresh_rate", "60.0", "Batas Peak Refresh Rate 60Hz", "Mencegah lonjakan daya 120Hz"),
            SettingSpec("global", "disable_window_blurs", "1", "Matikan Blur GPU", "Mengurangi beban GPU"),
            SettingSpec("system", "haptic_feedback_enabled", "0", "Matikan Getar Haptic", "Hemat daya aktuator"),
            SettingSpec("global", "ble_scan_always_enabled", "0", "Matikan BLE Scan Latar", "Hemat radio Bluetooth")
        )
    ),
    POTATO_RESCUE(
        id = "Potato Rescue",
        title = "Ultra Potato Rescue (Penyelamat HP Kentang RAM <= 4GB)",
        subtitle = "Animasi 0.0x instan, GPU Zero-Blur ON, Virtual RAM eMMC OFF, touch 180ms.",
        specs = listOf(
            SettingSpec("global", "disable_window_blurs", "1", "Matikan Blur GPU 100%", "Bebaskan memori VRAM"),
            SettingSpec("global", "window_animation_scale", "0.0", "Animasi Jendela 0.0x", "Buka aplikasi instan"),
            SettingSpec("global", "transition_animation_scale", "0.0", "Animasi Transisi 0.0x", "Tanpa jeda transisi"),
            SettingSpec("global", "animator_duration_scale", "0.0", "Durasi Animator 0.0x", "Respons instan"),
            SettingSpec("secure", "long_press_timeout", "180", "Touch Timeout 180ms", "Sentuhan responsif"),
            SettingSpec("global", "cached_apps_freezer", "enabled", "Cached Apps Freezer", "Bekukan aplikasi pasif")
        )
    ),
    TRIPLE_COMBO(
        id = "Quad-Combo Pro",
        title = "🔥 Quad-Combo (AETHERIA + Game Boost HP + Phone Master HP + Shizuku/Brevent)",
        subtitle = "Sinkronisasi 4 mesin sekaligus: XArena/Game Boost + Phone Master Bawaan Semua HP + AETHERIA + Shizuku/Brevent.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "120.0", "Quad-Combo Lock 120Hz", "Sinkron layar 120Hz"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Quad-Combo Peak 120Hz", "Tahan FPS puncak"),
            SettingSpec("system", "tran_game_mode", "1", "XArena / Dar-Link Game Mode", "Aktifkan XArena Game Engine"),
            SettingSpec("system", "tran_refresh_mode", "120", "XArena 120Hz Display Lock", "Sinkron layar XOS/HiOS 120Hz"),
            SettingSpec("global", "disable_window_blurs", "1", "GPU Zero-Blur Compositor", "Bebaskan 100% pipeline GPU"),
            SettingSpec("global", "window_animation_scale", "0.35", "Snappy UI 0.35x", "Respon sistem instan & mulus"),
            SettingSpec("secure", "long_press_timeout", "140", "Kontrol Sentuh Pro 140ms", "Input matriks ultra-responsif"),
            SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Akselerasi Jaringan Game", "Matikan scan Wi-Fi pemicu lag"),
            SettingSpec("global", "mobile_data_always_on", "1", "Akselerasi Saluran Ganda", "Siaga Wi-Fi + Data Seluler simultan")
        )
    )
}

data class DeviceTelemetry(
    val brand: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val socHardware: String,
    val cpuCores: Int,
    val cpuCurrentMhz: Int?,
    val ramTotalMb: Long,
    val ramAvailMb: Long,
    val ramUsedPercent: Int,
    val storageTotalGb: Double,
    val storageFreeGb: Double,
    val storageUsedPercent: Int,
    val batteryPercent: Int,
    val batteryTempC: Double,
    val batteryVoltageMv: Int,
    val isCharging: Boolean,
    val currentRefreshRateHz: Float,
    val supportedRefreshRatesHz: List<Int>,
    val sensorNames: List<String>,
    val termuxEngineConnected: Boolean,
    val detectedGames: List<DetectedGameApp> = emptyList(),
    val oemGameBooster: OemGameBoosterInfo? = null,
    val oemPhoneMaster: OemPhoneMasterInfo? = null,
    val hardwareSpecs: DeviceSpecs? = null,
    val communityActiveUsers: Int = 1,
    val communityTotalDownloads: Int = 0,
    val localOptimizationCount: Int = 1,
    val isInternetOnline: Boolean = true,
    val networkTransportLabel: String = "ONLINE / OFFLINE HYBRID",
    val privateDnsModeCurrent: String = "opportunistic"
)

/**
 * Pure validator functions (unit-testable without Android framework mocks).
 */
object CommandValidator {
    private val PACKAGE_REGEX = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
    private val KEY_REGEX = Regex("^[a-zA-Z0-9_.\\-]+$")
    private val VAL_REGEX = Regex("^[a-zA-Z0-9_.\\-,=:]+$")
    private val ALLOWED_NAMESPACES = setOf("system", "secure", "global")

    fun isValidPackageName(pkg: String?): Boolean {
        if (pkg.isNullOrBlank() || pkg.length > 128) return false
        return PACKAGE_REGEX.matches(pkg.trim())
    }

    fun isValidSettingSpec(ns: String?, key: String?, value: String?): Boolean {
        if (ns == null || key == null || value == null) return false
        return ns.trim() in ALLOWED_NAMESPACES &&
            key.trim().length in 1..96 &&
            KEY_REGEX.matches(key.trim()) &&
            value.trim().length in 1..96 &&
            VAL_REGEX.matches(value.trim())
    }

    fun isValuesEquivalent(target: String, actual: String): Boolean {
        val t = target.trim()
        val a = actual.trim()
        if (t == a) return true
        val tFloat = t.toDoubleOrNull()
        val aFloat = a.toDoubleOrNull()
        if (tFloat != null && aFloat != null) {
            return kotlin.math.abs(tFloat - aFloat) < 0.05
        }
        return false
    }
}
