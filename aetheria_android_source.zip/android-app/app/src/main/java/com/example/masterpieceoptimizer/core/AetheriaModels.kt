package com.example.masterpieceoptimizer.core

/**
 * AETHERIA CORE DATA MODELS & VALIDATORS (v28.5 3D HD SOVEREIGN EDITION)
 * Architect: Rangga Winata (kerambir14@ · QRIS NMID: ID1026619104999 · A01)
 */
object AetheriaIdentity {
    const val APP_NAME = "AETHERIA // RW-14 QUANTUM OS"
    const val VERSION = "29.5.0-HYBRID-OFFLINE-ONLINE"
    const val VERSION_CODE = 295
    const val ARCHITECT = "Rangga Winata"
    const val LAUNCHER_CODE = "kerambir14@"
    const val QRIS_MERCHANT = "RANGGA WINATA"
    const val QRIS_NMID = "ID1026619104999"
    const val QRIS_TID = "A01"
    const val QRIS_PRINTED_BY = "93600914"
    const val WA_CHANNEL_URL = "https://whatsapp.com/channel/0029Vb9AvLD8V0tsVOnjuU2n"
    const val GITHUB_REPO = "andikabenai2019-ship-it/aetheria-apk"
    const val GITHUB_RELEASES_URL = "https://github.com/andikabenai2019-ship-it/aetheria-apk/releases"
    const val GITHUB_ACTIONS_URL = "https://github.com/andikabenai2019-ship-it/aetheria-apk/actions"
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val TERMUX_PACKAGE = "com.termux"

    val KNOWN_POPULAR_GAMES = listOf(
        "com.mobile.legends" to "Mobile Legends: Bang Bang",
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX",
        "com.tencent.ig" to "PUBG Mobile Global",
        "com.pubg.krmobile" to "PUBG Mobile KR",
        "com.vng.pubgmobile" to "PUBG Mobile VN",
        "com.miHoYo.GenshinImpact" to "Genshin Impact",
        "com.HoYoverse.hkrpgoversea" to "Honkai: Star Rail",
        "com.HoYoverse.Nap" to "Zenless Zone Zero",
        "com.levelinfinite.sgameGlobal" to "Honor of Kings (HOK)",
        "com.garena.game.codm" to "Call of Duty: Mobile",
        "com.activision.callofduty.warzone" to "Call of Duty: Warzone",
        "com.roblox.client" to "Roblox",
        "jp.konami.pesam" to "eFootball™",
        "com.ea.gp.fifamobile" to "EA SPORTS FC™ Mobile",
        "com.proximabeta.mf.uamo" to "Arena Breakout",
        "com.kitkagames.fallbuddies" to "Stumble Guys",
        "com.mojang.minecraftpe" to "Minecraft",
        "com.supercell.clashofclans" to "Clash of Clans",
        "com.supercell.brawlstars" to "Brawl Stars",
        "com.kurogame.wutheringwaves.global" to "Wuthering Waves",
        "com.carxtech.sr" to "CarX Street",
        "com.maleo.bussimulatorid" to "Bus Simulator Indonesia (BUSSID)"
    )

    val DAILY_SOCIAL_PACKAGES = listOf(
        "com.zhiliaoapp.musically" to "TikTok Global",
        "com.ss.android.ugc.trill" to "TikTok Asia",
        "com.instagram.android" to "Instagram & Reels",
        "com.whatsapp" to "WhatsApp Messenger",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "com.google.android.youtube" to "YouTube",
        "com.shopee.id" to "Shopee",
        "com.tokopedia.tkpd" to "Tokopedia",
        "com.android.chrome" to "Google Chrome"
    )

    val OEM_AD_BLOAT_PACKAGES = listOf(
        "com.miui.msa.global",
        "com.miui.analytics",
        "com.xiaomi.mipicks",
        "com.transsion.aha",
        "com.palm.store",
        "com.transsion.plat.appupdate",
        "com.heytap.habit.analysis",
        "com.heytap.market",
        "com.coloros.gamespaceui",
        "com.vivo.magazine",
        "com.vivo.appfilter",
        "com.samsung.android.rubin.app",
        "com.samsung.android.game.gamehome"
    )

    val SCAM_APK_KEYWORDS = listOf(
        "undangan", "nikah", "kurir", "jne", "j&t", "jnt", "sicepat",
        "paket", "resi", "tilang", "etle", "polisi", "pajak", "djp",
        "bpjs", "dana_kaget", "slot", "gacor", "zeus", "pragmatic", "judol"
    )
}

data class DetectedGameApp(
    val packageName: String,
    val appName: String,
    val isInstalled: Boolean,
    val categoryLabel: String
)

data class OemGameBoosterInfo(
    val boosterName: String,
    val brandFamily: String,
    val detectedPackage: String?,
    val isDetectedOnDevice: Boolean,
    val syncDescription: String,
    val oemSettingsSpecs: List<SettingSpec>
)

data class UpdateCheckResult(
    val hasNewerRelease: Boolean,
    val currentVersion: String,
    val latestVersion: String,
    val statusMessage: String,
    val downloadUrl: String
)

object DeviceTierAdvisor {
    fun classifyTier(ramTotalMb: Long, cpuCores: Int): Pair<String, String> {
        val ramGb = ramTotalMb / 1024.0
        return when {
            ramGb <= 4.5 || cpuCores <= 4 -> Pair(
                "TIER 1: ENTRY / HP KENTANG RESCUE",
                "Rekomendasi: Aktifkan Smart Cool-Boost + Mode Game Ultra Potato 0.75x + Animasi 0.0x."
            )
            ramGb <= 8.5 -> Pair(
                "TIER 2: MID-RANGE / DAILY & E-SPORTS",
                "Rekomendasi: Gunakan E-Sports Ultimate Pro + Smart Cool-Boost (CPU/GPU + Pendingin Otomatis 0.85x)."
            )
            else -> Pair(
                "TIER 3: FLAGSHIP / ULTRA PERFORMANCE",
                "Rekomendasi: Gunakan E-Sports Ultimate Pro + Grafis Anisotropik & Mipmap LOD + Layar 120Hz."
            )
        }
    }
}

enum class CapabilityTier(val label: String) {
    NATIVE("NATIVE"),
    SHIZUKU_REQUIRED("SHIZUKU REQUIRED"),
    UNSUPPORTED("UNSUPPORTED")
}

sealed class ShizukuConnectionState(val code: String, val displayTitle: String) {
    object NotInstalled : ShizukuConnectionState(
        "SHIZUKU_NOT_INSTALLED",
        "Aplikasi Shizuku Belum Terpasang"
    )
    object ServiceNotRunning : ShizukuConnectionState(
        "SERVICE_NOT_RUNNING",
        "Layanan Shizuku Belum Berjalan"
    )
    object PermissionRequired : ShizukuConnectionState(
        "PERMISSION_REQUIRED",
        "Izin AETHERIA Belum Diberikan"
    )
    data class PermissionDenied(val shouldShowRationale: Boolean) : ShizukuConnectionState(
        "PERMISSION_DENIED",
        "Izin Shizuku Ditolak"
    )
    data class Ready(val uid: Int, val serviceVersion: Int, val isRoot: Boolean) : ShizukuConnectionState(
        "READY",
        "Terhubung Penuh (uid=$uid · v$serviceVersion)"
    )
}

data class ShizukuDiagnostics(
    val state: ShizukuConnectionState,
    val shizukuAppInstalled: Boolean,
    val binderAlive: Boolean,
    val permissionGranted: Boolean,
    val uid: Int?,
    val serviceVersion: Int?,
    val lastCheckedTime: String,
    val diagnosticMessage: String,
    val recoverySteps: List<String>,
    val reconnectAttempts: Int = 0
) {
    val isReady: Boolean get() = state is ShizukuConnectionState.Ready
}

data class FeatureCapability(
    val id: String,
    val title: String,
    val tier: CapabilityTier,
    val available: Boolean,
    val reason: String
)

data class VerificationRecord(
    val feature: String,
    val parameter: String,
    val beforeValue: String,
    val targetValue: String,
    val actualValue: String,
    val exitCode: Int,
    val verified: Boolean,
    val badge: String,
    val detail: String
)

data class SettingSpec(
    val namespace: String,
    val key: String,
    val targetValue: String,
    val label: String,
    val detail: String
)

enum class SystemProfile(
    val id: String,
    val title: String,
    val subtitle: String,
    val specs: List<SettingSpec>
) {
    BALANCED(
        id = "Balanced",
        title = "Balanced (Seimbang Harian)",
        subtitle = "Refresh rate adaptif 60–120Hz, skala animasi 1.0x standar, touch 400ms.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "60.0", "Min Refresh Rate Adaptif", "60Hz bawah"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate Adaptif", "120Hz atas"),
            SettingSpec("global", "window_animation_scale", "1.0", "Skala Animasi Jendela", "1.0x standar"),
            SettingSpec("global", "disable_window_blurs", "0", "Efek Blur Standar", "Aktif"),
            SettingSpec("secure", "long_press_timeout", "400", "Touch Long-Press Timeout", "400ms standar")
        )
    ),
    GAMING(
        id = "Gaming",
        title = "Gaming (Responsivitas & Anti-Stutter)",
        subtitle = "Target 120Hz min/peak, GPU Zero-Blur ON, skala animasi 0.5x, touch 180ms.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "120.0", "Target Min Refresh Rate 120Hz", "Menahan layar di 120Hz"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Target Peak Refresh Rate 120Hz", "Batas atas 120Hz"),
            SettingSpec("global", "disable_window_blurs", "1", "GPU Zero-Blur Compositor", "Meringankan beban render GPU"),
            SettingSpec("global", "window_animation_scale", "0.5", "Skala Animasi 0.5x", "Transisi cepat"),
            SettingSpec("secure", "long_press_timeout", "180", "Touch Timeout 180ms", "Respons sentuh cepat"),
            SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Reduksi Wi-Fi Scan Lag", "Menjaga kestabilan ping")
        )
    ),
    ESPORT_ULTIMATE_PRO(
        id = "E-Sports Ultimate Pro",
        title = "🏆 E-Sports Ultimate Pro (Turnamen & Kompetitif)",
        subtitle = "Kinerja + Kontrol + Penstabilan Bingkai + Akselerasi Jaringan Ganda + Touch 150ms.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "120.0", "Kunci Frame Rate 120Hz", "Penstabilan bingkai turnamen"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Frame Rate 120Hz", "Cegah drop Hz saat teamfight"),
            SettingSpec("global", "disable_window_blurs", "1", "GPU Zero-Blur Compositor", "100% fokus render grafis game"),
            SettingSpec("global", "window_animation_scale", "0.25", "Animasi Instan 0.25x", "Respons sistem ultra-cepat"),
            SettingSpec("global", "transition_animation_scale", "0.25", "Transisi Instan 0.25x", "Perpindahan frame instan"),
            SettingSpec("secure", "long_press_timeout", "150", "Kontrol Sentuh Pro 150ms", "Input matriks ultra-presisi"),
            SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Akselerasi Jaringan Game", "Matikan scan Wi-Fi pemicu lonjakan ping"),
            SettingSpec("global", "mobile_data_always_on", "1", "Akselerasi Saluran Ganda", "Siaga Wi-Fi + Data Seluler simultan")
        )
    ),
    SMART_COOL_BOOST(
        id = "Smart Cool-Boost",
        title = "⚖️ Smart Cool-Boost (Boost CPU + GPU + Pendingin Seimbang)",
        subtitle = "Boost performa CPU & GPU sambil mengaktifkan pendingin otomatis agar suhu tetap adem.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "90.0", "Refresh Rate Stabil 90Hz/120Hz", "Halus tanpa membakar daya"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate 120Hz", "Responsif saat dibutuhkan"),
            SettingSpec("global", "disable_window_blurs", "1", "Boost GPU (Bebas Beban Blur)", "Turunkan suhu GPU 3–5°C"),
            SettingSpec("global", "window_animation_scale", "0.5", "Boost CPU & UI 0.5x", "Kerja CPU lebih ringan"),
            SettingSpec("global", "cached_apps_freezer", "enabled", "Pendingin Otomatis (Freeze Latar)", "Bekukan aplikasi pemanas mesin"),
            SettingSpec("global", "ble_scan_always_enabled", "0", "Pendingin Radio Latar", "Matikan pemindaian BLE pasif"),
            SettingSpec("secure", "long_press_timeout", "180", "Kontrol Responsif 180ms", "Sentuhan tetap gesit")
        )
    ),
    BATTERY_SAVER(
        id = "Battery Saver",
        title = "Battery Saver (Penghemat Daya)",
        subtitle = "Kunci 60Hz hemat daya, GPU Zero-Blur ON, getar Haptic OFF, BLE scan OFF.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "60.0", "Kunci Min Refresh Rate 60Hz", "Hemat daya layar"),
            SettingSpec("system", "peak_refresh_rate", "60.0", "Batas Peak Refresh Rate 60Hz", "Mencegah lonjakan daya 120Hz"),
            SettingSpec("global", "disable_window_blurs", "1", "Matikan Blur GPU", "Mengurangi beban GPU"),
            SettingSpec("system", "haptic_feedback_enabled", "0", "Matikan Getar Haptic", "Hemat daya aktuator"),
            SettingSpec("global", "ble_scan_always_enabled", "0", "Matikan BLE Scan Latar", "Hemat radio Bluetooth")
        )
    ),
    POTATO_RESCUE(
        id = "Potato Rescue",
        title = "Ultra Potato Rescue (Penyelamat HP Kentang RAM <= 4GB)",
        subtitle = "Animasi 0.0x instan, GPU Zero-Blur ON, touch 180ms, cached freezer ON.",
        specs = listOf(
            SettingSpec("global", "disable_window_blurs", "1", "Matikan Blur GPU 100%", "Bebaskan memori VRAM"),
            SettingSpec("global", "window_animation_scale", "0.0", "Animasi Jendela 0.0x", "Buka aplikasi instan"),
            SettingSpec("global", "transition_animation_scale", "0.0", "Animasi Transisi 0.0x", "Tanpa jeda transisi"),
            SettingSpec("global", "animator_duration_scale", "0.0", "Durasi Animator 0.0x", "Respons instan"),
            SettingSpec("secure", "long_press_timeout", "180", "Touch Timeout 180ms", "Sentuhan responsif"),
            SettingSpec("global", "cached_apps_freezer", "enabled", "Cached Apps Freezer", "Bekukan aplikasi pasif")
        )
    ),
    TRIPLE_COMBO(
        id = "Triple-Combo Pro",
        title = "🔥 Triple-Combo (AETHERIA + Game Boost Bawaan HP / XArena + Shizuku)",
        subtitle = "Sinkronisasi 3 mesin sekaligus: Game Space Bawaan HP (XArena/Game Turbo/HyperBoost/Ultra Game) + AETHERIA + Shizuku.",
        specs = listOf(
            SettingSpec("system", "min_refresh_rate", "120.0", "Triple-Combo Lock 120Hz", "Sinkron layar 120Hz"),
            SettingSpec("system", "peak_refresh_rate", "120.0", "Triple-Combo Peak 120Hz", "Tahan FPS puncak"),
            SettingSpec("system", "tran_game_mode", "1", "XArena / Dar-Link Game Mode", "Aktifkan XArena Game Engine"),
            SettingSpec("system", "tran_refresh_mode", "120", "XArena 120Hz Display Lock", "Sinkron layar XOS/HiOS 120Hz"),
            SettingSpec("global", "disable_window_blurs", "1", "GPU Zero-Blur Compositor", "Bebaskan 100% pipeline GPU"),
            SettingSpec("global", "window_animation_scale", "0.25", "Fast UI 0.25x", "Respon sistem instan"),
            SettingSpec("secure", "long_press_timeout", "140", "Kontrol Sentuh Pro 140ms", "Input matriks ultra-responsif"),
            SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Akselerasi Jaringan Game", "Matikan scan Wi-Fi pemicu lag"),
            SettingSpec("global", "mobile_data_always_on", "1", "Akselerasi Saluran Ganda", "Siaga Wi-Fi + Data Seluler simultan")
        )
    )
}

data class DeviceTelemetry(
    val brand: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val socHardware: String,
    val cpuCores: Int,
    val cpuCurrentMhz: Int?,
    val ramTotalMb: Long,
    val ramAvailMb: Long,
    val ramUsedPercent: Int,
    val storageTotalGb: Double,
    val storageFreeGb: Double,
    val storageUsedPercent: Int,
    val batteryPercent: Int,
    val batteryTempC: Double,
    val batteryVoltageMv: Int,
    val isCharging: Boolean,
    val currentRefreshRateHz: Float,
    val supportedRefreshRatesHz: List<Int>,
    val sensorNames: List<String>,
    val termuxEngineConnected: Boolean,
    val detectedGames: List<DetectedGameApp> = emptyList(),
    val oemGameBooster: OemGameBoosterInfo? = null,
    val communityActiveUsers: Int = 1,
    val communityTotalDownloads: Int = 0,
    val localOptimizationCount: Int = 1,
    val isInternetOnline: Boolean = true,
    val networkTransportLabel: String = "ONLINE / OFFLINE HYBRID",
    val privateDnsModeCurrent: String = "opportunistic"
)

/**
 * Pure validator functions (unit-testable without Android framework mocks).
 */
object CommandValidator {
    private val PACKAGE_REGEX = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
    private val KEY_REGEX = Regex("^[a-zA-Z0-9_.\\-]+$")
    private val VAL_REGEX = Regex("^[a-zA-Z0-9_.\\-,=:]+$")
    private val ALLOWED_NAMESPACES = setOf("system", "secure", "global")

    fun isValidPackageName(pkg: String?): Boolean {
        if (pkg.isNullOrBlank() || pkg.length > 128) return false
        return PACKAGE_REGEX.matches(pkg.trim())
    }

    fun isValidSettingSpec(ns: String?, key: String?, value: String?): Boolean {
        if (ns == null || key == null || value == null) return false
        return ns.trim() in ALLOWED_NAMESPACES &&
            key.trim().length in 1..96 &&
            KEY_REGEX.matches(key.trim()) &&
            value.trim().length in 1..96 &&
            VAL_REGEX.matches(value.trim())
    }

    fun isValuesEquivalent(target: String, actual: String): Boolean {
        val t = target.trim()
        val a = actual.trim()
        if (t == a) return true
        val tFloat = t.toDoubleOrNull()
        val aFloat = a.toDoubleOrNull()
        if (tFloat != null && aFloat != null) {
            return kotlin.math.abs(tFloat - aFloat) < 0.05
        }
        return false
    }
}
