package com.example.masterpieceoptimizer.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

// 3D HD Quantum Glassmorphism & Metallic Bevel Palette
val ObsidianBg = Color(0xFF03060E)
val MidnightPanel = Color(0xFF0B152B)
val MidnightPanelBottom = Color(0xFF050A16)
val CardInnerBg = Color(0xFF101F3C)
val CardInnerBottom = Color(0xFF081022)
val SovereignGold = Color(0xFFFFC857)
val IceCyan = Color(0xFF00F2FE)
val QuantumEmerald = Color(0xFF00FFA3)
val CyberViolet = Color(0xFFB56BFF)
val AlertRose = Color(0xFFFF3B6B)
val TextPrimary = Color(0xFFF8FBFF)
val TextSecondary = Color(0xFFA3B8D7)

private val AetheriaDarkScheme = darkColorScheme(
    primary = IceCyan,
    secondary = SovereignGold,
    tertiary = QuantumEmerald,
    background = ObsidianBg,
    surface = MidnightPanel,
    onPrimary = Color(0xFF021019),
    onSecondary = Color(0xFF1A0F00),
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun AetheriaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AetheriaDarkScheme,
        content = content
    )
}

/**
 * 3D HD Holographic Reactor Emblem for AETHERIA // RW-14 by Rangga Winata.
 */
@Composable
fun Rw14QuantumEmblem(size: Dp = 74.dp) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val rOuter = this.size.minDimension * 0.47f
            val rMid = this.size.minDimension * 0.37f
            val rInner = this.size.minDimension * 0.25f

            fun hexPath(radius: Float, angleOffsetDeg: Float, yShift: Float = 0f): Path {
                val path = Path()
                for (i in 0..5) {
                    val rad = Math.toRadians((60.0 * i + angleOffsetDeg))
                    val x = cx + (radius * cos(rad)).toFloat()
                    val y = (cy + yShift) + (radius * sin(rad)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                return path
            }

            // 1. 3D Ambient Radial Halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(IceCyan.copy(alpha = 0.28f), SovereignGold.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = rOuter * 1.1f
                ),
                radius = rOuter * 1.05f,
                center = Offset(cx, cy)
            )

            // 2. 3D Drop Shadow Hexagon (Depth Layer)
            drawPath(
                path = hexPath(rOuter, -90f, yShift = 4f),
                color = Color(0xFF010308),
                style = Stroke(width = 8f)
            )

            // 3. 3D Filled Core Chamber
            drawPath(
                path = hexPath(rOuter, -90f),
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF15294F), Color(0xFF050B18))
                )
            )

            // 4. Outer 3D Beveled Metallic Gold-Cyan-Emerald Hexagon
            drawPath(
                path = hexPath(rOuter, -90f),
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan, QuantumEmerald, SovereignGold)),
                style = Stroke(width = 6.5f)
            )

            // 5. Mid 3D Rotated Holographic Frame
            drawPath(
                path = hexPath(rMid, -60f),
                brush = Brush.linearGradient(listOf(IceCyan, CyberViolet, QuantumEmerald)),
                style = Stroke(width = 3.2f)
            )

            // 6. Inner 3D Sphere Shadow + Bevel Ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF162C54), Color(0xFF040914)),
                    center = Offset(cx - 3f, cy - 3f),
                    radius = rInner
                ),
                radius = rInner,
                center = Offset(cx, cy)
            )
            drawCircle(
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan)),
                radius = rInner,
                center = Offset(cx, cy),
                style = Stroke(width = 4f)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "RW",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
            Text(
                text = "14",
                color = IceCyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 9.5.sp
            )
        }
    }
}

/**
 * 3D HD Beveled Instrument Ring Gauge with Multi-Layer Depth & Specular Glow.
 */
@Composable
fun CircularRingGauge(
    percent: Float,
    centerValue: String,
    unitLabel: String,
    ringColor: Color,
    size: Dp = 108.dp
) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val strokeW = 22f
            val pad = strokeW / 2f + 6f
            val arcSize = Size(this.size.width - pad * 2, this.size.height - pad * 2)

            // 1. 3D Inner Sphere Depth Background
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(ringColor.copy(alpha = 0.14f), Color(0xFF050B18), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = this.size.minDimension * 0.45f
                ),
                radius = this.size.minDimension * 0.42f,
                center = Offset(cx, cy)
            )

            // 2. 3D Recessed Track Shadow
            drawArc(
                color = Color(0xFF040812),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(pad, pad + 3f),
                size = arcSize,
                style = Stroke(width = strokeW + 4f, cap = StrokeCap.Round)
            )

            // 3. 3D Metallic Track Groove
            drawArc(
                color = Color(0xFF162442),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            val clamped = percent.coerceIn(0f, 100f)
            val sweep = (clamped / 100f) * 270f

            // 4. Outer Glow Layer for 3D HD Neon Effect
            drawArc(
                color = ringColor.copy(alpha = 0.28f),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW + 7f, cap = StrokeCap.Round)
            )

            // 5. Primary 3D HD Beveled Progress Arc
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(ringColor, IceCyan, ringColor, SovereignGold, ringColor)
                ),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            // 6. Specular Top Highlight Ribbon
            drawArc(
                color = Color.White.copy(alpha = 0.26f),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = 4.5f, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerValue,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 15.5.sp
            )
            Text(
                text = unitLabel,
                color = ringColor,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
        }
    }
}
