package com.example.masterpieceoptimizer.ui.theme

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

// 3D OMNI Quantum Cockpit & Extruded Metallic Bevel Palette (v30.0)
val ObsidianBg = Color(0xFF02050C)
val MidnightPanelTop = Color(0xFF14274E)
val MidnightPanel = Color(0xFF0B162E)
val MidnightPanelBottom = Color(0xFF040915)
val ExtrudedBaseDark = Color(0xFF010308)
val CardInnerBg = Color(0xFF122344)
val CardInnerBottom = Color(0xFF070E1F)
val SovereignGold = Color(0xFFFFCA58)
val SovereignGoldDeep = Color(0xFF9A6B08)
val IceCyan = Color(0xFF00F2FE)
val IceCyanDeep = Color(0xFF007788)
val QuantumEmerald = Color(0xFF00FFA3)
val QuantumEmeraldDeep = Color(0xFF007A4D)
val CyberViolet = Color(0xFFB96EFF)
val CyberVioletDeep = Color(0xFF5A2499)
val AlertRose = Color(0xFFFF3B6B)
val AlertRoseDeep = Color(0xFF8C1432)
val TextPrimary = Color(0xFFF8FBFF)
val TextSecondary = Color(0xFFA7BCD9)

private val AetheriaDarkScheme = darkColorScheme(
    primary = IceCyan,
    secondary = SovereignGold,
    tertiary = QuantumEmerald,
    background = ObsidianBg,
    surface = MidnightPanel,
    onPrimary = Color(0xFF021019),
    onSecondary = Color(0xFF1A0F00),
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun AetheriaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AetheriaDarkScheme,
        content = content
    )
}

/**
 * Animated 3D Holographic Perspective Cockpit Grid Background.
 * Creates real 3D spatial depth behind all extruded console panels.
 */
@Composable
fun Cyber3dPerspectiveGridBackground(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "grid_3d")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "grid_phase"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val horizonY = h * 0.24f

        // 1. Deep 3D Cockpit Sky & Ambient Reactor Glow
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF081632), Color(0xFF030816), ObsidianBg)
            )
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(IceCyan.copy(alpha = 0.14f), CyberViolet.copy(alpha = 0.06f), Color.Transparent),
                center = Offset(w * 0.5f, horizonY),
                radius = w * 0.72f
            ),
            radius = w * 0.72f,
            center = Offset(w * 0.5f, horizonY)
        )

        // 2. Horizon Neon Laser Line
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, IceCyan.copy(alpha = 0.35f), SovereignGold.copy(alpha = 0.35f), Color.Transparent)
            ),
            start = Offset(0f, horizonY),
            end = Offset(w, horizonY),
            strokeWidth = 2f
        )

        // 3. Perspective Converging Vanishing-Point Rays
        val vanishX = w * 0.5f
        val rayCount = 10
        for (i in -rayCount..rayCount) {
            val bottomX = vanishX + (i * (w * 0.16f))
            drawLine(
                color = IceCyan.copy(alpha = 0.075f),
                start = Offset(vanishX, horizonY),
                end = Offset(bottomX, h),
                strokeWidth = 1.2f
            )
        }

        // 4. Moving 3D Perspective Horizontal Depth Bars
        val rowCount = 11
        for (r in 0 until rowCount) {
            val norm = ((r.toFloat() + phase) / rowCount.toFloat()).coerceIn(0.01f, 1f)
            val perspectiveT = norm * norm // Quadratic foreshortening for authentic 3D depth!
            val y = horizonY + perspectiveT * (h - horizonY)
            drawLine(
                color = IceCyan.copy(alpha = (0.04f + 0.12f * perspectiveT)),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f + (1.4f * perspectiveT)
            )
        }
    }
}

/**
 * Multi-Layer 3D Extruded Console Card:
 * - Outer 3D drop shadow
 * - Thick physical 3D bottom extruded metallic lip (5.dp deep)
 * - Raised beveled console body with top specular glass reflection strip
 */
@Composable
fun Extruded3dConsoleCard(
    modifier: Modifier = Modifier,
    accentColor: Color = IceCyan,
    secondaryAccent: Color = SovereignGold,
    isHighlightedActive: Boolean = false,
    cornerRadius: Dp = 22.dp,
    lipDepth: Dp = 5.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val activeRim = if (isHighlightedActive) QuantumEmerald else accentColor
    val bottomLipBrush = if (isHighlightedActive) {
        Brush.horizontalGradient(listOf(QuantumEmeraldDeep, IceCyanDeep, SovereignGoldDeep))
    } else {
        Brush.horizontalGradient(listOf(Color(0xFF040D1E), activeRim.copy(alpha = 0.42f), Color(0xFF040D1E)))
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(cornerRadius))
            .clip(RoundedCornerShape(cornerRadius))
            .background(bottomLipBrush)
            .padding(bottom = lipDepth) // Exposes the physical 3D extruded bottom lip!
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(cornerRadius))
                .background(
                    Brush.verticalGradient(
                        colors = if (isHighlightedActive) {
                            listOf(Color(0xFF0E322C), MidnightPanel, MidnightPanelBottom)
                        } else {
                            listOf(MidnightPanelTop, MidnightPanel, MidnightPanelBottom)
                        }
                    )
                )
                .border(
                    width = if (isHighlightedActive) 2.dp else 1.5.dp,
                    brush = if (isHighlightedActive) {
                        Brush.linearGradient(listOf(QuantumEmerald, IceCyan, SovereignGold))
                    } else {
                        Brush.linearGradient(
                            listOf(
                                secondaryAccent.copy(alpha = 0.78f),
                                activeRim.copy(alpha = 0.58f),
                                Color(0xFF122346)
                            )
                        )
                    },
                    shape = RoundedCornerShape(cornerRadius)
                )
        ) {
            // Top 3D Specular Glass Reflection Strip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.5.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.40f),
                                activeRim.copy(alpha = 0.65f),
                                Color.White.copy(alpha = 0.40f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(15.dp),
                content = content
            )
        }
    }
}

/**
 * Physical 3D Tactile Arcade / Cockpit Push-Button with Extruded Bottom Base & Top Specular Bevel.
 */
@Composable
fun Tactile3dPushButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    faceColor: Color = QuantumEmerald,
    deepBaseColor: Color = QuantumEmeraldDeep,
    textColor: Color = Color(0xFF021810),
    fontSizeSp: Float = 11f
) {
    Box(
        modifier = modifier
            .shadow(8.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(deepBaseColor)
            .clickable { onClick() }
            .padding(bottom = 4.dp) // 3D Physical Button Travel Base!
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            faceColor,
                            faceColor.copy(alpha = 0.88f)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    color = Color.White.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(14.dp)
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Specular Highlight Edge
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .height(1.8.dp)
                    .background(Color.White.copy(alpha = 0.55f))
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = text,
                    color = textColor,
                    fontWeight = FontWeight.Black,
                    fontSize = fontSizeSp.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * Synthesizes a futuristic Quantum OS Polyphonic Startup Chime (1.45 seconds).
 * Plays ONLY ONCE when the user enters the AETHERIA app, then cleanly releases AudioTrack.
 */
fun playAetheriaStartupSound() {
    Thread {
        var track: AudioTrack? = null
        try {
            val sampleRate = 44100
            val durationSec = 1.45
            val numSamples = (sampleRate * durationSec).toInt()
            val pcm = ShortArray(numSamples)

            val notes = listOf(
                Triple(523.25, 0.00, 1.35),
                Triple(659.25, 0.14, 1.35),
                Triple(783.99, 0.28, 1.40),
                Triple(987.77, 0.42, 1.42),
                Triple(1046.50, 0.56, 1.45),
                Triple(261.63, 0.00, 1.25)
            )

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                var mix = 0.0
                for ((freq, startSec, endSec) in notes) {
                    if (t >= startSec && t <= endSec) {
                        val dt = t - startSec
                        val attack = (dt / 0.035).coerceIn(0.0, 1.0)
                        val decay = exp(-dt * 2.9)
                        val env = attack * decay
                        val fundamental = sin(2.0 * Math.PI * freq * dt)
                        val overtone = 0.32 * sin(2.0 * Math.PI * (freq * 2.0) * dt)
                        mix += env * (fundamental + overtone) * 0.20
                    }
                }
                val tailFade = ((durationSec - t) / 0.18).coerceIn(0.0, 1.0)
                val clamped = (mix * tailFade).coerceIn(-0.95, 0.95)
                pcm[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
            }

            val byteCount = numSamples * 2
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(byteCount)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcm, 0, numSamples)
            track.play()
            Thread.sleep(1550L)
        } catch (_: Throwable) {
        } finally {
            try {
                track?.stop()
            } catch (_: Throwable) {
            }
            try {
                track?.release()
            } catch (_: Throwable) {
            }
        }
    }.start()
}

/**
 * 3D OMNI Quantum Boot / Splash Animation shown only when first opening AETHERIA.
 */
@Composable
fun AetheriaSplashBootScreen(
    detectedBoosterName: String,
    detectedPhoneMasterName: String = "Phone Master Bawaan HP",
    onBootFinished: () -> Unit
) {
    var progress by remember { mutableStateOf(0f) }
    var stageText by remember { mutableStateOf("MEMUAT MESIN 3D OMNI QUANTUM OS v30.0...") }

    val infiniteTransition = rememberInfiniteTransition(label = "splash_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "emblem_scale"
    )
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rot"
    )

    LaunchedEffect(Unit) {
        playAetheriaStartupSound()
        val steps = 22
        for (step in 1..steps) {
            progress = step.toFloat() / steps.toFloat()
            stageText = when {
                step < 6 -> "MEMUAT KONSOL 3D OMNI & DUAL-BRIDGE (SHIZUKU + BREVENT)..."
                step < 12 -> "TERHUBUNG KE GAME BOOST: $detectedBoosterName..."
                step < 18 -> "TERHUBUNG KE PHONE MASTER: $detectedPhoneMasterName..."
                else -> "QUAD-COMBO 4X & PERISAI WA/IG SIAP — SELAMAT DATANG DI v30.0!"
            }
            delay(85L)
        }
        delay(220L)
        onBootFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        Cyber3dPerspectiveGridBackground()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(198.dp)
                        .scale(pulseScale)
                ) {
                    Canvas(modifier = Modifier.size(198.dp)) {
                        val cx = this.size.width / 2f
                        val cy = this.size.height / 2f
                        val rOuter = this.size.minDimension * 0.47f
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(IceCyan.copy(alpha = 0.32f), SovereignGold.copy(alpha = 0.14f), Color.Transparent),
                                center = Offset(cx, cy),
                                radius = rOuter * 1.18f
                            ),
                            radius = rOuter * 1.14f,
                            center = Offset(cx, cy)
                        )
                        drawArc(
                            brush = Brush.sweepGradient(listOf(SovereignGold, IceCyan, QuantumEmerald, SovereignGold)),
                            startAngle = ringRotation,
                            sweepAngle = 250f,
                            useCenter = false,
                            topLeft = Offset(10f, 10f),
                            size = Size(this.size.width - 20f, this.size.height - 20f),
                            style = Stroke(width = 7.5f, cap = StrokeCap.Round)
                        )
                        drawArc(
                            brush = Brush.sweepGradient(listOf(IceCyan, CyberViolet, QuantumEmerald, IceCyan)),
                            startAngle = -ringRotation * 1.35f,
                            sweepAngle = 200f,
                            useCenter = false,
                            topLeft = Offset(24f, 24f),
                            size = Size(this.size.width - 48f, this.size.height - 48f),
                            style = Stroke(width = 5f, cap = StrokeCap.Round)
                        )
                    }
                    Rw14QuantumEmblem(size = 120.dp)
                }

                Spacer(modifier = Modifier.height(22.dp))

                Text(
                    text = "AETHERIA // RW-14",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "QUANTUM OS v31.0 · OMNI MASTER PRO · 6-JALUR + 120FPS",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Architect: Rangga Winata · kerambir14@",
                    color = IceCyan,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(26.dp))

                // 3D Extruded Neon Progress Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.90f)
                        .height(16.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color(0xFF060E1F))
                        .border(1.4.dp, IceCyan.copy(alpha = 0.65f), RoundedCornerShape(999.dp))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progress.coerceIn(0.05f, 1f))
                            .height(16.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(SovereignGold, IceCyan, QuantumEmerald)
                                )
                            )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "${(progress * 100).toInt()}% — $stageText",
                    color = QuantumEmerald,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * 3D HD Holographic Reactor Emblem for AETHERIA // RW-14 by Rangga Winata.
 */
@Composable
fun Rw14QuantumEmblem(size: Dp = 74.dp) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val rOuter = this.size.minDimension * 0.47f
            val rMid = this.size.minDimension * 0.37f
            val rInner = this.size.minDimension * 0.25f

            fun hexPath(radius: Float, angleOffsetDeg: Float, yShift: Float = 0f): Path {
                val path = Path()
                for (i in 0..5) {
                    val rad = Math.toRadians((60.0 * i + angleOffsetDeg))
                    val x = cx + (radius * cos(rad)).toFloat()
                    val y = (cy + yShift) + (radius * sin(rad)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                return path
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(IceCyan.copy(alpha = 0.32f), SovereignGold.copy(alpha = 0.12f), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = rOuter * 1.12f
                ),
                radius = rOuter * 1.06f,
                center = Offset(cx, cy)
            )

            drawPath(
                path = hexPath(rOuter, -90f, yShift = 5f),
                color = ExtrudedBaseDark,
                style = Stroke(width = 9f)
            )

            drawPath(
                path = hexPath(rOuter, -90f),
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF18305E), Color(0xFF050B18))
                )
            )

            drawPath(
                path = hexPath(rOuter, -90f),
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan, QuantumEmerald, SovereignGold)),
                style = Stroke(width = 6.5f)
            )

            drawPath(
                path = hexPath(rMid, -60f),
                brush = Brush.linearGradient(listOf(IceCyan, CyberViolet, QuantumEmerald)),
                style = Stroke(width = 3.4f)
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF1A3464), Color(0xFF040914)),
                    center = Offset(cx - 3f, cy - 3f),
                    radius = rInner
                ),
                radius = rInner,
                center = Offset(cx, cy)
            )
            drawCircle(
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan)),
                radius = rInner,
                center = Offset(cx, cy),
                style = Stroke(width = 4f)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "RW",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
            Text(
                text = "14",
                color = IceCyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 9.5.sp
            )
        }
    }
}

/**
 * 3D HD Beveled Instrument Ring Gauge with Multi-Layer Depth & Specular Glow.
 */
@Composable
fun CircularRingGauge(
    percent: Float,
    centerValue: String,
    unitLabel: String,
    ringColor: Color,
    size: Dp = 108.dp
) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val strokeW = 22f
            val pad = strokeW / 2f + 6f
            val arcSize = Size(this.size.width - pad * 2, this.size.height - pad * 2)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(ringColor.copy(alpha = 0.18f), Color(0xFF050B18), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = this.size.minDimension * 0.46f
                ),
                radius = this.size.minDimension * 0.43f,
                center = Offset(cx, cy)
            )

            drawArc(
                color = ExtrudedBaseDark,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(pad, pad + 3.5f),
                size = arcSize,
                style = Stroke(width = strokeW + 5f, cap = StrokeCap.Round)
            )

            drawArc(
                color = Color(0xFF162646),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            val clamped = percent.coerceIn(0f, 100f)
            val sweep = (clamped / 100f) * 270f

            drawArc(
                color = ringColor.copy(alpha = 0.30f),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW + 8f, cap = StrokeCap.Round)
            )

            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(ringColor, IceCyan, ringColor, SovereignGold, ringColor)
                ),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            drawArc(
                color = Color.White.copy(alpha = 0.30f),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = 4.5f, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerValue,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 15.5.sp
            )
            Text(
                text = unitLabel,
                color = ringColor,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
        }
    }
}
