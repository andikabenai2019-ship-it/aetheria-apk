package com.example.masterpieceoptimizer.ui.theme

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

// 3D HD Quantum Glassmorphism & Metallic Bevel Palette
val ObsidianBg = Color(0xFF03060E)
val MidnightPanel = Color(0xFF0B152B)
val MidnightPanelBottom = Color(0xFF050A16)
val CardInnerBg = Color(0xFF101F3C)
val CardInnerBottom = Color(0xFF081022)
val SovereignGold = Color(0xFFFFC857)
val IceCyan = Color(0xFF00F2FE)
val QuantumEmerald = Color(0xFF00FFA3)
val CyberViolet = Color(0xFFB56BFF)
val AlertRose = Color(0xFFFF3B6B)
val TextPrimary = Color(0xFFF8FBFF)
val TextSecondary = Color(0xFFA3B8D7)

private val AetheriaDarkScheme = darkColorScheme(
    primary = IceCyan,
    secondary = SovereignGold,
    tertiary = QuantumEmerald,
    background = ObsidianBg,
    surface = MidnightPanel,
    onPrimary = Color(0xFF021019),
    onSecondary = Color(0xFF1A0F00),
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun AetheriaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AetheriaDarkScheme,
        content = content
    )
}

/**
 * Synthesizes a futuristic Quantum OS Polyphonic Startup Chime (1.45 seconds).
 * Plays ONLY ONCE when the user enters the AETHERIA app, then cleanly releases AudioTrack.
 */
fun playAetheriaStartupSound() {
    Thread {
        var track: AudioTrack? = null
        try {
            val sampleRate = 44100
            val durationSec = 1.45
            val numSamples = (sampleRate * durationSec).toInt()
            val pcm = ShortArray(numSamples)

            // Futuristic Quantum Chord Arpeggio: C5 (523.25Hz) -> E5 (659.25Hz) -> G5 (783.99Hz) -> B5 (987.77Hz) -> C6 (1046.50Hz)
            val notes = listOf(
                Triple(523.25, 0.00, 1.35),
                Triple(659.25, 0.14, 1.35),
                Triple(783.99, 0.28, 1.40),
                Triple(987.77, 0.42, 1.42),
                Triple(1046.50, 0.56, 1.45),
                Triple(261.63, 0.00, 1.25) // Warm sub-harmonic foundation
            )

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                var mix = 0.0
                for ((freq, startSec, endSec) in notes) {
                    if (t >= startSec && t <= endSec) {
                        val dt = t - startSec
                        val attack = (dt / 0.035).coerceIn(0.0, 1.0)
                        val decay = exp(-dt * 2.9)
                        val env = attack * decay
                        val fundamental = sin(2.0 * Math.PI * freq * dt)
                        val overtone = 0.32 * sin(2.0 * Math.PI * (freq * 2.0) * dt)
                        mix += env * (fundamental + overtone) * 0.20
                    }
                }
                // Gentle master fade-out at the end so there is zero click
                val tailFade = ((durationSec - t) / 0.18).coerceIn(0.0, 1.0)
                val clamped = (mix * tailFade).coerceIn(-0.95, 0.95)
                pcm[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
            }

            val byteCount = numSamples * 2
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(byteCount)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcm, 0, numSamples)
            track.play()
            Thread.sleep(1550L)
        } catch (_: Throwable) {
        } finally {
            try {
                track?.stop()
            } catch (_: Throwable) {
            }
            try {
                track?.release()
            } catch (_: Throwable) {
            }
        }
    }.start()
}

/**
 * 3D HD Quantum Boot / Splash Animation shown only when first opening AETHERIA.
 */
@Composable
fun AetheriaSplashBootScreen(
    detectedBoosterName: String,
    onBootFinished: () -> Unit
) {
    var progress by remember { mutableStateOf(0f) }
    var stageText by remember { mutableStateOf("MEMUAT MESIN 3D HD QUANTUM OS...") }

    val infiniteTransition = rememberInfiniteTransition(label = "splash_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "emblem_scale"
    )
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rot"
    )

    LaunchedEffect(Unit) {
        playAetheriaStartupSound()
        val steps = 22
        for (step in 1..steps) {
            progress = step.toFloat() / steps.toFloat()
            stageText = when {
                step < 7 -> "MEMUAT MESIN GRAFIS 3D HD & DSP AUDIO IPHONE..."
                step < 14 -> "MENDETEKSI GAME BOOSTER HP: $detectedBoosterName..."
                step < 19 -> "MENYINKRONKAN TRIPLE-COMBO (AETHERIA + GAME BOOST HP + SHIZUKU)..."
                else -> "SISTEM SIAP 100% — SELAMAT DATANG DI AETHERIA // RW-14!"
            }
            delay(85L)
        }
        delay(220L)
        onBootFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF132850), Color(0xFF060E1F), ObsidianBg)
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Animated 3D Holographic Reactor Core
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(190.dp)
                    .scale(pulseScale)
            ) {
                Canvas(modifier = Modifier.size(190.dp)) {
                    val cx = this.size.width / 2f
                    val cy = this.size.height / 2f
                    val rOuter = this.size.minDimension * 0.47f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(IceCyan.copy(alpha = 0.30f), SovereignGold.copy(alpha = 0.12f), Color.Transparent),
                            center = Offset(cx, cy),
                            radius = rOuter * 1.15f
                        ),
                        radius = rOuter * 1.1f,
                        center = Offset(cx, cy)
                    )
                    drawArc(
                        brush = Brush.sweepGradient(listOf(SovereignGold, IceCyan, QuantumEmerald, SovereignGold)),
                        startAngle = ringRotation,
                        sweepAngle = 240f,
                        useCenter = false,
                        topLeft = Offset(10f, 10f),
                        size = Size(this.size.width - 20f, this.size.height - 20f),
                        style = Stroke(width = 7f, cap = StrokeCap.Round)
                    )
                    drawArc(
                        brush = Brush.sweepGradient(listOf(IceCyan, CyberViolet, QuantumEmerald, IceCyan)),
                        startAngle = -ringRotation * 1.3f,
                        sweepAngle = 190f,
                        useCenter = false,
                        topLeft = Offset(24f, 24f),
                        size = Size(this.size.width - 48f, this.size.height - 48f),
                        style = Stroke(width = 4.5f, cap = StrokeCap.Round)
                    )
                }
                Rw14QuantumEmblem(size = 116.dp)
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = "AETHERIA // RW-14",
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 23.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "QUANTUM OS v29.0 · 3D HD · TRIPLE-COMBO XARENA EDITION",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Architect: Rangga Winata · kerambir14@",
                color = IceCyan,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(26.dp))

            // 3D Neon Progress Track
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .height(14.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color(0xFF0A1428))
                    .border(1.2.dp, IceCyan.copy(alpha = 0.55f), RoundedCornerShape(999.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress.coerceIn(0.05f, 1f))
                        .height(14.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(SovereignGold, IceCyan, QuantumEmerald)
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "${(progress * 100).toInt()}% — $stageText",
                color = QuantumEmerald,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * 3D HD Holographic Reactor Emblem for AETHERIA // RW-14 by Rangga Winata.
 */
@Composable
fun Rw14QuantumEmblem(size: Dp = 74.dp) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val rOuter = this.size.minDimension * 0.47f
            val rMid = this.size.minDimension * 0.37f
            val rInner = this.size.minDimension * 0.25f

            fun hexPath(radius: Float, angleOffsetDeg: Float, yShift: Float = 0f): Path {
                val path = Path()
                for (i in 0..5) {
                    val rad = Math.toRadians((60.0 * i + angleOffsetDeg))
                    val x = cx + (radius * cos(rad)).toFloat()
                    val y = (cy + yShift) + (radius * sin(rad)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                return path
            }

            // 1. 3D Ambient Radial Halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(IceCyan.copy(alpha = 0.28f), SovereignGold.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = rOuter * 1.1f
                ),
                radius = rOuter * 1.05f,
                center = Offset(cx, cy)
            )

            // 2. 3D Drop Shadow Hexagon (Depth Layer)
            drawPath(
                path = hexPath(rOuter, -90f, yShift = 4f),
                color = Color(0xFF010308),
                style = Stroke(width = 8f)
            )

            // 3. 3D Filled Core Chamber
            drawPath(
                path = hexPath(rOuter, -90f),
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF15294F), Color(0xFF050B18))
                )
            )

            // 4. Outer 3D Beveled Metallic Gold-Cyan-Emerald Hexagon
            drawPath(
                path = hexPath(rOuter, -90f),
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan, QuantumEmerald, SovereignGold)),
                style = Stroke(width = 6.5f)
            )

            // 5. Mid 3D Rotated Holographic Frame
            drawPath(
                path = hexPath(rMid, -60f),
                brush = Brush.linearGradient(listOf(IceCyan, CyberViolet, QuantumEmerald)),
                style = Stroke(width = 3.2f)
            )

            // 6. Inner 3D Sphere Shadow + Bevel Ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF162C54), Color(0xFF040914)),
                    center = Offset(cx - 3f, cy - 3f),
                    radius = rInner
                ),
                radius = rInner,
                center = Offset(cx, cy)
            )
            drawCircle(
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan)),
                radius = rInner,
                center = Offset(cx, cy),
                style = Stroke(width = 4f)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "RW",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
            Text(
                text = "14",
                color = IceCyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 9.5.sp
            )
        }
    }
}

/**
 * 3D HD Beveled Instrument Ring Gauge with Multi-Layer Depth & Specular Glow.
 */
@Composable
fun CircularRingGauge(
    percent: Float,
    centerValue: String,
    unitLabel: String,
    ringColor: Color,
    size: Dp = 108.dp
) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val strokeW = 22f
            val pad = strokeW / 2f + 6f
            val arcSize = Size(this.size.width - pad * 2, this.size.height - pad * 2)

            // 1. 3D Inner Sphere Depth Background
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(ringColor.copy(alpha = 0.14f), Color(0xFF050B18), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = this.size.minDimension * 0.45f
                ),
                radius = this.size.minDimension * 0.42f,
                center = Offset(cx, cy)
            )

            // 2. 3D Recessed Track Shadow
            drawArc(
                color = Color(0xFF040812),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(pad, pad + 3f),
                size = arcSize,
                style = Stroke(width = strokeW + 4f, cap = StrokeCap.Round)
            )

            // 3. 3D Metallic Track Groove
            drawArc(
                color = Color(0xFF162442),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            val clamped = percent.coerceIn(0f, 100f)
            val sweep = (clamped / 100f) * 270f

            // 4. Outer Glow Layer for 3D HD Neon Effect
            drawArc(
                color = ringColor.copy(alpha = 0.28f),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW + 7f, cap = StrokeCap.Round)
            )

            // 5. Primary 3D HD Beveled Progress Arc
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(ringColor, IceCyan, ringColor, SovereignGold, ringColor)
                ),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )

            // 6. Specular Top Highlight Ribbon
            drawArc(
                color = Color.White.copy(alpha = 0.26f),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = 4.5f, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerValue,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 15.5.sp
            )
            Text(
                text = unitLabel,
                color = ringColor,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
        }
    }
}
