package com.example.masterpieceoptimizer.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val ObsidianBg = Color(0xFF050811)
val MidnightPanel = Color(0xFF0C1426)
val CardInnerBg = Color(0xFF111D36)
val SovereignGold = Color(0xFFF5B041)
val IceCyan = Color(0xFF00F2FE)
val QuantumEmerald = Color(0xFF00F5A0)
val CyberViolet = Color(0xFFA855F7)
val AlertRose = Color(0xFFFF3B6B)
val TextPrimary = Color(0xFFF4F8FF)
val TextSecondary = Color(0xFF94A3B8)

private val AetheriaDarkScheme = darkColorScheme(
    primary = IceCyan,
    secondary = SovereignGold,
    tertiary = QuantumEmerald,
    background = ObsidianBg,
    surface = MidnightPanel,
    onPrimary = Color(0xFF03101A),
    onSecondary = Color(0xFF1A0F00),
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun AetheriaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AetheriaDarkScheme,
        content = content
    )
}

/**
 * Original Custom Vector/Canvas Emblem for AETHERIA // RW-14 by Rangga Winata.
 */
@Composable
fun Rw14QuantumEmblem(size: Dp = 68.dp) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val rOuter = this.size.minDimension * 0.46f
            val rInner = this.size.minDimension * 0.34f

            fun hexPath(radius: Float, angleOffsetDeg: Float): Path {
                val path = Path()
                for (i in 0..5) {
                    val rad = Math.toRadians((60.0 * i + angleOffsetDeg))
                    val x = cx + (radius * cos(rad)).toFloat()
                    val y = cy + (radius * sin(rad)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                return path
            }

            drawPath(
                path = hexPath(rOuter, -90f),
                brush = Brush.linearGradient(listOf(IceCyan, SovereignGold, QuantumEmerald)),
                style = Stroke(width = 6f)
            )
            drawPath(
                path = hexPath(rInner, -60f),
                color = IceCyan.copy(alpha = 0.45f),
                style = Stroke(width = 3f)
            )
            drawCircle(
                color = SovereignGold,
                radius = this.size.minDimension * 0.22f,
                center = Offset(cx, cy),
                style = Stroke(width = 4f)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "RW",
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.sp
            )
            Text(
                text = "14",
                color = IceCyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 9.sp
            )
        }
    }
}

/**
 * Custom Circular Ring Gauge matching the Sovereign v23/v27 AETHERIA design.
 */
@Composable
fun CircularRingGauge(
    percent: Float,
    centerValue: String,
    unitLabel: String,
    ringColor: Color,
    size: Dp = 104.dp
) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(modifier = Modifier.size(size)) {
            val strokeW = 20f
            val pad = strokeW / 2f + 4f
            val arcSize = Size(this.size.width - pad * 2, this.size.height - pad * 2)
            drawArc(
                color = Color(0xFF1E293B),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )
            val clamped = percent.coerceIn(0f, 100f)
            drawArc(
                color = ringColor,
                startAngle = 135f,
                sweepAngle = (clamped / 100f) * 270f,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerValue,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp
            )
            Text(
                text = unitLabel,
                color = TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
        }
    }
}
