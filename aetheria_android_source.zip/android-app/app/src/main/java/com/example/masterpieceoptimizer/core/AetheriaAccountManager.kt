package com.example.masterpieceoptimizer.core

import android.accounts.AccountManager
import android.content.Context
import android.content.Intent
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AuthProvider(val label: String, val badgeIcon: String) {
    GOOGLE("Google Account", "🔵"),
    FACEBOOK("Facebook Account", "🔷"),
    GITHUB("GitHub Developer", "⚫"),
    AETHERIA_ID("Aetheria Cloud ID", "🟣")
}

data class UserAccountProfile(
    val provider: AuthProvider,
    val displayName: String,
    val emailOrHandle: String,
    val lastSyncedAt: String,
    val cloudSyncToken: String
) {
    val avatarInitial: String
        get() = displayName.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "A"
}

data class AccountCloudSnapshot(
    val stackedModes: Set<String> = emptySet(),
    val fpsTarget: Int = 120,
    val gfxQuality: String = GfxRenderQuality.BALANCED_085.name,
    val hdMediaEnabled: Boolean = false,
    val turboChargeEnabled: Boolean = false,
    val iphoneAudioEnabled: Boolean = false,
    val dualNetEnabled: Boolean = false,
    val adSdkBlockerEnabled: Boolean = false,
    val autoResetOnReboot: Boolean = true,
    val customGames: Set<String> = emptySet(),
    val customWhitelist: Set<String> = emptySet()
)

/**
 * AETHERIA ACCOUNT LOGIN & PORTABLE CLOUD VAULT (v31.0 OMNI MASTER PRO)
 * - Supports Google (Native Android System AccountChooser — zero OAuth Code-10 errors!),
 *   Facebook, GitHub, and Aetheria Cloud ID.
 * - Auto-saves & restores user presets, stacked modes, 120FPS configs, and whitelists
 *   across reboots, reinstalls, and phone upgrades via Portable Cloud Sync Tokens & Internal Backup.
 */
class AetheriaAccountManager(private val context: Context) {

    companion object {
        private const val PREFS_ACCOUNT = "aetheria_account_cloud_vault_v310"
        private const val KEY_LOGGED_IN = "is_logged_in"
        private const val KEY_PROVIDER = "auth_provider"
        private const val KEY_DISPLAY_NAME = "display_name"
        private const val KEY_EMAIL = "email_or_handle"
        private const val KEY_LAST_SYNC = "last_synced_at"
        private const val KEY_SYNC_TOKEN = "cloud_sync_token"
        private const val TOKEN_PREFIX = "AETH31:"
        private const val HEX_CHARS = "0123456789abcdef"

        private fun encodeHex(bytes: ByteArray): String {
            val sb = StringBuilder(bytes.size * 2)
            for (b in bytes) {
                val v = b.toInt() and 0xFF
                sb.append(HEX_CHARS[v ushr 4])
                sb.append(HEX_CHARS[v and 0x0F])
            }
            return sb.toString()
        }

        private fun decodeHex(hex: String): ByteArray {
            val clean = hex.lowercase(Locale.US)
            require(clean.length % 2 == 0) { "Invalid hex length" }
            val out = ByteArray(clean.length / 2)
            for (i in out.indices) {
                val hi = Character.digit(clean[i * 2], 16)
                val lo = Character.digit(clean[i * 2 + 1], 16)
                require(hi >= 0 && lo >= 0) { "Invalid hex digit" }
                out[i] = ((hi shl 4) or lo).toByte()
            }
            return out
        }

        /**
         * Pure-JVM & minSdk-24 portable Cloud Sync Token encoder (unit-testable without Android mocks).
         */
        fun encodeSnapshotToken(snapshot: AccountCloudSnapshot): String {
            val pairs = listOf(
                "modes" to snapshot.stackedModes.sorted().joinToString(","),
                "fps" to snapshot.fpsTarget.toString(),
                "gfx" to snapshot.gfxQuality,
                "hd" to if (snapshot.hdMediaEnabled) "1" else "0",
                "chg" to if (snapshot.turboChargeEnabled) "1" else "0",
                "aud" to if (snapshot.iphoneAudioEnabled) "1" else "0",
                "net" to if (snapshot.dualNetEnabled) "1" else "0",
                "ads" to if (snapshot.adSdkBlockerEnabled) "1" else "0",
                "rst" to if (snapshot.autoResetOnReboot) "1" else "0",
                "gms" to snapshot.customGames.sorted().joinToString(","),
                "whl" to snapshot.customWhitelist.sorted().joinToString(",")
            )
            val raw = pairs.joinToString("|") { (k, v) -> "$k=$v" }
            val hex = encodeHex(raw.toByteArray(Charsets.UTF_8))
            return "$TOKEN_PREFIX$hex"
        }

        /**
         * Pure-JVM & minSdk-24 portable Cloud Sync Token decoder.
         */
        fun decodeSnapshotToken(token: String): AccountCloudSnapshot? {
            val clean = token.trim()
            if (!clean.startsWith(TOKEN_PREFIX)) return null
            return try {
                val payload = clean.removePrefix(TOKEN_PREFIX)
                val decoded = String(decodeHex(payload), Charsets.UTF_8)
                val map = mutableMapOf<String, String>()
                decoded.split("|").forEach { entry ->
                    val idx = entry.indexOf('=')
                    if (idx > 0) {
                        map[entry.substring(0, idx)] = entry.substring(idx + 1)
                    }
                }
                val modes = map["modes"]?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
                val games = map["gms"]?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
                val wl = map["whl"]?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
                AccountCloudSnapshot(
                    stackedModes = modes,
                    fpsTarget = (map["fps"]?.toIntOrNull() ?: 120).coerceIn(60, 144),
                    gfxQuality = map["gfx"]?.takeIf { it.isNotBlank() } ?: GfxRenderQuality.BALANCED_085.name,
                    hdMediaEnabled = map["hd"] == "1",
                    turboChargeEnabled = map["chg"] == "1",
                    iphoneAudioEnabled = map["aud"] == "1",
                    dualNetEnabled = map["net"] == "1",
                    adSdkBlockerEnabled = map["ads"] == "1",
                    autoResetOnReboot = map["rst"] != "0",
                    customGames = games,
                    customWhitelist = wl
                )
            } catch (_: Throwable) {
                null
            }
        }
    }

    private val prefs = context.getSharedPreferences(PREFS_ACCOUNT, Context.MODE_PRIVATE)

    /**
     * Builds Android's official built-in Google Account chooser intent (requires ZERO extra permissions).
     */
    fun createGoogleSystemAccountPickerIntent(): Intent? {
        return try {
            @Suppress("DEPRECATION")
            AccountManager.newChooseAccountIntent(
                null,
                null,
                arrayOf("com.google"),
                false,
                null,
                null,
                null,
                null
            )
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Auto-detects device primary Google email if accessible, or empty string.
     */
    fun getPrimaryDeviceGoogleEmail(): String {
        return try {
            val am = AccountManager.get(context)
            val accounts = am.getAccountsByType("com.google")
            accounts.firstOrNull()?.name?.trim() ?: ""
        } catch (_: Throwable) {
            ""
        }
    }

    fun getCurrentAccount(): UserAccountProfile? {
        if (!prefs.getBoolean(KEY_LOGGED_IN, false)) return null
        val provName = prefs.getString(KEY_PROVIDER, AuthProvider.GOOGLE.name) ?: AuthProvider.GOOGLE.name
        val provider = runCatching { AuthProvider.valueOf(provName) }.getOrDefault(AuthProvider.GOOGLE)
        val name = prefs.getString(KEY_DISPLAY_NAME, "Pengguna AETHERIA") ?: "Pengguna AETHERIA"
        val email = prefs.getString(KEY_EMAIL, "") ?: ""
        val syncTime = prefs.getString(KEY_LAST_SYNC, "-") ?: "-"
        val token = prefs.getString(KEY_SYNC_TOKEN, "") ?: ""
        return UserAccountProfile(
            provider = provider,
            displayName = name,
            emailOrHandle = email,
            lastSyncedAt = syncTime,
            cloudSyncToken = token
        )
    }

    fun signInAccount(
        provider: AuthProvider,
        displayName: String,
        emailOrHandle: String,
        initialSnapshot: AccountCloudSnapshot
    ): UserAccountProfile {
        val cleanEmail = emailOrHandle.trim().ifBlank { "user@aetheria.id" }
        val cleanName = displayName.trim().ifBlank {
            cleanEmail.substringBefore('@').replace('.', ' ')
                .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        }
        val existingToken = prefs.getString(KEY_SYNC_TOKEN, "") ?: ""
        val tokenToStore = if (existingToken.startsWith(TOKEN_PREFIX)) {
            existingToken
        } else {
            encodeSnapshotToken(initialSnapshot)
        }
        val nowStr = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
        prefs.edit()
            .putBoolean(KEY_LOGGED_IN, true)
            .putString(KEY_PROVIDER, provider.name)
            .putString(KEY_DISPLAY_NAME, cleanName)
            .putString(KEY_EMAIL, cleanEmail)
            .putString(KEY_LAST_SYNC, nowStr)
            .putString(KEY_SYNC_TOKEN, tokenToStore)
            .apply()

        val profile = UserAccountProfile(
            provider = provider,
            displayName = cleanName,
            emailOrHandle = cleanEmail,
            lastSyncedAt = nowStr,
            cloudSyncToken = tokenToStore
        )
        exportBackupToFile(profile)
        return profile
    }

    fun syncSnapshotToAccount(snapshot: AccountCloudSnapshot): UserAccountProfile? {
        val current = getCurrentAccount()
        val token = encodeSnapshotToken(snapshot)
        val nowStr = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date())
        prefs.edit()
            .putString(KEY_SYNC_TOKEN, token)
            .putString(KEY_LAST_SYNC, nowStr)
            .apply()
        if (current == null) return null
        val updated = current.copy(lastSyncedAt = nowStr, cloudSyncToken = token)
        exportBackupToFile(updated)
        return updated
    }

    fun getSavedAccountSnapshot(): AccountCloudSnapshot? {
        val token = prefs.getString(KEY_SYNC_TOKEN, "") ?: ""
        return decodeSnapshotToken(token)
    }

    fun importSyncToken(rawToken: String): AccountCloudSnapshot? {
        val decoded = decodeSnapshotToken(rawToken) ?: return null
        val nowStr = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date())
        prefs.edit()
            .putString(KEY_SYNC_TOKEN, rawToken.trim())
            .putString(KEY_LAST_SYNC, nowStr)
            .apply()
        return decoded
    }

    fun signOut() {
        prefs.edit().putBoolean(KEY_LOGGED_IN, false).apply()
    }

    fun exportBackupToFile(profile: UserAccountProfile? = getCurrentAccount()): String {
        val active = profile ?: return ""
        val content = buildString {
            appendLine("# AETHERIA // RW-14 CLOUD ACCOUNT BACKUP (${AetheriaIdentity.VERSION})")
            appendLine("PROVIDER=${active.provider.name}")
            appendLine("NAME=${active.displayName}")
            appendLine("ACCOUNT=${active.emailOrHandle}")
            appendLine("LAST_SYNC=${active.lastSyncedAt}")
            appendLine("SYNC_TOKEN=${active.cloudSyncToken}")
        }
        val candidates = listOfNotNull(
            runCatching {
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Aetheria_Account_Backup.txt")
            }.getOrNull(),
            runCatching {
                File(context.getExternalFilesDir(null), "Aetheria_Account_Backup.txt")
            }.getOrNull(),
            File(context.filesDir, "Aetheria_Account_Backup.txt")
        )
        for (target in candidates) {
            try {
                target.parentFile?.mkdirs()
                target.writeText(content, Charsets.UTF_8)
                if (target.exists() && target.length() > 0L) {
                    return target.absolutePath
                }
            } catch (_: Throwable) {
            }
        }
        return ""
    }
}
