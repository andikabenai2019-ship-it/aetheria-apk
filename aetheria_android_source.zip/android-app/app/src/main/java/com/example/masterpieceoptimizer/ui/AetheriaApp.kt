package com.example.masterpieceoptimizer.ui

import android.accounts.AccountManager
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.masterpieceoptimizer.R
import com.example.masterpieceoptimizer.core.AccountCloudSnapshot
import com.example.masterpieceoptimizer.core.ActiveProfileMode
import com.example.masterpieceoptimizer.core.AetheriaAccountManager
import com.example.masterpieceoptimizer.core.AetheriaIdentity
import com.example.masterpieceoptimizer.core.AuthProvider
import com.example.masterpieceoptimizer.core.CommandValidator
import com.example.masterpieceoptimizer.core.DeviceTelemetry
import com.example.masterpieceoptimizer.core.DeviceTelemetryRepository
import com.example.masterpieceoptimizer.core.DeviceTierAdvisor
import com.example.masterpieceoptimizer.core.DiscoveredApkFile
import com.example.masterpieceoptimizer.core.FpsUnlockPreset
import com.example.masterpieceoptimizer.core.GfxRenderQuality
import com.example.masterpieceoptimizer.core.PingServerResult
import com.example.masterpieceoptimizer.core.ShizukuDiagnostics
import com.example.masterpieceoptimizer.core.StackableMode
import com.example.masterpieceoptimizer.core.StackableModeCategory
import com.example.masterpieceoptimizer.core.SystemProfile
import com.example.masterpieceoptimizer.core.UpdateCheckResult
import com.example.masterpieceoptimizer.core.UserAccountProfile
import com.example.masterpieceoptimizer.core.VerificationRecord
import com.example.masterpieceoptimizer.data.DebloatPackageItem
import com.example.masterpieceoptimizer.data.OemDebloatDatabase
import com.example.masterpieceoptimizer.service.AutoSwitchEngineService
import com.example.masterpieceoptimizer.service.FloatingHudOverlayService
import com.example.masterpieceoptimizer.service.GameDetectionRepository
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.theme.AetheriaSplashBootScreen
import com.example.masterpieceoptimizer.ui.theme.AlertRose
import com.example.masterpieceoptimizer.ui.theme.AlertRoseDeep
import com.example.masterpieceoptimizer.ui.theme.CardInnerBg
import com.example.masterpieceoptimizer.ui.theme.CardInnerBottom
import com.example.masterpieceoptimizer.ui.theme.CircularRingGauge
import com.example.masterpieceoptimizer.ui.theme.Cyber3dPerspectiveGridBackground
import com.example.masterpieceoptimizer.ui.theme.CyberViolet
import com.example.masterpieceoptimizer.ui.theme.CyberVioletDeep
import com.example.masterpieceoptimizer.ui.theme.Extruded3dConsoleCard
import com.example.masterpieceoptimizer.ui.theme.IceCyan
import com.example.masterpieceoptimizer.ui.theme.IceCyanDeep
import com.example.masterpieceoptimizer.ui.theme.ObsidianBg
import com.example.masterpieceoptimizer.ui.theme.QuantumEmerald
import com.example.masterpieceoptimizer.ui.theme.QuantumEmeraldDeep
import com.example.masterpieceoptimizer.ui.theme.Rw14QuantumEmblem
import com.example.masterpieceoptimizer.ui.theme.SovereignGold
import com.example.masterpieceoptimizer.ui.theme.SovereignGoldDeep
import com.example.masterpieceoptimizer.ui.theme.Tactile3dPushButton
import com.example.masterpieceoptimizer.ui.theme.TextPrimary
import com.example.masterpieceoptimizer.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AetheriaTab(val icon: String, val shortLabel: String, val fullTitle: String) {
    MASTER("🛡️", "Master", "Phone Master + AETHERIA Smart Hub"),
    FPS_COMBO("🎮", "120FPS", "Universal 120FPS & Multi-Mode Combo"),
    TWEAKS("⚡", "Tweaks", "8-Kategori Tweaks Rapi & APK Otomatis"),
    BRIDGES("🔗", "6-Jalur", "Pusat 6-Jalur Tembus Sistem (OmniBridge)"),
    ACCOUNT("👤", "Akun", "Login Akun, Cloud Backup, Update & QRIS")
}

enum class MasterSubPanel {
    GRID_HOME,
    STORAGE_CLEANER,
    APP_APK_MANAGER,
    MEMORY_BOOSTER,
    COOL_DOWN,
    BATTERY_FAST_CHARGE,
    NETWORK_ASSISTANT,
    HD_MEDIA_STORY,
    SECURITY_PRIVACY
}

private data class QuickSearchItem(
    val title: String,
    val subtitle: String,
    val keywords: String,
    val badge: String,
    val onOpen: () -> Unit
)

@Composable
fun AetheriaRootScreen(
    shizukuManager: ShizukuBridgeManager,
    telemetryRepo: DeviceTelemetryRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizukuDiag by shizukuManager.diagnostics.collectAsState()
    val gameDetectionRepo = remember { GameDetectionRepository(context.applicationContext) }
    val accountManager = remember { AetheriaAccountManager(context.applicationContext) }

    var showSplash by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(AetheriaTab.MASTER) }
    var masterSubPanel by remember { mutableStateOf(MasterSubPanel.GRID_HOME) }
    var expandedTweakSection by remember { mutableStateOf(0) }
    var globalSearchQuery by remember { mutableStateOf("") }

    var telemetry by remember { mutableStateOf<DeviceTelemetry?>(null) }
    var showOnboardingWizard by remember {
        mutableStateOf(!shizukuManager.refreshDiagnostics().isReady && !shizukuManager.isOnboardingDismissed())
    }
    var pendingSafeDpiLabel by remember { mutableStateOf<String?>(null) }

    // Account Login & Cloud Sync State
    var currentAccount by remember { mutableStateOf<UserAccountProfile?>(accountManager.getCurrentAccount()) }
    var showLoginModalProvider by remember { mutableStateOf<AuthProvider?>(null) }
    var importTokenInput by remember { mutableStateOf("") }

    // Stackable Modes (2 or more can be active simultaneously!)
    val stackedModesState = remember {
        mutableStateMapOf<StackableMode, Boolean>().apply {
            StackableMode.values().forEach { mode ->
                put(mode, shizukuManager.loadUiStateBool(mode.key, false))
            }
        }
    }

    // Universal 120FPS & GFX Unlocker State
    var selectedFpsPreset by remember {
        val savedFps = shizukuManager.loadUiStateInt("unlocked_fps_target", 120)
        val matched = FpsUnlockPreset.values().firstOrNull { it.fps == savedFps } ?: FpsUnlockPreset.FPS_120
        mutableStateOf(matched)
    }
    var selectedGfxQuality by remember {
        val savedGfx = shizukuManager.loadUiStateString("unlocked_gfx_quality", GfxRenderQuality.BALANCED_085.name)
        val matched = runCatching { GfxRenderQuality.valueOf(savedGfx) }.getOrDefault(GfxRenderQuality.BALANCED_085)
        mutableStateOf(matched)
    }
    var fpsUnlockedActive by remember { mutableStateOf(shizukuManager.loadUiStateBool("fps_unlocker_active", false)) }
    var customGameInput by remember { mutableStateOf("") }

    // Core Feature Toggles (boot-session persistent, auto-reset on HP Reboot!)
    var hdMediaStoryEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("hd_media_story", false)) }
    var turboFastChargeEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("turbo_fast_charge", false)) }
    var iphoneAudioEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("iphone_audio", false)) }
    var btGamingLowLatency by remember { mutableStateOf(shizukuManager.loadUiStateBool("bt_gaming_low_latency", false)) }
    var dualNetEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("dual_net", false)) }
    var gameFirewallEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("game_firewall", false)) }
    var adSdkBlockerEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("adsdk_blocker", false)) }
    var bypassChargingEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("bypass_charging", false)) }
    var deepDozeEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("deep_doze_60s", false)) }
    var vulkanSkiaVkEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("vulkan_skiavk", false)) }
    var framePacingEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("frame_pacing", false)) }
    var inGameTouchGuardEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("ingame_touch_guard", false)) }
    var powerHalMaxEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("power_hal_max", false)) }
    var virtualRamEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("virtual_ram_on", false)) }
    var gyro200HzEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("gyro_200hz", false)) }
    var rawControllerEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("raw_controller", false)) }
    var freeformWindowEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("freeform_windows", false)) }
    var cleanStatusBarEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("clean_statusbar", false)) }

    var autoResetOnReboot by remember { mutableStateOf(shizukuManager.isAutoResetOnRebootEnabled()) }
    var autoSwitchServiceOn by remember { mutableStateOf(gameDetectionRepo.isAutoSwitchEnabledPref()) }
    var overnightMaintOn by remember { mutableStateOf(gameDetectionRepo.isOvernightMaintEnabledPref()) }
    var floatingHudOn by remember { mutableStateOf(gameDetectionRepo.isFloatingHudEnabledPref()) }

    // Auto-Scan Internal APK Installer & Debloater State
    var discoveredApks by remember { mutableStateOf<List<DiscoveredApkFile>>(emptyList()) }
    var isScanningApks by remember { mutableStateOf(false) }
    var debloatItems by remember { mutableStateOf<List<DebloatPackageItem>>(emptyList()) }
    var isScanningDebloat by remember { mutableStateOf(false) }

    // Network Ping & Update Check State
    var pingResults by remember { mutableStateOf<List<PingServerResult>>(emptyList()) }
    var isTestingPing by remember { mutableStateOf(false) }
    var updateStatus by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var isCheckingUpdate by remember { mutableStateOf(false) }

    // Live Script Execution Console State
    var lastVerifications by remember { mutableStateOf<List<VerificationRecord>>(emptyList()) }
    var lastActionSuccess by remember { mutableStateOf(true) }
    var lastActionSummary by remember {
        mutableStateOf(
            shizukuManager.loadUiStateString(
                "last_summary",
                "🟢 AETHERIA v31.0 OMNI MASTER PRO SIAGA — Gabungan Phone Master + 6-Jalur Koneksi + 120FPS Semua Game Aktif!"
            )
        )
    }
    var terminalLines by remember {
        mutableStateOf(
            listOf(
                "> Initializing ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION})...",
                "✓ Architect: ${AetheriaIdentity.ARCHITECT} (QRIS NMID: ${AetheriaIdentity.QRIS_NMID} · ${AetheriaIdentity.QRIS_TID})",
                "✓ 6-Jalur OmniBridge: Shizuku · Brevent · LADB · Bugjaeger OTG · Root · Izin Sistem Langsung",
                "✓ Phone Master Unified Hub + Universal 120FPS Unlocker + Multi-Mode Stackable Siap!",
                "✓ Perisai Immortal WA & IG + Auto-Reset Saat HP Restart Aktif!"
            )
        )
    }

    fun buildCurrentCloudSnapshot(): AccountCloudSnapshot {
        val activeModeKeys = stackedModesState.filterValues { it }.keys.map { it.key }.toSet()
        val userWhitelist = shizukuManager.getWhitelistedPackages() - AetheriaIdentity.IMMORTAL_PROTECTED_PACKAGES
        return AccountCloudSnapshot(
            stackedModes = activeModeKeys,
            fpsTarget = selectedFpsPreset.fps,
            gfxQuality = selectedGfxQuality.name,
            hdMediaEnabled = hdMediaStoryEnabled,
            turboChargeEnabled = turboFastChargeEnabled,
            iphoneAudioEnabled = iphoneAudioEnabled,
            dualNetEnabled = dualNetEnabled,
            adSdkBlockerEnabled = adSdkBlockerEnabled,
            autoResetOnReboot = autoResetOnReboot,
            customGames = gameDetectionRepo.getCustomGames(),
            customWhitelist = userWhitelist
        )
    }

    fun autoSyncToCloudIfLoggedIn() {
        if (currentAccount != null) {
            val updated = accountManager.syncSnapshotToAccount(buildCurrentCloudSnapshot())
            if (updated != null) currentAccount = updated
        }
    }

    fun markImmediateFeedback(actionTitle: String) {
        lastActionSuccess = true
        lastActionSummary = "⚡ MENJALANKAN SKRIP 3D INSTAN: $actionTitle..."
    }

    fun recordExecutionResult(actionTitle: String, records: List<VerificationRecord>) {
        telemetryRepo.incrementOptimizationCounter()
        lastVerifications = records
        val nowStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val okCount = records.count { it.verified }
        val total = records.size
        val activeBridge = shizukuManager.refreshDiagnostics().activeBridgeMode.badgeLabel

        val lines = mutableListOf<String>()
        lines.add("> [$nowStr] SKRIP: $actionTitle")
        lines.add("> Jalur Aktif: $activeBridge")
        lines.add("--------------------------------------------------")
        records.take(10).forEachIndexed { idx, r ->
            lines.add("[${idx + 1}] ${r.feature} (${r.parameter})")
            lines.add("    ${r.beforeValue} -> ${r.targetValue} -> ${r.actualValue} [${r.badge}]")
        }
        if (records.size > 10) {
            lines.add("... (+${records.size - 10} parameter lainnya terverifikasi)")
        }
        lines.add("--------------------------------------------------")

        if (okCount > 0) {
            lastActionSuccess = true
            lastActionSummary = "✅ BERHASIL ($actionTitle): $okCount/$total Parameter Aktif via ${shizukuDiag.activeBridgeMode.name}!"
            lines.add("✅ KESIMPULAN: BERHASIL DITERAPKAN ($okCount/$total Parameter Aktif)!")
        } else {
            lastActionSuccess = false
            lastActionSummary = "🟡 INFO ($actionTitle): Buka tab 🔗 6-Jalur untuk mengaktifkan jalur tembus sistem."
            lines.add("🟡 KESIMPULAN: DIEKSEKUSI ($okCount/$total Terverifikasi).")
        }
        shizukuManager.saveUiStateString("last_summary", lastActionSummary)
        terminalLines = lines
        autoSyncToCloudIfLoggedIn()
    }

    // Native Android System Google Account Picker (Zero OAuth Error Code 10!)
    val googlePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val pickedEmail = result.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)?.trim().orEmpty()
            if (pickedEmail.isNotBlank()) {
                val displayName = pickedEmail.substringBefore('@').replace('.', ' ')
                val profile = accountManager.signInAccount(
                    provider = AuthProvider.GOOGLE,
                    displayName = displayName,
                    emailOrHandle = pickedEmail,
                    initialSnapshot = buildCurrentCloudSnapshot()
                )
                currentAccount = profile
                recordExecutionResult(
                    "🔵 Login Google Berhasil ($pickedEmail)",
                    listOf(
                        VerificationRecord(
                            feature = "Google Account Cloud Sync",
                            parameter = pickedEmail,
                            beforeValue = "Tamu (Lokal)",
                            targetValue = "Tersambung & Auto-Backup",
                            actualValue = "Login Aktif (${profile.displayName})",
                            exitCode = 0,
                            verified = true,
                            badge = "🔵 GOOGLE AKTIF",
                            detail = "Seluruh pengaturan mode, 120FPS & tweaks otomatis tersimpan ke akun & memori internal"
                        )
                    )
                )
            } else {
                showLoginModalProvider = AuthProvider.GOOGLE
            }
        }
    }

    // Native Android Internal Storage APK File Picker (1-Click Pick .apk without typing paths!)
    val apkDocumentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            markImmediateFeedback("📦 Membaca & Menyiapkan File APK dari Memori Internal")
            scope.launch {
                val staged = shizukuManager.commandRegistry.stagePickedApkUri(uri)
                if (staged != null) {
                    discoveredApks = listOf(staged) + discoveredApks.filterNot { it.fullPath == staged.fullPath }
                    val installRes = shizukuManager.commandRegistry.executePowerApkInstaller(staged.fullPath)
                    recordExecutionResult("📦 Install Bypass APK (${staged.fileName})", installRes)
                } else {
                    lastActionSuccess = false
                    lastActionSummary = "🟡 File yang dipilih bukan paket .apk yang valid."
                }
            }
        }
    }

    fun refreshApkAndDebloatLists() {
        scope.launch {
            isScanningApks = true
            discoveredApks = shizukuManager.commandRegistry.scanInternalApkFiles()
            isScanningApks = false
        }
        scope.launch {
            isScanningDebloat = true
            val quadOn = stackedModesState[StackableMode.QUAD_COMBO] == true
            debloatItems = OemDebloatDatabase.scanInstalledPackages(context.packageManager, quadOn)
            isScanningDebloat = false
        }
    }

    fun applyRestoredSnapshot(snap: AccountCloudSnapshot, sourceLabel: String) {
        StackableMode.values().forEach { mode ->
            val on = mode.key in snap.stackedModes
            stackedModesState[mode] = on
            shizukuManager.saveUiStateBool(mode.key, on)
        }
        selectedFpsPreset = FpsUnlockPreset.values().firstOrNull { it.fps == snap.fpsTarget } ?: FpsUnlockPreset.FPS_120
        selectedGfxQuality = runCatching { GfxRenderQuality.valueOf(snap.gfxQuality) }.getOrDefault(GfxRenderQuality.BALANCED_085)
        hdMediaStoryEnabled = snap.hdMediaEnabled
        turboFastChargeEnabled = snap.turboChargeEnabled
        iphoneAudioEnabled = snap.iphoneAudioEnabled
        dualNetEnabled = snap.dualNetEnabled
        adSdkBlockerEnabled = snap.adSdkBlockerEnabled
        autoResetOnReboot = snap.autoResetOnReboot

        shizukuManager.saveUiStateInt("unlocked_fps_target", selectedFpsPreset.fps)
        shizukuManager.saveUiStateString("unlocked_gfx_quality", selectedGfxQuality.name)
        shizukuManager.saveUiStateBool("hd_media_story", hdMediaStoryEnabled)
        shizukuManager.saveUiStateBool("turbo_fast_charge", turboFastChargeEnabled)
        shizukuManager.saveUiStateBool("iphone_audio", iphoneAudioEnabled)
        shizukuManager.saveUiStateBool("dual_net", dualNetEnabled)
        shizukuManager.saveUiStateBool("adsdk_blocker", adSdkBlockerEnabled)
        shizukuManager.setAutoResetOnRebootEnabled(autoResetOnReboot)

        snap.customGames.forEach { gameDetectionRepo.addCustomGame(it) }
        snap.customWhitelist.forEach { shizukuManager.toggleUserWhitelistPackage(it, true) }

        markImmediateFeedback("☁️ Memulihkan Seluruh Preset dari $sourceLabel")
        scope.launch {
            val verifs = mutableListOf<VerificationRecord>()
            val activeModes = stackedModesState.filterValues { it }.keys
            if (activeModes.isNotEmpty()) {
                verifs.addAll(
                    shizukuManager.commandRegistry.applyStackedComboModes(
                        activeModes = activeModes,
                        specs = telemetry?.hardwareSpecs,
                        boosterInfo = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster(),
                        phoneMasterInfo = telemetry?.oemPhoneMaster ?: telemetryRepo.detectOemPhoneMaster(),
                        targetGamePkg = telemetry?.detectedGames?.firstOrNull { it.isInstalled }?.packageName
                    )
                )
            }
            if (hdMediaStoryEnabled) {
                verifs.addAll(shizukuManager.commandRegistry.applyHdMediaAndStoryBooster(true))
            }
            if (turboFastChargeEnabled) {
                verifs.addAll(shizukuManager.commandRegistry.applyTurboFastCharging(true))
            }
            if (iphoneAudioEnabled) {
                verifs.addAll(shizukuManager.applyIphoneAudioEnhancer(true))
            }
            if (dualNetEnabled) {
                verifs.addAll(shizukuManager.applyDualChannelNetworkBoost(true))
            }
            if (verifs.isEmpty()) {
                verifs.add(
                    VerificationRecord(
                        feature = "Pemulihan Data Akun ($sourceLabel)",
                        parameter = "FPS=${selectedFpsPreset.fps} · GFX=${selectedGfxQuality.label}",
                        beforeValue = "Backup Tersimpan",
                        targetValue = "Pulih 100%",
                        actualValue = "Berhasil Dipulihkan",
                        exitCode = 0,
                        verified = true,
                        badge = "☁️ DATA PULIH",
                        detail = "Seluruh daftar game, whitelist, dan preferensi akun telah dimuat kembali"
                    )
                )
            }
            recordExecutionResult("☁️ Pulihkan Pengaturan Akun ($sourceLabel)", verifs)
        }
    }

    fun toggleStackableMode(mode: StackableMode, enable: Boolean) {
        stackedModesState[mode] = enable
        shizukuManager.saveUiStateBool(mode.key, enable)
        if (mode == StackableMode.TURBO_CHARGE) {
            turboFastChargeEnabled = enable
            shizukuManager.saveUiStateBool("turbo_fast_charge", enable)
        }
        val activeSet = stackedModesState.filterValues { it }.keys
        val label = if (activeSet.isEmpty()) {
            "⚪ Matikan Semua Mode Combo (Kembali ke Standar)"
        } else {
            "🧩 Multi-Mode Aktif (${activeSet.size} Mode Digabung): ${activeSet.joinToString(" + ") { it.title }}"
        }
        markImmediateFeedback(label)
        scope.launch {
            val res = shizukuManager.commandRegistry.applyStackedComboModes(
                activeModes = activeSet,
                specs = telemetry?.hardwareSpecs,
                boosterInfo = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster(),
                phoneMasterInfo = telemetry?.oemPhoneMaster ?: telemetryRepo.detectOemPhoneMaster(),
                targetGamePkg = telemetry?.detectedGames?.firstOrNull { it.isInstalled }?.packageName
            )
            recordExecutionResult(label, res)
        }
    }

    fun applyMultipleStackableModesPreset(modesToActivate: Set<StackableMode>, presetLabel: String) {
        StackableMode.values().forEach { m ->
            val on = m in modesToActivate
            stackedModesState[m] = on
            shizukuManager.saveUiStateBool(m.key, on)
        }
        turboFastChargeEnabled = StackableMode.TURBO_CHARGE in modesToActivate
        shizukuManager.saveUiStateBool("turbo_fast_charge", turboFastChargeEnabled)
        markImmediateFeedback(presetLabel)
        scope.launch {
            val res = shizukuManager.commandRegistry.applyStackedComboModes(
                activeModes = modesToActivate,
                specs = telemetry?.hardwareSpecs,
                boosterInfo = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster(),
                phoneMasterInfo = telemetry?.oemPhoneMaster ?: telemetryRepo.detectOemPhoneMaster(),
                targetGamePkg = telemetry?.detectedGames?.firstOrNull { it.isInstalled }?.packageName
            )
            recordExecutionResult(presetLabel, res)
        }
    }

    fun triggerPanicFactoryReset() {
        StackableMode.values().forEach { stackedModesState[it] = false }
        fpsUnlockedActive = false
        hdMediaStoryEnabled = false
        turboFastChargeEnabled = false
        iphoneAudioEnabled = false
        btGamingLowLatency = false
        dualNetEnabled = false
        gameFirewallEnabled = false
        adSdkBlockerEnabled = false
        bypassChargingEnabled = false
        deepDozeEnabled = false
        vulkanSkiaVkEnabled = false
        framePacingEnabled = false
        inGameTouchGuardEnabled = false
        powerHalMaxEnabled = false
        virtualRamEnabled = false
        gyro200HzEnabled = false
        rawControllerEnabled = false
        freeformWindowEnabled = false
        cleanStatusBarEnabled = false
        if (autoSwitchServiceOn) {
            AutoSwitchEngineService.stop(context)
            gameDetectionRepo.setAutoSwitchEnabledPref(false)
            autoSwitchServiceOn = false
        }
        if (floatingHudOn) {
            FloatingHudOverlayService.stop(context)
            gameDetectionRepo.setFloatingHudEnabledPref(false)
            floatingHudOn = false
        }
        shizukuManager.clearAllUiStates()
        markImmediateFeedback("🚨 1-CLICK PANIC RESET (Kembalikan Semua Tweaks, FPS & DPI ke Standar Pabrik)")
        scope.launch {
            shizukuManager.applyIphoneAudioEnhancer(false)
            shizukuManager.fixMobileDataInternetDns()
            val allGames = (telemetry?.detectedGames?.map { it.packageName }.orEmpty() + gameDetectionRepo.getCustomGames()).distinct()
            shizukuManager.commandRegistry.resetUniversal120FpsGames(allGames)
            val res = shizukuManager.restoreFromSnapshots()
            recordExecutionResult("🚨 1-Click Panic Factory Restore (100% Standar Pabrik)", res)
        }
    }

    LaunchedEffect(shizukuDiag.isReady) {
        val healedDns = shizukuManager.autoHealMobileDataDnsIfNeeded()
        if (healedDns) {
            lastActionSummary = "🟢 AUTO-HEAL AKTIF: Kunci DNS Port 853 dilepas otomatis agar Kuota Data 4G/5G & Wi-Fi lancar!"
            shizukuManager.saveUiStateString("last_summary", lastActionSummary)
        }
        if (iphoneAudioEnabled) {
            shizukuManager.applyIphoneAudioEnhancer(true)
        }
        while (true) {
            shizukuManager.refreshDiagnostics()
            telemetry = telemetryRepo.collectTelemetry(shizukuManager.diagnostics.value.isReady)
            delay(4500L)
        }
    }

    LaunchedEffect(currentTab, masterSubPanel) {
        if (masterSubPanel == MasterSubPanel.APP_APK_MANAGER || currentTab == AetheriaTab.TWEAKS) {
            if (discoveredApks.isEmpty() && !isScanningApks) {
                refreshApkAndDebloatLists()
            }
        }
    }

    if (showSplash) {
        val detectedBoosterLabel = remember { telemetryRepo.detectOemGameBooster().boosterName }
        val detectedPhoneMasterLabel = remember { telemetryRepo.detectOemPhoneMaster().managerName }
        AetheriaSplashBootScreen(
            detectedBoosterName = detectedBoosterLabel,
            detectedPhoneMasterName = detectedPhoneMasterLabel,
            onBootFinished = { showSplash = false }
        )
        return
    }

    // 6-Path OmniBridge Wizard Dialog
    if (showOnboardingWizard) {
        DualPathOnboardingWizardDialog(
            diag = shizukuDiag,
            shizukuManager = shizukuManager,
            onRefreshStatus = {
                shizukuManager.refreshDiagnostics()
                scope.launch { shizukuManager.autoGrantPermissionsViaShellIfPossible() }
            },
            onDismiss = {
                shizukuManager.setOnboardingDismissed(true)
                showOnboardingWizard = false
            }
        )
    }

    // 15-Second Fail-Safe DPI Guard Dialog
    pendingSafeDpiLabel?.let { activeDpiLabel ->
        SafeDisplayConfirmDialog(
            appliedDpiLabel = activeDpiLabel,
            timeoutSeconds = 15,
            onKeepChanges = { pendingSafeDpiLabel = null },
            onAutoOrManualRevert = {
                pendingSafeDpiLabel = null
                markImmediateFeedback("🛡️ Fail-Safe 15 Detik: Mengembalikan DPI & Resolusi Pabrik")
                scope.launch {
                    val res = shizukuManager.commandRegistry.revertDisplaySizeAndDpi()
                    recordExecutionResult("🛡️ Auto-Revert DPI & Resolusi Pabrik", res)
                }
            }
        )
    }

    // Quick Account Login Dialog (Google Manual Fallback / Facebook / GitHub)
    showLoginModalProvider?.let { provider ->
        AccountQuickSignInDialog(
            provider = provider,
            onDismiss = { showLoginModalProvider = null },
            onConfirmSignIn = { nameInput, emailOrHandleInput ->
                showLoginModalProvider = null
                val profile = accountManager.signInAccount(
                    provider = provider,
                    displayName = nameInput,
                    emailOrHandle = emailOrHandleInput,
                    initialSnapshot = buildCurrentCloudSnapshot()
                )
                currentAccount = profile
                recordExecutionResult(
                    "${provider.badgeIcon} Login ${provider.label} Berhasil",
                    listOf(
                        VerificationRecord(
                            feature = "Login & Cloud Vault (${provider.label})",
                            parameter = "${profile.displayName} (${profile.emailOrHandle})",
                            beforeValue = "Tamu",
                            targetValue = "Tersimpan & Auto-Sync",
                            actualValue = "Aktif · Backup Internal & Cloud Token Siap",
                            exitCode = 0,
                            verified = true,
                            badge = "${provider.badgeIcon} LOGIN AKTIF",
                            detail = "Seluruh preset mode, 120FPS, dan daftar game otomatis tersimpan"
                        )
                    )
                )
            }
        )
    }

    val quickSearchDirectory = remember(telemetry, currentTab) {
        listOf(
            QuickSearchItem(
                title = "🎮 Universal 120 FPS Unlocker (PUBG + Semua Game)",
                subtitle = "Buka kunci 60 / 90 / 120 / 144 FPS & GFX tanpa edit file game (Anti-Ban).",
                keywords = "120 fps 90 144 pubg mlbb free fire genshin unlock game gfx",
                badge = "120FPS",
                onOpen = { currentTab = AetheriaTab.FPS_COMBO; globalSearchQuery = "" }
            ),
            QuickSearchItem(
                title = "🧩 Gabung 2 Mode atau Lebih (Performa + Hemat Baterai)",
                subtitle = "Aktifkan E-Sports Pro + Quad-Combo + Pendingin / Fast Charge sekaligus.",
                keywords = "combo mode performa hemat baterai esport quad tenang gabung",
                badge = "MULTI-MODE",
                onOpen = { currentTab = AetheriaTab.FPS_COMBO; globalSearchQuery = "" }
            ),
            QuickSearchItem(
                title = "📦 Power APK Installer Otomatis (Bypass Android 14–16 & Downgrade)",
                subtitle = "Scan otomatis file .apk di memori internal tanpa ketik folder manual.",
                keywords = "apk install installer downgrade bypass folder internal memori",
                badge = "AUTO-APK",
                onOpen = {
                    currentTab = AetheriaTab.MASTER
                    masterSubPanel = MasterSubPanel.APP_APK_MANAGER
                    globalSearchQuery = ""
                }
            ),
            QuickSearchItem(
                title = "📸 Tweaks HD Upload/Download & Story (WA, IG, TikTok, FB)",
                subtitle = "Cegah kompresi buram saat upload Status WA / Story IG & percepat unduhan media.",
                keywords = "wa whatsapp ig instagram tiktok story hd foto video upload download sosmed",
                badge = "HD STORY",
                onOpen = {
                    currentTab = AetheriaTab.MASTER
                    masterSubPanel = MasterSubPanel.HD_MEDIA_STORY
                    globalSearchQuery = ""
                }
            ),
            QuickSearchItem(
                title = "⚡ Turbo Fast Charging & Pendingin Cas",
                subtitle = "Percepat pengisian daya & tekan suhu panas (>40°C) saat HP sedang di-cas.",
                keywords = "charging cas fast cepat baterai panas suhu tenang dingin",
                badge = "FAST CHARGE",
                onOpen = {
                    currentTab = AetheriaTab.MASTER
                    masterSubPanel = MasterSubPanel.BATTERY_FAST_CHARGE
                    globalSearchQuery = ""
                }
            ),
            QuickSearchItem(
                title = "🔗 6-Jalur Tembus Sistem (Selain Shizuku & Brevent)",
                subtitle = "LADB, Bugjaeger OTG HP Teman, AxManager, Root, & Izin Sistem Langsung di HP.",
                keywords = "shizuku brevent ladb otg bugjaeger axmanager koneksi jalur izin sistem",
                badge = "6-JALUR",
                onOpen = { currentTab = AetheriaTab.BRIDGES; globalSearchQuery = "" }
            ),
            QuickSearchItem(
                title = "👤 Login Google / Facebook / GitHub & Backup Data",
                subtitle = "Simpan & pulihkan semua pengaturan AETHERIA agar tidak hilang.",
                keywords = "login akun google facebook github simpan backup restore cloud",
                badge = "AKUN",
                onOpen = { currentTab = AetheriaTab.ACCOUNT; globalSearchQuery = "" }
            ),
            QuickSearchItem(
                title = "📶 Perbaiki Kuota Data Seluler 4G/5G & Dual-Channel Boost",
                subtitle = "Atasi kuota ada tapi internet mati akibat DNS & stabilkan ping game.",
                keywords = "kuota data internet dns ping wifi jaringan sinyal 4g 5g",
                badge = "JARINGAN",
                onOpen = {
                    currentTab = AetheriaTab.MASTER
                    masterSubPanel = MasterSubPanel.NETWORK_ASSISTANT
                    globalSearchQuery = ""
                }
            ),
            QuickSearchItem(
                title = "🎧 Modul Suara Speaker & Headset Setara iPhone",
                subtitle = "Hardware Audio DSP Spatial Clarity + Bluetooth Gaming Low-Latency / LDAC.",
                keywords = "audio suara speaker headset iphone bluetooth tws ldac",
                badge = "AUDIO",
                onOpen = {
                    currentTab = AetheriaTab.TWEAKS
                    expandedTweakSection = 0
                    globalSearchQuery = ""
                }
            ),
            QuickSearchItem(
                title = "📐 Custom DPI Layar Aman (Pelindung Timer 15 Detik)",
                subtitle = "Ubah ketajaman/lebar DPI layar dengan auto-revert 15 detik anti terkunci.",
                keywords = "dpi layar resolusi vulkan warna kontras sensitivitas",
                badge = "LAYAR",
                onOpen = {
                    currentTab = AetheriaTab.TWEAKS
                    expandedTweakSection = 3
                    globalSearchQuery = ""
                }
            )
        )
    }

    Scaffold(
        containerColor = ObsidianBg,
        bottomBar = {
            BottomNavigationDock(
                currentTab = currentTab,
                onSelect = { selected ->
                    currentTab = selected
                    if (selected == AetheriaTab.MASTER) {
                        masterSubPanel = MasterSubPanel.GRID_HOME
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBg)
        ) {
            Cyber3dPerspectiveGridBackground()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                // Compact Clean 3D Top Header Bar
                OmniTopStatusHeader(
                    diag = shizukuDiag,
                    telemetry = telemetry,
                    account = currentAccount,
                    activeStackedCount = stackedModesState.count { it.value },
                    onOpenBridges = { currentTab = AetheriaTab.BRIDGES },
                    onOpenAccount = { currentTab = AetheriaTab.ACCOUNT }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Global Instant Search Bar (Never get confused looking for any feature!)
                GlobalFeatureSearchBar(
                    query = globalSearchQuery,
                    onQueryChange = { globalSearchQuery = it },
                    matchingItems = if (globalSearchQuery.isBlank()) {
                        emptyList()
                    } else {
                        val q = globalSearchQuery.trim().lowercase(Locale.ROOT)
                        quickSearchDirectory.filter {
                            it.title.lowercase(Locale.ROOT).contains(q) ||
                                it.subtitle.lowercase(Locale.ROOT).contains(q) ||
                                it.keywords.contains(q)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                when (currentTab) {
                    AetheriaTab.MASTER -> {
                        PhoneMasterUnifiedTab(
                            telemetry = telemetry,
                            diag = shizukuDiag,
                            subPanel = masterSubPanel,
                            onSelectSubPanel = { masterSubPanel = it },
                            hdMediaEnabled = hdMediaStoryEnabled,
                            onToggleHdMedia = { enable ->
                                hdMediaStoryEnabled = enable
                                shizukuManager.saveUiStateBool("hd_media_story", enable)
                                markImmediateFeedback("📸 HD Upload/Download & Story WA/IG/TikTok [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.applyHdMediaAndStoryBooster(enable)
                                    recordExecutionResult("📸 Tweaks HD Media & Story Sosmed", res)
                                }
                            },
                            turboChargeEnabled = turboFastChargeEnabled,
                            onToggleTurboCharge = { enable ->
                                turboFastChargeEnabled = enable
                                shizukuManager.saveUiStateBool("turbo_fast_charge", enable)
                                stackedModesState[StackableMode.TURBO_CHARGE] = enable
                                shizukuManager.saveUiStateBool(StackableMode.TURBO_CHARGE.key, enable)
                                markImmediateFeedback("⚡ Turbo Fast Charging [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.applyTurboFastCharging(enable)
                                    recordExecutionResult("⚡ Turbo Fast Charging & Cool-Charge", res)
                                }
                            },
                            bypassChargeEnabled = bypassChargingEnabled,
                            onToggleBypassCharge = { enable ->
                                bypassChargingEnabled = enable
                                shizukuManager.saveUiStateBool("bypass_charging", enable)
                                markImmediateFeedback("🔌 Smart Bypass Charging [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.setSmartBypassCharging(enable, telemetry?.hardwareSpecs)
                                    recordExecutionResult("🔌 Smart Bypass Charging", res)
                                }
                            },
                            deepDozeEnabled = deepDozeEnabled,
                            onToggleDeepDoze = { enable ->
                                deepDozeEnabled = enable
                                shizukuManager.saveUiStateBool("deep_doze_60s", enable)
                                markImmediateFeedback("🌙 Deep Doze Hemat Baterai [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.enableAggressiveDoze(enable)
                                    recordExecutionResult("🌙 Deep Doze 60s (WA & IG Aman)", res)
                                }
                            },
                            dualNetEnabled = dualNetEnabled,
                            onToggleDualNet = { enable ->
                                dualNetEnabled = enable
                                shizukuManager.saveUiStateBool("dual_net", enable)
                                markImmediateFeedback("🌐 Akselerasi Saluran Ganda Wi-Fi + Data [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    val res = shizukuManager.applyDualChannelNetworkBoost(enable)
                                    recordExecutionResult("🌐 Boost Jaringan Wi-Fi & Kuota Data", res)
                                }
                            },
                            adSdkBlockerEnabled = adSdkBlockerEnabled,
                            onToggleAdSdkBlocker = { enable ->
                                adSdkBlockerEnabled = enable
                                shizukuManager.saveUiStateBool("adsdk_blocker", enable)
                                markImmediateFeedback("🚫 Pemutus Iklan Tanam Ad-SDK [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.disableEmbeddedAdSdkComponents(enable)
                                    recordExecutionResult("🚫 Pemutus Komponen Pop-Up Iklan", res)
                                }
                            },
                            discoveredApks = discoveredApks,
                            isScanningApks = isScanningApks,
                            onRescanApks = { refreshApkAndDebloatLists() },
                            onPickApkFromStorage = {
                                apkDocumentPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                            },
                            onInstallApkPath = { path, label ->
                                markImmediateFeedback("📦 Menginstal $label (Bypass Downgrade & Android 14–16)")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.executePowerApkInstaller(path)
                                    recordExecutionResult("📦 Power APK Installer ($label)", res)
                                }
                            },
                            onOpenAllFilesPermission = { shizukuManager.openAllFilesAccessScreen() },
                            debloatItems = debloatItems,
                            isScanningDebloat = isScanningDebloat,
                            onToggleDebloatPkg = { pkg, enableApp ->
                                markImmediateFeedback("${if (enableApp) "🟢 Pulihkan" else "❄️ Bekukan"} $pkg")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.setSystemAppEnabled(pkg, enableApp)
                                    debloatItems = OemDebloatDatabase.scanInstalledPackages(
                                        context.packageManager,
                                        stackedModesState[StackableMode.QUAD_COMBO] == true
                                    )
                                    recordExecutionResult("📦 Manajemen Aplikasi ($pkg)", res)
                                }
                            },
                            onRestoreAllDebloat = {
                                markImmediateFeedback("🟢 Memulihkan Seluruh Aplikasi Bawaan")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.restoreAllDebloatedPackages(debloatItems)
                                    debloatItems = OemDebloatDatabase.scanInstalledPackages(context.packageManager, false)
                                    recordExecutionResult("🟢 Restore Seluruh Aplikasi Bawaan", res)
                                }
                            },
                            pingResults = pingResults,
                            isTestingPing = isTestingPing,
                            onRunPingTest = {
                                isTestingPing = true
                                scope.launch {
                                    pingResults = telemetryRepo.testGameServersPing()
                                    isTestingPing = false
                                }
                            },
                            onFixMobileData = {
                                markImmediateFeedback("📶 Memperbaiki Koneksi Internet Kuota Data 4G/5G")
                                scope.launch {
                                    val res = shizukuManager.fixMobileDataInternetDns()
                                    recordExecutionResult("📶 Perbaiki Internet Data Seluler", res)
                                }
                            },
                            onOpenRadioLock = {
                                val rec = shizukuManager.commandRegistry.openRadioNetworkLockMenu()
                                recordExecutionResult("📡 Menu Kunci Sinyal 4G/5G Only", listOf(rec))
                            },
                            onRunAiMasterSweep = {
                                val temp = telemetry?.batteryTempC ?: 37.0
                                val charging = telemetry?.isCharging ?: false
                                val booster = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster()
                                val master = telemetry?.oemPhoneMaster ?: telemetryRepo.detectOemPhoneMaster()
                                markImmediateFeedback("✨ Manajer AI Terpadu (AETHERIA + ${master.managerName})")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.runUnifiedPhoneMasterAiSweep(
                                        tempC = temp,
                                        isCharging = charging,
                                        boosterInfo = booster,
                                        phoneMasterInfo = master
                                    )
                                    telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                                    recordExecutionResult("✨ Manajer AI Terpadu (Bersih + Adem + Kuota Lancar)", res)
                                }
                            },
                            onLaunchBuiltInPhoneMaster = {
                                shizukuManager.launchOemPhoneMaster(telemetry?.oemPhoneMaster)
                            },
                            onRunStorageClean = {
                                markImmediateFeedback("🗑️ Pembersihan Penyimpanan, Shader Cache & FSTRIM")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.cleanGameShaderAndTrimStorage(null)
                                    telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                                    recordExecutionResult("🗑️ Pembersihan Penyimpanan & FSTRIM", res)
                                }
                            },
                            onRunMemoryBoost = {
                                markImmediateFeedback("🚀 Peningkat Memori RAM & Anti-Reload WA/IG")
                                scope.launch {
                                    val verifs = mutableListOf<VerificationRecord>()
                                    shizukuManager.runLocalNativeCleanup()
                                    verifs.addAll(shizukuManager.commandRegistry.configureMultitaskingLimits(24, disablePhantomKiller = true))
                                    verifs.addAll(shizukuManager.commandRegistry.compileSystemUiAndLauncher())
                                    telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                                    recordExecutionResult("🚀 Peningkat Memori & Speed SystemUI", verifs)
                                }
                            },
                            onRunCoolDown = {
                                stackedModesState[StackableMode.SMART_COOL] = true
                                shizukuManager.saveUiStateBool(StackableMode.SMART_COOL.key, true)
                                markImmediateFeedback("❄️ Tenang / Pendinginan Mesin & Baterai (WA/IG Aman)")
                                scope.launch {
                                    val res = shizukuManager.applySmartCoolBoostBalance()
                                    telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                                    recordExecutionResult("❄️ Pendingin Otomatis Seimbang (Tenang)", res)
                                }
                            },
                            onRunMalwareScan = {
                                markImmediateFeedback("🛡️ Pemindaian Keamanan & Auto-Purge Virus APK")
                                scope.launch {
                                    val res = shizukuManager.scanAndAutoPurgeMalware(autoPurge = true)
                                    recordExecutionResult("🛡️ Pemindaian Keamanan APK Penipuan", res)
                                }
                            }
                        )
                    }

                    AetheriaTab.FPS_COMBO -> {
                        FpsAndStackableModesTab(
                            telemetry = telemetry,
                            selectedFps = selectedFpsPreset,
                            onSelectFps = {
                                selectedFpsPreset = it
                                shizukuManager.saveUiStateInt("unlocked_fps_target", it.fps)
                            },
                            selectedGfx = selectedGfxQuality,
                            onSelectGfx = {
                                selectedGfxQuality = it
                                shizukuManager.saveUiStateString("unlocked_gfx_quality", it.name)
                            },
                            fpsUnlockedActive = fpsUnlockedActive,
                            customGames = gameDetectionRepo.getCustomGames(),
                            customGameInput = customGameInput,
                            onCustomGameInputChange = { customGameInput = it },
                            onAddCustomGame = { pkg ->
                                if (CommandValidator.isValidPackageName(pkg)) {
                                    gameDetectionRepo.addCustomGame(pkg.trim())
                                    customGameInput = ""
                                    autoSyncToCloudIfLoggedIn()
                                }
                            },
                            onUnlockAllGamesFps = {
                                fpsUnlockedActive = true
                                shizukuManager.saveUiStateBool("fps_unlocker_active", true)
                                val allPkgs = (
                                    telemetry?.detectedGames?.map { it.packageName }.orEmpty() +
                                        AetheriaIdentity.KNOWN_POPULAR_GAMES.map { it.first } +
                                        gameDetectionRepo.getCustomGames()
                                    ).distinct()
                                markImmediateFeedback("🎮 Unlock ${selectedFpsPreset.fps} FPS (${selectedGfxQuality.label}) pada PUBG & Semua Game")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.unlockUniversal120FpsGames(
                                        targetFps = selectedFpsPreset.fps,
                                        renderQuality = selectedGfxQuality,
                                        targetPackages = allPkgs
                                    )
                                    recordExecutionResult("🎮 Universal ${selectedFpsPreset.fps} FPS Unlocker (Semua Game)", res)
                                }
                            },
                            onResetAllGamesFps = {
                                fpsUnlockedActive = false
                                shizukuManager.saveUiStateBool("fps_unlocker_active", false)
                                val allPkgs = (
                                    telemetry?.detectedGames?.map { it.packageName }.orEmpty() +
                                        AetheriaIdentity.KNOWN_POPULAR_GAMES.map { it.first } +
                                        gameDetectionRepo.getCustomGames()
                                    ).distinct()
                                markImmediateFeedback("↩️ Reset FPS & GFX Semua Game ke Standar")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.resetUniversal120FpsGames(allPkgs)
                                    recordExecutionResult("↩️ Reset Universal FPS Standar", res)
                                }
                            },
                            onUnlockSingleGameFps = { pkg, appName ->
                                fpsUnlockedActive = true
                                shizukuManager.saveUiStateBool("fps_unlocker_active", true)
                                markImmediateFeedback("🎮 Unlock ${selectedFpsPreset.fps} FPS untuk $appName")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.unlockUniversal120FpsGames(
                                        targetFps = selectedFpsPreset.fps,
                                        renderQuality = selectedGfxQuality,
                                        targetPackages = listOf(pkg)
                                    )
                                    recordExecutionResult("🎮 ${selectedFpsPreset.fps} FPS ($appName)", res)
                                }
                            },
                            onCompileSingleGame = { pkg, appName ->
                                markImmediateFeedback("🚀 Kompilasi AOT Speed Mode untuk $appName")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.compileAppPackage(pkg, "speed")
                                    recordExecutionResult("🚀 Kompilasi Speed ($appName)", res)
                                }
                            },
                            stackedModesState = stackedModesState,
                            onToggleStackableMode = { mode, on -> toggleStackableMode(mode, on) },
                            onApplyMultiPreset = { modes, title -> applyMultipleStackableModesPreset(modes, title) },
                            onLaunchOemGameBooster = { shizukuManager.launchOemGameBooster(telemetry?.oemGameBooster) },
                            autoSwitchOn = autoSwitchServiceOn,
                            onToggleAutoSwitch = { enable ->
                                autoSwitchServiceOn = enable
                                gameDetectionRepo.setAutoSwitchEnabledPref(enable)
                                if (enable) {
                                    scope.launch { shizukuManager.autoGrantPermissionsViaShellIfPossible() }
                                    AutoSwitchEngineService.start(context)
                                } else {
                                    AutoSwitchEngineService.stop(context)
                                }
                            },
                            onOpenUsageAccess = {
                                runCatching {
                                    val i = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(i)
                                }
                            },
                            floatingHudOn = floatingHudOn,
                            onToggleFloatingHud = { enable ->
                                scope.launch {
                                    if (enable) {
                                        val ok = FloatingHudOverlayService.ensureOverlayPermissionOrOpenSettings(context, shizukuManager)
                                        if (ok) {
                                            floatingHudOn = true
                                            gameDetectionRepo.setFloatingHudEnabledPref(true)
                                            FloatingHudOverlayService.start(context)
                                        }
                                    } else {
                                        floatingHudOn = false
                                        gameDetectionRepo.setFloatingHudEnabledPref(false)
                                        FloatingHudOverlayService.stop(context)
                                    }
                                }
                            },
                            overnightMaintOn = overnightMaintOn,
                            onToggleOvernightMaint = { enable ->
                                overnightMaintOn = enable
                                gameDetectionRepo.setOvernightMaintEnabledPref(enable)
                            }
                        )
                    }

                    AetheriaTab.TWEAKS -> {
                        OrganizedTweaksAccordionTab(
                            expandedSection = expandedTweakSection,
                            onSelectSection = { idx ->
                                expandedTweakSection = if (expandedTweakSection == idx) -1 else idx
                            },
                            telemetry = telemetry,
                            hdMediaEnabled = hdMediaStoryEnabled,
                            onToggleHdMedia = { enable ->
                                hdMediaStoryEnabled = enable
                                shizukuManager.saveUiStateBool("hd_media_story", enable)
                                markImmediateFeedback("📸 HD Story & Media [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("📸 HD Story & Media Sosmed", shizukuManager.commandRegistry.applyHdMediaAndStoryBooster(enable))
                                }
                            },
                            iphoneAudioEnabled = iphoneAudioEnabled,
                            onToggleIphoneAudio = { enable ->
                                iphoneAudioEnabled = enable
                                shizukuManager.saveUiStateBool("iphone_audio", enable)
                                markImmediateFeedback("🎧 Audio Speaker & Headset iPhone [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🎧 Modul Audio Setara iPhone", shizukuManager.commandRegistry.setFineVolumeAndSoundUnlocker(enable))
                                }
                            },
                            btGamingLowLatency = btGamingLowLatency,
                            onToggleBtGaming = { lowLat ->
                                btGamingLowLatency = lowLat
                                shizukuManager.saveUiStateBool("bt_gaming_low_latency", lowLat)
                                markImmediateFeedback("🎧 Bluetooth ${if (lowLat) "Gaming Low-Latency" else "Hi-Res LDAC 990kbps"}")
                                scope.launch {
                                    recordExecutionResult("🎧 Mode Audio Bluetooth", shizukuManager.commandRegistry.setBluetoothAudioMode(lowLat))
                                }
                            },
                            turboChargeEnabled = turboFastChargeEnabled,
                            onToggleTurboCharge = { enable ->
                                turboFastChargeEnabled = enable
                                shizukuManager.saveUiStateBool("turbo_fast_charge", enable)
                                stackedModesState[StackableMode.TURBO_CHARGE] = enable
                                shizukuManager.saveUiStateBool(StackableMode.TURBO_CHARGE.key, enable)
                                markImmediateFeedback("⚡ Turbo Fast Charging [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("⚡ Turbo Fast Charging", shizukuManager.commandRegistry.applyTurboFastCharging(enable))
                                }
                            },
                            bypassChargeEnabled = bypassChargingEnabled,
                            onToggleBypassCharge = { enable ->
                                bypassChargingEnabled = enable
                                shizukuManager.saveUiStateBool("bypass_charging", enable)
                                markImmediateFeedback("🔌 Smart Bypass Charging [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🔌 Smart Bypass Charging", shizukuManager.commandRegistry.setSmartBypassCharging(enable, telemetry?.hardwareSpecs))
                                }
                            },
                            deepDozeEnabled = deepDozeEnabled,
                            onToggleDeepDoze = { enable ->
                                deepDozeEnabled = enable
                                shizukuManager.saveUiStateBool("deep_doze_60s", enable)
                                markImmediateFeedback("🌙 Deep Doze 60s [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🌙 Deep Doze 60s (WA/IG Aman)", shizukuManager.commandRegistry.enableAggressiveDoze(enable))
                                }
                            },
                            discoveredApks = discoveredApks,
                            isScanningApks = isScanningApks,
                            onRescanApks = { refreshApkAndDebloatLists() },
                            onPickApkFromStorage = {
                                apkDocumentPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                            },
                            onInstallApkPath = { path, label ->
                                markImmediateFeedback("📦 Install Bypass APK ($label)")
                                scope.launch {
                                    recordExecutionResult("📦 Power APK Installer ($label)", shizukuManager.commandRegistry.executePowerApkInstaller(path))
                                }
                            },
                            onOpenAllFilesPermission = { shizukuManager.openAllFilesAccessScreen() },
                            debloatItems = debloatItems,
                            onToggleDebloatPkg = { pkg, enableApp ->
                                markImmediateFeedback("${if (enableApp) "🟢 Pulihkan" else "❄️ Bekukan"} $pkg")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.setSystemAppEnabled(pkg, enableApp)
                                    debloatItems = OemDebloatDatabase.scanInstalledPackages(context.packageManager, stackedModesState[StackableMode.QUAD_COMBO] == true)
                                    recordExecutionResult("📦 Debloater ($pkg)", res)
                                }
                            },
                            onRestoreAllDebloat = {
                                markImmediateFeedback("🟢 Restore Semua Aplikasi Bawaan")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.restoreAllDebloatedPackages(debloatItems)
                                    debloatItems = OemDebloatDatabase.scanInstalledPackages(context.packageManager, false)
                                    recordExecutionResult("🟢 Restore Semua Aplikasi Bawaan", res)
                                }
                            },
                            vulkanEnabled = vulkanSkiaVkEnabled,
                            onToggleVulkan = { enable ->
                                vulkanSkiaVkEnabled = enable
                                shizukuManager.saveUiStateBool("vulkan_skiavk", enable)
                                markImmediateFeedback("🎨 Vulkan SkiaVK [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🎨 Vulkan Hardware Renderer", shizukuManager.commandRegistry.setVulkanRenderer(enable))
                                }
                            },
                            framePacingEnabled = framePacingEnabled,
                            onToggleFramePacing = { enable ->
                                framePacingEnabled = enable
                                shizukuManager.saveUiStateBool("frame_pacing", enable)
                                markImmediateFeedback("🎞️ Penstabil Bingkai Zero-Lag [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🎞️ SurfaceFlinger Frame Pacing", shizukuManager.commandRegistry.optimizeFramePacing(enable))
                                }
                            },
                            onSelectRefreshRate = { hz ->
                                markImmediateFeedback("🖥️ Kunci Refresh Rate ${if (hz == 0) "Adaptif" else if (hz == 1) "LTPO 1-120Hz" else "${hz}Hz"}")
                                scope.launch {
                                    recordExecutionResult("🖥️ Pengunci Refresh Rate", shizukuManager.commandRegistry.lockRefreshRate(hz))
                                }
                            },
                            onSelectColorMode = { mode ->
                                markImmediateFeedback("🌈 Kalibrasi Warna SurfaceFlinger (Mode $mode)")
                                scope.launch {
                                    recordExecutionResult("🌈 Saturasi & Kontras Layar", shizukuManager.commandRegistry.setSurfaceFlingerColorMode(mode))
                                }
                            },
                            inGameTouchGuard = inGameTouchGuardEnabled,
                            onToggleInGameGuard = { enable ->
                                inGameTouchGuardEnabled = enable
                                shizukuManager.saveUiStateBool("ingame_touch_guard", enable)
                                markImmediateFeedback("🛡️ Kunci Kecerahan & Anti-Mistouch [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🛡️ Anti-Redup & Mistouch Guard", shizukuManager.commandRegistry.setInGameBrightnessAndTouchGuard(enable))
                                }
                            },
                            onApplySafeCustomDpi = { dpi ->
                                val safe = dpi.coerceIn(280, 600)
                                markImmediateFeedback("📐 Terapkan Custom DPI $safe (Timer Aman 15 Detik)")
                                scope.launch {
                                    val res = shizukuManager.commandRegistry.applyCustomDpi(safe)
                                    if (res.any { it.verified }) {
                                        pendingSafeDpiLabel = "$safe DPI"
                                    }
                                    recordExecutionResult("📐 Custom DPI ($safe)", res)
                                }
                            },
                            onResetDefaultDpi = {
                                markImmediateFeedback("↩️ Kembalikan DPI & Resolusi Asli Pabrik")
                                scope.launch {
                                    recordExecutionResult("↩️ Reset DPI Pabrik", shizukuManager.commandRegistry.revertDisplaySizeAndDpi())
                                }
                            },
                            powerHalEnabled = powerHalMaxEnabled,
                            onTogglePowerHal = { enable ->
                                powerHalMaxEnabled = enable
                                shizukuManager.saveUiStateBool("power_hal_max", enable)
                                markImmediateFeedback("⚡ Power HAL Fixed Performance [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("⚡ Power HAL Max Clock", shizukuManager.commandRegistry.setFixedPerformanceMode(enable))
                                }
                            },
                            onCompileSystemUi = {
                                markImmediateFeedback("🚀 Kompilasi Speed SystemUI & Home Launcher")
                                scope.launch {
                                    recordExecutionResult("🚀 Speed SystemUI & Launcher", shizukuManager.commandRegistry.compileSystemUiAndLauncher())
                                }
                            },
                            onApplyMultitasking = { maxCached ->
                                markImmediateFeedback("🧠 Set Batas Multitasking ($maxCached App) & Phantom Killer OFF")
                                scope.launch {
                                    recordExecutionResult("🧠 Multitasking & Anti-Reload", shizukuManager.commandRegistry.configureMultitaskingLimits(maxCached, true))
                                }
                            },
                            virtualRamEnabled = virtualRamEnabled,
                            onToggleVirtualRam = { enable ->
                                virtualRamEnabled = enable
                                shizukuManager.saveUiStateBool("virtual_ram_on", enable)
                                markImmediateFeedback("💾 Virtual RAM / MemFusion [${if (enable) "ON" else "OFF (Bebas Lag eMMC)"}]")
                                scope.launch {
                                    recordExecutionResult("💾 Kontrol Virtual RAM OEM", shizukuManager.commandRegistry.setVirtualRamEnabled(enable))
                                }
                            },
                            onBoostTouch240Hz = {
                                markImmediateFeedback("👆 Aktifkan Touch Polling 240Hz & Flick Instan 140ms")
                                scope.launch {
                                    recordExecutionResult("👆 Touch Polling 240Hz", shizukuManager.commandRegistry.tuneTouchAndScrolling(240, 5, 140))
                                }
                            },
                            gyro200HzEnabled = gyro200HzEnabled,
                            onToggleGyro200Hz = { enable ->
                                gyro200HzEnabled = enable
                                shizukuManager.saveUiStateBool("gyro_200hz", enable)
                                markImmediateFeedback("🎯 Gyroscope Fast-Polling 200Hz [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🎯 Gyroscope 200Hz Booster", shizukuManager.commandRegistry.boostGyroscopePolling(enable))
                                }
                            },
                            onSelectAnimScale = { scale ->
                                markImmediateFeedback("✨ Skala Animasi Desimal ${scale}x")
                                scope.launch {
                                    recordExecutionResult("✨ Skala Animasi (${scale}x)", shizukuManager.commandRegistry.setDecimalAnimationScale(scale))
                                }
                            },
                            onSelectHapticLevel = { lvl ->
                                markImmediateFeedback("📳 Intensitas Getar Haptic Level $lvl")
                                scope.launch {
                                    recordExecutionResult("📳 Haptic Feedback ($lvl/3)", shizukuManager.commandRegistry.setHapticIntensity(lvl))
                                }
                            },
                            rawControllerEnabled = rawControllerEnabled,
                            onToggleRawController = { enable ->
                                rawControllerEnabled = enable
                                shizukuManager.saveUiStateBool("raw_controller", enable)
                                markImmediateFeedback("🎮 Raw Input Gamepad & Mouse OTG [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🎮 Kalibrasi Gamepad/Mouse OTG", shizukuManager.commandRegistry.optimizeExternalControllerMouse(enable))
                                }
                            },
                            dualNetEnabled = dualNetEnabled,
                            onToggleDualNet = { enable ->
                                dualNetEnabled = enable
                                shizukuManager.saveUiStateBool("dual_net", enable)
                                markImmediateFeedback("🌐 Akselerasi Saluran Ganda [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🌐 Dual-Channel Network Boost", shizukuManager.applyDualChannelNetworkBoost(enable))
                                }
                            },
                            onFixMobileData = {
                                markImmediateFeedback("📶 Perbaiki Internet Kuota Data 4G/5G")
                                scope.launch {
                                    recordExecutionResult("📶 Perbaiki Internet Data Seluler", shizukuManager.fixMobileDataInternetDns())
                                }
                            },
                            onSelectDnsProfile = { prof ->
                                markImmediateFeedback("🌐 Set Profil DNS ($prof)")
                                scope.launch {
                                    recordExecutionResult("🌐 Smart DNS Switcher", shizukuManager.commandRegistry.setSmartDnsProfile(prof))
                                }
                            },
                            gameFirewallEnabled = gameFirewallEnabled,
                            onToggleGameFirewall = { enable ->
                                gameFirewallEnabled = enable
                                shizukuManager.saveUiStateBool("game_firewall", enable)
                                val topGame = telemetry?.detectedGames?.firstOrNull { it.isInstalled }?.packageName
                                markImmediateFeedback("🛡️ Firewall Bandwith Game (WA & IG Aman) [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🛡️ Firewall Bandwith Game", shizukuManager.commandRegistry.setBackgroundDataFirewall(enable, topGame))
                                }
                            },
                            onOpenRadioLock = {
                                recordExecutionResult("📡 Kunci Sinyal 4G/5G Only", listOf(shizukuManager.commandRegistry.openRadioNetworkLockMenu()))
                            },
                            freeformEnabled = freeformWindowEnabled,
                            onToggleFreeform = { enable ->
                                freeformWindowEnabled = enable
                                shizukuManager.saveUiStateBool("freeform_windows", enable)
                                markImmediateFeedback("🪟 Freeform Multi-Window [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("🪟 Freeform Jendela Melayang", shizukuManager.commandRegistry.unlockFreeformWindows(enable))
                                }
                            },
                            cleanStatusBarEnabled = cleanStatusBarEnabled,
                            onToggleCleanStatusBar = { enable ->
                                cleanStatusBarEnabled = enable
                                shizukuManager.saveUiStateBool("clean_statusbar", enable)
                                markImmediateFeedback("📱 Anti Burn-In Status Bar [${if (enable) "ON" else "OFF"}]")
                                scope.launch {
                                    recordExecutionResult("📱 Pembersih Ikon Status Bar", shizukuManager.commandRegistry.setStatusBarCleaner(enable))
                                }
                            },
                            onRunOvernightNow = {
                                markImmediateFeedback("🌙 Menjalankan Perawatan Dexopt + FSTRIM Sekarang")
                                scope.launch {
                                    recordExecutionResult("🌙 Perawatan Sistem Mendalam", shizukuManager.commandRegistry.runOvernightIdleMaintenance())
                                }
                            },
                            whitelistedPackages = shizukuManager.getWhitelistedPackages(),
                            onToggleWhitelist = { pkg, on ->
                                shizukuManager.toggleUserWhitelistPackage(pkg, on)
                                autoSyncToCloudIfLoggedIn()
                            }
                        )
                    }

                    AetheriaTab.BRIDGES -> {
                        OmniBridgeSixPathTab(
                            diag = shizukuDiag,
                            shizukuManager = shizukuManager,
                            onOpenWizard = { showOnboardingWizard = true },
                            onRefreshAndAutoGrant = {
                                shizukuManager.refreshDiagnostics()
                                scope.launch {
                                    shizukuManager.autoGrantPermissionsViaShellIfPossible()
                                    shizukuManager.refreshDiagnostics()
                                }
                            }
                        )
                    }

                    AetheriaTab.ACCOUNT -> {
                        AccountCloudAndSettingsTab(
                            account = currentAccount,
                            telemetry = telemetry,
                            autoResetOnReboot = autoResetOnReboot,
                            onToggleAutoReset = { enable ->
                                autoResetOnReboot = enable
                                shizukuManager.setAutoResetOnRebootEnabled(enable)
                                autoSyncToCloudIfLoggedIn()
                            },
                            onClickGoogleSignIn = {
                                val pickerIntent = accountManager.createGoogleSystemAccountPickerIntent()
                                if (pickerIntent != null) {
                                    runCatching { googlePickerLauncher.launch(pickerIntent) }
                                        .onFailure { showLoginModalProvider = AuthProvider.GOOGLE }
                                } else {
                                    showLoginModalProvider = AuthProvider.GOOGLE
                                }
                            },
                            onClickProviderSignIn = { provider ->
                                showLoginModalProvider = provider
                            },
                            onSyncNow = {
                                val updated = accountManager.syncSnapshotToAccount(buildCurrentCloudSnapshot())
                                if (updated != null) {
                                    currentAccount = updated
                                    val path = accountManager.exportBackupToFile(updated)
                                    recordExecutionResult(
                                        "☁️ Simpan Data ke Akun & Memori Internal",
                                        listOf(
                                            VerificationRecord(
                                                feature = "Cloud Account Sync & Local Backup",
                                                parameter = updated.emailOrHandle,
                                                beforeValue = "Preset Aktif",
                                                targetValue = "Tersimpan Aman",
                                                actualValue = if (path.isNotBlank()) "Tersimpan di $path" else "Tersimpan di Vault Akun",
                                                exitCode = 0,
                                                verified = true,
                                                badge = "☁️ TERSIMPAN",
                                                detail = "Seluruh mode performa/hemat, 120FPS, dan daftar game tersimpan"
                                            )
                                        )
                                    )
                                }
                            },
                            onRestoreFromAccount = {
                                val saved = accountManager.getSavedAccountSnapshot()
                                if (saved != null) {
                                    applyRestoredSnapshot(saved, currentAccount?.displayName ?: "Vault Akun")
                                }
                            },
                            onCopyCloudToken = {
                                val token = currentAccount?.cloudSyncToken?.ifBlank {
                                    AetheriaAccountManager.encodeSnapshotToken(buildCurrentCloudSnapshot())
                                } ?: AetheriaAccountManager.encodeSnapshotToken(buildCurrentCloudSnapshot())
                                shizukuManager.copyCommandToClipboard("AETHERIA Cloud Token", token)
                                lastActionSuccess = true
                                lastActionSummary = "📋 Kode Cloud Sync Token berhasil disalin! Simpan di catatan WA untuk pindah HP kapan saja."
                            },
                            importTokenInput = importTokenInput,
                            onImportTokenInputChange = { importTokenInput = it },
                            onImportCloudToken = {
                                val decoded = accountManager.importSyncToken(importTokenInput)
                                if (decoded != null) {
                                    importTokenInput = ""
                                    applyRestoredSnapshot(decoded, "Kode Cloud Sync Token")
                                } else {
                                    lastActionSuccess = false
                                    lastActionSummary = "🟡 Kode Token tidak valid (pastikan diawali AETH31:...)."
                                }
                            },
                            onSignOut = {
                                accountManager.signOut()
                                currentAccount = null
                            },
                            updateStatus = updateStatus,
                            isCheckingUpdate = isCheckingUpdate,
                            onCheckUpdate = {
                                isCheckingUpdate = true
                                markImmediateFeedback("🔄 Memeriksa Update APK Resmi di GitHub")
                                scope.launch {
                                    val res = telemetryRepo.checkForApkUpdate()
                                    updateStatus = res
                                    isCheckingUpdate = false
                                    recordExecutionResult(
                                        "🔄 Cek Update OTA GitHub",
                                        listOf(
                                            VerificationRecord(
                                                feature = "Pemeriksaan Update APK",
                                                parameter = AetheriaIdentity.GITHUB_REPO,
                                                beforeValue = res.currentVersion,
                                                targetValue = res.latestVersion,
                                                actualValue = if (res.hasNewerRelease) "Tersedia Versi Baru!" else "Sudah Paling Baru",
                                                exitCode = 0,
                                                verified = true,
                                                badge = if (res.hasNewerRelease) "🚀 UPDATE BARU" else "🟢 TERBARU",
                                                detail = res.statusMessage
                                            )
                                        )
                                    )
                                }
                            },
                            onPanicFactoryReset = { triggerPanicFactoryReset() },
                            snapshots = shizukuManager.getSavedSnapshots()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Always-Accessible Live 3D Execution Proof Console (with vertical wrap bug 100% FIXED!)
                LiveScriptExecutionConsoleCard(
                    summaryText = lastActionSummary,
                    isSuccess = lastActionSuccess,
                    terminalLines = terminalLines,
                    verifications = lastVerifications
                )

                Spacer(modifier = Modifier.height(18.dp))
            }
        }
    }
}

// =============================================================================
// TOP STATUS HEADER & GLOBAL INSTANT FEATURE SEARCH BAR
// =============================================================================

@Composable
private fun OmniTopStatusHeader(
    diag: ShizukuDiagnostics,
    telemetry: DeviceTelemetry?,
    account: UserAccountProfile?,
    activeStackedCount: Int,
    onOpenBridges: () -> Unit,
    onOpenAccount: () -> Unit
) {
    Extruded3dConsoleCard(
        accentColor = if (diag.isReady) QuantumEmerald else IceCyan,
        secondaryAccent = SovereignGold,
        isHighlightedActive = diag.isReady,
        cornerRadius = 20.dp,
        lipDepth = 4.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Rw14QuantumEmblem(size = 44.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "AETHERIA // RW-14 v31.0",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${telemetry?.brand ?: "Android"} ${telemetry?.model ?: ""} · ${telemetry?.oemPhoneMaster?.managerName ?: "Phone Master Sync"}",
                    color = SovereignGold,
                    fontSize = 10.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(if (account != null) QuantumEmerald.copy(alpha = 0.18f) else CardInnerBg)
                    .border(1.dp, if (account != null) QuantumEmerald else IceCyan.copy(alpha = 0.5f), RoundedCornerShape(999.dp))
                    .clickable { onOpenAccount() }
                    .padding(horizontal = 9.dp, vertical = 5.dp)
            ) {
                Text(
                    text = if (account != null) "${account.provider.badgeIcon} ${account.displayName.take(9)}" else "👤 Login",
                    color = if (account != null) QuantumEmerald else IceCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (diag.isReady) Color(0xFF062C1E) else Color(0xFF1A223A))
                    .border(1.dp, if (diag.isReady) QuantumEmerald else SovereignGold, RoundedCornerShape(10.dp))
                    .clickable { onOpenBridges() }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(
                    text = diag.activeBridgeMode.badgeLabel,
                    color = if (diag.isReady) QuantumEmerald else SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.8.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (activeStackedCount > 0) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberViolet.copy(alpha = 0.22f))
                        .border(1.dp, CyberViolet, RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "🧩 $activeStackedCount Mode",
                        color = TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 9.8.sp,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}

@Composable
private fun GlobalFeatureSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    matchingItems: List<QuickSearchItem>
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(6.dp, RoundedCornerShape(14.dp))
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF0E1D3A), Color(0xFF081226))))
                .border(1.2.dp, IceCyan.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "🔍", fontSize = 14.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Box(modifier = Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = "Cari fitur instan (contoh: 120FPS, APK, Story WA, Charging, OTG)...",
                        color = TextSecondary.copy(alpha = 0.75f),
                        fontSize = 11.2.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = TextStyle(
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    cursorBrush = SolidColor(IceCyan),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "✖ Hapus",
                    color = AlertRose,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    modifier = Modifier.clickable { onQueryChange("") }
                )
            }
        }

        if (query.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Extruded3dConsoleCard(accentColor = SovereignGold, secondaryAccent = IceCyan, cornerRadius = 16.dp) {
                Text(
                    text = "⚡ HASIL PENCARIAN CEPAT (${matchingItems.size} FITUR):",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 10.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                if (matchingItems.isEmpty()) {
                    Text(
                        text = "Tidak ditemukan kata kunci \"$query\". Coba ketik: 120, apk, story, cas, kuota, audio, atau jalur.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                } else {
                    matchingItems.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(CardInnerBg)
                                .border(1.dp, IceCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                .clickable { item.onOpen() }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                Text(item.subtitle, color = TextSecondary, fontSize = 10.2.sp)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            StatusBadge(text = item.badge, color = QuantumEmerald)
                        }
                    }
                }
            }
        }
    }
}

// =============================================================================
// TAB 1: UNIFIED PHONE MASTER + AETHERIA SMART HUB (CLEAN 2-COLUMN GRID)
// =============================================================================

@Composable
private fun PhoneMasterUnifiedTab(
    telemetry: DeviceTelemetry?,
    diag: ShizukuDiagnostics,
    subPanel: MasterSubPanel,
    onSelectSubPanel: (MasterSubPanel) -> Unit,
    hdMediaEnabled: Boolean,
    onToggleHdMedia: (Boolean) -> Unit,
    turboChargeEnabled: Boolean,
    onToggleTurboCharge: (Boolean) -> Unit,
    bypassChargeEnabled: Boolean,
    onToggleBypassCharge: (Boolean) -> Unit,
    deepDozeEnabled: Boolean,
    onToggleDeepDoze: (Boolean) -> Unit,
    dualNetEnabled: Boolean,
    onToggleDualNet: (Boolean) -> Unit,
    adSdkBlockerEnabled: Boolean,
    onToggleAdSdkBlocker: (Boolean) -> Unit,
    discoveredApks: List<DiscoveredApkFile>,
    isScanningApks: Boolean,
    onRescanApks: () -> Unit,
    onPickApkFromStorage: () -> Unit,
    onInstallApkPath: (String, String) -> Unit,
    onOpenAllFilesPermission: () -> Unit,
    debloatItems: List<DebloatPackageItem>,
    isScanningDebloat: Boolean,
    onToggleDebloatPkg: (String, Boolean) -> Unit,
    onRestoreAllDebloat: () -> Unit,
    pingResults: List<PingServerResult>,
    isTestingPing: Boolean,
    onRunPingTest: () -> Unit,
    onFixMobileData: () -> Unit,
    onOpenRadioLock: () -> Unit,
    onRunAiMasterSweep: () -> Unit,
    onLaunchBuiltInPhoneMaster: () -> Unit,
    onRunStorageClean: () -> Unit,
    onRunMemoryBoost: () -> Unit,
    onRunCoolDown: () -> Unit,
    onRunMalwareScan: () -> Unit
) {
    val tempC = telemetry?.batteryTempC ?: 35.0
    val isHot = tempC >= 40.0
    val ramUsedGb = ((telemetry?.ramTotalMb ?: 4096L) - (telemetry?.ramAvailMb ?: 1536L)).coerceAtLeast(0L) / 1024.0
    val ramUsedLabel = String.format(Locale.US, "%.2f GB", ramUsedGb)
    val freeStorageGb = telemetry?.storageFreeGb ?: 64.0
    val battPct = telemetry?.batteryPercent ?: 80
    val isCharging = telemetry?.isCharging ?: false
    val phoneMasterName = telemetry?.oemPhoneMaster?.managerName ?: "Phone Master Bawaan HP"

    // Calculate live Phone Master Health Score (0-100)
    val tempPenalty = if (tempC >= 43.0) 16 else if (tempC >= 40.0) 9 else 0
    val ramPenalty = if ((telemetry?.ramUsedPercent ?: 60) >= 85) 8 else 0
    val bridgeBonus = if (diag.isReady) 4 else 0
    val healthScore = (96 - tempPenalty - ramPenalty + bridgeBonus).coerceIn(72, 100)

    if (subPanel != MasterSubPanel.GRID_HOME) {
        Tactile3dPushButton(
            text = "⬅️ Kembali ke 8 Menu Utama Phone Master",
            onClick = { onSelectSubPanel(MasterSubPanel.GRID_HOME) },
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep
        )
        Spacer(modifier = Modifier.height(10.dp))

        when (subPanel) {
            MasterSubPanel.STORAGE_CLEANER -> {
                SectionCard(title = "🗑️ Pembersihan Penyimpanan & Shader Cache") {
                    Text(
                        text = "Sisa Penyimpanan Tersedia: $freeStorageGb GB dari ${telemetry?.storageTotalGb ?: 128.0} GB (${telemetry?.hardwareSpecs?.storageType?.label ?: "Flash"}).",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Membersihkan cache sampah aplikasi, Unity/Unreal Shader Cache korup pasca update game, dan menjalankan NAND Flash FSTRIM tanpa menyentuh chat/foto WhatsApp & Instagram.",
                        color = TextSecondary,
                        fontSize = 11.2.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Tactile3dPushButton(
                        text = "🧹 Bersihkan Penyimpanan & Jalankan FSTRIM Sekarang",
                        onClick = onRunStorageClean,
                        modifier = Modifier.fillMaxWidth(),
                        faceColor = QuantumEmerald,
                        deepBaseColor = QuantumEmeraldDeep
                    )
                }
            }

            MasterSubPanel.APP_APK_MANAGER -> {
                AutoScanPowerApkInstallerCard(
                    discoveredApks = discoveredApks,
                    isScanningApks = isScanningApks,
                    onRescanApks = onRescanApks,
                    onPickApkFromStorage = onPickApkFromStorage,
                    onInstallApkPath = onInstallApkPath,
                    onOpenAllFilesPermission = onOpenAllFilesPermission
                )
                Spacer(modifier = Modifier.height(12.dp))
                CategorizedDebloaterCard(
                    debloatItems = debloatItems,
                    isScanningDebloat = isScanningDebloat,
                    onRescan = onRescanApks,
                    onToggleDebloatPkg = onToggleDebloatPkg,
                    onRestoreAll = onRestoreAllDebloat
                )
            }

            MasterSubPanel.MEMORY_BOOSTER -> {
                SectionCard(title = "🚀 Peningkat Memori RAM & Anti-Reload") {
                    Text(
                        text = "Penggunaan Memori Saat Ini: $ramUsedLabel (${telemetry?.ramUsedPercent ?: 60}% terpakai · Sisa ${telemetry?.ramAvailMb ?: 1500} MB).",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Membebaskan RAM aplikasi pasif, mematikan Phantom Process Killer Android 12–16 (agar game & WA/IG tidak reload), serta mengompilasi Speed OAT SystemUI & Home Launcher.",
                        color = TextSecondary,
                        fontSize = 11.2.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Tactile3dPushButton(
                        text = "🚀 Tingkatkan RAM & Speed Launcher Sekarang",
                        onClick = onRunMemoryBoost,
                        modifier = Modifier.fillMaxWidth(),
                        faceColor = QuantumEmerald,
                        deepBaseColor = QuantumEmeraldDeep
                    )
                }
            }

            MasterSubPanel.COOL_DOWN -> {
                SectionCard(
                    title = "❄️ Tenang — Pendingin Mesin & Baterai Cerdas",
                    isHighlightedActive = !isHot
                ) {
                    Text(
                        text = "Suhu Saat Ini: ${tempC}°C — ${if (isHot) "⚠️ PANAS TERDETEKSI, disarankan segera pendinginan!" else "🟢 Mesin & Baterai Adem Optimal"}",
                        color = if (isHot) AlertRose else QuantumEmerald,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Membekukan proses pemanas latar belakang, mematikan beban GPU Blur & pemindaian BLE pasif, serta menyinkronkan pendingin $phoneMasterName (WhatsApp & Instagram tetap 100% aman).",
                        color = TextSecondary,
                        fontSize = 11.2.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Tactile3dPushButton(
                        text = "❄️ Dinginkan Mesin Sekarang (Smart Cool-Boost)",
                        onClick = onRunCoolDown,
                        modifier = Modifier.fillMaxWidth(),
                        faceColor = IceCyan,
                        deepBaseColor = IceCyanDeep
                    )
                }
            }

            MasterSubPanel.BATTERY_FAST_CHARGE -> {
                SectionCard(
                    title = "⚡🔋 Pengoptimalan Baterai & Turbo Fast Charging",
                    isHighlightedActive = turboChargeEnabled
                ) {
                    val bh = telemetry?.hardwareSpecs?.batteryHealth
                    Text(
                        text = "Baterai Tersisa: $battPct% (${if (isCharging) "⚡ Sedang Mengisi Daya" else "Baterai"}) · Suhu: ${tempC}°C · Tegangan: ${telemetry?.batteryVoltageMv ?: 4000}mV",
                        color = SovereignGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                    if (bh != null) {
                        Text(
                            text = "Kesehatan Baterai: ${bh.healthPercent}% (${bh.healthLabel}) · Daya Real-Time: ${String.format(Locale.US, "%.1f", bh.realTimeWattageW)} W",
                            color = IceCyan,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    GraphicOptionToggleRow(
                        title = "⚡ Turbo Fast Charging & Cool-Charge Pro",
                        subtitle = "Matikan penahan trickle charge & turunkan panas (<39°C) saat di-cas agar watt charger masuk maksimal.",
                        checked = turboChargeEnabled,
                        onToggle = { onToggleTurboCharge(!turboChargeEnabled) }
                    )
                    GraphicOptionToggleRow(
                        title = "🔌 Smart Bypass Charging (Main Game Sambil Cas)",
                        subtitle = "Alirkan daya langsung ke mesin (Infinix/TECNO XArena, Samsung, ROG, OEM yang mendukung).",
                        checked = bypassChargeEnabled,
                        onToggle = { onToggleBypassCharge(!bypassChargingEnabled) }
                    )
                    GraphicOptionToggleRow(
                        title = "🌙 Deep Doze Hemat Baterai 60 Detik (WA & IG Bebas Tidur)",
                        subtitle = "Hemat baterai ekstrem saat layar mati tanpa menunda pesan/telepon WhatsApp & Instagram.",
                        checked = deepDozeEnabled,
                        onToggle = { onToggleDeepDoze(!deepDozeEnabled) }
                    )
                }
            }

            MasterSubPanel.NETWORK_ASSISTANT -> {
                SectionCard(title = "⇅ Asisten Jaringan, Kuota 4G/5G & Tes Ping Game", isHighlightedActive = dualNetEnabled) {
                    Text(
                        text = "Status Jaringan: ${telemetry?.networkTransportLabel ?: "Aktif"} · Mode DNS: ${telemetry?.privateDnsModeCurrent ?: "opportunistic"}",
                        color = QuantumEmerald,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    GraphicOptionToggleRow(
                        title = "🌐 Akselerasi Saluran Ganda (Boost Wi-Fi + Data Seluler)",
                        subtitle = "Siagakan jalur ganda Wi-Fi + 4G/5G simultan & matikan Wi-Fi scan pemicu lonjakan ping.",
                        checked = dualNetEnabled,
                        onToggle = { onToggleDualNet(!dualNetEnabled) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Tactile3dPushButton(
                            text = "📶 Perbaiki Kuota Data",
                            onClick = onFixMobileData,
                            modifier = Modifier.weight(1f),
                            faceColor = SovereignGold,
                            deepBaseColor = SovereignGoldDeep
                        )
                        Tactile3dPushButton(
                            text = "📡 Kunci 4G/5G Only",
                            onClick = onOpenRadioLock,
                            modifier = Modifier.weight(1f),
                            faceColor = IceCyan,
                            deepBaseColor = IceCyanDeep
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Tactile3dPushButton(
                        text = if (isTestingPing) "⏳ Mengukur Ping Server Game..." else "🎯 Tes Ping Real-Time (MLBB, PUBG, FF, Roblox)",
                        onClick = onRunPingTest,
                        modifier = Modifier.fillMaxWidth(),
                        faceColor = QuantumEmerald,
                        deepBaseColor = QuantumEmeraldDeep
                    )
                    if (pingResults.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        pingResults.forEach { p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(CardInnerBg)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(p.serverName, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(p.statusBadge, color = QuantumEmerald, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp)
                            }
                        }
                    }
                }
            }

            MasterSubPanel.HD_MEDIA_STORY -> {
                SectionCard(
                    title = "📸 HD Foto, Video & Story Booster (WA, IG, TikTok, FB, Telegram)",
                    isHighlightedActive = hdMediaEnabled
                ) {
                    Text(
                        text = "Mencegah sistem Android menurunkan bitrate Story WhatsApp, Instagram Reels/Story, dan TikTok menjadi buram 480p akibat deteksi penghemat data latar, sekaligus mengaktifkan Hardware Codec2 AVC/HEVC + Camera2 HAL3 + TCP Window besar (rwnd=60) untuk upload & download super cepat!",
                        color = TextSecondary,
                        fontSize = 11.3.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    GraphicOptionToggleRow(
                        title = "📸 Aktifkan Kualitas HD Upload/Download & Story Sosmed",
                        subtitle = "Mendukung WhatsApp, WA Business, Instagram Story, TikTok, Telegram & Facebook.",
                        checked = hdMediaEnabled,
                        onToggle = { onToggleHdMedia(!hdMediaEnabled) }
                    )
                }
            }

            MasterSubPanel.SECURITY_PRIVACY -> {
                SectionCard(title = "🔒 Pemindaian Keamanan, Anti-Iklan & Perisai WA/IG") {
                    Text(
                        text = "🛡️ Perisai Immortal Aktif: WhatsApp, WA Business & Instagram dikunci permanen agar TIDAK PERNAH dibekukan atau dimatikan oleh pembersih mana pun.",
                        color = QuantumEmerald,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.3.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    GraphicOptionToggleRow(
                        title = "🚫 Matikan Pop-Up Iklan Tanam (Ad-SDK Blocker Aman Kuota)",
                        subtitle = "Lumpuhkan layar iklan penuh (AdMob/UnityAds/AppLovin) tanpa mengganggu internet kuota 4G/5G.",
                        checked = adSdkBlockerEnabled,
                        onToggle = { onToggleAdSdkBlocker(!adSdkBlockerEnabled) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Tactile3dPushButton(
                        text = "🛡️ Pindai & Hapus Otomatis Virus APK Undangan/Kurir/Judol",
                        onClick = onRunMalwareScan,
                        modifier = Modifier.fillMaxWidth(),
                        faceColor = SovereignGold,
                        deepBaseColor = SovereignGoldDeep
                    )
                }
            }

            MasterSubPanel.GRID_HOME -> {}
        }
        return
    }

    // =========================================================================
    // MAIN UNIFIED PHONE MASTER + AETHERIA SMART HUB (MATCHES PHONE MASTER UI!)
    // =========================================================================
    Extruded3dConsoleCard(
        accentColor = if (isHot) AlertRose else QuantumEmerald,
        secondaryAccent = IceCyan,
        isHighlightedActive = !isHot
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularRingGauge(
                percent = healthScore / 100f,
                centerValue = "$healthScore",
                unitLabel = "SKOR MASTER",
                ringColor = if (isHot) AlertRose else QuantumEmerald,
                size = 92.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "✨ MANAJER AI TERPADU",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.5.sp
                )
                Text(
                    text = "Sistem digabung langsung dengan $phoneMasterName + ${telemetry?.oemGameBooster?.boosterName ?: "Game Boost HP"}!",
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isHot) "⚠️ Suhu ${tempC}°C terdeteksi hangat/panas — ketuk Optimalkan AI untuk mendinginkan!"
                    else "🟢 RAM $ramUsedLabel · Sisa $freeStorageGb GB · Suhu ${tempC}°C",
                    color = if (isHot) AlertRose else IceCyan,
                    fontSize = 10.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "✨ Optimalkan AI 1-Klik",
                onClick = onRunAiMasterSweep,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
            Tactile3dPushButton(
                text = "🔗 Buka Phone Master",
                onClick = onLaunchBuiltInPhoneMaster,
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Clean 2-Column Smart Grid (8 Cards matching Phone Master + AETHERIA Superpowers!)
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "🗑️",
            title = "Pembersihan\nPenyimpanan",
            subtitle = "Sisa tersedia $freeStorageGb GB",
            accentColor = IceCyan,
            onClick = { onSelectSubPanel(MasterSubPanel.STORAGE_CLEANER) }
        )
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "📦",
            title = "Manajemen\nAplikasi & APK",
            subtitle = "Auto-Scan APK & Debloat",
            accentColor = SovereignGold,
            badgeDotColor = QuantumEmerald,
            onClick = { onSelectSubPanel(MasterSubPanel.APP_APK_MANAGER) }
        )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "⇅",
            title = "Asisten\nJaringan",
            subtitle = if (dualNetEnabled) "Dual-Boost Aktif" else "Kuota 4G/5G & Ping",
            accentColor = if (dualNetEnabled) QuantumEmerald else IceCyan,
            onClick = { onSelectSubPanel(MasterSubPanel.NETWORK_ASSISTANT) }
        )
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "🔒",
            title = "Privasi &\nKeamanan",
            subtitle = if (adSdkBlockerEnabled) "Anti-Iklan & Virus ON" else " dalam Perlindungan",
            accentColor = QuantumEmerald,
            onClick = { onSelectSubPanel(MasterSubPanel.SECURITY_PRIVACY) }
        )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "❄️",
            title = "Tenang\n(Pendingin)",
            subtitle = if (isHot) "${tempC}°C, disarankan pendinginan!" else "${tempC}°C · Mesin Adem",
            subtitleColor = if (isHot) AlertRose else QuantumEmerald,
            accentColor = if (isHot) AlertRose else IceCyan,
            badgeDotColor = if (isHot) AlertRose else null,
            onClick = { onSelectSubPanel(MasterSubPanel.COOL_DOWN) }
        )
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "🚀",
            title = "Peningkat\nMemori RAM",
            subtitle = "Memori $ramUsedLabel (${telemetry?.ramUsedPercent ?: 60}%)",
            accentColor = CyberViolet,
            onClick = { onSelectSubPanel(MasterSubPanel.MEMORY_BOOSTER) }
        )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "⚡",
            title = "Baterai &\nFast Charging",
            subtitle = if (turboChargeEnabled) "⚡ Turbo Charge ON ($battPct%)" else "Baterai tersisa: $battPct%",
            subtitleColor = if (turboChargeEnabled) QuantumEmerald else TextSecondary,
            accentColor = if (turboChargeEnabled) QuantumEmerald else SovereignGold,
            onClick = { onSelectSubPanel(MasterSubPanel.BATTERY_FAST_CHARGE) }
        )
        PhoneMasterGridTile(
            modifier = Modifier.weight(1f),
            icon = "📸",
            title = "HD Media &\nStory WA/IG",
            subtitle = if (hdMediaEnabled) "📸 HD Story 1080p ON" else "Upload/Download HD",
            subtitleColor = if (hdMediaEnabled) QuantumEmerald else TextSecondary,
            accentColor = if (hdMediaEnabled) QuantumEmerald else CyberViolet,
            badgeDotColor = SovereignGold,
            onClick = { onSelectSubPanel(MasterSubPanel.HD_MEDIA_STORY) }
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Device Tier Advisor Summary Card
    val (tierTitle, tierAdvice) = remember(telemetry?.ramTotalMb, telemetry?.cpuCores) {
        DeviceTierAdvisor.classifyTier(telemetry?.ramTotalMb ?: 6144L, telemetry?.cpuCores ?: 8)
    }
    Extruded3dConsoleCard(accentColor = IceCyan, secondaryAccent = SovereignGold, cornerRadius = 18.dp, lipDepth = 4.dp) {
        Text(
            text = "🤖 DETEKSI SPESIFIKASI OTOMATIS: $tierTitle",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 10.8.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = tierAdvice, color = TextSecondary, fontSize = 10.8.sp)
    }
}

@Composable
private fun PhoneMasterGridTile(
    modifier: Modifier,
    icon: String,
    title: String,
    subtitle: String,
    accentColor: Color,
    subtitleColor: Color = TextSecondary,
    badgeDotColor: Color? = null,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(10.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(accentColor.copy(alpha = 0.28f))
            .clickable { onClick() }
            .padding(bottom = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF15294F), Color(0xFF091328))))
                .border(1.3.dp, accentColor.copy(alpha = 0.65f), RoundedCornerShape(20.dp))
                .padding(13.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(accentColor.copy(alpha = 0.35f), Color(0xFF0A1936))
                            )
                        )
                        .border(1.2.dp, accentColor, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = icon, fontSize = 18.sp)
                }
                if (badgeDotColor != null) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(badgeDotColor)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 12.8.sp,
                lineHeight = 16.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                color = subtitleColor,
                fontSize = 10.4.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// =============================================================================
// TAB 2: UNIVERSAL 120 FPS UNLOCKER (PUBG + ALL GAMES) & MULTI-MODE STACKABLE
// =============================================================================

@Composable
private fun FpsAndStackableModesTab(
    telemetry: DeviceTelemetry?,
    selectedFps: FpsUnlockPreset,
    onSelectFps: (FpsUnlockPreset) -> Unit,
    selectedGfx: GfxRenderQuality,
    onSelectGfx: (GfxRenderQuality) -> Unit,
    fpsUnlockedActive: Boolean,
    customGames: Set<String>,
    customGameInput: String,
    onCustomGameInputChange: (String) -> Unit,
    onAddCustomGame: (String) -> Unit,
    onUnlockAllGamesFps: () -> Unit,
    onResetAllGamesFps: () -> Unit,
    onUnlockSingleGameFps: (String, String) -> Unit,
    onCompileSingleGame: (String, String) -> Unit,
    stackedModesState: Map<StackableMode, Boolean>,
    onToggleStackableMode: (StackableMode, Boolean) -> Unit,
    onApplyMultiPreset: (Set<StackableMode>, String) -> Unit,
    onLaunchOemGameBooster: () -> Unit,
    autoSwitchOn: Boolean,
    onToggleAutoSwitch: (Boolean) -> Unit,
    onOpenUsageAccess: () -> Unit,
    floatingHudOn: Boolean,
    onToggleFloatingHud: (Boolean) -> Unit,
    overnightMaintOn: Boolean,
    onToggleOvernightMaint: (Boolean) -> Unit
) {
    var modeFilter by remember { mutableStateOf(0) } // 0 = Semua, 1 = Performa, 2 = Hemat & Adem

    // 1. UNIVERSAL 90 / 120 / 144 FPS & GFX UNLOCKER (PUBG + ALL GAMES)
    SectionCard(
        title = "🎮 Universal 120 FPS & GFX Unlocker (PUBG + Semua Game)",
        isHighlightedActive = fpsUnlockedActive
    ) {
        Text(
            text = "Membuka kunci 60 / 90 / 120 / 144 FPS untuk PUBG Mobile (Global/KR/VN/BGMI), MLBB, Free Fire, Genshin, CODM, Roblox & semua game di HP via Android GameManager API + Multi-OEM Refresh Lock (100% Aman Anti-Ban, tanpa ubah file .pak game!).",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Text("1️⃣ Pilih Target Frame Rate (FPS):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.2.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FpsUnlockPreset.values().forEach { preset ->
                SelectableChipButton(
                    modifier = Modifier.weight(1f),
                    title = "${preset.fps} FPS",
                    selected = (selectedFps == preset),
                    onClick = { onSelectFps(preset) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("2️⃣ Pilih Kualitas Grafis Render (GFX):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.2.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            GfxRenderQuality.values().take(2).forEach { q ->
                SelectableChipButton(
                    modifier = Modifier.weight(1f),
                    title = q.label,
                    selected = (selectedGfx == q),
                    onClick = { onSelectGfx(q) }
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            GfxRenderQuality.values().drop(2).forEach { q ->
                SelectableChipButton(
                    modifier = Modifier.weight(1f),
                    title = q.label,
                    selected = (selectedGfx == q),
                    onClick = { onSelectGfx(q) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Tactile3dPushButton(
            text = "🚀 Buka Kunci ${selectedFps.fps} FPS untuk PUBG & Semua Game (1-Klik)",
            onClick = onUnlockAllGamesFps,
            modifier = Modifier.fillMaxWidth(),
            faceColor = QuantumEmerald,
            deepBaseColor = QuantumEmeraldDeep
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "🎮 Buka ${telemetry?.oemGameBooster?.boosterName?.take(14) ?: "Game Boost"}",
                onClick = onLaunchOemGameBooster,
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
            Tactile3dPushButton(
                text = "↩️ Reset FPS Pabrik",
                onClick = onResetAllGamesFps,
                modifier = Modifier.weight(1f),
                faceColor = AlertRose,
                deepBaseColor = AlertRoseDeep,
                textColor = Color.White
            )
        }

        // Detected Games on Phone + Per-Game 120FPS & Speed Compile
        val installedGames = telemetry?.detectedGames?.filter { it.isInstalled }.orEmpty()
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "📱 Game Terdeteksi Otomatis di HP Ini (${installedGames.size + customGames.size} Game):",
            color = IceCyan,
            fontWeight = FontWeight.Bold,
            fontSize = 11.2.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        if (installedGames.isEmpty() && customGames.isEmpty()) {
            Text(
                text = "PUBG Mobile & 23 game populer sudah siap di-unlock otomatis oleh tombol 1-Klik di atas. Anda juga bisa menambah paket game custom di bawah:",
                color = TextSecondary,
                fontSize = 10.5.sp
            )
        } else {
            installedGames.take(8).forEach { game ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CardInnerBg)
                        .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(game.appName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(game.packageName, color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Tactile3dPushButton(
                        text = "${selectedFps.fps}FPS",
                        onClick = { onUnlockSingleGameFps(game.packageName, game.appName) },
                        faceColor = QuantumEmerald,
                        deepBaseColor = QuantumEmeraldDeep,
                        fontSizeSp = 10f
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Tactile3dPushButton(
                        text = "AOT",
                        onClick = { onCompileSingleGame(game.packageName, game.appName) },
                        faceColor = SovereignGold,
                        deepBaseColor = SovereignGoldDeep,
                        fontSizeSp = 10f
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardInnerBg)
                    .border(1.dp, IceCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 9.dp)
            ) {
                if (customGameInput.isEmpty()) {
                    Text("Tambah paket game lain (cth: com.tencent.ig)...", color = TextSecondary.copy(alpha = 0.65f), fontSize = 10.5.sp, maxLines = 1)
                }
                BasicTextField(
                    value = customGameInput,
                    onValueChange = onCustomGameInputChange,
                    singleLine = true,
                    textStyle = TextStyle(color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                    cursorBrush = SolidColor(IceCyan),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Tactile3dPushButton(
                text = "+ Tambah",
                onClick = { onAddCustomGame(customGameInput) },
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                fontSizeSp = 10.5f
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 2. MULTI-MODE STACKABLE ENGINE (SEPARATED PERFORMANCE VS BATTERY, 2+ SIMULTANEOUS!)
    val activeCount = stackedModesState.count { it.value }
    SectionCard(
        title = "🧩 Multi-Mode Combo (Aktifkan 2 Mode atau Lebih Sekaligus!)",
        isHighlightedActive = activeCount > 0
    ) {
        Text(
            text = "Dipisah rapi antara Kelompok Performa dan Kelompok Hemat Baterai/Pendingin. Anda bebas menyalakan 2, 3, atau lebih mode secara bersamaan ($activeCount Mode sedang aktif simultan)!",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Quick Multi-Combo Presets
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(
                text = "🔥+❄️ Performa + Adem",
                onClick = {
                    onApplyMultiPreset(
                        setOf(StackableMode.ESPORTS_PRO, StackableMode.QUAD_COMBO, StackableMode.SMART_COOL),
                        "🔥+❄️ Hybrid Combo (E-Sports Pro + Quad-Combo + Pendingin)"
                    )
                },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "🔋+⚡ Hemat + Fast Cas",
                onClick = {
                    onApplyMultiPreset(
                        setOf(StackableMode.BATTERY_SAVER, StackableMode.TURBO_CHARGE, StackableMode.SMART_COOL),
                        "🔋+⚡ Combo Hemat Daya + Turbo Fast Charge + Pendingin"
                    )
                },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                fontSizeSp = 10f
            )
        }

        if (activeCount > 0) {
            Spacer(modifier = Modifier.height(6.dp))
            Tactile3dPushButton(
                text = "⭕ Matikan Semua Mode Combo ($activeCount Aktif)",
                onClick = { onApplyMultiPreset(emptySet(), "⭕ Semua Mode Combo Dimatikan") },
                modifier = Modifier.fillMaxWidth(),
                faceColor = AlertRose,
                deepBaseColor = AlertRoseDeep,
                textColor = Color.White,
                fontSizeSp = 10.5f
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Chips: Semua | Performa | Hemat & Adem
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "Semua (8)",
                selected = (modeFilter == 0),
                onClick = { modeFilter = 0 }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🔥 Performa",
                selected = (modeFilter == 1),
                onClick = { modeFilter = 1 }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "❄️🔋 Hemat",
                selected = (modeFilter == 2),
                onClick = { modeFilter = 2 }
            )
        }

        if (modeFilter == 0 || modeFilter == 1) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = StackableModeCategory.PERFORMANCE.title,
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            StackableMode.values()
                .filter { it.category == StackableModeCategory.PERFORMANCE }
                .forEach { mode ->
                    val isOn = stackedModesState[mode] == true
                    GraphicOptionToggleRow(
                        title = mode.title,
                        subtitle = mode.subtitle,
                        checked = isOn,
                        onToggle = { onToggleStackableMode(mode, !isOn) }
                    )
                }
        }

        if (modeFilter == 0 || modeFilter == 2) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = StackableModeCategory.BATTERY_COOL.title,
                color = IceCyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            StackableMode.values()
                .filter { it.category == StackableModeCategory.BATTERY_COOL }
                .forEach { mode ->
                    val isOn = stackedModesState[mode] == true
                    GraphicOptionToggleRow(
                        title = mode.title,
                        subtitle = mode.subtitle,
                        checked = isOn,
                        onToggle = { onToggleStackableMode(mode, !isOn) }
                    )
                }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 3. FLOATING 3D GAMING HUD & AUTO-SWITCH DAEMON
    SectionCard(title = "🤖 Otomasi Deteksi Game & 3D Floating FPS HUD") {
        GraphicOptionToggleRow(
            title = "🎯 3D Floating Gaming HUD + Crosshair Aim",
            subtitle = "Tampilkan FPS real-time, ms, suhu °C, Watt baterai & tombol Boost melayang di atas game.",
            checked = floatingHudOn,
            onToggle = { onToggleFloatingHud(!floatingHudOn) }
        )
        GraphicOptionToggleRow(
            title = "🤖 Auto-Switch Mode Gaming Saat Buka Game",
            subtitle = "Otomatis gas performa penuh saat masuk game & kembali hemat kuota saat keluar game.",
            checked = autoSwitchOn,
            onToggle = { onToggleAutoSwitch(!autoSwitchOn) }
        )
        GraphicOptionToggleRow(
            title = "🌙 Perawatan Otomatis Malam Hari (Saat Idle & Di-Cas)",
            subtitle = "Jalankan bg-dexopt + fstrim otomatis dini hari saat layar mati.",
            checked = overnightMaintOn,
            onToggle = { onToggleOvernightMaint(!overnightMaintOn) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "⚙️ Buka Izin Akses Penggunaan (Usage Access) Bila Diperlukan",
            onClick = onOpenUsageAccess,
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep,
            fontSizeSp = 10.5f
        )
    }
}

// =============================================================================
// AUTOMATIC INTERNAL APK INSTALLER & CATEGORIZED MULTI-OEM DEBLOATER CARDS
// =============================================================================

@Composable
private fun AutoScanPowerApkInstallerCard(
    discoveredApks: List<DiscoveredApkFile>,
    isScanningApks: Boolean,
    onRescanApks: () -> Unit,
    onPickApkFromStorage: () -> Unit,
    onInstallApkPath: (String, String) -> Unit,
    onOpenAllFilesPermission: () -> Unit
) {
    SectionCard(title = "📦 Power APK Installer Otomatis (Tanpa Ketik Folder Manual!)") {
        Text(
            text = "Otomatis memindai seluruh file .apk di memori internal (Download, WhatsApp Documents, Telegram, Bluetooth, APKs) & mendukung instalasi bypass Downgrade (-d) + bypass blokir Android 14 sampai Android 16!",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = if (isScanningApks) "⏳ Memindai..." else "🔍 Scan Otomatis APK",
                onClick = onRescanApks,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 10.5f
            )
            Tactile3dPushButton(
                text = "📂 Pilih File APK Internal",
                onClick = onPickApkFromStorage,
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                fontSizeSp = 10.5f
            )
        }

        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "🔓 Izinkan Akses Semua File Internal (Agar Scan Folder 100% Lengkap)",
            onClick = onOpenAllFilesPermission,
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep,
            fontSizeSp = 10f
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "📋 Daftar File APK Terdeteksi di Memori Internal (${discoveredApks.size} File):",
            color = SovereignGold,
            fontWeight = FontWeight.Bold,
            fontSize = 11.2.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        if (discoveredApks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardInnerBg)
                    .border(1.dp, IceCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = if (isScanningApks) "Sedang memindai folder Download, WhatsApp, Telegram & Bluetooth..."
                    else "Belum terlihat file .apk di folder Download, atau ketuk '📂 Pilih File APK Internal' di atas untuk memilih langsung dari File Manager HP Anda!",
                    color = TextSecondary,
                    fontSize = 10.8.sp
                )
            }
        } else {
            discoveredApks.take(15).forEach { apk ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.5.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                        .border(1.1.dp, QuantumEmerald.copy(alpha = 0.45f), RoundedCornerShape(13.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "📦 ${apk.appLabel} (${apk.versionName})",
                                color = TextPrimary,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "📁 ${apk.folderLabel} · ${apk.sizeMb} MB · ${apk.fileName}",
                                color = IceCyan,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Tactile3dPushButton(
                            text = "⚡ Install Bypass",
                            onClick = { onInstallApkPath(apk.fullPath, apk.fileName) },
                            faceColor = QuantumEmerald,
                            deepBaseColor = QuantumEmeraldDeep,
                            fontSizeSp = 10f
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategorizedDebloaterCard(
    debloatItems: List<DebloatPackageItem>,
    isScanningDebloat: Boolean = false,
    onRescan: () -> Unit,
    onToggleDebloatPkg: (String, Boolean) -> Unit,
    onRestoreAll: () -> Unit
) {
    val installedBloat = debloatItems.filter { it.isInstalled }
    SectionCard(title = "🧊 Manajemen Aplikasi & Multi-OEM Bloatware Freezer") {
        Text(
            text = "Bekukan aplikasi iklan/bloatware bawaan pabrik agar hemat RAM & baterai (0 MB RAM) tanpa menghapus permanen. WhatsApp & Instagram dikunci Immortal (tidak pernah tersentuh!).",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = if (isScanningDebloat) "⏳ Memindai..." else "🔄 Pindai Bloatware HP",
                onClick = onRescan,
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                fontSizeSp = 10.5f
            )
            Tactile3dPushButton(
                text = "🟢 Pulihkan Semua",
                onClick = onRestoreAll,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 10.5f
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        if (installedBloat.isEmpty()) {
            Text(
                text = "Ketuk '🔄 Pindai Bloatware HP' untuk menampilkan aplikasi prainstal pabrik yang terpasang di HP ini.",
                color = TextSecondary,
                fontSize = 10.8.sp
            )
        } else {
            installedBloat.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CardInnerBg)
                        .border(
                            1.dp,
                            if (item.isDisabled) QuantumEmerald else SovereignGold.copy(alpha = 0.35f),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${item.appName} ${if (item.isDisabled) "[BEKU ❄️]" else "[AKTIF]"}",
                            color = if (item.isDisabled) QuantumEmerald else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.3.sp
                        )
                        Text(text = "${item.category} · ${item.packageName}", color = TextSecondary, fontSize = 9.8.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Tactile3dPushButton(
                        text = if (item.isDisabled) "Pulihkan" else "Bekukan",
                        onClick = { onToggleDebloatPkg(item.packageName, item.isDisabled) },
                        faceColor = if (item.isDisabled) QuantumEmerald else SovereignGold,
                        deepBaseColor = if (item.isDisabled) QuantumEmeraldDeep else SovereignGoldDeep,
                        fontSizeSp = 10f
                    )
                }
            }
        }
    }
}

// =============================================================================
// TAB 3: CLEAN COLLAPSIBLE 8-CATEGORY TWEAKS ACCORDION (ZERO CLUTTER!)
// =============================================================================

@Composable
private fun OrganizedTweaksAccordionTab(
    expandedSection: Int,
    onSelectSection: (Int) -> Unit,
    telemetry: DeviceTelemetry?,
    hdMediaEnabled: Boolean,
    onToggleHdMedia: (Boolean) -> Unit,
    iphoneAudioEnabled: Boolean,
    onToggleIphoneAudio: (Boolean) -> Unit,
    btGamingLowLatency: Boolean,
    onToggleBtGaming: (Boolean) -> Unit,
    turboChargeEnabled: Boolean,
    onToggleTurboCharge: (Boolean) -> Unit,
    bypassChargeEnabled: Boolean,
    onToggleBypassCharge: (Boolean) -> Unit,
    deepDozeEnabled: Boolean,
    onToggleDeepDoze: (Boolean) -> Unit,
    discoveredApks: List<DiscoveredApkFile>,
    isScanningApks: Boolean,
    onRescanApks: () -> Unit,
    onPickApkFromStorage: () -> Unit,
    onInstallApkPath: (String, String) -> Unit,
    onOpenAllFilesPermission: () -> Unit,
    debloatItems: List<DebloatPackageItem>,
    onToggleDebloatPkg: (String, Boolean) -> Unit,
    onRestoreAllDebloat: () -> Unit,
    vulkanEnabled: Boolean,
    onToggleVulkan: (Boolean) -> Unit,
    framePacingEnabled: Boolean,
    onToggleFramePacing: (Boolean) -> Unit,
    onSelectRefreshRate: (Int) -> Unit,
    onSelectColorMode: (Int) -> Unit,
    inGameTouchGuard: Boolean,
    onToggleInGameGuard: (Boolean) -> Unit,
    onApplySafeCustomDpi: (Int) -> Unit,
    onResetDefaultDpi: () -> Unit,
    powerHalEnabled: Boolean,
    onTogglePowerHal: (Boolean) -> Unit,
    onCompileSystemUi: () -> Unit,
    onApplyMultitasking: (Int) -> Unit,
    virtualRamEnabled: Boolean,
    onToggleVirtualRam: (Boolean) -> Unit,
    onBoostTouch240Hz: () -> Unit,
    gyro200HzEnabled: Boolean,
    onToggleGyro200Hz: (Boolean) -> Unit,
    onSelectAnimScale: (Float) -> Unit,
    onSelectHapticLevel: (Int) -> Unit,
    rawControllerEnabled: Boolean,
    onToggleRawController: (Boolean) -> Unit,
    dualNetEnabled: Boolean,
    onToggleDualNet: (Boolean) -> Unit,
    onFixMobileData: () -> Unit,
    onSelectDnsProfile: (String) -> Unit,
    gameFirewallEnabled: Boolean,
    onToggleGameFirewall: (Boolean) -> Unit,
    onOpenRadioLock: () -> Unit,
    freeformEnabled: Boolean,
    onToggleFreeform: (Boolean) -> Unit,
    cleanStatusBarEnabled: Boolean,
    onToggleCleanStatusBar: (Boolean) -> Unit,
    onRunOvernightNow: () -> Unit,
    whitelistedPackages: Set<String>,
    onToggleWhitelist: (String, Boolean) -> Unit
) {
    var dpiInput by remember { mutableStateOf("410") }

    MenuGuideBanner(
        title = "8 KATEGORI TWEAKS RAPI (KETUK KATEGORI UNTUK MEMBUKA / MENUTUP)",
        guideText = "Seluruh 38+ tweaks sistem dikelompokkan rapi dalam 8 laci lipat (Accordion) agar tidak berantakan dan langsung ketemu!"
    )

    // 1. HD Media, Story & Audio iPhone
    AccordionCategoryCard(
        index = 0,
        title = "1. 📸 HD Story WA/IG/TikTok & Audio Speaker iPhone",
        subtitle = "Upload/Download Foto & Video HD + Spatial Audio DSP + Bluetooth Gaming/LDAC",
        expanded = (expandedSection == 0),
        onToggleExpand = { onSelectSection(0) }
    ) {
        GraphicOptionToggleRow(
            title = "📸 HD Foto, Video & Story Upload/Download Booster",
            subtitle = "Bitrate penuh 1080p/60FPS + Codec2 HW + Camera2 HAL3 untuk WA, IG, TikTok, FB & Telegram.",
            checked = hdMediaEnabled,
            onToggle = { onToggleHdMedia(!hdMediaEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🎧 Modul Suara Speaker & Headset Setara iPhone + 30-Step Volume",
            subtitle = "Hardware DSP Clarity, Bass punchy & vokal jernih untuk musik, film & langkah kaki game.",
            checked = iphoneAudioEnabled,
            onToggle = { onToggleIphoneAudio(!iphoneAudioEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🎮 Bluetooth TWS Mode Gaming Low-Latency (OFF = Hi-Res LDAC 990kbps)",
            subtitle = "Pangkas delay suara langkah kaki/tembakan TWS saat mabar.",
            checked = btGamingLowLatency,
            onToggle = { onToggleBtGaming(!btGamingLowLatency) }
        )
    }

    // 2. Turbo Fast Charging & Battery
    AccordionCategoryCard(
        index = 1,
        title = "2. ⚡ Turbo Fast Charging, Bypass Cas & Deep Doze",
        subtitle = "Pengisian daya cepat adem (<39°C), Bypass Charging game & hemat baterai",
        expanded = (expandedSection == 1),
        onToggleExpand = { onSelectSection(1) }
    ) {
        GraphicOptionToggleRow(
            title = "⚡ Turbo Fast Charging & Cool-Charge Thermal Drop",
            subtitle = "Matikan adaptive trickle hold & turunkan panas parasit agar watt charger maksimal.",
            checked = turboChargeEnabled,
            onToggle = { onToggleTurboCharge(!turboChargeEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🔌 Smart Bypass Charging (Direct Power Game)",
            subtitle = "Alirkan listrik langsung ke mesin saat main game (untuk HP yang mendukung).",
            checked = bypassChargeEnabled,
            onToggle = { onToggleBypassCharge(!bypassChargeEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🌙 Deep Doze Hemat Baterai 60 Detik (WA & IG Bebas Tidur)",
            subtitle = "Tidurkan penguras baterai latar saat layar mati (notifikasi WA & IG tetap instan).",
            checked = deepDozeEnabled,
            onToggle = { onToggleDeepDoze(!deepDozeEnabled) }
        )
    }

    // 3. Auto-Scan Power APK Installer & Debloater
    AccordionCategoryCard(
        index = 2,
        title = "3. 📦 Power APK Installer Otomatis & Debloater",
        subtitle = "Scan otomatis APK di memori internal + Bypass Downgrade & Android 14–16",
        expanded = (expandedSection == 2),
        onToggleExpand = { onSelectSection(2) }
    ) {
        AutoScanPowerApkInstallerCard(
            discoveredApks = discoveredApks,
            isScanningApks = isScanningApks,
            onRescanApks = onRescanApks,
            onPickApkFromStorage = onPickApkFromStorage,
            onInstallApkPath = onInstallApkPath,
            onOpenAllFilesPermission = onOpenAllFilesPermission
        )
        Spacer(modifier = Modifier.height(10.dp))
        CategorizedDebloaterCard(
            debloatItems = debloatItems,
            onRescan = onRescanApks,
            onToggleDebloatPkg = onToggleDebloatPkg,
            onRestoreAll = onRestoreAllDebloat
        )
    }

    // 4. Graphics Vulkan, Refresh Rate, Color & Safe Custom DPI
    AccordionCategoryCard(
        index = 3,
        title = "4. 🎨 Grafis Vulkan, Layar Hz, Warna & Custom DPI",
        subtitle = "SkiaVK, Penstabil Bingkai, Kunci 60–144Hz, Kontras Gamer & DPI Aman 15s",
        expanded = (expandedSection == 3),
        onToggleExpand = { onSelectSection(3) }
    ) {
        GraphicOptionToggleRow(
            title = "🎨 Engine Renderer Vulkan (SkiaVK) + 100% GPU Composition",
            subtitle = "Pindahkan beban render UI & game dari OpenGL lama ke multi-thread Vulkan.",
            checked = vulkanEnabled,
            onToggle = { onToggleVulkan(!vulkanEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🎞️ Penstabilan Bingkai SurfaceFlinger (Zero VSync Lag)",
            subtitle = "Kirim frame GPU langsung ke layar tanpa ditahan buffer VSync.",
            checked = framePacingEnabled,
            onToggle = { onToggleFramePacing(!framePacingEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🛡️ Kunci Kecerahan Anti-Redup & Anti-Mistouch Notifikasi",
            subtitle = "Cegah layar tiba-tiba gelap atau salah pencet pop-up saat teamfight.",
            checked = inGameTouchGuard,
            onToggle = { onToggleInGameGuard(!inGameTouchGuard) }
        )

        Spacer(modifier = Modifier.height(8.dp))
        Text("🖥️ Kunci Refresh Rate Multi-Brand:", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0 to "Adaptif", 60 to "60Hz", 90 to "90Hz", 120 to "120Hz", 144 to "144Hz").forEach { (hz, lbl) ->
                Tactile3dPushButton(
                    text = lbl,
                    onClick = { onSelectRefreshRate(hz) },
                    modifier = Modifier.weight(1f),
                    faceColor = IceCyan,
                    deepBaseColor = IceCyanDeep,
                    fontSizeSp = 9.5f
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text("🌈 Kalibrasi Warna & Visibilitas Musuh:", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(text = "Normal", onClick = { onSelectColorMode(0) }, modifier = Modifier.weight(1f), faceColor = IceCyan, deepBaseColor = IceCyanDeep, fontSizeSp = 10f)
            Tactile3dPushButton(text = "Vivid AMOLED", onClick = { onSelectColorMode(1) }, modifier = Modifier.weight(1f), faceColor = QuantumEmerald, deepBaseColor = QuantumEmeraldDeep, fontSizeSp = 10f)
            Tactile3dPushButton(text = "Pro Gamer", onClick = { onSelectColorMode(2) }, modifier = Modifier.weight(1f), faceColor = SovereignGold, deepBaseColor = SovereignGoldDeep, fontSizeSp = 10f)
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("📐 Custom DPI Aman (280–600 · Dilindungi Timer Auto-Revert 15 Detik):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardInnerBg)
                    .border(1.dp, IceCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 9.dp)
            ) {
                BasicTextField(
                    value = dpiInput,
                    onValueChange = { dpiInput = it.filter { ch -> ch.isDigit() }.take(3) },
                    singleLine = true,
                    textStyle = TextStyle(color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace),
                    cursorBrush = SolidColor(IceCyan),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Tactile3dPushButton(
                text = "Terapkan DPI",
                onClick = { dpiInput.toIntOrNull()?.let { onApplySafeCustomDpi(it) } },
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "Reset DPI",
                onClick = onResetDefaultDpi,
                faceColor = AlertRose,
                deepBaseColor = AlertRoseDeep,
                textColor = Color.White,
                fontSizeSp = 10f
            )
        }
    }

    // 5. CPU, ART Speed Compiler & RAM
    AccordionCategoryCard(
        index = 4,
        title = "5. 🧠 CPU Power HAL, Speed SystemUI & Virtual RAM",
        subtitle = "Kunci frekuensi Power HAL, kompilasi bahasa mesin & matikan Phantom Killer",
        expanded = (expandedSection == 4),
        onToggleExpand = { onSelectSection(4) }
    ) {
        GraphicOptionToggleRow(
            title = "⚡ Power HAL Fixed Performance Mode (Kunci Clock CPU/GPU)",
            subtitle = "Tahan frekuensi Big Cores prosesor saat bermain game berat.",
            checked = powerHalEnabled,
            onToggle = { onTogglePowerHal(!powerHalEnabled) }
        )
        GraphicOptionToggleRow(
            title = "💾 Virtual RAM / RAM Plus / MemFusion (Matikan di HP eMMC Agar Tidak Lag!)",
            subtitle = "Storage HP ini: ${telemetry?.hardwareSpecs?.storageType?.label ?: "Flash"}.",
            checked = virtualRamEnabled,
            onToggle = { onToggleVirtualRam(!virtualRamEnabled) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "🚀 Kompilasi Speed OAT SystemUI & Home Launcher (Bebas Patah-Patah)",
            onClick = onCompileSystemUi,
            modifier = Modifier.fillMaxWidth(),
            faceColor = QuantumEmerald,
            deepBaseColor = QuantumEmeraldDeep,
            fontSizeSp = 10.5f
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(
                text = "🎮 Fokus RAM Game (8 App)",
                onClick = { onApplyMultitasking(8) },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "🔄 Anti-Reload (32 App)",
                onClick = { onApplyMultitasking(32) },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                fontSizeSp = 10f
            )
        }
    }

    // 6. Touch, Gyro, Decimal Animation & Controller
    AccordionCategoryCard(
        index = 5,
        title = "6. 👆 Sentuhan 240Hz, Gyro 200Hz & Skala Animasi",
        subtitle = "Input lag 140ms, recoil Gyroscope PUBG/CODM, animasi desimal & Haptic",
        expanded = (expandedSection == 5),
        onToggleExpand = { onSelectSection(5) }
    ) {
        Tactile3dPushButton(
            text = "👆 Aktifkan Touch Polling 240Hz + Flick Kamera Cepat (140ms)",
            onClick = onBoostTouch240Hz,
            modifier = Modifier.fillMaxWidth(),
            faceColor = QuantumEmerald,
            deepBaseColor = QuantumEmeraldDeep,
            fontSizeSp = 10.5f
        )
        Spacer(modifier = Modifier.height(6.dp))
        GraphicOptionToggleRow(
            title = "🎯 Gyroscope & Sensor Fast-Polling 200Hz (PUBG / CODM)",
            subtitle = "Kurangi delay kemiringan sensor gyro untuk kontrol recoil akurat.",
            checked = gyro200HzEnabled,
            onToggle = { onToggleGyro200Hz(!gyro200HzEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🎮 Kalibrasi Raw Input Gamepad Bluetooth & Mouse OTG",
            subtitle = "Matikan akselerasi acak kursor & kurangi latensi kontroler eksternal.",
            checked = rawControllerEnabled,
            onToggle = { onToggleRawController(!rawControllerEnabled) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text("✨ Skala Animasi Desimal Presisi:", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf(0.0f to "0.0x", 0.25f to "0.25x", 0.5f to "0.5x", 0.7f to "0.7x", 1.0f to "1.0x").forEach { (sc, lbl) ->
                Tactile3dPushButton(
                    text = lbl,
                    onClick = { onSelectAnimScale(sc) },
                    modifier = Modifier.weight(1f),
                    faceColor = IceCyan,
                    deepBaseColor = IceCyanDeep,
                    fontSizeSp = 9.5f
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("📳 Intensitas Getar Haptic (0 = Mati Hemat Daya .. 3 = Kuat):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0 to "0 (OFF)", 1 to "Level 1", 2 to "Level 2", 3 to "Level 3").forEach { (lvl, lbl) ->
                Tactile3dPushButton(
                    text = lbl,
                    onClick = { onSelectHapticLevel(lvl) },
                    modifier = Modifier.weight(1f),
                    faceColor = SovereignGold,
                    deepBaseColor = SovereignGoldDeep,
                    fontSizeSp = 9.5f
                )
            }
        }
    }

    // 7. Network, Kuota Data Repair, Firewall & 4G/5G Lock
    AccordionCategoryCard(
        index = 6,
        title = "7. 🌐 Jaringan Ganda, Perbaiki Kuota & Firewall Game",
        subtitle = "Boost Wi-Fi + Data, DNS Aman Kuota, Firewall Game (WA/IG Aman) & 4G/5G Lock",
        expanded = (expandedSection == 6),
        onToggleExpand = { onSelectSection(6) }
    ) {
        GraphicOptionToggleRow(
            title = "🌐 Akselerasi Jaringan Saluran Ganda (Wi-Fi + Data Seluler)",
            subtitle = "Stabilkan ping game & sosmed, matikan Wi-Fi scan lag.",
            checked = dualNetEnabled,
            onToggle = { onToggleDualNet(!dualNetEnabled) }
        )
        GraphicOptionToggleRow(
            title = "🛡️ Firewall Fokus Bandwith Game (WA & IG 100% Tetap Lancar)",
            subtitle = "Tahan update latar aplikasi lain saat bermain game agar ping tidak melonjak.",
            checked = gameFirewallEnabled,
            onToggle = { onToggleGameFirewall(!gameFirewallEnabled) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(
                text = "📶 Perbaiki Kuota 4G/5G",
                onClick = onFixMobileData,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "⚡ DNS Gaming 1.1.1.1",
                onClick = { onSelectDnsProfile("cloudflare_gaming") },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                fontSizeSp = 10f
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "📡 Buka Menu Pengunci Sinyal 4G LTE Only / 5G NR Only",
            onClick = onOpenRadioLock,
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep,
            fontSizeSp = 10.5f
        )
    }

    // 8. Productivity, Freeform Windows & Whitelist WA/IG
    AccordionCategoryCard(
        index = 7,
        title = "8. 🪟 Freeform Jendela Melayang & Whitelist WA/IG",
        subtitle = "Split-screen semua game, Anti Burn-In AMOLED & aplikasi bebas pembersihan",
        expanded = (expandedSection == 7),
        onToggleExpand = { onSelectSection(7) }
    ) {
        GraphicOptionToggleRow(
            title = "🪟 Buka Kunci Freeform Multi-Window & Paksa Split-Screen",
            subtitle = "Buka aplikasi/game apa saja dalam jendela melayang bebas ukuran.",
            checked = freeformEnabled,
            onToggle = { onToggleFreeform(!freeformEnabled) }
        )
        GraphicOptionToggleRow(
            title = "📱 Pembersih Ikon Status Bar (Anti Burn-In Layar AMOLED)",
            subtitle = "Sembunyikan ikon statis pemicu bayangan layar.",
            checked = cleanStatusBarEnabled,
            onToggle = { onToggleCleanStatusBar(!cleanStatusBarEnabled) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "🌙 Jalankan Perawatan Mendalam (Dexopt + FSTRIM) Sekarang",
            onClick = onRunOvernightNow,
            modifier = Modifier.fillMaxWidth(),
            faceColor = QuantumEmerald,
            deepBaseColor = QuantumEmeraldDeep,
            fontSizeSp = 10.5f
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text("🛡️ Daftar Whitelist Anti-Mati (WA & IG Dikunci Permanen):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(4.dp))
        AetheriaIdentity.DEFAULT_WHITELIST_OPTIONS.forEach { (pkg, label) ->
            val isImmortal = OemDebloatDatabase.isImmortalProtected(pkg)
            val checked = isImmortal || (pkg in whitelistedPackages)
            GraphicOptionToggleRow(
                title = label,
                subtitle = if (isImmortal) "🔒 Dikunci Permanen (Tidak pernah dimatikan)" else pkg,
                checked = checked,
                onToggle = { if (!isImmortal) onToggleWhitelist(pkg, !checked) }
            )
        }
    }
}

@Composable
private fun AccordionCategoryCard(
    index: Int,
    title: String,
    subtitle: String,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Extruded3dConsoleCard(
        modifier = Modifier.padding(bottom = 10.dp),
        accentColor = if (expanded) QuantumEmerald else IceCyan,
        secondaryAccent = SovereignGold,
        isHighlightedActive = expanded,
        cornerRadius = 18.dp,
        lipDepth = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onToggleExpand() },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = if (expanded) QuantumEmerald else SovereignGold,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.2.sp
                )
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 10.4.sp,
                    maxLines = if (expanded) 2 else 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (expanded) QuantumEmerald.copy(alpha = 0.2f) else CardInnerBg)
                    .border(1.dp, if (expanded) QuantumEmerald else IceCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 9.dp, vertical = 5.dp)
            ) {
                Text(
                    text = if (expanded) "▲ Tutup" else "▼ Buka",
                    color = if (expanded) QuantumEmerald else IceCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    softWrap = false
                )
            }
        }

        if (expanded) {
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

// =============================================================================
// TAB 4: 6-PATH SYSTEM PENETRATION CENTER (OMNIBRIDGE 6-JALUR)
// =============================================================================

@Composable
private fun OmniBridgeSixPathTab(
    diag: ShizukuDiagnostics,
    shizukuManager: ShizukuBridgeManager,
    onOpenWizard: () -> Unit,
    onRefreshAndAutoGrant: () -> Unit
) {
    var copiedMsg by remember { mutableStateOf("") }

    SectionCard(
        title = "🔗 Pusat 6-Jalur Tembus Sistem (Tidak Bergantung 2 APK Saja!)",
        isHighlightedActive = diag.isReady
    ) {
        Text(
            text = "Jalur Aktif Saat Ini: ${diag.activeBridgeMode.badgeLabel}",
            color = if (diag.isReady) QuantumEmerald else SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = diag.diagnosticMessage, color = TextPrimary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "🔄 Cek & Kunci Izin",
                onClick = onRefreshAndAutoGrant,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
            Tactile3dPushButton(
                text = "🧙 Panduan 6-Jalur",
                onClick = onOpenWizard,
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
        }

        if (copiedMsg.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = copiedMsg, color = QuantumEmerald, fontWeight = FontWeight.Bold, fontSize = 10.8.sp)
        }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // JALUR 6 (PALING MUDAH - TANPA APLIKASI LUAR SAMA SEKALI!)
    SectionCard(
        title = "🔵 Jalur 6: Tanpa Aplikasi Luar (Langsung di HP & Permanen)",
        isHighlightedActive = diag.writeSecureSettingsGranted || diag.writeSystemSettingsGranted
    ) {
        Text(
            text = "Jika HP tidak cocok dengan Shizuku maupun Brevent:\n" +
                "• 6B (Langsung Tanpa Kabel/Wi-Fi): Aktifkan tombol 'Ubah Pengaturan Sistem' langsung di Pengaturan HP Anda.\n" +
                "• 6A (Permanen Selamanya): Sekali jalankan kode WRITE_SECURE_SETTINGS (lewat HP teman / LADB / Warnet), AETHERIA tembus sistem selamanya walau semua APK lain dihapus!",
            color = TextSecondary,
            fontSize = 10.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = if (diag.writeSystemSettingsGranted) "✅ Izin Ubah Sistem HP (WRITE_SETTINGS) Sudah Aktif"
            else "⚙️ Aktifkan Izin Ubah Sistem Langsung di HP (Tanpa APK Luar)",
            onClick = { shizukuManager.openWriteSystemSettingsScreen() },
            modifier = Modifier.fillMaxWidth(),
            faceColor = if (diag.writeSystemSettingsGranted) QuantumEmerald else IceCyan,
            deepBaseColor = if (diag.writeSystemSettingsGranted) QuantumEmeraldDeep else IceCyanDeep,
            fontSizeSp = 10.5f
        )
        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "📋 Salin Kode Grant Permanen (WRITE_SECURE_SETTINGS)",
            onClick = {
                shizukuManager.copyCommandToClipboard("Grant Permanen AETHERIA", diag.universalAdbGrantCommand)
                copiedMsg = "✅ Kode Grant Permanen disalin ke Clipboard!"
            },
            modifier = Modifier.fillMaxWidth(),
            faceColor = SovereignGold,
            deepBaseColor = SovereignGoldDeep,
            fontSizeSp = 10.5f
        )
    }

    Spacer(modifier = Modifier.height(10.dp))

    // JALUR 4: BUGJAEGER OTG (COLOK KABEL KE HP TEMAN - TANPA WIFI & TANPA PC!) + AXMANAGER
    SectionCard(
        title = "🟠 Jalur 4: Bugjaeger OTG (HP-ke-HP Tanpa Wi-Fi) & AxManager",
        isHighlightedActive = diag.breventBridgeActive
    ) {
        Text(
            text = "Solusi paling ampuh untuk Android 10–16 yang susah Wireless Debugging: instal Bugjaeger di HP teman, colok kabel Type-C dari HP teman ke HP ini, lalu tempel kode aktivasi 1 baris!",
            color = TextSecondary,
            fontSize = 10.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(
                text = "🔌 Salin & Bugjaeger OTG",
                onClick = {
                    shizukuManager.copyCommandToClipboard("Kode OTG AETHERIA", diag.breventActivationCommand)
                    copiedMsg = "✅ Kode Worker UID-2000 disalin! Tempel di Bugjaeger -> Shell."
                    shizukuManager.openPartnerBridgeOrStore(AetheriaIdentity.BUGJAEGER_PACKAGE)
                },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "⚡ Salin & AxManager",
                onClick = {
                    shizukuManager.copyCommandToClipboard("Kode AxManager AETHERIA", diag.breventActivationCommand)
                    copiedMsg = "✅ Kode Worker UID-2000 disalin!"
                    shizukuManager.openPartnerBridgeOrStore(
                        AetheriaIdentity.AXMANAGER_PACKAGE,
                        "https://github.com/fahrez256/AxManager"
                    )
                },
                modifier = Modifier.weight(1f),
                faceColor = CyberViolet,
                deepBaseColor = CyberVioletDeep,
                textColor = Color.White,
                fontSizeSp = 10f
            )
        }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // JALUR 3: LADB / QUTE / TERMUX ADB SHELL
    SectionCard(title = "🩵 Jalur 3: LADB / Qute / Termux Wireless ADB") {
        Text(
            text = "Alternatif ringan pengganti Shizuku & Brevent. Mendukung LADB, Qute Command Console, maupun Termux `adb shell` menggunakan worker UID-2000 yang sama.",
            color = TextSecondary,
            fontSize = 10.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(
                text = "💻 Salin & Buka LADB",
                onClick = {
                    shizukuManager.copyCommandToClipboard("Kode LADB AETHERIA", diag.breventActivationCommand)
                    copiedMsg = "✅ Kode disalin! Tempel di baris perintah LADB."
                    shizukuManager.openPartnerBridgeOrStore(AetheriaIdentity.LADB_PACKAGE)
                },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "⌨️ Salin & Buka Qute",
                onClick = {
                    shizukuManager.copyCommandToClipboard("Kode Qute AETHERIA", diag.breventActivationCommand)
                    copiedMsg = "✅ Kode disalin! Tempel di Qute Terminal."
                    shizukuManager.openPartnerBridgeOrStore(AetheriaIdentity.QUTE_PACKAGE)
                },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 10f
            )
        }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // JALUR 1 & 2 & 5: SHIZUKU, BREVENT & ROOT SU
    SectionCard(title = "🟢🟣🔴 Jalur 1 (Shizuku), Jalur 2 (Brevent) & Jalur 5 (Root SU)") {
        Text(
            text = "• Shizuku: ${if (diag.isShizukuReady) "AKTIF (UID 2000)" else "Siaga"}\n" +
                "• Brevent Worker: ${if (diag.breventBridgeActive) "AKTIF (UID 2000)" else "Siaga"}\n" +
                "• Root / Magisk / KernelSU: ${if (diag.rootSuAvailable) "AKTIF OTOMATIS (UID 0)" else "Non-Root Aman"}",
            color = TextPrimary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(
                text = if (diag.binderAlive && !diag.isShizukuReady) "🔑 Izin Shizuku" else "🟢 Buka Shizuku",
                onClick = {
                    if (diag.binderAlive && !diag.isShizukuReady) shizukuManager.requestPermissionSafely()
                    else shizukuManager.openShizukuOrPlayStore()
                },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "🟣 Salin & Brevent",
                onClick = {
                    shizukuManager.copyBreventCommandAndOpenApp(true)
                    copiedMsg = "✅ Kode Brevent disalin! Tempel di Brevent -> Exec Command."
                },
                modifier = Modifier.weight(1f),
                faceColor = CyberViolet,
                deepBaseColor = CyberVioletDeep,
                textColor = Color.White,
                fontSizeSp = 10f
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "⚙️ Buka Opsi Pengembang (Wireless Debugging & Matikan Batas Izin Xiaomi/OPPO)",
            onClick = { shizukuManager.openDeveloperOptions() },
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep,
            fontSizeSp = 10f
        )
    }
}

// =============================================================================
// TAB 5: ACCOUNT LOGIN (GOOGLE / FB / GITHUB), CLOUD SYNC, UPDATE & QRIS
// =============================================================================

@Composable
private fun AccountCloudAndSettingsTab(
    account: UserAccountProfile?,
    telemetry: DeviceTelemetry?,
    autoResetOnReboot: Boolean,
    onToggleAutoReset: (Boolean) -> Unit,
    onClickGoogleSignIn: () -> Unit,
    onClickProviderSignIn: (AuthProvider) -> Unit,
    onSyncNow: () -> Unit,
    onRestoreFromAccount: () -> Unit,
    onCopyCloudToken: () -> Unit,
    importTokenInput: String,
    onImportTokenInputChange: (String) -> Unit,
    onImportCloudToken: () -> Unit,
    onSignOut: () -> Unit,
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit,
    onPanicFactoryReset: () -> Unit,
    snapshots: Map<String, String>
) {
    val context = LocalContext.current

    // 1. ACCOUNT LOGIN & CLOUD VAULT CARD
    SectionCard(
        title = "👤 Login Akun & Cloud Data Vault (Simpan Preset Permanen)",
        isHighlightedActive = (account != null)
    ) {
        if (account == null) {
            Text(
                text = "Masuk dengan Google, Facebook, atau GitHub agar seluruh kombinasi Mode Performa/Hemat, setelan 120FPS, dan daftar game Anda otomatis tersimpan & bisa dipulihkan kapan saja (termasuk saat ganti HP atau habis restart)!",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Tactile3dPushButton(
                text = "🔵 Login Cepat dengan Akun Google di HP Ini",
                onClick = onClickGoogleSignIn,
                modifier = Modifier.fillMaxWidth(),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tactile3dPushButton(
                    text = "🔷 Login Facebook",
                    onClick = { onClickProviderSignIn(AuthProvider.FACEBOOK) },
                    modifier = Modifier.weight(1f),
                    faceColor = IceCyan,
                    deepBaseColor = IceCyanDeep,
                    fontSizeSp = 10.5f
                )
                Tactile3dPushButton(
                    text = "⚫ Login GitHub",
                    onClick = { onClickProviderSignIn(AuthProvider.GITHUB) },
                    modifier = Modifier.weight(1f),
                    faceColor = SovereignGold,
                    deepBaseColor = SovereignGoldDeep,
                    fontSizeSp = 10.5f
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF07291E))
                    .border(1.3.dp, QuantumEmerald, RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(QuantumEmerald),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = account.avatarInitial,
                        color = Color(0xFF031A10),
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${account.provider.badgeIcon} ${account.displayName}",
                        color = TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "${account.emailOrHandle} · Sync: ${account.lastSyncedAt}",
                        color = QuantumEmerald,
                        fontSize = 10.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tactile3dPushButton(
                    text = "☁️ Simpan Sekarang",
                    onClick = onSyncNow,
                    modifier = Modifier.weight(1f),
                    faceColor = QuantumEmerald,
                    deepBaseColor = QuantumEmeraldDeep,
                    fontSizeSp = 10.5f
                )
                Tactile3dPushButton(
                    text = "📥 Pulihkan Preset",
                    onClick = onRestoreFromAccount,
                    modifier = Modifier.weight(1f),
                    faceColor = SovereignGold,
                    deepBaseColor = SovereignGoldDeep,
                    fontSizeSp = 10.5f
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tactile3dPushButton(
                    text = "📋 Salin Cloud Token",
                    onClick = onCopyCloudToken,
                    modifier = Modifier.weight(1f),
                    faceColor = IceCyan,
                    deepBaseColor = IceCyanDeep,
                    fontSizeSp = 10f
                )
                Tactile3dPushButton(
                    text = "🚪 Keluar Akun",
                    onClick = onSignOut,
                    modifier = Modifier.weight(1f),
                    faceColor = AlertRose,
                    deepBaseColor = AlertRoseDeep,
                    textColor = Color.White,
                    fontSizeSp = 10f
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("🔑 Pindah HP / Impor Kode Cloud Sync Token (`AETH31:...`):", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 10.8.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardInnerBg)
                    .border(1.dp, IceCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 9.dp)
            ) {
                if (importTokenInput.isEmpty()) {
                    Text("Tempel kode AETH31:... di sini", color = TextSecondary.copy(alpha = 0.65f), fontSize = 10.5.sp, maxLines = 1)
                }
                BasicTextField(
                    value = importTokenInput,
                    onValueChange = onImportTokenInputChange,
                    singleLine = true,
                    textStyle = TextStyle(color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                    cursorBrush = SolidColor(IceCyan),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Tactile3dPushButton(
                text = "Impor",
                onClick = onImportCloudToken,
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                fontSizeSp = 10.5f
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 2. KERNEL BOOT-ID AUTO-RESET & PANIC RESTORE
    SectionCard(title = "🛡️ Keamanan Boot-ID & 1-Click Panic Factory Reset") {
        GraphicOptionToggleRow(
            title = "🔄 Otomatis Reset Tweaks ke Standar Pabrik Saat HP Restart / Mati",
            subtitle = "Tetap AKTIF walau dihapus dari Recent Apps, namun 100% aman kembali normal saat HP di-restart (preset tetap bisa dipulihkan 1-klik dari Akun!).",
            checked = autoResetOnReboot,
            onToggle = { onToggleAutoReset(!autoResetOnReboot) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "🚨 1-Click Panic Factory Reset (${snapshots.size} Snapshot Tersimpan)",
            onClick = onPanicFactoryReset,
            modifier = Modifier.fillMaxWidth(),
            faceColor = AlertRose,
            deepBaseColor = AlertRoseDeep,
            textColor = Color.White
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 3. OTA UPDATE & HONEST REAL-TIME STATS
    OtaUpdateCard(
        updateStatus = updateStatus,
        isCheckingUpdate = isCheckingUpdate,
        onCheckUpdate = onCheckUpdate
    )

    Spacer(modifier = Modifier.height(12.dp))

    CommunityStatsBannerCard(
        activeUsers = telemetry?.communityActiveUsers ?: 1,
        totalDownloads = telemetry?.communityTotalDownloads ?: 1,
        localOptCount = telemetry?.localOptimizationCount ?: 1,
        installedGamesCount = telemetry?.detectedGames?.count { it.isInstalled } ?: 0
    )

    Spacer(modifier = Modifier.height(12.dp))

    // 4. OFFICIAL QRIS RANGGA WINATA & WHATSAPP CHANNEL
    SectionCard(title = "👑 Architect & QRIS Apresiasi Resmi — Rangga Winata") {
        Text(
            text = "AETHERIA dibuat dengan niat tulus agar HP kentang maupun flagship lancar dipakai harian & main game. Bagi kawan-kawan yang ingin memberikan apresiasi sukarela, silakan scan QRIS resmi di bawah:",
            color = TextSecondary,
            fontSize = 11.2.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(18.dp))
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White)
                .border(2.5.dp, SovereignGold, RoundedCornerShape(18.dp))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.qris_rangga),
                contentDescription = "QRIS Resmi Rangga Winata (NMID: ID1026619104999)",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 250.dp, max = 410.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "RANGGA WINATA · NMID: ID1026619104999 · A01",
                color = Color(0xFF0A1629),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Menerima GoPay, OVO, DANA, ShopeePay, LinkAja & Seluruh Mobile Banking (QRIS)",
                color = Color(0xFF334155),
                fontSize = 10.5.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Tactile3dPushButton(
            text = "💬 Gabung Saluran Resmi WhatsApp Rangga Winata",
            onClick = {
                runCatching {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AetheriaIdentity.WA_CHANNEL_URL)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            faceColor = QuantumEmerald,
            deepBaseColor = QuantumEmeraldDeep
        )
    }
}

@Composable
private fun AccountQuickSignInDialog(
    provider: AuthProvider,
    onDismiss: () -> Unit,
    onConfirmSignIn: (String, String) -> Unit
) {
    var nameInput by remember { mutableStateOf("") }
    var handleInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Extruded3dConsoleCard(accentColor = QuantumEmerald, secondaryAccent = SovereignGold) {
            Text(
                text = "${provider.badgeIcon} Hubungkan ${provider.label}",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Masukkan nama & email/username ${provider.label} Anda untuk mengikat Cloud Backup & file pemulihan otomatis AETHERIA:",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Text("Nama Tampilan:", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 10.8.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardInnerBg)
                    .border(1.dp, IceCyan.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                if (nameInput.isEmpty()) {
                    Text("Contoh: Rangga Winata", color = TextSecondary.copy(alpha = 0.6f), fontSize = 11.sp)
                }
                BasicTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    singleLine = true,
                    textStyle = TextStyle(color = TextPrimary, fontSize = 12.sp),
                    cursorBrush = SolidColor(IceCyan),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("Email / Username ${provider.label}:", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 10.8.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardInnerBg)
                    .border(1.dp, IceCyan.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                if (handleInput.isEmpty()) {
                    Text("Contoh: nama@gmail.com / @username", color = TextSecondary.copy(alpha = 0.6f), fontSize = 11.sp)
                }
                BasicTextField(
                    value = handleInput,
                    onValueChange = { handleInput = it },
                    singleLine = true,
                    textStyle = TextStyle(color = TextPrimary, fontSize = 12.sp),
                    cursorBrush = SolidColor(IceCyan),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tactile3dPushButton(
                    text = "Batal",
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                    faceColor = AlertRose,
                    deepBaseColor = AlertRoseDeep,
                    textColor = Color.White
                )
                Tactile3dPushButton(
                    text = "✅ Masuk & Simpan",
                    onClick = {
                        onConfirmSignIn(
                            nameInput.ifBlank { "Member AETHERIA" },
                            handleInput.ifBlank { "${provider.name.lowercase(Locale.ROOT)}@aetheria.id" }
                        )
                    },
                    modifier = Modifier.weight(1f),
                    faceColor = QuantumEmerald,
                    deepBaseColor = QuantumEmeraldDeep
                )
            }
        }
    }
}

// =============================================================================
// REUSABLE 3D COCKPIT WIDGETS, FIXED LIVE CONSOLE & FIXED 5-TAB BOTTOM DOCK
// =============================================================================

@Composable
private fun MenuGuideBanner(title: String, guideText: String) {
    Extruded3dConsoleCard(
        modifier = Modifier.padding(bottom = 10.dp),
        accentColor = SovereignGold,
        secondaryAccent = IceCyan,
        cornerRadius = 18.dp,
        lipDepth = 4.dp
    ) {
        Text(
            text = "📘 $title",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = guideText, color = TextPrimary, fontSize = 10.8.sp)
    }
}

@Composable
private fun SectionCard(
    title: String,
    isHighlightedActive: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Extruded3dConsoleCard(
        accentColor = IceCyan,
        secondaryAccent = SovereignGold,
        isHighlightedActive = isHighlightedActive
    ) {
        Text(
            text = title,
            color = if (isHighlightedActive) QuantumEmerald else SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.2.sp
        )
        Spacer(modifier = Modifier.height(9.dp))
        content()
    }
}

@Composable
private fun OtaUpdateCard(
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit
) {
    val context = LocalContext.current
    Extruded3dConsoleCard(accentColor = QuantumEmerald, secondaryAccent = SovereignGold) {
        Text(
            text = "🔄 PEMBARUAN APK OTOMATIS (TANPA HAPUS APLIKASI LAMA)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = updateStatus?.statusMessage
                ?: "APK v31.0 menggunakan Sertifikat Kriptografi Permanen RW-14. Cukup klik 'Instal / Update' langsung menimpa APK lama tanpa kehilangan data akun!",
            color = TextSecondary,
            fontSize = 10.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = if (isCheckingUpdate) "⏳ Memeriksa..." else "🔄 Cek Update",
                onClick = onCheckUpdate,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
            Tactile3dPushButton(
                text = "📥 Halaman Rilis",
                onClick = {
                    runCatching {
                        val url = updateStatus?.downloadUrl ?: AetheriaIdentity.GITHUB_ACTIONS_URL
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    }
                },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
        }
    }
}

@Composable
private fun CommunityStatsBannerCard(
    activeUsers: Int,
    totalDownloads: Int,
    localOptCount: Int,
    installedGamesCount: Int
) {
    Extruded3dConsoleCard(accentColor = IceCyan, secondaryAccent = SovereignGold, cornerRadius = 18.dp) {
        Text(
            text = "📊 STATISTIK JUJUR REAL-TIME (GITHUB & HP INI)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 10.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatMiniBox(modifier = Modifier.weight(1f), value = "$activeUsers", label = "Komunitas", color = QuantumEmerald)
            StatMiniBox(modifier = Modifier.weight(1f), value = "$totalDownloads", label = "Unduhan", color = IceCyan)
            StatMiniBox(modifier = Modifier.weight(1f), value = "$installedGamesCount Game", label = "Di HP Ini", color = SovereignGold)
            StatMiniBox(modifier = Modifier.weight(1f), value = "${localOptCount}x", label = "Boost Aktif", color = CyberViolet)
        }
    }
}

@Composable
private fun StatMiniBox(
    modifier: Modifier,
    value: String,
    label: String,
    color: Color
) {
    Column(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = value, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 11.5.sp, maxLines = 1)
        Text(text = label, color = TextSecondary, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SelectableChipButton(
    modifier: Modifier,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(if (selected) 6.dp else 2.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) QuantumEmeraldDeep else Color(0xFF050B16))
            .clickable { onClick() }
            .padding(bottom = 2.5.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (selected) Brush.verticalGradient(listOf(Color(0xFF0E382C), CardInnerBottom))
                    else Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
                )
                .border(
                    width = if (selected) 1.5.dp else 1.dp,
                    color = if (selected) QuantumEmerald else IceCyan.copy(alpha = 0.28f),
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(vertical = 8.dp, horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (selected) "✓ $title" else title,
                color = if (selected) QuantumEmerald else TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GraphicOptionToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.5.dp)
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    if (checked) listOf(Color(0xFF08271E), CardInnerBottom)
                    else listOf(CardInnerBg, CardInnerBottom)
                )
            )
            .border(
                width = if (checked) 1.5.dp else 1.dp,
                color = if (checked) QuantumEmerald else AlertRose.copy(alpha = 0.35f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onToggle() }
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.3.sp)
            Text(text = subtitle, color = TextSecondary, fontSize = 10.1.sp)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (checked) QuantumEmerald else Color(0xFF2B1624))
                .border(
                    width = 1.dp,
                    color = if (checked) Color.White else AlertRose,
                    shape = RoundedCornerShape(999.dp)
                )
                .padding(horizontal = 11.dp, vertical = 5.dp)
        ) {
            Text(
                text = if (checked) "● ON" else "OFF ○",
                color = if (checked) Color(0xFF031A10) else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp,
                softWrap = false,
                maxLines = 1
            )
        }
    }
}

/**
 * FIXED v31.0: Left title uses `Modifier.weight(1f)` + `maxLines = 1` + `TextOverflow.Ellipsis`
 * and right status badge uses `softWrap = false, maxLines = 1`, permanently eliminating the
 * vertical 1-letter-per-line `A / S / I` text wrap seen on 360dp phones!
 */
@Composable
private fun LiveScriptExecutionConsoleCard(
    summaryText: String,
    isSuccess: Boolean,
    terminalLines: List<String>,
    verifications: List<VerificationRecord>
) {
    var showFullDetails by remember { mutableStateOf(false) }

    Extruded3dConsoleCard(
        accentColor = if (isSuccess) QuantumEmerald else SovereignGold,
        secondaryAccent = IceCyan,
        isHighlightedActive = isSuccess,
        cornerRadius = 18.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "🟢 BUKTI EKSEKUSI SKRIP REAL-TIME",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.8.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(if (isSuccess) QuantumEmerald.copy(alpha = 0.16f) else AlertRose.copy(alpha = 0.16f))
                    .border(1.dp, if (isSuccess) QuantumEmerald else AlertRose, RoundedCornerShape(999.dp))
                    .clickable { showFullDetails = !showFullDetails }
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = if (showFullDetails) "▲ RINGKAS" else "▼ LOG (${verifications.size})",
                    color = if (isSuccess) QuantumEmerald else AlertRose,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp,
                    softWrap = false,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (isSuccess) QuantumEmerald.copy(alpha = 0.13f)
                    else AlertRose.copy(alpha = 0.15f)
                )
                .border(
                    width = 1.dp,
                    color = if (isSuccess) QuantumEmerald else AlertRose,
                    shape = RoundedCornerShape(12.dp)
                )
                .clickable { showFullDetails = !showFullDetails }
                .padding(10.dp)
        ) {
            Text(
                text = summaryText,
                color = if (isSuccess) QuantumEmerald else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.8.sp
            )
        }

        if (showFullDetails) {
            Spacer(modifier = Modifier.height(8.dp))
            terminalLines.forEach { line ->
                val lineColor = when {
                    line.startsWith("✅") || line.startsWith("✓") -> QuantumEmerald
                    line.startsWith("❌") -> AlertRose
                    line.startsWith("🟡") -> SovereignGold
                    else -> IceCyan
                }
                Text(text = line, color = lineColor, fontFamily = FontFamily.Monospace, fontSize = 10.3.sp)
            }

            if (verifications.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                verifications.take(12).forEach { v ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.5.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                            .border(1.dp, IceCyan.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                            .padding(8.dp)
                    ) {
                        Text("${v.feature} — ${v.badge}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 10.8.sp)
                        Text("Sebelum: ${v.beforeValue} | Target: ${v.targetValue} | Aktual: ${v.actualValue}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(999.dp))
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.16f))
            .border(1.1.dp, color, RoundedCornerShape(999.dp))
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 9.5.sp,
            softWrap = false,
            maxLines = 1
        )
    }
}

/**
 * FIXED v31.0: Every bottom dock tab gets equal `Modifier.weight(1f)` with centered vertical
 * Icon on top + short 1-word label underneath (`Master` | `120FPS` | `Tweaks` | `6-Jalur` | `Akun`).
 * Zero text truncation on 320dp–480dp screens!
 */
@Composable
private fun BottomNavigationDock(
    currentTab: AetheriaTab,
    onSelect: (AetheriaTab) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(20.dp)
            .background(Brush.verticalGradient(listOf(Color(0xFF102042), Color(0xFF040812))))
            .border(
                width = 1.3.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold.copy(alpha = 0.65f), IceCyan.copy(alpha = 0.65f))),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(vertical = 7.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AetheriaTab.values().forEach { tab ->
            val active = (currentTab == tab)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (active) SovereignGoldDeep else Color.Transparent)
                    .clickable { onSelect(tab) }
                    .padding(bottom = if (active) 2.5.dp else 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (active) Brush.verticalGradient(listOf(Color(0xFF282008), Color(0xFF0B2736)))
                            else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .border(
                            width = if (active) 1.2.dp else 0.dp,
                            color = if (active) SovereignGold else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(vertical = 5.dp, horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = tab.icon,
                        fontSize = 14.sp,
                        maxLines = 1,
                        softWrap = false
                    )
                    Text(
                        text = tab.shortLabel,
                        color = if (active) SovereignGold else TextSecondary,
                        fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                        fontSize = 10.sp,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
