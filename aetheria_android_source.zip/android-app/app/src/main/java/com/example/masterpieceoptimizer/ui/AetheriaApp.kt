package com.example.masterpieceoptimizer.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.masterpieceoptimizer.R
import com.example.masterpieceoptimizer.core.AetheriaIdentity
import com.example.masterpieceoptimizer.core.DeviceTelemetry
import com.example.masterpieceoptimizer.core.DeviceTelemetryRepository
import com.example.masterpieceoptimizer.core.DeviceTierAdvisor
import com.example.masterpieceoptimizer.core.FeatureCapability
import com.example.masterpieceoptimizer.core.OemGameBoosterInfo
import com.example.masterpieceoptimizer.core.SettingSpec
import com.example.masterpieceoptimizer.core.ShizukuDiagnostics
import com.example.masterpieceoptimizer.core.SystemProfile
import com.example.masterpieceoptimizer.core.UpdateCheckResult
import com.example.masterpieceoptimizer.core.VerificationRecord
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.theme.AetheriaSplashBootScreen
import com.example.masterpieceoptimizer.ui.theme.AlertRose
import com.example.masterpieceoptimizer.ui.theme.CardInnerBg
import com.example.masterpieceoptimizer.ui.theme.CardInnerBottom
import com.example.masterpieceoptimizer.ui.theme.CircularRingGauge
import com.example.masterpieceoptimizer.ui.theme.CyberViolet
import com.example.masterpieceoptimizer.ui.theme.IceCyan
import com.example.masterpieceoptimizer.ui.theme.MidnightPanel
import com.example.masterpieceoptimizer.ui.theme.MidnightPanelBottom
import com.example.masterpieceoptimizer.ui.theme.ObsidianBg
import com.example.masterpieceoptimizer.ui.theme.QuantumEmerald
import com.example.masterpieceoptimizer.ui.theme.Rw14QuantumEmblem
import com.example.masterpieceoptimizer.ui.theme.SovereignGold
import com.example.masterpieceoptimizer.ui.theme.TextPrimary
import com.example.masterpieceoptimizer.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AetheriaPage(val index: Int, val chipLabel: String) {
    HOME(1, "01. 3D Command Center"),
    DEVICE(2, "02. Device Intel"),
    PERF_LAB(3, "03. Perf Lab & Audio/Net"),
    GAMING(4, "04. E-Sports & XArena Combo"),
    SHIZUKU(5, "05. Shizuku Center"),
    STORAGE(6, "06. Anti-Malware, Iklan & Judol"),
    PROFILES(7, "07. Profiles"),
    LOGS(8, "08. Diagnostics"),
    SETTINGS(9, "09. Update & QRIS")
}

@Composable
fun AetheriaRootScreen(
    shizukuManager: ShizukuBridgeManager,
    telemetryRepo: DeviceTelemetryRepository
) {
    val scope = rememberCoroutineScope()
    val shizukuDiag by shizukuManager.diagnostics.collectAsState()
    var showSplash by remember { mutableStateOf(true) }
    var currentPage by remember { mutableStateOf(AetheriaPage.HOME) }
    var telemetry by remember { mutableStateOf<DeviceTelemetry?>(null) }

    // PERSISTENT UI STATE (Survives clearing Recent Apps / App History 100%!)
    var activeProfile by remember {
        val savedId = shizukuManager.loadUiStateString("active_profile", SystemProfile.BALANCED.id)
        val matched = SystemProfile.values().firstOrNull { it.id == savedId } ?: SystemProfile.BALANCED
        mutableStateOf(matched)
    }
    var lastVerifications by remember { mutableStateOf<List<VerificationRecord>>(emptyList()) }
    var updateStatus by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var isCheckingUpdate by remember { mutableStateOf(false) }

    var lastActionSummary by remember {
        mutableStateOf(
            shizukuManager.loadUiStateString(
                "last_summary",
                "🟢 SISTEM SIAGA (v29.5 HYBRID ONLINE & OFFLINE) — Pengaturan tersimpan permanen walau riwayat APK dihapus!"
            )
        )
    }
    var lastActionSuccess by remember { mutableStateOf(true) }

    val moduleStates = remember {
        mutableStateMapOf(
            "cpu" to shizukuManager.loadUiStateBool("mod_cpu", false),
            "gpu" to shizukuManager.loadUiStateBool("mod_gpu", false),
            "net" to shizukuManager.loadUiStateBool("mod_net", false),
            "touch" to shizukuManager.loadUiStateBool("mod_touch", false),
            "hz" to shizukuManager.loadUiStateBool("mod_hz", false),
            "focus" to shizukuManager.loadUiStateBool("mod_focus", false)
        )
    }
    var iphoneAudioEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("iphone_audio", false)) }
    var dualNetEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("dual_net", false)) }
    var smartCoolBoostEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("smart_cool_boost", false)) }
    var tripleComboEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("triple_combo", false)) }
    var adblockShieldEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("adblock_shield", false)) }

    var terminalLines by remember {
        mutableStateOf(
            listOf(
                "> Initializing ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION})...",
                "✓ Architect Seal: ${AetheriaIdentity.ARCHITECT} (QRIS NMID: ${AetheriaIdentity.QRIS_NMID} · ${AetheriaIdentity.QRIS_TID})",
                "✓ Persistent Memory Lock Active: Pengaturan TIDAK mereset walau riwayat APK dihapus",
                "✓ Hybrid Online & Offline Engine Ready: Berfungsi 100% saat Online maupun Offline (Tanpa Kuota/Wi-Fi)",
                "✓ Auto-Heal Mobile Data DNS Ready: Internet Kuota Data Seluler 4G/5G & Wi-Fi dijamin lancar 100%",
                "> Menunggu perintah eksekusi skrip dari pengguna..."
            )
        )
    }
    var auditLog by remember {
        mutableStateOf(
            listOf(
                "✓ ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION}) Initialized",
                "✓ Architect: ${AetheriaIdentity.ARCHITECT} (NMID: ${AetheriaIdentity.QRIS_NMID})"
            )
        )
    }

    LaunchedEffect(shizukuDiag.isReady) {
        // 1. Auto-heal Mobile Data DNS if stuck on strict hostname mode from earlier session
        val healedDns = shizukuManager.autoHealMobileDataDnsIfNeeded()
        if (healedDns) {
            lastActionSummary = "🟢 AUTO-HEAL AKTIF: Kunci DNS Family yang menghambat Kuota Data Seluler telah diperbaiki otomatis!"
            shizukuManager.saveUiStateString("last_summary", lastActionSummary)
        }
        // 2. Re-attach Hardware iPhone Audio DSP if user had it enabled before clearing Recent Apps
        if (iphoneAudioEnabled) {
            shizukuManager.applyIphoneAudioEnhancer(true)
        }
        while (true) {
            telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
            delay(5000L)
        }
    }

    // Show 3D HD Boot Animation + Startup Sound ONLY ONCE when entering the app
    if (showSplash) {
        val detectedBoosterLabel = remember {
            telemetryRepo.detectOemGameBooster().boosterName
        }
        AetheriaSplashBootScreen(
            detectedBoosterName = detectedBoosterLabel,
            onBootFinished = { showSplash = false }
        )
        return
    }

    fun appendLog(msg: String) {
        auditLog = (listOf(msg) + auditLog).take(60)
    }

    fun markImmediateFeedback(actionTitle: String) {
        lastActionSuccess = true
        lastActionSummary = "⚡ MENJALANKAN SKRIP INSTAN: $actionTitle..."
    }

    fun recordExecutionResult(actionTitle: String, records: List<VerificationRecord>) {
        telemetryRepo.incrementOptimizationCounter()
        lastVerifications = records
        val nowStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        val okCount = records.count { it.verified }
        val total = records.size
        val isOfflineMandiri = records.any { it.badge.contains("MODE MANDIRI") }

        val lines = mutableListOf<String>()
        lines.add("> [$nowStr] MENJALANKAN SKRIP: $actionTitle")
        lines.add("> Mode Mesin: ${if (shizukuDiag.isReady) "SHIZUKU KERNEL + NATIVE (${shizukuDiag.state.displayTitle})" else "MESIN LOKAL MANDIRI (OFFLINE / ONLINE TANPA SHIZUKU)"}")
        lines.add("--------------------------------------------------")
        records.forEachIndexed { idx, r ->
            lines.add("[${idx + 1}] ${r.feature} (${r.parameter})")
            lines.add("    Sebelum: ${r.beforeValue} -> Target: ${r.targetValue} -> Aktual: ${r.actualValue} [${r.badge}]")
        }
        lines.add("--------------------------------------------------")

        if (okCount > 0) {
            lastActionSuccess = true
            lastActionSummary = if (isOfflineMandiri) {
                "✅ AKTIF ($actionTitle): $okCount/$total Parameter Berjalan di Mode Mandiri (Tersimpan Permanen!)"
            } else {
                "✅ SKRIP BERHASIL ($actionTitle): $okCount/$total Parameter Aktif & Tersimpan Permanen!"
            }
            lines.add("✅ KESIMPULAN SKRIP: BERHASIL DITERAPKAN ($okCount/$total Parameter Aktif)!")
            lines.add("🔒 KUNCI MEMORI PERMANEN: Tetap tersimpan ON walau riwayat APK dihapus / HP ganti Wi-Fi ke Kuota.")
        } else {
            lastActionSuccess = false
            lastActionSummary = "🟡 INFO ($actionTitle): Skrip dijalankan ($okCount/$total parameter terverifikasi)."
            lines.add("🟡 KESIMPULAN SKRIP: DIEKSEKUSI ($okCount/$total Terverifikasi).")
        }

        shizukuManager.saveUiStateString("last_summary", lastActionSummary)
        terminalLines = lines
        appendLog("[$nowStr] [$actionTitle] $okCount/$total parameter berhasil diverifikasi.")
    }

    fun triggerFixMobileDataDns() {
        markImmediateFeedback("📶 Memperbaiki Koneksi Internet Data Seluler (Kuota 4G/5G)")
        scope.launch {
            val res = shizukuManager.fixMobileDataInternetDns()
            telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
            recordExecutionResult("📶 Perbaiki Internet Data Seluler (Kuota & Wi-Fi Lancar)", res)
        }
    }

    fun triggerUpdateCheck() {
        isCheckingUpdate = true
        markImmediateFeedback("🔄 Memeriksa Update APK Terbaru di Server GitHub")
        scope.launch {
            val res = telemetryRepo.checkForApkUpdate()
            updateStatus = res
            isCheckingUpdate = false
            val rec = VerificationRecord(
                feature = "Pemeriksaan Update OTA GitHub",
                parameter = AetheriaIdentity.GITHUB_REPO,
                beforeValue = res.currentVersion,
                targetValue = res.latestVersion,
                actualValue = if (res.hasNewerRelease) "Tersedia Update Baru!" else "Sudah Paling Baru",
                exitCode = 0,
                verified = true,
                badge = if (res.hasNewerRelease) "🚀 UPDATE TERSEDIA" else "🟢 VERSI TERBARU",
                detail = res.statusMessage
            )
            recordExecutionResult("🔄 Cek Update APK Resmi", listOf(rec))
        }
    }

    fun triggerTripleCombo(enable: Boolean, targetGamePkg: String? = null) {
        tripleComboEnabled = enable
        shizukuManager.saveUiStateBool("triple_combo", enable)
        if (enable) {
            activeProfile = SystemProfile.TRIPLE_COMBO
            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
        }
        val boosterInfo = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster()
        val label = if (enable) {
            "🔥 TRIPLE-COMBO ON (AETHERIA + ${boosterInfo.boosterName} + Shizuku)"
        } else {
            "⚪ TRIPLE-COMBO OFF (Standar)"
        }
        markImmediateFeedback(label)
        scope.launch {
            val res = shizukuManager.applyTripleComboOemGameBoost(boosterInfo, targetGamePkg, enable)
            recordExecutionResult(label, res)
        }
    }

    Scaffold(
        containerColor = ObsidianBg,
        bottomBar = {
            BottomNavigationDock(currentPage = currentPage, onSelect = { currentPage = it })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF060E20), ObsidianBg, Color(0xFF02040A))
                    )
                )
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            // 3D HD Horizontal 9-Page Selector Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AetheriaPage.values().forEach { page ->
                    val selected = (page == currentPage)
                    Box(
                        modifier = Modifier
                            .shadow(if (selected) 8.dp else 3.dp, RoundedCornerShape(999.dp))
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                if (selected) {
                                    Brush.horizontalGradient(
                                        listOf(SovereignGold.copy(alpha = 0.32f), IceCyan.copy(alpha = 0.24f))
                                    )
                                } else {
                                    Brush.verticalGradient(listOf(MidnightPanel, MidnightPanelBottom))
                                }
                            )
                            .border(
                                width = if (selected) 1.5.dp else 1.dp,
                                brush = if (selected) {
                                    Brush.horizontalGradient(listOf(SovereignGold, IceCyan))
                                } else {
                                    Brush.horizontalGradient(listOf(IceCyan.copy(alpha = 0.3f), Color(0xFF1E293B)))
                                },
                                shape = RoundedCornerShape(999.dp)
                            )
                            .clickable { currentPage = page }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = page.chipLabel,
                            color = if (selected) SovereignGold else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            when (currentPage) {
                AetheriaPage.HOME -> HomeOverviewPane(
                    telemetry = telemetry,
                    shizukuDiag = shizukuDiag,
                    activeProfile = activeProfile,
                    iphoneAudioEnabled = iphoneAudioEnabled,
                    dualNetEnabled = dualNetEnabled,
                    smartCoolBoostEnabled = smartCoolBoostEnabled,
                    tripleComboEnabled = tripleComboEnabled,
                    updateStatus = updateStatus,
                    isCheckingUpdate = isCheckingUpdate,
                    onCheckUpdate = { triggerUpdateCheck() },
                    onFixMobileDataDns = { triggerFixMobileDataDns() },
                    onToggleTripleCombo = { enable -> triggerTripleCombo(enable) },
                    onOpenOemBooster = {
                        val b = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster()
                        shizukuManager.launchOemGameBooster(b)
                    },
                    onCleanRam = {
                        markImmediateFeedback("🧊 Dinginkan & Bersihkan Standby RAM")
                        val beforeAvail = telemetry?.ramAvailMb ?: 0L
                        System.gc()
                        scope.launch {
                            val updated = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                            telemetry = updated
                            val afterAvail = updated.ramAvailMb
                            val rec = VerificationRecord(
                                feature = "Pembersihan Standby RAM & Garbage Collector",
                                parameter = "Runtime.gc() + MemoryTrim",
                                beforeValue = "Bebas $beforeAvail MB",
                                targetValue = "Optimalisasi RAM",
                                actualValue = "Bebas $afterAvail MB (${updated.ramUsedPercent}% Terpakai)",
                                exitCode = 0,
                                verified = true,
                                badge = "🟢 BERHASIL",
                                detail = "WhatsApp & Instagram tetap aman 100%"
                            )
                            recordExecutionResult("🧊 Dinginkan & Bersihkan Standby RAM", listOf(rec))
                        }
                    },
                    onSmartCoolBoost = {
                        smartCoolBoostEnabled = !smartCoolBoostEnabled
                        shizukuManager.saveUiStateBool("smart_cool_boost", smartCoolBoostEnabled)
                        if (smartCoolBoostEnabled) {
                            activeProfile = SystemProfile.SMART_COOL_BOOST
                            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                            markImmediateFeedback("⚖️ Smart Cool-Boost [ON] (Boost CPU + GPU + Pendingin Otomatis)")
                            scope.launch {
                                val res = shizukuManager.applySmartCoolBoostBalance()
                                recordExecutionResult("⚖️ Smart Cool-Boost [ON] (CPU + GPU + Pendingin Seimbang)", res)
                            }
                        } else {
                            activeProfile = SystemProfile.BALANCED
                            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                            markImmediateFeedback("⚖️ Smart Cool-Boost [OFF] (Standar)")
                            scope.launch {
                                val res = shizukuManager.applyAndVerifySpecs(SystemProfile.BALANCED.specs)
                                recordExecutionResult("⚖️ Smart Cool-Boost [OFF] (Standar)", res)
                            }
                        }
                    },
                    onDailyBoost = {
                        markImmediateFeedback("📱 Booster Harian TikTok/WA/IG + Network Boost")
                        scope.launch {
                            val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = false)
                            recordExecutionResult("📱 Booster Harian TikTok/WA/IG Anti Patah-Patah", res)
                        }
                    },
                    onToggleIphoneAudio = { enable ->
                        iphoneAudioEnabled = enable
                        shizukuManager.saveUiStateBool("iphone_audio", enable)
                        markImmediateFeedback("🎧 Modul Suara Speaker & Headset Setara iPhone [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyIphoneAudioEnhancer(enable)
                            recordExecutionResult("🎧 Audio Speaker & Headset iPhone Mode [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onToggleDualNet = { enable ->
                        dualNetEnabled = enable
                        shizukuManager.saveUiStateBool("dual_net", enable)
                        markImmediateFeedback("🌐 Akselerasi Saluran Ganda Wi-Fi + Data [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyDualChannelNetworkBoost(enable)
                            recordExecutionResult("🌐 Boost Jaringan Wi-Fi + Data Seluler [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onOpenGaming = { currentPage = AetheriaPage.GAMING },
                    onOpenShizuku = { currentPage = AetheriaPage.SHIZUKU },
                    onOpenQris = { currentPage = AetheriaPage.SETTINGS },
                    onRestore = {
                        iphoneAudioEnabled = false
                        dualNetEnabled = false
                        smartCoolBoostEnabled = false
                        tripleComboEnabled = false
                        adblockShieldEnabled = false
                        moduleStates.keys.toList().forEach { moduleStates[it] = false }
                        shizukuManager.clearAllUiStates()
                        markImmediateFeedback("🛡️ Restore Point (Kembali ke Standar Pabrik)")
                        scope.launch {
                            shizukuManager.applyIphoneAudioEnhancer(false)
                            shizukuManager.fixMobileDataInternetDns()
                            val res = shizukuManager.restoreFromSnapshots()
                            activeProfile = SystemProfile.BALANCED
                            recordExecutionResult("🛡️ Restore Point (Kembali ke Standar Pabrik)", res)
                        }
                    }
                )

                AetheriaPage.DEVICE -> DeviceIntelligencePane(
                    telemetry = telemetry,
                    capabilities = telemetryRepo.buildCapabilityMatrix(shizukuDiag.isReady)
                )

                AetheriaPage.PERF_LAB -> PerformanceLabPane(
                    moduleStates = moduleStates,
                    iphoneAudioEnabled = iphoneAudioEnabled,
                    dualNetEnabled = dualNetEnabled,
                    smartCoolBoostEnabled = smartCoolBoostEnabled,
                    tripleComboEnabled = tripleComboEnabled,
                    oemBooster = telemetry?.oemGameBooster,
                    onFixMobileDataDns = { triggerFixMobileDataDns() },
                    onToggleTripleCombo = { enable -> triggerTripleCombo(enable) },
                    onToggleIphoneAudio = { enable ->
                        iphoneAudioEnabled = enable
                        shizukuManager.saveUiStateBool("iphone_audio", enable)
                        markImmediateFeedback("🎧 Audio Speaker & Headset Setara iPhone [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyIphoneAudioEnhancer(enable)
                            recordExecutionResult("🎧 Audio Speaker & Headset Setara iPhone [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onToggleDualNet = { enable ->
                        dualNetEnabled = enable
                        shizukuManager.saveUiStateBool("dual_net", enable)
                        markImmediateFeedback("🌐 Boost Jaringan Saluran Ganda Wi-Fi + Data [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyDualChannelNetworkBoost(enable)
                            recordExecutionResult("🌐 Boost Jaringan Wi-Fi + Data Seluler [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onToggleSmartCoolBoost = { enable ->
                        smartCoolBoostEnabled = enable
                        shizukuManager.saveUiStateBool("smart_cool_boost", enable)
                        if (enable) {
                            activeProfile = SystemProfile.SMART_COOL_BOOST
                            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                            markImmediateFeedback("⚖️ Smart Cool-Boost [ON] (CPU + GPU + Pendingin Otomatis)")
                            scope.launch {
                                val res = shizukuManager.applySmartCoolBoostBalance()
                                recordExecutionResult("⚖️ Smart Cool-Boost [ON] (CPU + GPU + Pendingin Seimbang)", res)
                            }
                        } else {
                            activeProfile = SystemProfile.BALANCED
                            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                            markImmediateFeedback("⚖️ Smart Cool-Boost [OFF] (Standar)")
                            scope.launch {
                                val res = shizukuManager.applyAndVerifySpecs(SystemProfile.BALANCED.specs)
                                recordExecutionResult("⚖️ Smart Cool-Boost [OFF] (Standar)", res)
                            }
                        }
                    },
                    onRunSpecs = { moduleId, isTurnOn, title, specs ->
                        moduleStates[moduleId] = isTurnOn
                        shizukuManager.saveUiStateBool("mod_$moduleId", isTurnOn)
                        markImmediateFeedback(title)
                        scope.launch {
                            val res = shizukuManager.applyAndVerifySpecs(specs)
                            recordExecutionResult(title, res)
                        }
                    }
                )

                AetheriaPage.GAMING -> GamingCenterPane(
                    telemetry = telemetry,
                    tripleComboEnabled = tripleComboEnabled,
                    shizukuManager = shizukuManager,
                    onToggleTripleCombo = { enable, pkg -> triggerTripleCombo(enable, pkg) },
                    onOpenOemBooster = {
                        val b = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster()
                        shizukuManager.launchOemGameBooster(b)
                    },
                    onDailyBoost = { fullDex ->
                        val title = if (fullDex) "🔥 Full System Dexopt" else "⚡ Booster Cepat TikTok/WA/IG/Shopee/YT"
                        markImmediateFeedback(title)
                        scope.launch {
                            val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = fullDex)
                            recordExecutionResult(title, res)
                        }
                    },
                    onApplyGamingMode = { gamePkg, gameName, mode, launchAfter ->
                        val modeLabel = when (mode) {
                            "potato_075" -> "🥔 Mode Penyelamat HP Kentang 0.75x ($gameName)"
                            "thermal_080" -> "❄️ Mode Thermal Guard 0.80x ($gameName)"
                            "balanced_085" -> "⚖️ Smart Cool-Boost 0.85x ($gameName)"
                            "esports_pro" -> "🏆 E-Sports Ultimate Pro ($gameName)"
                            else -> "🎮 Mode Native HD 1.0x ($gameName)"
                        }
                        markImmediateFeedback(modeLabel)
                        scope.launch {
                            val res = shizukuManager.applyUniversalGamingMode(gamePkg, mode)
                            activeProfile = when (mode) {
                                "potato_075" -> SystemProfile.POTATO_RESCUE
                                "esports_pro" -> SystemProfile.ESPORT_ULTIMATE_PRO
                                "balanced_085" -> SystemProfile.SMART_COOL_BOOST
                                else -> SystemProfile.GAMING
                            }
                            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                            recordExecutionResult(modeLabel, res)
                            if (launchAfter) {
                                shizukuManager.launchGamePackage(gamePkg)
                            }
                        }
                    },
                    onApplyEsportsGraphics = { perfMode, aniso, tex, mipmap, frameStab, dualNet ->
                        val title = "🏆 E-Sports Ultimate Pro & Graphic Optimization ($perfMode)"
                        markImmediateFeedback(title)
                        scope.launch {
                            val res = shizukuManager.applyEsportsProGraphics(
                                performanceMode = perfMode,
                                anisotropicOn = aniso,
                                textureFilterOn = tex,
                                mipmapLodOn = mipmap,
                                frameStabilizerOn = frameStab,
                                dualChannelNetOn = dualNet
                            )
                            activeProfile = SystemProfile.ESPORT_ULTIMATE_PRO
                            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                            recordExecutionResult(title, res)
                        }
                    }
                )

                AetheriaPage.SHIZUKU -> ShizukuCenterPane(
                    diag = shizukuDiag,
                    onRefresh = {
                        val d = shizukuManager.refreshDiagnostics()
                        val rec = VerificationRecord(
                            feature = "Pemeriksaan Jembatan Shizuku",
                            parameter = "Shizuku.pingBinder() + checkSelfPermission()",
                            beforeValue = "Probe",
                            targetValue = "READY (uid=2000)",
                            actualValue = "${d.state.displayTitle} [${d.state.code}]",
                            exitCode = if (d.isReady) 0 else -1,
                            verified = d.isReady,
                            badge = if (d.isReady) "🟢 TERHUBUNG" else "🔴 BELUM SIAP",
                            detail = d.diagnosticMessage
                        )
                        recordExecutionResult("🔗 Cek Koneksi & Izin Shizuku", listOf(rec))
                    },
                    onRequestPermission = { shizukuManager.requestPermissionSafely() }
                )

                AetheriaPage.STORAGE -> StorageResourcePane(
                    telemetry = telemetry,
                    adblockShieldEnabled = adblockShieldEnabled,
                    onFixMobileDataDns = { triggerFixMobileDataDns() },
                    onScanAndPurgeMalware = { autoPurge ->
                        markImmediateFeedback("🛡️ Pemindaian Anti-Malware & Auto-Purge APK Penipuan")
                        scope.launch {
                            val res = shizukuManager.scanAndAutoPurgeMalware(autoPurge = autoPurge)
                            recordExecutionResult("🛡️ Pemindaian Anti-Malware & Auto-Purge APK Penipuan", res)
                        }
                    },
                    onConfigureAdblockJudol = { dnsMode, freezeOem ->
                        adblockShieldEnabled = (dnsMode != "off")
                        shizukuManager.saveUiStateBool("adblock_shield", adblockShieldEnabled)
                        markImmediateFeedback("🚫 Pemblokir Iklan HP & Perisai Anti-Judol Aman Kuota ($dnsMode)")
                        scope.launch {
                            val res = shizukuManager.configureAdblockAndJudolShield(dnsMode, freezeOem)
                            telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                            recordExecutionResult("🚫 Pemblokir Iklan HP & Perisai Anti-Judol Aman Kuota ($dnsMode)", res)
                        }
                    }
                )

                AetheriaPage.PROFILES -> AutomationProfilesPane(
                    activeProfile = activeProfile,
                    onSelectProfile = { profile ->
                        activeProfile = profile
                        shizukuManager.saveUiStateString("active_profile", profile.id)
                        markImmediateFeedback("🔄 Terapkan Profil Sistem: ${profile.title}")
                        scope.launch {
                            val res = shizukuManager.applyAndVerifySpecs(profile.specs)
                            recordExecutionResult("🔄 Terapkan Profil Sistem: ${profile.title}", res)
                        }
                    }
                )

                AetheriaPage.LOGS -> DiagnosticsLogsPane(
                    verifications = lastVerifications,
                    auditLog = auditLog
                )

                AetheriaPage.SETTINGS -> SettingsRecoveryQrisPane(
                    telemetry = telemetry,
                    snapshots = shizukuManager.getSavedSnapshots(),
                    updateStatus = updateStatus,
                    isCheckingUpdate = isCheckingUpdate,
                    onCheckUpdate = { triggerUpdateCheck() },
                    onRestore = {
                        iphoneAudioEnabled = false
                        dualNetEnabled = false
                        smartCoolBoostEnabled = false
                        tripleComboEnabled = false
                        adblockShieldEnabled = false
                        moduleStates.keys.toList().forEach { moduleStates[it] = false }
                        shizukuManager.clearAllUiStates()
                        markImmediateFeedback("🛡️ Pulihkan Snapshot Asli / Standar Pabrik")
                        scope.launch {
                            shizukuManager.applyIphoneAudioEnhancer(false)
                            shizukuManager.fixMobileDataInternetDns()
                            val res = shizukuManager.restoreFromSnapshots()
                            activeProfile = SystemProfile.BALANCED
                            recordExecutionResult("🛡️ Pulihkan Snapshot Asli / Standar Pabrik", res)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ALWAYS-VISIBLE 3D HD LIVE EXECUTION CONSOLE & PROOF OF SCRIPT SUCCESS ON EVERY PAGE
            LiveScriptExecutionConsoleCard(
                summaryText = lastActionSummary,
                isSuccess = lastActionSuccess,
                terminalLines = terminalLines,
                verifications = lastVerifications
            )
        }
    }
}

/**
 * High-contrast, unmistakable ON / OFF Status Indicator & Visual Switch Pill
 * (Fixes Screenshot 3 where users couldn't easily tell if a module was ON or OFF).
 */
@Composable
private fun ClearStatusSwitchBanner(
    isOn: Boolean,
    activeLabel: String = "SEDANG AKTIF [ON]",
    inactiveLabel: String = "MATI / STANDAR [OFF]",
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isOn) Color(0xFF062C1E) else Color(0xFF181122)
            )
            .border(
                width = 1.5.dp,
                color = if (isOn) QuantumEmerald else AlertRose.copy(alpha = 0.65f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onToggle() }
            .padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (isOn) "✅ STATUS: $activeLabel" else "⭕ STATUS: $inactiveLabel",
                color = if (isOn) QuantumEmerald else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp
            )
            Text(
                text = if (isOn) "Fitur ini sedang menyala & bekerja aktif di sistem HP" else "Fitur ini masih mati (ketuk sakelar untuk menyalakan)",
                color = TextSecondary,
                fontSize = 10.sp
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        // Visual Physical-Style Switch Track
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (isOn) QuantumEmerald else Color(0xFF2B3548))
                .border(
                    width = 1.5.dp,
                    color = if (isOn) Color.White.copy(alpha = 0.8f) else AlertRose.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(999.dp)
                )
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = if (isOn) "● ON" else "OFF ○",
                color = if (isOn) Color(0xFF021A10) else TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
            )
        }
    }
}

/**
 * Unambiguous Two-Button Row where ONLY the active state glows brightly and the inactive button is dark slate.
 */
@Composable
private fun ClearOnOffButtonRow(
    isOn: Boolean,
    turnOnLabel: String = "▶️ NYALAKAN (ON)",
    activeOnLabel: String = "✅ SEDANG AKTIF (ON)",
    turnOffLabel: String = "📴 MATIKAN (OFF)",
    activeOffLabel: String = "⭕ POSISI MATI (OFF)",
    onTurnOn: () -> Unit,
    onTurnOff: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // ON Button
        Button(
            onClick = onTurnOn,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isOn) QuantumEmerald else Color(0xFF152744)
            ),
            modifier = Modifier
                .weight(1f)
                .border(
                    width = if (isOn) 2.dp else 1.dp,
                    color = if (isOn) Color.White else IceCyan.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(999.dp)
                )
        ) {
            Text(
                text = if (isOn) activeOnLabel else turnOnLabel,
                color = if (isOn) Color(0xFF021A10) else IceCyan,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // OFF Button
        Button(
            onClick = onTurnOff,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (!isOn) Color(0xFF2D1222) else Color(0xFF121A2B)
            ),
            modifier = Modifier
                .weight(1f)
                .border(
                    width = if (!isOn) 1.8.dp else 1.dp,
                    color = if (!isOn) AlertRose else Color(0xFF334155),
                    shape = RoundedCornerShape(999.dp)
                )
        ) {
            Text(
                text = if (!isOn) activeOffLabel else turnOffLabel,
                color = if (!isOn) AlertRose else TextSecondary,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Triple-Combo Card: AETHERIA + Built-in OEM Game Booster (XArena / Game Turbo / HyperBoost / Ultra Game Mode) + Shizuku
 */
@Composable
private fun TripleComboOemCard(
    oemBooster: OemGameBoosterInfo?,
    tripleComboEnabled: Boolean,
    onToggleTripleCombo: (Boolean) -> Unit,
    onOpenOemBooster: () -> Unit
) {
    val boosterTitle = oemBooster?.boosterName ?: "XArena & Dar-Link Game Engine (Otomatis Semua HP)"
    val boosterDesc = oemBooster?.syncDescription
        ?: "Menggabungkan AETHERIA + Game Booster Bawaan HP (seperti XArena di Infinix/TECNO, Game Turbo di Xiaomi, HyperBoost di Realme/OPPO, Ultra Game di Vivo, Game Booster di Samsung) + Shizuku secara serentak tanpa bentrok!"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(14.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF1A1E46), MidnightPanel, MidnightPanelBottom))
            )
            .border(
                width = if (tripleComboEnabled) 2.dp else 1.5.dp,
                brush = if (tripleComboEnabled) {
                    Brush.horizontalGradient(listOf(QuantumEmerald, SovereignGold, IceCyan))
                } else {
                    Brush.horizontalGradient(listOf(SovereignGold, CyberViolet, IceCyan))
                },
                shape = RoundedCornerShape(20.dp)
            )
            .padding(15.dp)
    ) {
        Text(
            text = "🔥 TRIPLE-COMBO ENGINE (AETHERIA + GAME BOOST HP + SHIZUKU)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "🎯 Terdeteksi Otomatis di HP Ini: $boosterTitle",
            color = QuantumEmerald,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = boosterDesc,
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        ClearStatusSwitchBanner(
            isOn = tripleComboEnabled,
            activeLabel = "TRIPLE-COMBO 3 MESIN AKTIF [ON]",
            inactiveLabel = "TRIPLE-COMBO BELUM AKTIF [OFF]",
            onToggle = { onToggleTripleCombo(!tripleComboEnabled) }
        )

        Spacer(modifier = Modifier.height(8.dp))

        ClearOnOffButtonRow(
            isOn = tripleComboEnabled,
            turnOnLabel = "🔥 Aktifkan Combo 3X",
            activeOnLabel = "✅ Combo 3X Menyala",
            turnOffLabel = "📴 Matikan Combo",
            activeOffLabel = "⭕ Combo Masih OFF",
            onTurnOn = { onToggleTripleCombo(true) },
            onTurnOff = { onToggleTripleCombo(false) }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onOpenOemBooster,
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "🎮 Buka Panel Game Boost Bawaan HP ($boosterTitle)",
                color = Color(0xFF1A0F00),
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MenuGuideBanner(title: String, guideText: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .shadow(6.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF102244), Color(0xFF071124))
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold, IceCyan.copy(alpha = 0.6f))),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(13.dp)
    ) {
        Text(
            text = "📘 $title",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = guideText,
            color = TextPrimary,
            fontSize = 11.5.sp
        )
    }
}

@Composable
private fun HomeOverviewPane(
    telemetry: DeviceTelemetry?,
    shizukuDiag: ShizukuDiagnostics,
    activeProfile: SystemProfile,
    iphoneAudioEnabled: Boolean,
    dualNetEnabled: Boolean,
    smartCoolBoostEnabled: Boolean,
    tripleComboEnabled: Boolean,
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit,
    onFixMobileDataDns: () -> Unit,
    onToggleTripleCombo: (Boolean) -> Unit,
    onOpenOemBooster: () -> Unit,
    onCleanRam: () -> Unit,
    onSmartCoolBoost: () -> Unit,
    onDailyBoost: () -> Unit,
    onToggleIphoneAudio: (Boolean) -> Unit,
    onToggleDualNet: (Boolean) -> Unit,
    onOpenGaming: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenQris: () -> Unit,
    onRestore: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 01: 3D Command Center, Mode Hybrid Online/Offline & Kunci Memori Permanen",
        guideText = "Tampilan 3D HD v29.5. Seluruh pengaturan yang sudah Anda nyalakan TERSIMPAN PERMANEN (tidak akan reset walau riwayat aplikasi dihapus), bisa dipakai 100% Online maupun Offline, serta menjamin internet Kuota Data Seluler & Wi-Fi tetap lancar!"
    )

    // 3D HD Sovereign Hero Card
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(14.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF15284E), MidnightPanel, MidnightPanelBottom)
                )
            )
            .border(
                width = 1.8.dp,
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan, QuantumEmerald, SovereignGold)),
                shape = RoundedCornerShape(22.dp)
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Rw14QuantumEmblem()
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = "AETHERIA // RW-14 3D HD",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.5.sp
                )
                Text(
                    text = "v29.5 HYBRID ONLINE/OFFLINE · XARENA · ${AetheriaIdentity.LAUNCHER_CODE}",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp
                )
                Text(
                    text = "Architect: ${AetheriaIdentity.ARCHITECT} · NMID: ${AetheriaIdentity.QRIS_NMID}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = telemetry?.networkTransportLabel ?: "🌐 MODE ONLINE / OFFLINE HYBRID AKTIF",
            color = if (telemetry?.isInternetOnline == false) SovereignGold else QuantumEmerald,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        val (tierTitle, tierAdvice) = DeviceTierAdvisor.classifyTier(
            telemetry?.ramTotalMb ?: 4096L,
            telemetry?.cpuCores ?: 8
        )
        Text(
            text = "🎯 $tierTitle — $tierAdvice",
            color = IceCyan,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusBadge(
                text = if (shizukuDiag.isReady) "🟢 SHIZUKU: READY" else "⚡ MODE MANDIRI AKTIF",
                color = if (shizukuDiag.isReady) QuantumEmerald else SovereignGold,
                modifier = Modifier.clickable { onOpenShizuku() }
            )
            StatusBadge(
                text = "🔒 ANTI-RESET RIWAYAT APK",
                color = IceCyan
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusBadge(
                text = "PROFIL: ${activeProfile.id.uppercase()}",
                color = SovereignGold
            )
            StatusBadge(
                text = "📶 PERBAIKI DATA/KUOTA",
                color = QuantumEmerald,
                modifier = Modifier.clickable { onFixMobileDataDns() }
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // NEW: Triple-Combo OEM Game Booster Card (AETHERIA + XArena/OEM + Shizuku)
    TripleComboOemCard(
        oemBooster = telemetry?.oemGameBooster,
        tripleComboEnabled = tripleComboEnabled,
        onToggleTripleCombo = onToggleTripleCombo,
        onOpenOemBooster = onOpenOemBooster
    )

    Spacer(modifier = Modifier.height(12.dp))

    // 100% Honest Real-Time GitHub & Local Usage Counter Card
    CommunityStatsBannerCard(
        activeUsers = telemetry?.communityActiveUsers ?: 1,
        totalDownloads = telemetry?.communityTotalDownloads ?: 1,
        localOptCount = telemetry?.localOptimizationCount ?: 1,
        installedGamesCount = telemetry?.detectedGames?.count { it.isInstalled } ?: 0,
        onOpenQris = onOpenQris
    )

    Spacer(modifier = Modifier.height(12.dp))

    // 3D HD Adaptive Thermal Guard & Smart Cool-Boost Panel with Clear ON/OFF Status
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
            )
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(listOf(QuantumEmerald, IceCyan, SovereignGold)),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(15.dp)
    ) {
        Text(
            text = "🟢 PANEL KONTROL CEPAT 3D & SUHU (${telemetry?.batteryTempC ?: 35.0}°C)",
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Status sakelar kini dibuat super jelas: Hijau Terang = SEDANG AKTIF [ON], Gelap = MATI [OFF].",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Quick Status Indicators for the 3 Core Engines
        ClearStatusSwitchBanner(
            isOn = smartCoolBoostEnabled,
            activeLabel = "SMART COOL-BOOST: AKTIF [ON]",
            inactiveLabel = "SMART COOL-BOOST: MATI [OFF]",
            onToggle = onSmartCoolBoost
        )
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = iphoneAudioEnabled,
            activeLabel = "AUDIO SPEAKER/HEADSET IPHONE: AKTIF [ON]",
            inactiveLabel = "AUDIO SPEAKER/HEADSET IPHONE: MATI [OFF]",
            onToggle = { onToggleIphoneAudio(!iphoneAudioEnabled) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = dualNetEnabled,
            activeLabel = "DUAL-NET BOOST (WI-FI + DATA): AKTIF [ON]",
            inactiveLabel = "DUAL-NET BOOST (WI-FI + DATA): MATI [OFF]",
            onToggle = { onToggleDualNet(!dualNetEnabled) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Row 1: 2 equal-width 3D action buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onCleanRam,
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "🧊 Dinginkan RAM",
                    color = Color(0xFF031A10),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Button(
                onClick = onDailyBoost,
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "📱 Boost TikTok/WA",
                    color = Color(0xFF03101A),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Row 2: Mode Game E-Sports & Restore Standar Pabrik
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onOpenGaming,
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "🎮 Menu E-Sports",
                    color = Color(0xFF1A0F00),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Button(
                onClick = onRestore,
                colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "⚪ Standar Pabrik",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Built-in OTA Update Card on Home Overview
    OtaUpdateCard(
        updateStatus = updateStatus,
        isCheckingUpdate = isCheckingUpdate,
        onCheckUpdate = onCheckUpdate
    )

    Spacer(modifier = Modifier.height(12.dp))

    // 2x2 3D HD Circular Ring Gauges
    val ramPct = telemetry?.ramUsedPercent ?: 0
    val batPct = telemetry?.batteryPercent ?: 0
    val tempC = telemetry?.batteryTempC ?: 35.0
    val romPct = telemetry?.storageUsedPercent ?: 0

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ramPct.toFloat(),
            centerValue = "$ramPct%",
            unitLabel = "LPDDR",
            title = "MEMORI RAM",
            subtitle = "Bebas ${telemetry?.ramAvailMb ?: 0} MB",
            color = IceCyan
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = batPct.toFloat(),
            centerValue = "$batPct%",
            unitLabel = "${telemetry?.batteryVoltageMv ?: 0}mV",
            title = "BATERAI AKTUAL",
            subtitle = if (telemetry?.isCharging == true) "CHARGING" else "DISCHARGING",
            color = QuantumEmerald
        )
    }
    Spacer(modifier = Modifier.height(10.dp))
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ((tempC - 20.0) * 2.5).toFloat().coerceIn(10f, 100f),
            centerValue = "${tempC}°C",
            unitLabel = "THERMAL",
            title = "SUHU & GUARD",
            subtitle = if (tempC >= 40.0) "PANAS (COOLING)" else "ADEM (OPTIMAL)",
            color = SovereignGold
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = romPct.toFloat(),
            centerValue = "$romPct%",
            unitLabel = "UFS ROM",
            title = "PARTISI ROM",
            subtitle = "Bebas ${telemetry?.storageFreeGb ?: 0.0} GB",
            color = CyberViolet
        )
    }
}

@Composable
private fun OtaUpdateCard(
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF102444), Color(0xFF071124)))
            )
            .border(
                width = 1.3.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold, QuantumEmerald)),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(14.dp)
    ) {
        Text(
            text = "🔄 PEMBARUAN APK OTOMATIS (SEPERTI PLAY STORE — TANPA HAPUS APLIKASI LAMA)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = updateStatus?.statusMessage
                ?: "APK v29.0 menggunakan Sertifikat Kriptografi Permanen RW-14 yang sama dengan v28.5. Anda cukup klik 'Instal / Update' langsung tanpa perlu menghapus aplikasi lama!",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onCheckUpdate,
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isCheckingUpdate) "⏳ Memeriksa..." else "🔄 Cek Update Sekarang",
                    color = Color(0xFF031A10),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Button(
                onClick = {
                    try {
                        val url = updateStatus?.downloadUrl ?: AetheriaIdentity.GITHUB_ACTIONS_URL
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } catch (_: Throwable) {
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "📥 Buka Halaman Rilis",
                    color = Color(0xFF03101A),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun CommunityStatsBannerCard(
    activeUsers: Int,
    totalDownloads: Int,
    localOptCount: Int,
    installedGamesCount: Int,
    onOpenQris: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0F203C), Color(0xFF060E1E)))
            )
            .border(
                width = 1.3.dp,
                brush = Brush.horizontalGradient(listOf(IceCyan, SovereignGold)),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(13.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📊 STATISTIK JUJUR REAL-TIME (GITHUB & HP INI)",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
            Text(
                text = "👑 QRIS →",
                color = QuantumEmerald,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                modifier = Modifier.clickable { onOpenQris() }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "$activeUsers",
                label = "Komunitas GitHub",
                color = QuantumEmerald
            )
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "$totalDownloads",
                label = "Rilis Diunduh",
                color = IceCyan
            )
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "$installedGamesCount Game",
                label = "Terpasang di HP",
                color = SovereignGold
            )
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "${localOptCount}x",
                label = "Boost di HP Ini",
                color = CyberViolet
            )
        }
    }
}

@Composable
private fun StatMiniBox(
    modifier: Modifier,
    value: String,
    label: String,
    color: Color
) {
    Column(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
            )
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp,
            maxLines = 1
        )
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 9.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun GaugeCard(
    modifier: Modifier,
    percent: Float,
    centerValue: String,
    unitLabel: String,
    title: String,
    subtitle: String,
    color: Color
) {
    Column(
        modifier = modifier
            .shadow(10.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(listOf(MidnightPanel, MidnightPanelBottom))
            )
            .border(
                width = 1.3.dp,
                brush = Brush.verticalGradient(listOf(color.copy(alpha = 0.65f), Color(0xFF14223E))),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(13.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularRingGauge(
            percent = percent,
            centerValue = centerValue,
            unitLabel = unitLabel,
            ringColor = color
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = title, color = SovereignGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 11.sp)
        Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun DeviceIntelligencePane(
    telemetry: DeviceTelemetry?,
    capabilities: List<FeatureCapability>
) {
    MenuGuideBanner(
        title = "Panduan Menu 02: Device Intelligence, Game Booster HP & Deteksi Game",
        guideText = "Menampilkan spesifikasi asli perangkat keras HP Anda, Game Booster bawaan pabrik yang terdeteksi otomatis (XArena, Game Turbo, HyperBoost, Ultra Game Mode, Game Booster), serta daftar game di HP."
    )
    SectionCard(title = "📱 Spesifikasi Perangkat, Game Booster HP & Sensor Native") {
        Text("Perangkat: ${telemetry?.brand ?: "-"} ${telemetry?.model ?: "-"} (Android ${telemetry?.androidRelease ?: "-"} · SDK ${telemetry?.sdkInt ?: "-"})", color = TextPrimary, fontWeight = FontWeight.Bold)
        Text("SoC / Hardware: ${telemetry?.socHardware ?: "-"} (${telemetry?.cpuCores ?: 8} Cores · ${telemetry?.cpuCurrentMhz ?: "-"} MHz)", color = TextSecondary, fontSize = 12.sp)
        Text("Game Booster Bawaan HP: ${telemetry?.oemGameBooster?.boosterName ?: "XArena / Android Game Space"}", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("Refresh Rate Layar Aktif: ${telemetry?.currentRefreshRateHz ?: 60f} Hz (Mode Didukung: ${telemetry?.supportedRefreshRatesHz?.joinToString(", ") ?: "60"} Hz)", color = IceCyan, fontSize = 12.sp)
        val installedGames = telemetry?.detectedGames?.filter { it.isInstalled } ?: emptyList()
        Text("Game Terdeteksi Otomatis di HP Ini: ${installedGames.size} Game (${if (installedGames.isEmpty()) "Lihat tab 04. E-Sports" else installedGames.joinToString { it.appName }})", color = QuantumEmerald, fontSize = 12.sp)
    }
    Spacer(modifier = Modifier.height(12.dp))
    SectionCard(title = "🔐 Matriks Kapabilitas (Native vs Shizuku)") {
        capabilities.forEach { cap ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                    .border(1.dp, IceCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                    .padding(11.dp)
            ) {
                Text("${cap.title} [${cap.tier.label}]", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(cap.reason, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PerformanceLabPane(
    moduleStates: Map<String, Boolean>,
    iphoneAudioEnabled: Boolean,
    dualNetEnabled: Boolean,
    smartCoolBoostEnabled: Boolean,
    tripleComboEnabled: Boolean,
    oemBooster: OemGameBoosterInfo?,
    onFixMobileDataDns: () -> Unit,
    onToggleTripleCombo: (Boolean) -> Unit,
    onToggleIphoneAudio: (Boolean) -> Unit,
    onToggleDualNet: (Boolean) -> Unit,
    onToggleSmartCoolBoost: (Boolean) -> Unit,
    onRunSpecs: (String, Boolean, String, List<SettingSpec>) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 03: Perf Lab, Audio iPhone & Dual-Channel Network (Anti-Reset Riwayat APK)",
        guideText = "Setiap modul kini memiliki Kunci Memori Permanen: walaupun riwayat aplikasi AETHERIA dihapus dari Recent Apps, semua tombol yang sudah ON tetap tersimpan ON! Dilengkapi juga tombol Perbaiki Internet Data Seluler (Kuota)."
    )

    // Module A: iPhone Speaker & Headset Audio Enhancer Card with Crystal-Clear ON/OFF Indicator
    SectionCard(
        title = "🎧 Modul Suara Speaker & Headset Setara iPhone (Hardware DSP + Clarity)",
        isHighlightedActive = iphoneAudioEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = iphoneAudioEnabled,
            activeLabel = "AUDIO IPHONE SEDANG AKTIF [ON]",
            inactiveLabel = "AUDIO IPHONE MATI / STANDAR [OFF]",
            onToggle = { onToggleIphoneAudio(!iphoneAudioEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Mengaktifkan Hardware AudioFX (LoudnessEnhancer +4.5dB, Warm BassBoost 65%, Spatial 3D Virtualizer 75%) ditambah K2HD, Tube Amp & Dirac HD. Bikin suara Speaker HP maupun Headset/TWS jernih, vokal tegas, dan bass empuk seperti iPhone!",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        ClearOnOffButtonRow(
            isOn = iphoneAudioEnabled,
            turnOnLabel = "▶️ Nyalakan Audio iPhone",
            activeOnLabel = "✅ Audio iPhone: ON",
            turnOffLabel = "📴 Matikan (Standar)",
            activeOffLabel = "⭕ Posisi: Standar (OFF)",
            onTurnOn = { onToggleIphoneAudio(true) },
            onTurnOff = { onToggleIphoneAudio(false) }
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Module B: Dual-Channel Network Boost with Crystal-Clear ON/OFF Indicator
    SectionCard(
        title = "🌐 Akselerasi Saluran Ganda (Boost Wi-Fi + Data Seluler Sosmed & Game)",
        isHighlightedActive = dualNetEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = dualNetEnabled,
            activeLabel = "DUAL-NET BOOST SEDANG AKTIF [ON]",
            inactiveLabel = "DUAL-NET BOOST MATI / STANDAR [OFF]",
            onToggle = { onToggleDualNet(!dualNetEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Menggabungkan kesiagaan Wi-Fi + Data Seluler (mobile_data_always_on=1), mematikan Wi-Fi scan throttling pemicu lonjakan ping, mencegah Wi-Fi sleep, dan menghentikan gangguan frekuensi 2.4GHz BLE. Bikin buka TikTok/IG/WA & main game bebas lag!",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        ClearOnOffButtonRow(
            isOn = dualNetEnabled,
            turnOnLabel = "▶️ Nyalakan Dual-Net",
            activeOnLabel = "✅ Dual-Net: ON",
            turnOffLabel = "📴 Reset Jaringan (OFF)",
            activeOffLabel = "⭕ Posisi: Standar (OFF)",
            onTurnOn = { onToggleDualNet(true) },
            onTurnOff = { onToggleDualNet(false) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onFixMobileDataDns,
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "📶 Perbaiki Internet Data Seluler (Reset DNS agar Kuota 4G/5G Jalan Lagi)",
                color = Color(0xFF1A0F00),
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Module C: Smart Cool-Boost with Crystal-Clear ON/OFF Indicator
    SectionCard(
        title = "⚖️ Smart Cool-Boost (Boost CPU + Boost GPU + Pendingin Otomatis)",
        isHighlightedActive = smartCoolBoostEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = smartCoolBoostEnabled,
            activeLabel = "SMART COOL-BOOST SEDANG AKTIF [ON]",
            inactiveLabel = "SMART COOL-BOOST MATI [OFF]",
            onToggle = { onToggleSmartCoolBoost(!smartCoolBoostEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Menyeimbangkan kenaikan performa CPU & GPU (Zero-Blur + Fast UI 0.5x) sekaligus menyalakan Pendingin Otomatis (membekukan aplikasi pemanas di latar & membersihkan cache) agar HP kencang namun tetap dingin.",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        ClearOnOffButtonRow(
            isOn = smartCoolBoostEnabled,
            turnOnLabel = "▶️ Aktifkan Cool-Boost",
            activeOnLabel = "✅ Cool-Boost: ON",
            turnOffLabel = "📴 Matikan Cool-Boost",
            activeOffLabel = "⭕ Posisi: Standar (OFF)",
            onTurnOn = { onToggleSmartCoolBoost(true) },
            onTurnOff = { onToggleSmartCoolBoost(false) }
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Module D: Triple-Combo Quick Switch in Perf Lab
    SectionCard(
        title = "🔥 Triple-Combo (${oemBooster?.boosterName ?: "XArena / Game Boost HP"} + Shizuku)",
        isHighlightedActive = tripleComboEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = tripleComboEnabled,
            activeLabel = "TRIPLE-COMBO 3X SEDANG AKTIF [ON]",
            inactiveLabel = "TRIPLE-COMBO 3X MATI [OFF]",
            onToggle = { onToggleTripleCombo(!tripleComboEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        ClearOnOffButtonRow(
            isOn = tripleComboEnabled,
            turnOnLabel = "▶️ Aktifkan Combo 3X",
            activeOnLabel = "✅ Combo 3X: ON",
            turnOffLabel = "📴 Matikan Combo 3X",
            activeOffLabel = "⭕ Posisi: OFF",
            onTurnOn = { onToggleTripleCombo(true) },
            onTurnOff = { onToggleTripleCombo(false) }
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🔒 Zona Kontrol Manual Shizuku (Indikator ON/OFF Jelas)") {
        ManualModuleRow(
            title = "⚡ 1. CPU Speed Mode & Cached Apps Freezer",
            desc = "Responsivitas frekuensi CPU & bekukan aplikasi pasif di memori cached.",
            isOn = moduleStates["cpu"] == true,
            onTurnOn = {
                onRunSpecs(
                    "cpu",
                    true,
                    "CPU Speed Mode & Freezer [ON]",
                    listOf(
                        SettingSpec("global", "cached_apps_freezer", "enabled", "Cached Apps Freezer", "Bekukan aplikasi pasif"),
                        SettingSpec("global", "activity_manager_constants", "max_cached_processes=32", "Limit Cached Process", "Hemat RAM latar")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "cpu",
                    false,
                    "CPU Speed Mode & Freezer [OFF]",
                    listOf(SettingSpec("global", "cached_apps_freezer", "default", "Reset Cached Freezer", "Standar sistem"))
                )
            }
        )

        ManualModuleRow(
            title = "🎮 2. GPU Zero-Blur & Skala Animasi 0.5x",
            desc = "Matikan efek blur kompositor Android 12–15 dan percepat transisi jendela ke 0.5x.",
            isOn = moduleStates["gpu"] == true,
            onTurnOn = {
                onRunSpecs(
                    "gpu",
                    true,
                    "GPU Zero-Blur & Animasi 0.5x [ON]",
                    listOf(
                        SettingSpec("global", "disable_window_blurs", "1", "Zero-Blur GPU", "Matikan blur kompositor"),
                        SettingSpec("global", "window_animation_scale", "0.5", "Animasi Jendela 0.5x", "Transisi cepat"),
                        SettingSpec("global", "transition_animation_scale", "0.5", "Animasi Transisi 0.5x", "Perpindahan cepat"),
                        SettingSpec("global", "animator_duration_scale", "0.5", "Durasi Animator 0.5x", "Respons cepat")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "gpu",
                    false,
                    "GPU Zero-Blur & Animasi [OFF]",
                    listOf(
                        SettingSpec("global", "disable_window_blurs", "0", "Blur Standar", "Aktifkan kembali blur"),
                        SettingSpec("global", "window_animation_scale", "1.0", "Animasi Standar 1.0x", "Normal"),
                        SettingSpec("global", "transition_animation_scale", "1.0", "Transisi Standar 1.0x", "Normal"),
                        SettingSpec("global", "animator_duration_scale", "1.0", "Animator Standar 1.0x", "Normal")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "🌐 3. Network Low-Latency & Stop Wi-Fi Scan Lag",
            desc = "Kurangi lonjakan ping akibat pemindaian Wi-Fi/BLE di latar belakang saat main game.",
            isOn = moduleStates["net"] == true,
            onTurnOn = {
                onRunSpecs(
                    "net",
                    true,
                    "Network Low-Latency [ON]",
                    listOf(
                        SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Stop Wi-Fi Scan Lag", "Stabilkan ping"),
                        SettingSpec("global", "ble_scan_always_enabled", "0", "Stop BLE Scan Latar", "Kurangi interferensi")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "net",
                    false,
                    "Network Low-Latency [OFF]",
                    listOf(SettingSpec("global", "wifi_scan_throttle_enabled", "1", "Wi-Fi Scan Standar", "Standar"))
                )
            }
        )

        ManualModuleRow(
            title = "👆 4. Touch Responsiveness 180ms & Pointer Speed",
            desc = "Pangkas jeda tekan-lama dari 400ms ke 180ms dan tingkatkan kecepatan sentuhan layar.",
            isOn = moduleStates["touch"] == true,
            onTurnOn = {
                onRunSpecs(
                    "touch",
                    true,
                    "Touch Responsiveness 180ms [ON]",
                    listOf(
                        SettingSpec("secure", "long_press_timeout", "180", "Touch Timeout 180ms", "Respons sentuh instan"),
                        SettingSpec("system", "pointer_speed", "5", "Pointer Speed +5", "Kecepatan geser tinggi")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "touch",
                    false,
                    "Touch Responsiveness [OFF]",
                    listOf(
                        SettingSpec("secure", "long_press_timeout", "400", "Touch Timeout 400ms", "Standar pabrik"),
                        SettingSpec("system", "pointer_speed", "0", "Pointer Speed 0", "Standar pabrik")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "⚙️ 5. Target Refresh Rate 120Hz Multi-Brand",
            desc = "Kunci min/peak refresh rate 120Hz (AOSP, Infinix/TECNO XArena, Xiaomi/POCO, Samsung, Realme/OPPO, Vivo).",
            isOn = moduleStates["hz"] == true,
            onTurnOn = {
                onRunSpecs(
                    "hz",
                    true,
                    "Target Refresh Rate 120Hz [ON]",
                    listOf(
                        SettingSpec("system", "min_refresh_rate", "120.0", "Min Refresh Rate 120Hz", "Kunci bawah 120Hz"),
                        SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate 120Hz", "Kunci atas 120Hz"),
                        SettingSpec("system", "tran_refresh_mode", "120", "Infinix/TECNO 120Hz", "Mode 120Hz"),
                        SettingSpec("system", "user_refresh_rate", "120", "Xiaomi/HyperOS 120Hz", "Mode 120Hz")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "hz",
                    false,
                    "Target Refresh Rate 60Hz Standar [OFF]",
                    listOf(
                        SettingSpec("system", "min_refresh_rate", "60.0", "Min Refresh Rate 60Hz", "Adaptif 60Hz"),
                        SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate Adaptif", "Adaptif")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "📸 6. Fokus Game Anti Pop-Up (Heads-Up OFF)",
            desc = "Cegah notifikasi mengambang menutupi layar saat bertanding game kompetitif.",
            isOn = moduleStates["focus"] == true,
            onTurnOn = {
                onRunSpecs(
                    "focus",
                    true,
                    "Fokus Game Anti Pop-Up [ON]",
                    listOf(SettingSpec("global", "heads_up_notifications_enabled", "0", "Blokir Pop-Up Mengambang", "Fokus penuh"))
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "focus",
                    false,
                    "Fokus Game Anti Pop-Up [OFF]",
                    listOf(SettingSpec("global", "heads_up_notifications_enabled", "1", "Notifikasi Pop-Up Normal", "Standar"))
                )
            }
        )
    }
}

@Composable
private fun ManualModuleRow(
    title: String,
    desc: String,
    isOn: Boolean,
    onTurnOn: () -> Unit,
    onTurnOff: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .shadow(6.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    if (isOn) listOf(Color(0xFF0A2922), CardInnerBottom)
                    else listOf(CardInnerBg, CardInnerBottom)
                )
            )
            .border(
                width = if (isOn) 1.8.dp else 1.dp,
                color = if (isOn) QuantumEmerald else IceCyan.copy(alpha = 0.28f),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(12.dp)
    ) {
        Text(
            text = title,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = isOn,
            activeLabel = "MODUL SEDANG AKTIF [ON]",
            inactiveLabel = "MODUL MATI / SIAGA [OFF]",
            onToggle = { if (isOn) onTurnOff() else onTurnOn() }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = desc, color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(8.dp))
        ClearOnOffButtonRow(
            isOn = isOn,
            turnOnLabel = "▶️ Nyalakan (ON)",
            activeOnLabel = "✅ Sedang ON",
            turnOffLabel = "📴 Matikan (OFF)",
            activeOffLabel = "⭕ Posisi OFF",
            onTurnOn = onTurnOn,
            onTurnOff = onTurnOff
        )
    }
}

@Composable
private fun GamingCenterPane(
    telemetry: DeviceTelemetry?,
    tripleComboEnabled: Boolean,
    shizukuManager: ShizukuBridgeManager,
    onToggleTripleCombo: (Boolean, String?) -> Unit,
    onOpenOemBooster: () -> Unit,
    onDailyBoost: (Boolean) -> Unit,
    onApplyGamingMode: (String, String, String, Boolean) -> Unit,
    onApplyEsportsGraphics: (String, Boolean, Boolean, Boolean, Boolean, Boolean) -> Unit
) {
    val games = telemetry?.detectedGames ?: emptyList()
    val firstInstalled = games.firstOrNull { it.isInstalled } ?: games.firstOrNull()
    var selectedGamePkg by remember(firstInstalled?.packageName) {
        mutableStateOf(
            shizukuManager.loadUiStateString(
                "selected_game_pkg",
                firstInstalled?.packageName ?: "com.mobile.legends"
            )
        )
    }
    var selectedGameName by remember(firstInstalled?.appName) {
        mutableStateOf(
            shizukuManager.loadUiStateString(
                "selected_game_name",
                firstInstalled?.appName ?: "Mobile Legends: Bang Bang"
            )
        )
    }

    var perfMode by remember {
        mutableStateOf(shizukuManager.loadUiStateString("esports_perf_mode", "esport_ultimate"))
    }
    var anisotropicOn by remember {
        mutableStateOf(shizukuManager.loadUiStateBool("esports_anisotropic", true))
    }
    var textureFilterOn by remember {
        mutableStateOf(shizukuManager.loadUiStateBool("esports_texture_filter", true))
    }
    var mipmapLodOn by remember {
        mutableStateOf(shizukuManager.loadUiStateBool("esports_mipmap_lod", true))
    }
    var frameStabilizerOn by remember {
        mutableStateOf(shizukuManager.loadUiStateBool("esports_frame_stab", true))
    }
    var dualChannelNetOn by remember {
        mutableStateOf(shizukuManager.loadUiStateBool("esports_dual_net", true))
    }

    MenuGuideBanner(
        title = "Panduan Menu 04: Triple-Combo (XArena / Game Boost HP + AETHERIA + Shizuku) & E-Sports Pro",
        guideText = "Otomatis mendeteksi Game Booster bawaan HP Anda (seperti XArena di Infinix/TECNO, Game Turbo di Xiaomi, HyperBoost di Realme/OPPO, Ultra Game di Vivo, Game Booster di Samsung) serta seluruh game terpasang untuk di-combo bersama Shizuku!"
    )

    // 1. Triple-Combo Card in Gaming Center targeting the selected game!
    TripleComboOemCard(
        oemBooster = telemetry?.oemGameBooster,
        tripleComboEnabled = tripleComboEnabled,
        onToggleTripleCombo = { enable -> onToggleTripleCombo(enable, selectedGamePkg) },
        onOpenOemBooster = onOpenOemBooster
    )

    Spacer(modifier = Modifier.height(12.dp))

    val installedCount = games.count { it.isInstalled }
    SectionCard(title = "🎯 Deteksi Otomatis Game di HP Anda ($installedCount Game Terpasang)") {
        Text(
            text = if (installedCount > 0) {
                "Ditemukan $installedCount game terpasang di HP ini! Ketuk nama game di bawah untuk memilih target Triple-Combo & peluncuran:"
            } else {
                "Pilih target game di bawah untuk dioptimasi dengan Triple-Combo XArena, E-Sports Ultimate Pro, atau Mode HP Kentang:"
            },
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            games.forEach { game ->
                val isSelected = (game.packageName == selectedGamePkg)
                Box(
                    modifier = Modifier
                        .shadow(if (isSelected) 8.dp else 3.dp, RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            when {
                                isSelected -> Brush.verticalGradient(listOf(SovereignGold.copy(alpha = 0.30f), Color(0xFF1A1405)))
                                game.isInstalled -> Brush.verticalGradient(listOf(QuantumEmerald.copy(alpha = 0.18f), CardInnerBottom))
                                else -> Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
                            }
                        )
                        .border(
                            width = if (isSelected) 1.6.dp else 1.dp,
                            color = when {
                                isSelected -> SovereignGold
                                game.isInstalled -> QuantumEmerald
                                else -> IceCyan.copy(alpha = 0.25f)
                            },
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            selectedGamePkg = game.packageName
                            selectedGameName = game.appName
                            shizukuManager.saveUiStateString("selected_game_pkg", game.packageName)
                            shizukuManager.saveUiStateString("selected_game_name", game.appName)
                        }
                        .padding(horizontal = 13.dp, vertical = 9.dp)
                ) {
                    Column {
                        Text(
                            text = "${if (game.isInstalled) "🟢 " else "🎮 "}${game.appName}",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Text(
                            text = "${game.packageName} · ${game.categoryLabel}",
                            color = if (game.isInstalled) QuantumEmerald else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "🎯 Target Terpilih: $selectedGameName ($selectedGamePkg)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    onToggleTripleCombo(true, selectedGamePkg)
                },
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                modifier = Modifier.weight(1f)
            ) {
                Text("🔥 Combo 3X Game Ini", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            Button(
                onClick = {
                    onToggleTripleCombo(true, selectedGamePkg)
                    onApplyGamingMode(selectedGamePkg, selectedGameName, "esports_pro", true)
                },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                modifier = Modifier.weight(1f)
            ) {
                Text("🚀 Combo & Buka Game", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🏆 E-Sports Ultimate Pro & Graphic Optimization Suite") {
        Text(
            text = "1. Pilih Mode Performa (Kinerja · Kontrol · Kualitas Grafik · E-Sports Ultimate Pro):",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "⚡ Kinerja",
                selected = perfMode == "kinerja",
                onClick = {
                    perfMode = "kinerja"
                    shizukuManager.saveUiStateString("esports_perf_mode", "kinerja")
                }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🎯 Kontrol",
                selected = perfMode == "kontrol",
                onClick = {
                    perfMode = "kontrol"
                    shizukuManager.saveUiStateString("esports_perf_mode", "kontrol")
                }
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🎨 Kualitas Grafik",
                selected = perfMode == "kualitas_grafik",
                onClick = {
                    perfMode = "kualitas_grafik"
                    shizukuManager.saveUiStateString("esports_perf_mode", "kualitas_grafik")
                }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🏆 E-Sports Pro",
                selected = perfMode == "esport_ultimate",
                onClick = {
                    perfMode = "esport_ultimate"
                    shizukuManager.saveUiStateString("esports_perf_mode", "esport_ultimate")
                }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "2. Parameter Optimasi Grafis & Jaringan Game (Ketuk untuk ON/OFF — Tersimpan Permanen):",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        GraphicOptionToggleRow(
            title = "Penyaring Anisotropik (Anisotropic Filtering 16x)",
            subtitle = "Pertajam tekstur tanah, dinding & objek miring di kejauhan tanpa drop FPS",
            checked = anisotropicOn,
            onToggle = {
                anisotropicOn = !anisotropicOn
                shizukuManager.saveUiStateBool("esports_anisotropic", anisotropicOn)
            }
        )
        GraphicOptionToggleRow(
            title = "Filter Tekstur (Texture Filtering SkiaGL Pro)",
            subtitle = "Optimalkan sampling tekstur GPU agar gambar jernih dan bebas pecah",
            checked = textureFilterOn,
            onToggle = {
                textureFilterOn = !textureFilterOn
                shizukuManager.saveUiStateBool("esports_texture_filter", textureFilterOn)
            }
        )
        GraphicOptionToggleRow(
            title = "Offset Mipmap LOD (Level of Detail Calibration)",
            subtitle = "Seimbangkan ketajaman objek jarak jauh & efisiensi memori VRAM",
            checked = mipmapLodOn,
            onToggle = {
                mipmapLodOn = !mipmapLodOn
                shizukuManager.saveUiStateBool("esports_mipmap_lod", mipmapLodOn)
            }
        )
        GraphicOptionToggleRow(
            title = "Penstabilan Bingkai (Frame Rate Stabilizer 120Hz)",
            subtitle = "Kunci pacing bingkai SurfaceFlinger agar FPS tidak naik-turun saat war",
            checked = frameStabilizerOn,
            onToggle = {
                frameStabilizerOn = !frameStabilizerOn
                shizukuManager.saveUiStateBool("esports_frame_stab", frameStabilizerOn)
            }
        )
        GraphicOptionToggleRow(
            title = "Akselerasi Saluran Ganda & Akselerasi Jaringan Game",
            subtitle = "Gabungkan kesiagaan Wi-Fi + Data Seluler & matikan Wi-Fi scan lag",
            checked = dualChannelNetOn,
            onToggle = {
                dualChannelNetOn = !dualChannelNetOn
                shizukuManager.saveUiStateBool("esports_dual_net", dualChannelNetOn)
            }
        )

        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = {
                onApplyEsportsGraphics(
                    perfMode,
                    anisotropicOn,
                    textureFilterOn,
                    mipmapLodOn,
                    frameStabilizerOn,
                    dualChannelNetOn
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "🏆 Terapkan E-Sports Ultimate Pro + Graphic Optimization",
                color = Color(0xFF1A0F00),
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🎮 Mode Resolusi & Pendingin Game ($selectedGameName)") {
        Text("Refresh Rate Fisik Layar Saat Ini: ${telemetry?.currentRefreshRateHz ?: 60f} Hz", color = QuantumEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "potato_075", false) },
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🥔 Mode Penyelamat HP Kentang (Downscale 0.75x + Animasi 0.0x)", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "balanced_085", false) },
            colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("⚖️ Mode Smart Cool-Boost (CPU + GPU + Pendingin Seimbang 0.85x)", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "thermal_080", false) },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("❄️ Mode Thermal Guard Anti-Panas (Downscale 0.80x + 120Hz)", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "📱 Booster Kelancaran Harian & Sosmed (TikTok, IG, WA, Shopee, YouTube)") {
        Text(
            text = "Mengompilasi ulang kode mesin aplikasi (speed-profile), membersihkan cache korup, mengaktifkan Dual-Channel Network Boost, dan mematikan blur jendela agar scroll TikTok & IG Reels mulus.",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onDailyBoost(false) },
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚡ Boost TikTok/WA/IG", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            Button(
                onClick = { onDailyBoost(true) },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("🔥 Full System Dexopt", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun SelectableChipButton(
    modifier: Modifier,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(if (selected) 6.dp else 2.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) Brush.verticalGradient(listOf(QuantumEmerald.copy(alpha = 0.28f), CardInnerBottom))
                else Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
            )
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) QuantumEmerald else IceCyan.copy(alpha = 0.25f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (selected) "✓ $title" else title,
            color = if (selected) QuantumEmerald else TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun GraphicOptionToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    if (checked) listOf(Color(0xFF08271E), CardInnerBottom)
                    else listOf(CardInnerBg, CardInnerBottom)
                )
            )
            .border(
                width = if (checked) 1.5.dp else 1.dp,
                color = if (checked) QuantumEmerald else AlertRose.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onToggle() }
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            Text(text = subtitle, color = TextSecondary, fontSize = 10.5.sp)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (checked) QuantumEmerald else Color(0xFF2B1624))
                .border(
                    width = 1.dp,
                    color = if (checked) Color.White else AlertRose,
                    shape = RoundedCornerShape(999.dp)
                )
                .padding(horizontal = 11.dp, vertical = 5.dp)
        ) {
            Text(
                text = if (checked) "● ON" else "OFF ○",
                color = if (checked) Color(0xFF031A10) else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
        }
    }
}

@Composable
private fun ShizukuCenterPane(
    diag: ShizukuDiagnostics,
    onRefresh: () -> Unit,
    onRequestPermission: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 05: Shizuku Center & Persistensi Tanpa Wi-Fi",
        guideText = "Shizuku hanya butuh Wi-Fi selama beberapa detik saat mengetuk tombol 'Start' di Wireless Debugging. Begitu skrip diaktifkan di AETHERIA, seluruh pengaturannya tetap berjalan 100% meskipun Wi-Fi dimatikan!"
    )
    SectionCard(title = "🔗 Shizuku Center — Status Layanan & Izin Resmi") {
        Text("Status Saat Ini: ${diag.state.displayTitle} [${diag.state.code}]", color = if (diag.isReady) QuantumEmerald else AlertRose, fontWeight = FontWeight.Bold)
        Text("Aplikasi Terpasang: ${if (diag.shizukuAppInstalled) "Ya" else "Tidak"} · Binder Hidup: ${if (diag.binderAlive) "Ya" else "Tidak"} · Izin: ${if (diag.permissionGranted) "Diberikan" else "Belum"}", color = TextSecondary, fontSize = 12.sp)
        Text("Waktu Pemeriksaan Terakhir: ${diag.lastCheckedTime}", color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text(diag.diagnosticMessage, color = TextPrimary, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        diag.recoverySteps.forEach { step ->
            Text(step, color = SovereignGold, fontSize = 11.5.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onRefresh,
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("↻ Periksa Ulang", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            if (diag.binderAlive && !diag.permissionGranted) {
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("🔑 Minta Izin Shizuku", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun StorageResourcePane(
    telemetry: DeviceTelemetry?,
    adblockShieldEnabled: Boolean,
    onFixMobileDataDns: () -> Unit,
    onScanAndPurgeMalware: (Boolean) -> Unit,
    onConfigureAdblockJudol: (String, Boolean) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 06: Anti-Malware Auto-Purge, Blokir Iklan HP & Perbaikan Kuota Data Seluler",
        guideText = "Versi v29.5 sudah diperbaiki 100%: Fitur Blokir Iklan & Anti-Judol kini menggunakan Mode Hybrid (Opportunistic) sehingga internet Kuota Data Seluler 4G/5G maupun Wi-Fi dijamin tetap lancar 100%!"
    )
    SectionCard(title = "📶 Solusi Cepat: Perbaiki Internet Data Seluler (Kuota 4G/5G)") {
        Text(
            text = "Status DNS Saat Ini: ${telemetry?.privateDnsModeCurrent ?: "opportunistic"} · Jaringan: ${telemetry?.networkTransportLabel ?: "Online/Offline"}\n" +
                "Jika sebelumnya Anda pernah mengaktifkan DNS Family lalu internet tidak jalan saat memakai Kuota Data Seluler (padahal kuota ada), ketuk tombol di bawah untuk melepas kunci Port 853 agar Kuota langsung lancar kembali!",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onFixMobileDataDns,
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "📶 Perbaiki Internet Data Seluler Sekarang (Kuota & Wi-Fi Lancar)",
                color = Color(0xFF031A10),
                fontWeight = FontWeight.Black,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
    Spacer(modifier = Modifier.height(12.dp))
    SectionCard(title = "🛡️ Perisai Anti-Malware 4-Lapis + Auto-Purge (Hapus Otomatis APK Penipuan)") {
        Text(
            text = "Memeriksa header biner (PK\\x03\\x04) di folder Download, WhatsApp & Telegram. Bila ditemukan file APK berbahaya yang menyamar jadi .pdf/.jpg/.doc atau APK penipuan kurir/undangan, file berbahaya tersebut langsung dihapus otomatis!",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { onScanAndPurgeMalware(true) },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🔍 Pindai & Hapus Otomatis Malware / APK Penipuan", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
    }
    Spacer(modifier = Modifier.height(12.dp))
    SectionCard(
        title = "🚫 Pemblokir Iklan Bawaan HP (OEM) & Anti-Judol (Aman Kuota Data & Wi-Fi)",
        isHighlightedActive = adblockShieldEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = adblockShieldEnabled,
            activeLabel = "BLOKIR IKLAN HP (AMAN KUOTA) AKTIF [ON]",
            inactiveLabel = "BLOKIR IKLAN HP MATI / STANDAR [OFF]",
            onToggle = {
                if (adblockShieldEnabled) onConfigureAdblockJudol("off", false)
                else onConfigureAdblockJudol("adguard_family", true)
            }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Membekukan 19 layanan iklan bawaan HP (Xiaomi MSA, Infinix PalmStore/AHA, Realme/OPPO HeyTap, Vivo, Samsung) dan mematikan ID pelacak iklan TANPA mengunci DNS Port 853, sehingga internet Kuota Data Seluler 4G/5G maupun Wi-Fi tetap lancar 100%!",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        ClearOnOffButtonRow(
            isOn = adblockShieldEnabled,
            turnOnLabel = "🛡️ Aktifkan (Aman Kuota)",
            activeOnLabel = "✅ Blokir Iklan: ON",
            turnOffLabel = "⚪ Matikan / Reset DNS",
            activeOffLabel = "⭕ Posisi: Standar (OFF)",
            onTurnOn = { onConfigureAdblockJudol("adguard_family", true) },
            onTurnOff = { onConfigureAdblockJudol("off", false) }
        )
    }
    Spacer(modifier = Modifier.height(12.dp))
    SectionCard(title = "💾 Analisis Penyimpanan & Memori RAM") {
        Text("Penyimpanan Internal: Bebas ${telemetry?.storageFreeGb ?: 0.0} GB dari ${telemetry?.storageTotalGb ?: 0.0} GB (${telemetry?.storageUsedPercent ?: 0}% Terpakai)", color = TextPrimary, fontWeight = FontWeight.Bold)
        Text("Memori RAM: Bebas ${telemetry?.ramAvailMb ?: 0} MB dari ${telemetry?.ramTotalMb ?: 0} MB (${telemetry?.ramUsedPercent ?: 0}% Terpakai)", color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun AutomationProfilesPane(
    activeProfile: SystemProfile,
    onSelectProfile: (SystemProfile) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 07: Automation & System Profiles",
        guideText = "Pilih karakter sistem dengan 1 klik: Balanced (Harian), Gaming, E-Sports Ultimate Pro, Triple-Combo Pro (XArena/OEM + Shizuku), Smart Cool-Boost, Battery Saver, atau Ultra Potato Rescue."
    )
    SectionCard(title = "🔄 Automation & System Profiles (Aktif: ${activeProfile.id})") {
        SystemProfile.values().forEach { prof ->
            val isSelected = (prof == activeProfile)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .shadow(6.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.verticalGradient(
                            if (isSelected) listOf(Color(0xFF08291E), CardInnerBottom)
                            else listOf(CardInnerBg, CardInnerBottom)
                        )
                    )
                    .border(
                        width = if (isSelected) 1.8.dp else 1.dp,
                        color = if (isSelected) QuantumEmerald else IceCyan.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(13.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(prof.title, color = TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(
                        text = if (isSelected) "● AKTIF [ON]" else "○ SIAGA [OFF]",
                        color = if (isSelected) QuantumEmerald else TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 10.sp
                    )
                }
                Text(prof.subtitle, color = TextSecondary, fontSize = 11.5.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onSelectProfile(prof) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isSelected) QuantumEmerald else SovereignGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isSelected) "✅ Sedang Aktif: ${prof.id}" else "▶️ Aktifkan ${prof.id}",
                        color = Color(0xFF04140C),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsLogsPane(
    verifications: List<VerificationRecord>,
    auditLog: List<String>
) {
    MenuGuideBanner(
        title = "Panduan Menu 08: Diagnostics & Logs",
        guideText = "Menampilkan buku besar bukti verifikasi setiap tindakan (Nilai Sebelum -> Target -> Aktual Hasil Pembacaan Ulang) secara transparan dan jujur."
    )
    SectionCard(title = "📋 Riwayat Verifikasi & Log Diagnostik") {
        VerificationListView(verifications = verifications)
        Spacer(modifier = Modifier.height(10.dp))
        auditLog.forEach { ln ->
            Text(ln, color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingsRecoveryQrisPane(
    telemetry: DeviceTelemetry?,
    snapshots: Map<String, String>,
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit,
    onRestore: () -> Unit
) {
    val context = LocalContext.current

    MenuGuideBanner(
        title = "Panduan Menu 09: Cek Update APK, Trik Anti-Blokir WA/Play Protect & QRIS Resmi",
        guideText = "Tempat memeriksa pembaruan APK otomatis (tanpa hapus aplikasi lama), panduan mengatasi peringatan WhatsApp/Play Protect, serta Barcode QRIS Resmi kreator Rangga Winata."
    )

    OtaUpdateCard(
        updateStatus = updateStatus,
        isCheckingUpdate = isCheckingUpdate,
        onCheckUpdate = onCheckUpdate
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Guide card for bypassing WhatsApp & Play Protect prompts
    SectionCard(title = "🛡️ Cara Akalin Peringatan WhatsApp & Google Play Protect") {
        Text(
            text = "1️⃣ Trik Agar Tidak Muncul 'File ini mungkin berbahaya' di WhatsApp:\n" +
                "• WhatsApp otomatis memberi label kuning pada SEMUA file berakhiran .apk yang dikirim langsung lewat chat.\n" +
                "• Solusinya: Bagikan menggunakan LINK GitHub Releases / Google Drive, atau kirim file dalam bentuk .zip! Jika dibuka dari Link Chrome atau .zip, peringatan WhatsApp 100% hilang.\n\n" +
                "2️⃣ Trik Mengatasi Pop-up Google Play Protect ('Aplikasi diblokir'):\n" +
                "• Saat muncul pop-up Play Protect, cukup ketuk tulisan 'Tetap instal' (di atas tombol Oke).\n" +
                "• Atau matikan sementara dari aplikasi Play Store -> ketuk Foto Profil pojok kanan atas -> Play Protect -> ikon Gerigi ⚙️ -> matikan 'Pindai aplikasi dengan Play Protect'.",
            color = TextPrimary,
            fontSize = 11.5.sp
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    CommunityStatsBannerCard(
        activeUsers = telemetry?.communityActiveUsers ?: 1,
        totalDownloads = telemetry?.communityTotalDownloads ?: 1,
        localOptCount = telemetry?.localOptimizationCount ?: 1,
        installedGamesCount = telemetry?.detectedGames?.count { it.isInstalled } ?: 0,
        onOpenQris = {}
    )

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "👑 Architect & QRIS Apresiasi Resmi — Rangga Winata") {
        Text(
            text = "AETHERIA dibuat dengan niat tulus untuk membantu sesama agar HP kentang maupun flagship bisa lancar dipakai harian & main game. Bagi kawan-kawan yang ingin memberikan apresiasi sukarela untuk mendukung pengembangan modul ini, silakan scan QRIS resmi di bawah:",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(10.dp, RoundedCornerShape(18.dp))
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White)
                .border(2.5.dp, SovereignGold, RoundedCornerShape(18.dp))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.qris_rangga),
                contentDescription = "QRIS Resmi Rangga Winata (NMID: ID1026619104999)",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 260.dp, max = 420.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "RANGGA WINATA · NMID: ID1026619104999 · A01",
                color = Color(0xFF0A1629),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Menerima GoPay, OVO, DANA, ShopeePay, LinkAja & Seluruh Mobile Banking (QRIS)",
                color = Color(0xFF334155),
                fontSize = 10.5.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("Merchant: ${AetheriaIdentity.QRIS_MERCHANT}", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text("NMID: ${AetheriaIdentity.QRIS_NMID} · TID: ${AetheriaIdentity.QRIS_TID} · Dicetak oleh: ${AetheriaIdentity.QRIS_PRINTED_BY}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AetheriaIdentity.WA_CHANNEL_URL)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Throwable) {
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("💬 Gabung Saluran Resmi WhatsApp Rangga Winata", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🛡️ Restore Point Snapshot (${snapshots.size} Parameter Tersimpan)") {
        if (snapshots.isEmpty()) {
            Text("Belum ada parameter sistem yang diubah.", color = TextSecondary, fontSize = 12.sp)
        } else {
            snapshots.forEach { (k, v) ->
                Text("$k = $v", color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onRestore,
            colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🛡️ Pulihkan ke Snapshot Asli / Standar Pabrik", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
    }
}

@Composable
private fun LiveScriptExecutionConsoleCard(
    summaryText: String,
    isSuccess: Boolean,
    terminalLines: List<String>,
    verifications: List<VerificationRecord>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF03060E))
            .border(
                width = 1.6.dp,
                color = if (isSuccess) QuantumEmerald.copy(alpha = 0.75f) else AlertRose.copy(alpha = 0.85f),
                shape = RoundedCornerShape(20.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(listOf(Color(0xFF0C1830), Color(0xFF070E1E)))
                )
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("🔴 🟡 🟢", fontSize = 10.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "AETHERIA // RW-14 3D LIVE LOG & BUKTI SKRIP",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 10.5.sp
                )
            }
            Text(
                text = if (isSuccess) "TERVERIFIKASI" else "CEK STATUS",
                color = if (isSuccess) QuantumEmerald else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }

        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isSuccess) QuantumEmerald.copy(alpha = 0.14f)
                        else AlertRose.copy(alpha = 0.16f)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSuccess) QuantumEmerald else AlertRose,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(11.dp)
            ) {
                Text(
                    text = summaryText,
                    color = if (isSuccess) QuantumEmerald else AlertRose,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            terminalLines.forEach { line ->
                val lineColor = when {
                    line.startsWith("✅") || line.startsWith("✓") || line.startsWith("📶") -> QuantumEmerald
                    line.startsWith("❌") -> AlertRose
                    line.startsWith("💡") || line.startsWith("🟡") -> SovereignGold
                    else -> IceCyan
                }
                Text(
                    text = line,
                    color = lineColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }

            if (verifications.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "🔬 TABEL BUKTI PEMBACAAN ULANG (BEFORE → TARGET → ACTUAL):",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                VerificationListView(verifications = verifications)
            }
        }
    }
}

@Composable
private fun VerificationListView(verifications: List<VerificationRecord>) {
    if (verifications.isEmpty()) {
        Text("Belum ada operasi yang diverifikasi pada sesi ini.", color = TextSecondary, fontSize = 12.sp)
        return
    }
    verifications.forEach { v ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                .border(1.dp, IceCyan.copy(alpha = 0.22f), RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Text("${v.feature} (${v.parameter}) — ${v.badge}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Sebelum: ${v.beforeValue} | Target: ${v.targetValue} | Aktual (Readback): ${v.actualValue}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    isHighlightedActive: Boolean = false,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    colors = if (isHighlightedActive) {
                        listOf(Color(0xFF0A2422), MidnightPanel, MidnightPanelBottom)
                    } else {
                        listOf(MidnightPanel, MidnightPanelBottom)
                    }
                )
            )
            .border(
                width = if (isHighlightedActive) 2.dp else 1.4.dp,
                brush = if (isHighlightedActive) {
                    Brush.linearGradient(listOf(QuantumEmerald, IceCyan, SovereignGold))
                } else {
                    Brush.linearGradient(
                        colors = listOf(SovereignGold.copy(alpha = 0.65f), IceCyan.copy(alpha = 0.45f), Color(0xFF16284C))
                    )
                },
                shape = RoundedCornerShape(20.dp)
            )
            .padding(16.dp)
    ) {
        Text(
            text = title,
            color = if (isHighlightedActive) QuantumEmerald else SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun StatusBadge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(999.dp))
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.16f))
            .border(1.2.dp, color, RoundedCornerShape(999.dp))
            .padding(horizontal = 11.dp, vertical = 5.dp)
    ) {
        Text(text = text, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 10.sp)
    }
}

@Composable
private fun BottomNavigationDock(
    currentPage: AetheriaPage,
    onSelect: (AetheriaPage) -> Unit
) {
    val dockItems = listOf(
        AetheriaPage.HOME to "❄️ 3D Home",
        AetheriaPage.PERF_LAB to "🎧 Audio/Net",
        AetheriaPage.GAMING to "🔥 XArena/Game",
        AetheriaPage.SHIZUKU to "🔗 Shizuku",
        AetheriaPage.SETTINGS to "🔄 Update/QR"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp)
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0D1830), Color(0xFF040812)))
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold.copy(alpha = 0.55f), IceCyan.copy(alpha = 0.55f))),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(vertical = 9.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        dockItems.forEach { (page, label) ->
            val active = (currentPage == page)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (active) Brush.horizontalGradient(listOf(SovereignGold.copy(alpha = 0.25f), IceCyan.copy(alpha = 0.20f)))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .border(
                        width = if (active) 1.dp else 0.dp,
                        color = if (active) SovereignGold else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onSelect(page) }
                    .padding(horizontal = 9.dp, vertical = 6.dp)
            ) {
                Text(
                    text = label,
                    color = if (active) SovereignGold else TextSecondary,
                    fontWeight = FontWeight.Black,
                    fontSize = 10.5.sp,
                    maxLines = 1
                )
            }
        }
    }
}
