package com.example.masterpieceoptimizer.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.masterpieceoptimizer.R
import com.example.masterpieceoptimizer.core.AetheriaIdentity
import com.example.masterpieceoptimizer.core.DeviceTelemetry
import com.example.masterpieceoptimizer.core.DeviceTelemetryRepository
import com.example.masterpieceoptimizer.core.DeviceTierAdvisor
import com.example.masterpieceoptimizer.core.FeatureCapability
import com.example.masterpieceoptimizer.core.SettingSpec
import com.example.masterpieceoptimizer.core.ShizukuDiagnostics
import com.example.masterpieceoptimizer.core.SystemProfile
import com.example.masterpieceoptimizer.core.UpdateCheckResult
import com.example.masterpieceoptimizer.core.VerificationRecord
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.theme.AlertRose
import com.example.masterpieceoptimizer.ui.theme.CardInnerBg
import com.example.masterpieceoptimizer.ui.theme.CardInnerBottom
import com.example.masterpieceoptimizer.ui.theme.CircularRingGauge
import com.example.masterpieceoptimizer.ui.theme.CyberViolet
import com.example.masterpieceoptimizer.ui.theme.IceCyan
import com.example.masterpieceoptimizer.ui.theme.MidnightPanel
import com.example.masterpieceoptimizer.ui.theme.MidnightPanelBottom
import com.example.masterpieceoptimizer.ui.theme.ObsidianBg
import com.example.masterpieceoptimizer.ui.theme.QuantumEmerald
import com.example.masterpieceoptimizer.ui.theme.Rw14QuantumEmblem
import com.example.masterpieceoptimizer.ui.theme.SovereignGold
import com.example.masterpieceoptimizer.ui.theme.TextPrimary
import com.example.masterpieceoptimizer.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AetheriaPage(val index: Int, val chipLabel: String) {
    HOME(1, "01. 3D Command Center"),
    DEVICE(2, "02. Device Intel"),
    PERF_LAB(3, "03. Perf Lab & Audio/Net"),
    GAMING(4, "04. E-Sports & Game Booster"),
    SHIZUKU(5, "05. Shizuku Center"),
    STORAGE(6, "06. Anti-Malware, Iklan & Judol"),
    PROFILES(7, "07. Profiles"),
    LOGS(8, "08. Diagnostics"),
    SETTINGS(9, "09. Update & QRIS")
}

@Composable
fun AetheriaRootScreen(
    shizukuManager: ShizukuBridgeManager,
    telemetryRepo: DeviceTelemetryRepository
) {
    val scope = rememberCoroutineScope()
    val shizukuDiag by shizukuManager.diagnostics.collectAsState()
    var currentPage by remember { mutableStateOf(AetheriaPage.HOME) }
    var telemetry by remember { mutableStateOf<DeviceTelemetry?>(null) }
    var activeProfile by remember { mutableStateOf(SystemProfile.BALANCED) }
    var lastVerifications by remember { mutableStateOf<List<VerificationRecord>>(emptyList()) }
    var updateStatus by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var isCheckingUpdate by remember { mutableStateOf(false) }

    var lastActionSummary by remember {
        mutableStateOf("🟢 SISTEM SIAGA (v28.5 3D HD) — Semua optimasi tetap aktif 100% walau Wi-Fi dimatikan!")
    }
    var lastActionSuccess by remember { mutableStateOf(true) }

    val moduleStates = remember { mutableStateMapOf<String, Boolean>() }
    var iphoneAudioEnabled by remember { mutableStateOf(false) }
    var dualNetEnabled by remember { mutableStateOf(false) }
    var smartCoolBoostEnabled by remember { mutableStateOf(false) }

    var terminalLines by remember {
        mutableStateOf(
            listOf(
                "> Initializing ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION})...",
                "✓ Architect Seal: ${AetheriaIdentity.ARCHITECT} (QRIS NMID: ${AetheriaIdentity.QRIS_NMID} · ${AetheriaIdentity.QRIS_TID})",
                "✓ Permanent Signing Certificate Active (Update APK langsung tanpa hapus aplikasi lama)",
                "✓ Offline Persistence Active: Skrip tetap berjalan walau Wi-Fi dimatikan",
                "> Menunggu perintah eksekusi skrip dari pengguna..."
            )
        )
    }
    var auditLog by remember {
        mutableStateOf(
            listOf(
                "✓ ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION}) Initialized",
                "✓ Architect: ${AetheriaIdentity.ARCHITECT} (NMID: ${AetheriaIdentity.QRIS_NMID})"
            )
        )
    }

    LaunchedEffect(shizukuDiag.isReady) {
        while (true) {
            telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
            delay(5000L)
        }
    }

    fun appendLog(msg: String) {
        auditLog = (listOf(msg) + auditLog).take(60)
    }

    fun markImmediateFeedback(actionTitle: String) {
        lastActionSuccess = true
        lastActionSummary = "⚡ MENJALANKAN SKRIP INSTAN: $actionTitle..."
    }

    fun recordExecutionResult(actionTitle: String, records: List<VerificationRecord>) {
        telemetryRepo.incrementOptimizationCounter()
        lastVerifications = records
        val nowStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        val okCount = records.count { it.verified }
        val total = records.size
        val shizukuOff = records.any { it.badge.contains("SHIZUKU OFF") }

        val lines = mutableListOf<String>()
        lines.add("> [$nowStr] MENJALANKAN SKRIP: $actionTitle")
        lines.add("> Status Jembatan Shizuku: ${shizukuDiag.state.displayTitle} [${shizukuDiag.state.code}]")
        lines.add("--------------------------------------------------")
        records.forEachIndexed { idx, r ->
            lines.add("[${idx + 1}] ${r.feature} (${r.parameter})")
            lines.add("    Sebelum: ${r.beforeValue} -> Target: ${r.targetValue} -> Aktual: ${r.actualValue} [${r.badge}]")
        }
        lines.add("--------------------------------------------------")

        if (shizukuOff) {
            lastActionSuccess = false
            lastActionSummary = "❌ GAGAL: SHIZUKU BELUM AKTIF! Buka Menu '05. Shizuku Center' untuk mengaktifkan izin Shizuku terlebih dahulu."
            lines.add("❌ KESIMPULAN SKRIP: BELUM BERHASIL KARENA SHIZUKU OFF.")
            lines.add("💡 SOLUSI: Buka menu '05. Shizuku Center' -> nyalakan Shizuku -> klik 'Minta Izin Shizuku Resmi'.")
        } else if (okCount > 0) {
            lastActionSuccess = true
            lastActionSummary = "✅ SKRIP BERHASIL ($actionTitle): $okCount/$total Parameter Aktif! (Tetap jalan walau Wi-Fi dimatikan)"
            lines.add("✅ KESIMPULAN SKRIP: BERHASIL DITERAPKAN ($okCount/$total Parameter Terverifikasi Sistem)!")
            lines.add("📶 PERSISTENSI: Tetap aktif walau Wi-Fi dimatikan / ganti Data Seluler.")
        } else {
            lastActionSuccess = false
            lastActionSummary = "🟡 INFO ($actionTitle): Skrip dijalankan namun parameter dikunci oleh ROM bawaan HP."
            lines.add("🟡 KESIMPULAN SKRIP: DIEKSEKUSI ($okCount/$total Terverifikasi).")
        }

        terminalLines = lines
        appendLog("[$nowStr] [$actionTitle] $okCount/$total parameter berhasil diverifikasi.")
    }

    fun triggerUpdateCheck() {
        isCheckingUpdate = true
        markImmediateFeedback("🔄 Memeriksa Update APK Terbaru di Server GitHub")
        scope.launch {
            val res = telemetryRepo.checkForApkUpdate()
            updateStatus = res
            isCheckingUpdate = false
            val rec = VerificationRecord(
                feature = "Pemeriksaan Update OTA GitHub",
                parameter = AetheriaIdentity.GITHUB_REPO,
                beforeValue = res.currentVersion,
                targetValue = res.latestVersion,
                actualValue = if (res.hasNewerRelease) "Tersedia Update Baru!" else "Sudah Paling Baru",
                exitCode = 0,
                verified = true,
                badge = if (res.hasNewerRelease) "🚀 UPDATE TERSEDIA" else "🟢 VERSI TERBARU",
                detail = res.statusMessage
            )
            recordExecutionResult("🔄 Cek Update APK Resmi", listOf(rec))
        }
    }

    Scaffold(
        containerColor = ObsidianBg,
        bottomBar = {
            BottomNavigationDock(currentPage = currentPage, onSelect = { currentPage = it })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF060E20), ObsidianBg, Color(0xFF02040A))
                    )
                )
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            // 3D HD Horizontal 9-Page Selector Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AetheriaPage.values().forEach { page ->
                    val selected = (page == currentPage)
                    Box(
                        modifier = Modifier
                            .shadow(if (selected) 8.dp else 3.dp, RoundedCornerShape(999.dp))
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                if (selected) {
                                    Brush.horizontalGradient(
                                        listOf(SovereignGold.copy(alpha = 0.32f), IceCyan.copy(alpha = 0.24f))
                                    )
                                } else {
                                    Brush.verticalGradient(listOf(MidnightPanel, MidnightPanelBottom))
                                }
                            )
                            .border(
                                width = if (selected) 1.5.dp else 1.dp,
                                brush = if (selected) {
                                    Brush.horizontalGradient(listOf(SovereignGold, IceCyan))
                                } else {
                                    Brush.horizontalGradient(listOf(IceCyan.copy(alpha = 0.3f), Color(0xFF1E293B)))
                                },
                                shape = RoundedCornerShape(999.dp)
                            )
                            .clickable { currentPage = page }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = page.chipLabel,
                            color = if (selected) SovereignGold else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            when (currentPage) {
                AetheriaPage.HOME -> HomeOverviewPane(
                    telemetry = telemetry,
                    shizukuDiag = shizukuDiag,
                    activeProfile = activeProfile,
                    iphoneAudioEnabled = iphoneAudioEnabled,
                    dualNetEnabled = dualNetEnabled,
                    smartCoolBoostEnabled = smartCoolBoostEnabled,
                    updateStatus = updateStatus,
                    isCheckingUpdate = isCheckingUpdate,
                    onCheckUpdate = { triggerUpdateCheck() },
                    onCleanRam = {
                        markImmediateFeedback("🧊 Dinginkan & Bersihkan Standby RAM")
                        val beforeAvail = telemetry?.ramAvailMb ?: 0L
                        System.gc()
                        scope.launch {
                            val updated = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                            telemetry = updated
                            val afterAvail = updated.ramAvailMb
                            val rec = VerificationRecord(
                                feature = "Pembersihan Standby RAM & Garbage Collector",
                                parameter = "Runtime.gc() + MemoryTrim",
                                beforeValue = "Bebas $beforeAvail MB",
                                targetValue = "Optimalisasi RAM",
                                actualValue = "Bebas $afterAvail MB (${updated.ramUsedPercent}% Terpakai)",
                                exitCode = 0,
                                verified = true,
                                badge = "🟢 BERHASIL",
                                detail = "WhatsApp & Instagram tetap aman 100%"
                            )
                            recordExecutionResult("🧊 Dinginkan & Bersihkan Standby RAM", listOf(rec))
                        }
                    },
                    onSmartCoolBoost = {
                        smartCoolBoostEnabled = true
                        activeProfile = SystemProfile.SMART_COOL_BOOST
                        markImmediateFeedback("⚖️ Smart Cool-Boost (Boost CPU + GPU + Pendingin Otomatis)")
                        scope.launch {
                            val res = shizukuManager.applySmartCoolBoostBalance()
                            recordExecutionResult("⚖️ Smart Cool-Boost (CPU + GPU + Pendingin Seimbang)", res)
                        }
                    },
                    onDailyBoost = {
                        markImmediateFeedback("📱 Booster Harian TikTok/WA/IG + Network Boost")
                        scope.launch {
                            val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = false)
                            recordExecutionResult("📱 Booster Harian TikTok/WA/IG Anti Patah-Patah", res)
                        }
                    },
                    onToggleIphoneAudio = { enable ->
                        iphoneAudioEnabled = enable
                        markImmediateFeedback("🎧 Modul Suara Speaker & Headset Setara iPhone [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyIphoneAudioEnhancer(enable)
                            recordExecutionResult("🎧 Audio Speaker & Headset iPhone Mode [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onToggleDualNet = { enable ->
                        dualNetEnabled = enable
                        markImmediateFeedback("🌐 Akselerasi Saluran Ganda Wi-Fi + Data [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyDualChannelNetworkBoost(enable)
                            recordExecutionResult("🌐 Boost Jaringan Wi-Fi + Data Seluler [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onOpenGaming = { currentPage = AetheriaPage.GAMING },
                    onOpenShizuku = { currentPage = AetheriaPage.SHIZUKU },
                    onOpenQris = { currentPage = AetheriaPage.SETTINGS },
                    onRestore = {
                        iphoneAudioEnabled = false
                        dualNetEnabled = false
                        smartCoolBoostEnabled = false
                        moduleStates.clear()
                        markImmediateFeedback("🛡️ Restore Point (Kembali ke Standar Pabrik)")
                        scope.launch {
                            shizukuManager.applyIphoneAudioEnhancer(false)
                            val res = shizukuManager.restoreFromSnapshots()
                            activeProfile = SystemProfile.BALANCED
                            recordExecutionResult("🛡️ Restore Point (Kembali ke Standar Pabrik)", res)
                        }
                    }
                )

                AetheriaPage.DEVICE -> DeviceIntelligencePane(
                    telemetry = telemetry,
                    capabilities = telemetryRepo.buildCapabilityMatrix(shizukuDiag.isReady)
                )

                AetheriaPage.PERF_LAB -> PerformanceLabPane(
                    moduleStates = moduleStates,
                    iphoneAudioEnabled = iphoneAudioEnabled,
                    dualNetEnabled = dualNetEnabled,
                    smartCoolBoostEnabled = smartCoolBoostEnabled,
                    onToggleIphoneAudio = { enable ->
                        iphoneAudioEnabled = enable
                        markImmediateFeedback("🎧 Audio Speaker & Headset Setara iPhone [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyIphoneAudioEnhancer(enable)
                            recordExecutionResult("🎧 Audio Speaker & Headset Setara iPhone [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onToggleDualNet = { enable ->
                        dualNetEnabled = enable
                        markImmediateFeedback("🌐 Boost Jaringan Saluran Ganda Wi-Fi + Data [${if (enable) "ON" else "OFF"}]")
                        scope.launch {
                            val res = shizukuManager.applyDualChannelNetworkBoost(enable)
                            recordExecutionResult("🌐 Boost Jaringan Wi-Fi + Data Seluler [${if (enable) "ON" else "OFF"}]", res)
                        }
                    },
                    onRunSmartCoolBoost = {
                        smartCoolBoostEnabled = true
                        activeProfile = SystemProfile.SMART_COOL_BOOST
                        markImmediateFeedback("⚖️ Smart Cool-Boost (CPU + GPU + Pendingin Otomatis)")
                        scope.launch {
                            val res = shizukuManager.applySmartCoolBoostBalance()
                            recordExecutionResult("⚖️ Smart Cool-Boost (CPU + GPU + Pendingin Seimbang)", res)
                        }
                    },
                    onRunSpecs = { moduleId, isTurnOn, title, specs ->
                        moduleStates[moduleId] = isTurnOn
                        markImmediateFeedback(title)
                        scope.launch {
                            val res = shizukuManager.applyAndVerifySpecs(specs)
                            recordExecutionResult(title, res)
                        }
                    }
                )

                AetheriaPage.GAMING -> GamingCenterPane(
                    telemetry = telemetry,
                    onDailyBoost = { fullDex ->
                        val title = if (fullDex) "🔥 Full System Dexopt" else "⚡ Booster Cepat TikTok/WA/IG/Shopee/YT"
                        markImmediateFeedback(title)
                        scope.launch {
                            val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = fullDex)
                            recordExecutionResult(title, res)
                        }
                    },
                    onApplyGamingMode = { gamePkg, gameName, mode, launchAfter ->
                        val modeLabel = when (mode) {
                            "potato_075" -> "🥔 Mode Penyelamat HP Kentang 0.75x ($gameName)"
                            "thermal_080" -> "❄️ Mode Thermal Guard 0.80x ($gameName)"
                            "balanced_085" -> "⚖️ Smart Cool-Boost 0.85x ($gameName)"
                            "esports_pro" -> "🏆 E-Sports Ultimate Pro ($gameName)"
                            else -> "🎮 Mode Native HD 1.0x ($gameName)"
                        }
                        markImmediateFeedback(modeLabel)
                        scope.launch {
                            val res = shizukuManager.applyUniversalGamingMode(gamePkg, mode)
                            activeProfile = when (mode) {
                                "potato_075" -> SystemProfile.POTATO_RESCUE
                                "esports_pro" -> SystemProfile.ESPORT_ULTIMATE_PRO
                                "balanced_085" -> SystemProfile.SMART_COOL_BOOST
                                else -> SystemProfile.GAMING
                            }
                            recordExecutionResult(modeLabel, res)
                            if (launchAfter) {
                                shizukuManager.launchGamePackage(gamePkg)
                            }
                        }
                    },
                    onApplyEsportsGraphics = { perfMode, aniso, tex, mipmap, frameStab, dualNet ->
                        val title = "🏆 E-Sports Ultimate Pro & Graphic Optimization ($perfMode)"
                        markImmediateFeedback(title)
                        scope.launch {
                            val res = shizukuManager.applyEsportsProGraphics(
                                performanceMode = perfMode,
                                anisotropicOn = aniso,
                                textureFilterOn = tex,
                                mipmapLodOn = mipmap,
                                frameStabilizerOn = frameStab,
                                dualChannelNetOn = dualNet
                            )
                            activeProfile = SystemProfile.ESPORT_ULTIMATE_PRO
                            recordExecutionResult(title, res)
                        }
                    }
                )

                AetheriaPage.SHIZUKU -> ShizukuCenterPane(
                    diag = shizukuDiag,
                    onRefresh = {
                        val d = shizukuManager.refreshDiagnostics()
                        val rec = VerificationRecord(
                            feature = "Pemeriksaan Jembatan Shizuku",
                            parameter = "Shizuku.pingBinder() + checkSelfPermission()",
                            beforeValue = "Probe",
                            targetValue = "READY (uid=2000)",
                            actualValue = "${d.state.displayTitle} [${d.state.code}]",
                            exitCode = if (d.isReady) 0 else -1,
                            verified = d.isReady,
                            badge = if (d.isReady) "🟢 TERHUBUNG" else "🔴 BELUM SIAP",
                            detail = d.diagnosticMessage
                        )
                        recordExecutionResult("🔗 Cek Koneksi & Izin Shizuku", listOf(rec))
                    },
                    onRequestPermission = { shizukuManager.requestPermissionSafely() }
                )

                AetheriaPage.STORAGE -> StorageResourcePane(
                    telemetry = telemetry,
                    onScanAndPurgeMalware = { autoPurge ->
                        markImmediateFeedback("🛡️ Pemindaian Anti-Malware & Auto-Purge APK Penipuan")
                        scope.launch {
                            val res = shizukuManager.scanAndAutoPurgeMalware(autoPurge = autoPurge)
                            recordExecutionResult("🛡️ Pemindaian Anti-Malware & Auto-Purge APK Penipuan", res)
                        }
                    },
                    onConfigureAdblockJudol = { dnsMode, freezeOem ->
                        markImmediateFeedback("🚫 Pemblokir Iklan HP & Perisai DNS Anti-Judol ($dnsMode)")
                        scope.launch {
                            val res = shizukuManager.configureAdblockAndJudolShield(dnsMode, freezeOem)
                            recordExecutionResult("🚫 Pemblokir Iklan HP & Perisai DNS Anti-Judol ($dnsMode)", res)
                        }
                    }
                )

                AetheriaPage.PROFILES -> AutomationProfilesPane(
                    activeProfile = activeProfile,
                    onSelectProfile = { profile ->
                        activeProfile = profile
                        markImmediateFeedback("🔄 Terapkan Profil Sistem: ${profile.title}")
                        scope.launch {
                            val res = shizukuManager.applyAndVerifySpecs(profile.specs)
                            recordExecutionResult("🔄 Terapkan Profil Sistem: ${profile.title}", res)
                        }
                    }
                )

                AetheriaPage.LOGS -> DiagnosticsLogsPane(
                    verifications = lastVerifications,
                    auditLog = auditLog
                )

                AetheriaPage.SETTINGS -> SettingsRecoveryQrisPane(
                    telemetry = telemetry,
                    snapshots = shizukuManager.getSavedSnapshots(),
                    updateStatus = updateStatus,
                    isCheckingUpdate = isCheckingUpdate,
                    onCheckUpdate = { triggerUpdateCheck() },
                    onRestore = {
                        markImmediateFeedback("🛡️ Pulihkan Snapshot Asli / Standar Pabrik")
                        scope.launch {
                            shizukuManager.applyIphoneAudioEnhancer(false)
                            val res = shizukuManager.restoreFromSnapshots()
                            activeProfile = SystemProfile.BALANCED
                            recordExecutionResult("🛡️ Pulihkan Snapshot Asli / Standar Pabrik", res)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ALWAYS-VISIBLE 3D HD LIVE EXECUTION CONSOLE & PROOF OF SCRIPT SUCCESS ON EVERY PAGE
            LiveScriptExecutionConsoleCard(
                summaryText = lastActionSummary,
                isSuccess = lastActionSuccess,
                terminalLines = terminalLines,
                verifications = lastVerifications
            )
        }
    }
}

@Composable
private fun MenuGuideBanner(title: String, guideText: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .shadow(6.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF102244), Color(0xFF071124))
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold, IceCyan.copy(alpha = 0.6f))),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(13.dp)
    ) {
        Text(
            text = "📘 $title",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = guideText,
            color = TextPrimary,
            fontSize = 11.5.sp
        )
    }
}

@Composable
private fun HomeOverviewPane(
    telemetry: DeviceTelemetry?,
    shizukuDiag: ShizukuDiagnostics,
    activeProfile: SystemProfile,
    iphoneAudioEnabled: Boolean,
    dualNetEnabled: Boolean,
    smartCoolBoostEnabled: Boolean,
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit,
    onCleanRam: () -> Unit,
    onSmartCoolBoost: () -> Unit,
    onDailyBoost: () -> Unit,
    onToggleIphoneAudio: (Boolean) -> Unit,
    onToggleDualNet: (Boolean) -> Unit,
    onOpenGaming: () -> Unit,
    onOpenShizuku: () -> Unit,
    onOpenQris: () -> Unit,
    onRestore: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 01: 3D Command Center, Smart Cool-Boost & Offline Persistence",
        guideText = "Tampilan 3D HD Quantum OS. Begitu tombol optimasi diaktifkan, skrip tersimpan permanen di tabel sistem Android dan TETAP JALAN 100% walau Wi-Fi dimatikan atau berganti ke Data Seluler, sampai HP di-restart atau tombol 'Standar Pabrik' ditekan."
    )

    // 3D HD Sovereign Hero Card
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(14.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF15284E), MidnightPanel, MidnightPanelBottom)
                )
            )
            .border(
                width = 1.8.dp,
                brush = Brush.linearGradient(listOf(SovereignGold, IceCyan, QuantumEmerald, SovereignGold)),
                shape = RoundedCornerShape(22.dp)
            )
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Rw14QuantumEmblem()
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = "AETHERIA // RW-14 3D HD",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.5.sp
                )
                Text(
                    text = "v28.5 SOVEREIGN · E-SPORTS · IPHONE AUDIO · DUAL-NET · ${AetheriaIdentity.LAUNCHER_CODE}",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp
                )
                Text(
                    text = "Architect: ${AetheriaIdentity.ARCHITECT} · NMID: ${AetheriaIdentity.QRIS_NMID}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        val (tierTitle, tierAdvice) = DeviceTierAdvisor.classifyTier(
            telemetry?.ramTotalMb ?: 4096L,
            telemetry?.cpuCores ?: 8
        )
        Text(
            text = "🎯 $tierTitle — $tierAdvice",
            color = IceCyan,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusBadge(
                text = if (shizukuDiag.isReady) "🟢 SHIZUKU: READY" else "🔴 ${shizukuDiag.state.code}",
                color = if (shizukuDiag.isReady) QuantumEmerald else AlertRose,
                modifier = Modifier.clickable { onOpenShizuku() }
            )
            StatusBadge(
                text = "📶 TETAP AKTIF TANPA WI-FI",
                color = IceCyan
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusBadge(
                text = "PROFIL: ${activeProfile.id.uppercase()}",
                color = SovereignGold
            )
            StatusBadge(
                text = "🔄 CEK UPDATE APK",
                color = QuantumEmerald,
                modifier = Modifier.clickable { onCheckUpdate() }
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 100% Honest Real-Time GitHub & Local Usage Counter Card
    CommunityStatsBannerCard(
        activeUsers = telemetry?.communityActiveUsers ?: 1,
        totalDownloads = telemetry?.communityTotalDownloads ?: 1,
        localOptCount = telemetry?.localOptimizationCount ?: 1,
        installedGamesCount = telemetry?.detectedGames?.count { it.isInstalled } ?: 0,
        onOpenQris = onOpenQris
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Wi-Fi Off Persistence Assurance Banner
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0D213F), Color(0xFF071224)))
            )
            .border(1.2.dp, IceCyan.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
            .padding(13.dp)
    ) {
        Text(
            text = "📶 JAMINAN PERSISTENSI: TETAP BERJALAN WALAU WI-FI MATI!",
            color = QuantumEmerald,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Shizuku hanya butuh Wi-Fi selama 5 detik saat penyambungan awal. Setelah skrip diaktifkan di AETHERIA, nilainya terkunci di sistem Android dan TETAP AKTIF 100% meskipun Wi-Fi dimatikan atau Anda memakai Data Seluler (kecuali HP di-restart atau Anda menekan tombol 'Standar Pabrik').",
            color = TextSecondary,
            fontSize = 11.sp
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 3D HD Adaptive Thermal Guard & Smart Cool-Boost Panel
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
            )
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(listOf(QuantumEmerald, IceCyan, SovereignGold)),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(15.dp)
    ) {
        Text(
            text = "🟢 MESIN SKRIP 3D: SMART COOL-BOOST & THERMAL (${telemetry?.batteryTempC ?: 35.0}°C)",
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Boost CPU + Boost GPU + Pendingin Otomatis bekerja seimbang secara instan (<0.12 detik).",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Highlighted 1-Click 3D Smart Cool-Boost Button
        Button(
            onClick = onSmartCoolBoost,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (smartCoolBoostEnabled) QuantumEmerald else SovereignGold
            ),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 11.dp),
            modifier = Modifier
                .fillMaxWidth()
                .shadow(6.dp, RoundedCornerShape(14.dp))
        ) {
            Text(
                text = "⚖️ Boost CPU + GPU + Pendingin Otomatis (Seimbang)",
                color = Color(0xFF04140C),
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Row 1: 2 equal-width 3D buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onCleanRam,
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "🧊 Dinginkan RAM",
                    color = Color(0xFF031A10),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Button(
                onClick = onDailyBoost,
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "📱 Boost TikTok/WA",
                    color = Color(0xFF03101A),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Row 2: iPhone Audio Quick Toggle & Dual-Channel Network Quick Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onToggleIphoneAudio(!iphoneAudioEnabled) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (iphoneAudioEnabled) QuantumEmerald else Color(0xFF192B4B)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (iphoneAudioEnabled) "🎧 Audio iPhone: ON" else "🎧 Audio iPhone: OFF",
                    color = if (iphoneAudioEnabled) Color(0xFF031A10) else TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Button(
                onClick = { onToggleDualNet(!dualNetEnabled) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (dualNetEnabled) QuantumEmerald else Color(0xFF192B4B)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (dualNetEnabled) "🌐 Dual-Net Boost: ON" else "🌐 Dual-Net Boost: OFF",
                    color = if (dualNetEnabled) Color(0xFF031A10) else TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Row 3: Mode Game E-Sports & Restore Standar Pabrik
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onOpenGaming,
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "🎮 E-Sports & Game",
                    color = Color(0xFF1A0F00),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Button(
                onClick = onRestore,
                colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "⚪ Standar Pabrik",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Built-in OTA Update Card on Home Overview
    OtaUpdateCard(
        updateStatus = updateStatus,
        isCheckingUpdate = isCheckingUpdate,
        onCheckUpdate = onCheckUpdate
    )

    Spacer(modifier = Modifier.height(12.dp))

    // 2x2 3D HD Circular Ring Gauges
    val ramPct = telemetry?.ramUsedPercent ?: 0
    val batPct = telemetry?.batteryPercent ?: 0
    val tempC = telemetry?.batteryTempC ?: 35.0
    val romPct = telemetry?.storageUsedPercent ?: 0

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ramPct.toFloat(),
            centerValue = "$ramPct%",
            unitLabel = "LPDDR",
            title = "MEMORI RAM",
            subtitle = "Bebas ${telemetry?.ramAvailMb ?: 0} MB",
            color = IceCyan
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = batPct.toFloat(),
            centerValue = "$batPct%",
            unitLabel = "${telemetry?.batteryVoltageMv ?: 0}mV",
            title = "BATERAI AKTUAL",
            subtitle = if (telemetry?.isCharging == true) "CHARGING" else "DISCHARGING",
            color = QuantumEmerald
        )
    }
    Spacer(modifier = Modifier.height(10.dp))
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ((tempC - 20.0) * 2.5).toFloat().coerceIn(10f, 100f),
            centerValue = "${tempC}°C",
            unitLabel = "THERMAL",
            title = "SUHU & GUARD",
            subtitle = if (tempC >= 40.0) "PANAS (COOLING)" else "ADEM (OPTIMAL)",
            color = SovereignGold
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = romPct.toFloat(),
            centerValue = "$romPct%",
            unitLabel = "UFS ROM",
            title = "PARTISI ROM",
            subtitle = "Bebas ${telemetry?.storageFreeGb ?: 0.0} GB",
            color = CyberViolet
        )
    }
}

@Composable
private fun OtaUpdateCard(
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF102444), Color(0xFF071124)))
            )
            .border(
                width = 1.3.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold, QuantumEmerald)),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(14.dp)
    ) {
        Text(
            text = "🔄 PEMBARUAN APK OTOMATIS (SEPERTI PLAY STORE — TANPA HAPUS APLIKASI LAMA)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = updateStatus?.statusMessage
                ?: "Mulai v28.5 ini, APK dilengkapi Sertifikat Kriptografi Permanen RW-14. Setiap kali ada versi baru, Anda cukup klik 'Update' tanpa perlu menghapus aplikasi lama!",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onCheckUpdate,
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isCheckingUpdate) "⏳ Memeriksa..." else "🔄 Cek Update Sekarang",
                    color = Color(0xFF031A10),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Button(
                onClick = {
                    try {
                        val url = updateStatus?.downloadUrl ?: AetheriaIdentity.GITHUB_ACTIONS_URL
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } catch (_: Throwable) {
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "📥 Buka Halaman Rilis",
                    color = Color(0xFF03101A),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun CommunityStatsBannerCard(
    activeUsers: Int,
    totalDownloads: Int,
    localOptCount: Int,
    installedGamesCount: Int,
    onOpenQris: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0F203C), Color(0xFF060E1E)))
            )
            .border(
                width = 1.3.dp,
                brush = Brush.horizontalGradient(listOf(IceCyan, SovereignGold)),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(13.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📊 STATISTIK JUJUR REAL-TIME (GITHUB & HP INI)",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
            Text(
                text = "👑 QRIS →",
                color = QuantumEmerald,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                modifier = Modifier.clickable { onOpenQris() }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "$activeUsers",
                label = "Komunitas GitHub",
                color = QuantumEmerald
            )
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "$totalDownloads",
                label = "Rilis Diunduh",
                color = IceCyan
            )
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "$installedGamesCount Game",
                label = "Terpasang di HP",
                color = SovereignGold
            )
            StatMiniBox(
                modifier = Modifier.weight(1f),
                value = "${localOptCount}x",
                label = "Boost di HP Ini",
                color = CyberViolet
            )
        }
    }
}

@Composable
private fun StatMiniBox(
    modifier: Modifier,
    value: String,
    label: String,
    color: Color
) {
    Column(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
            )
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            color = color,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp,
            maxLines = 1
        )
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 9.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun GaugeCard(
    modifier: Modifier,
    percent: Float,
    centerValue: String,
    unitLabel: String,
    title: String,
    subtitle: String,
    color: Color
) {
    Column(
        modifier = modifier
            .shadow(10.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(listOf(MidnightPanel, MidnightPanelBottom))
            )
            .border(
                width = 1.3.dp,
                brush = Brush.verticalGradient(listOf(color.copy(alpha = 0.65f), Color(0xFF14223E))),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(13.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularRingGauge(
            percent = percent,
            centerValue = centerValue,
            unitLabel = unitLabel,
            ringColor = color
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = title, color = SovereignGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 11.sp)
        Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun DeviceIntelligencePane(
    telemetry: DeviceTelemetry?,
    capabilities: List<FeatureCapability>
) {
    MenuGuideBanner(
        title = "Panduan Menu 02: Device Intelligence & Deteksi Game",
        guideText = "Menampilkan spesifikasi asli perangkat keras HP Anda (Chipset SoC, GPU, RAM, versi Android 7 s/d 15+), daftar game yang terdeteksi di HP, serta matriks kapabilitas fitur Native vs Shizuku."
    )
    SectionCard(title = "📱 Spesifikasi Perangkat & Sensor Native") {
        Text("Perangkat: ${telemetry?.brand ?: "-"} ${telemetry?.model ?: "-"} (Android ${telemetry?.androidRelease ?: "-"} · SDK ${telemetry?.sdkInt ?: "-"})", color = TextPrimary, fontWeight = FontWeight.Bold)
        Text("SoC / Hardware: ${telemetry?.socHardware ?: "-"} (${telemetry?.cpuCores ?: 8} Cores · ${telemetry?.cpuCurrentMhz ?: "-"} MHz)", color = TextSecondary, fontSize = 12.sp)
        Text("Refresh Rate Layar Aktif: ${telemetry?.currentRefreshRateHz ?: 60f} Hz (Mode Didukung: ${telemetry?.supportedRefreshRatesHz?.joinToString(", ") ?: "60"} Hz)", color = IceCyan, fontSize = 12.sp)
        val installedGames = telemetry?.detectedGames?.filter { it.isInstalled } ?: emptyList()
        Text("Game Terdeteksi Otomatis di HP Ini: ${installedGames.size} Game (${if (installedGames.isEmpty()) "Lihat tab 04. E-Sports" else installedGames.joinToString { it.appName }})", color = QuantumEmerald, fontSize = 12.sp)
        Text("Termux Localhost Bridge (127.0.0.1:8080): ${if (telemetry?.termuxEngineConnected == true) "🟢 TERHUBUNG" else "⚪ STANDALONE APK MODE"}", color = SovereignGold, fontSize = 12.sp)
    }
    Spacer(modifier = Modifier.height(12.dp))
    SectionCard(title = "🔐 Matriks Kapabilitas (Native vs Shizuku)") {
        capabilities.forEach { cap ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                    .border(1.dp, IceCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                    .padding(11.dp)
            ) {
                Text("${cap.title} [${cap.tier.label}]", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(cap.reason, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PerformanceLabPane(
    moduleStates: Map<String, Boolean>,
    iphoneAudioEnabled: Boolean,
    dualNetEnabled: Boolean,
    smartCoolBoostEnabled: Boolean,
    onToggleIphoneAudio: (Boolean) -> Unit,
    onToggleDualNet: (Boolean) -> Unit,
    onRunSmartCoolBoost: () -> Unit,
    onRunSpecs: (String, Boolean, String, List<SettingSpec>) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 03: Perf Lab, Audio iPhone & Dual-Channel Network",
        guideText = "Sakelar manual dengan respon instan (<0.12 detik via Fast-Batch Shizuku IPC). Begitu diaktifkan (ON), seluruh pengaturannya tetap berjalan meskipun Wi-Fi dimatikan!"
    )

    SectionCard(title = "🎧 Modul Suara Speaker & Headset Setara iPhone (Hardware DSP + Clarity)") {
        Text(
            text = "Mengaktifkan Hardware AudioFX (LoudnessEnhancer +4.5dB, Warm BassBoost 65%, Spatial 3D Virtualizer 75%) ditambah K2HD, Tube Amp & Dirac HD. Bikin suara Speaker HP maupun Headset/TWS jernih, vokal tegas, dan bass empuk seperti iPhone!",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onToggleIphoneAudio(true) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (iphoneAudioEnabled) QuantumEmerald else SovereignGold
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (iphoneAudioEnabled) "🟢 Audio iPhone: AKTIF" else "🎧 Aktifkan Audio iPhone",
                    color = Color(0xFF031A10),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Button(
                onClick = { onToggleIphoneAudio(false) },
                colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚪ Matikan (Standar)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🌐 Akselerasi Saluran Ganda (Boost Wi-Fi + Data Seluler Sosmed & Game)") {
        Text(
            text = "Menggabungkan kesiagaan Wi-Fi + Data Seluler (mobile_data_always_on=1), mematikan Wi-Fi scan throttling pemicu lonjakan ping, mencegah Wi-Fi sleep, dan menghentikan gangguan frekuensi 2.4GHz BLE. Bikin buka TikTok/IG/WA & main game bebas lag!",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onToggleDualNet(true) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (dualNetEnabled) QuantumEmerald else IceCyan
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (dualNetEnabled) "🟢 Dual-Net: AKTIF" else "🚀 Boost Wi-Fi + Data",
                    color = Color(0xFF03101A),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Button(
                onClick = { onToggleDualNet(false) },
                colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚪ Reset Jaringan", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "⚖️ Smart Cool-Boost (Boost CPU + Boost GPU + Pendingin Otomatis)") {
        Text(
            text = "Menyeimbangkan kenaikan performa CPU & GPU (Zero-Blur + Fast UI 0.5x) sekaligus menyalakan Pendingin Otomatis (membekukan aplikasi pemanas di latar & membersihkan cache) agar HP kencang namun tetap dingin.",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onRunSmartCoolBoost,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (smartCoolBoostEnabled) QuantumEmerald else SovereignGold
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = if (smartCoolBoostEnabled) "❄️⚡ Smart Cool-Boost Sedang Aktif (Klik untuk Refresh)" else "⚖️ Aktifkan Boost CPU + GPU + Pendingin Otomatis Seimbang",
                color = Color(0xFF031A10),
                fontWeight = FontWeight.Black,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🔒 Zona Kontrol Manual Shizuku (Respon Instan ON/OFF)") {
        ManualModuleRow(
            title = "⚡ 1. CPU Speed Mode & Cached Apps Freezer",
            desc = "Responsivitas frekuensi CPU & bekukan aplikasi pasif di memori cached.",
            isOn = moduleStates["cpu"] == true,
            onTurnOn = {
                onRunSpecs(
                    "cpu",
                    true,
                    "CPU Speed Mode & Freezer [ON]",
                    listOf(
                        SettingSpec("global", "cached_apps_freezer", "enabled", "Cached Apps Freezer", "Bekukan aplikasi pasif"),
                        SettingSpec("global", "activity_manager_constants", "max_cached_processes=32", "Limit Cached Process", "Hemat RAM latar")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "cpu",
                    false,
                    "CPU Speed Mode & Freezer [OFF]",
                    listOf(SettingSpec("global", "cached_apps_freezer", "default", "Reset Cached Freezer", "Standar sistem"))
                )
            }
        )

        ManualModuleRow(
            title = "🎮 2. GPU Zero-Blur & Skala Animasi 0.5x",
            desc = "Matikan efek blur kompositor Android 12–15 dan percepat transisi jendela ke 0.5x.",
            isOn = moduleStates["gpu"] == true,
            onTurnOn = {
                onRunSpecs(
                    "gpu",
                    true,
                    "GPU Zero-Blur & Animasi 0.5x [ON]",
                    listOf(
                        SettingSpec("global", "disable_window_blurs", "1", "Zero-Blur GPU", "Matikan blur kompositor"),
                        SettingSpec("global", "window_animation_scale", "0.5", "Animasi Jendela 0.5x", "Transisi cepat"),
                        SettingSpec("global", "transition_animation_scale", "0.5", "Animasi Transisi 0.5x", "Perpindahan cepat"),
                        SettingSpec("global", "animator_duration_scale", "0.5", "Durasi Animator 0.5x", "Respons cepat")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "gpu",
                    false,
                    "GPU Zero-Blur & Animasi [OFF]",
                    listOf(
                        SettingSpec("global", "disable_window_blurs", "0", "Blur Standar", "Aktifkan kembali blur"),
                        SettingSpec("global", "window_animation_scale", "1.0", "Animasi Standar 1.0x", "Normal"),
                        SettingSpec("global", "transition_animation_scale", "1.0", "Transisi Standar 1.0x", "Normal"),
                        SettingSpec("global", "animator_duration_scale", "1.0", "Animator Standar 1.0x", "Normal")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "🌐 3. Network Low-Latency & Stop Wi-Fi Scan Lag",
            desc = "Kurangi lonjakan ping akibat pemindaian Wi-Fi/BLE di latar belakang saat main game.",
            isOn = moduleStates["net"] == true,
            onTurnOn = {
                onRunSpecs(
                    "net",
                    true,
                    "Network Low-Latency [ON]",
                    listOf(
                        SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Stop Wi-Fi Scan Lag", "Stabilkan ping"),
                        SettingSpec("global", "ble_scan_always_enabled", "0", "Stop BLE Scan Latar", "Kurangi interferensi")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "net",
                    false,
                    "Network Low-Latency [OFF]",
                    listOf(SettingSpec("global", "wifi_scan_throttle_enabled", "1", "Wi-Fi Scan Standar", "Standar"))
                )
            }
        )

        ManualModuleRow(
            title = "👆 4. Touch Responsiveness 180ms & Pointer Speed",
            desc = "Pangkas jeda tekan-lama dari 400ms ke 180ms dan tingkatkan kecepatan sentuhan layar.",
            isOn = moduleStates["touch"] == true,
            onTurnOn = {
                onRunSpecs(
                    "touch",
                    true,
                    "Touch Responsiveness 180ms [ON]",
                    listOf(
                        SettingSpec("secure", "long_press_timeout", "180", "Touch Timeout 180ms", "Respons sentuh instan"),
                        SettingSpec("system", "pointer_speed", "5", "Pointer Speed +5", "Kecepatan geser tinggi")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "touch",
                    false,
                    "Touch Responsiveness [OFF]",
                    listOf(
                        SettingSpec("secure", "long_press_timeout", "400", "Touch Timeout 400ms", "Standar pabrik"),
                        SettingSpec("system", "pointer_speed", "0", "Pointer Speed 0", "Standar pabrik")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "⚙️ 5. Target Refresh Rate 120Hz Multi-Brand",
            desc = "Kunci min/peak refresh rate 120Hz (AOSP, Infinix/TECNO, Xiaomi/POCO, Samsung, Realme/OPPO, Vivo).",
            isOn = moduleStates["hz"] == true,
            onTurnOn = {
                onRunSpecs(
                    "hz",
                    true,
                    "Target Refresh Rate 120Hz [ON]",
                    listOf(
                        SettingSpec("system", "min_refresh_rate", "120.0", "Min Refresh Rate 120Hz", "Kunci bawah 120Hz"),
                        SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate 120Hz", "Kunci atas 120Hz"),
                        SettingSpec("system", "tran_refresh_mode", "120", "Infinix/TECNO 120Hz", "Mode 120Hz"),
                        SettingSpec("system", "user_refresh_rate", "120", "Xiaomi/HyperOS 120Hz", "Mode 120Hz")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "hz",
                    false,
                    "Target Refresh Rate 60Hz Standar [OFF]",
                    listOf(
                        SettingSpec("system", "min_refresh_rate", "60.0", "Min Refresh Rate 60Hz", "Adaptif 60Hz"),
                        SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate Adaptif", "Adaptif")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "📸 6. Fokus Game Anti Pop-Up (Heads-Up OFF)",
            desc = "Cegah notifikasi mengambang menutupi layar saat bertanding game kompetitif.",
            isOn = moduleStates["focus"] == true,
            onTurnOn = {
                onRunSpecs(
                    "focus",
                    true,
                    "Fokus Game Anti Pop-Up [ON]",
                    listOf(SettingSpec("global", "heads_up_notifications_enabled", "0", "Blokir Pop-Up Mengambang", "Fokus penuh"))
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "focus",
                    false,
                    "Fokus Game Anti Pop-Up [OFF]",
                    listOf(SettingSpec("global", "heads_up_notifications_enabled", "1", "Notifikasi Pop-Up Normal", "Standar"))
                )
            }
        )
    }
}

@Composable
private fun ManualModuleRow(
    title: String,
    desc: String,
    isOn: Boolean,
    onTurnOn: () -> Unit,
    onTurnOff: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .shadow(6.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
            )
            .border(
                width = if (isOn) 1.5.dp else 1.dp,
                color = if (isOn) QuantumEmerald else IceCyan.copy(alpha = 0.28f),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = if (isOn) "🟢 AKTIF" else "⚪ SIAGA",
                color = if (isOn) QuantumEmerald else TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = desc, color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onTurnOn,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isOn) QuantumEmerald else QuantumEmerald.copy(alpha = 0.85f)
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text("🟢 ON (Aktifkan)", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            Button(
                onClick = onTurnOff,
                colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚪ OFF (Matikan)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun GamingCenterPane(
    telemetry: DeviceTelemetry?,
    onDailyBoost: (Boolean) -> Unit,
    onApplyGamingMode: (String, String, String, Boolean) -> Unit,
    onApplyEsportsGraphics: (String, Boolean, Boolean, Boolean, Boolean, Boolean) -> Unit
) {
    val games = telemetry?.detectedGames ?: emptyList()
    val firstInstalled = games.firstOrNull { it.isInstalled } ?: games.firstOrNull()
    var selectedGamePkg by remember(firstInstalled?.packageName) {
        mutableStateOf(firstInstalled?.packageName ?: "com.mobile.legends")
    }
    var selectedGameName by remember(firstInstalled?.appName) {
        mutableStateOf(firstInstalled?.appName ?: "Mobile Legends: Bang Bang")
    }

    var perfMode by remember { mutableStateOf("esport_ultimate") }
    var anisotropicOn by remember { mutableStateOf(true) }
    var textureFilterOn by remember { mutableStateOf(true) }
    var mipmapLodOn by remember { mutableStateOf(true) }
    var frameStabilizerOn by remember { mutableStateOf(true) }
    var dualChannelNetOn by remember { mutableStateOf(true) }

    MenuGuideBanner(
        title = "Panduan Menu 04: Auto-Detect Game, E-Sports Ultimate Pro & Graphic Optimization",
        guideText = "Otomatis mendeteksi seluruh game yang terpasang di HP Anda. Dilengkapi kontrol Mode Performa (Kinerja, Kontrol, Kualitas Grafik), Penyaring Anisotropik, Filter Tekstur, Offset Mipmap LOD, Penstabilan Bingkai, serta Akselerasi Saluran Ganda & Jaringan Game."
    )

    val installedCount = games.count { it.isInstalled }
    SectionCard(title = "🎯 Deteksi Otomatis Game di HP Anda ($installedCount Game Terpasang)") {
        Text(
            text = if (installedCount > 0) {
                "Ditemukan $installedCount game terpasang di HP ini! Ketuk nama game di bawah untuk memilih target optimasi & peluncuran:"
            } else {
                "Pilih target game di bawah untuk dioptimasi dengan E-Sports Ultimate Pro atau Mode HP Kentang:"
            },
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            games.forEach { game ->
                val isSelected = (game.packageName == selectedGamePkg)
                Box(
                    modifier = Modifier
                        .shadow(if (isSelected) 8.dp else 3.dp, RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            when {
                                isSelected -> Brush.verticalGradient(listOf(SovereignGold.copy(alpha = 0.30f), Color(0xFF1A1405)))
                                game.isInstalled -> Brush.verticalGradient(listOf(QuantumEmerald.copy(alpha = 0.18f), CardInnerBottom))
                                else -> Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
                            }
                        )
                        .border(
                            width = if (isSelected) 1.6.dp else 1.dp,
                            color = when {
                                isSelected -> SovereignGold
                                game.isInstalled -> QuantumEmerald
                                else -> IceCyan.copy(alpha = 0.25f)
                            },
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            selectedGamePkg = game.packageName
                            selectedGameName = game.appName
                        }
                        .padding(horizontal = 13.dp, vertical = 9.dp)
                ) {
                    Column {
                        Text(
                            text = "${if (game.isInstalled) "🟢 " else "🎮 "}${game.appName}",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Text(
                            text = "${game.packageName} · ${game.categoryLabel}",
                            color = if (game.isInstalled) QuantumEmerald else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "🎯 Target Terpilih: $selectedGameName ($selectedGamePkg)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "esports_pro", false) },
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚡ Boost Game Ini", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            Button(
                onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "esports_pro", true) },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                modifier = Modifier.weight(1f)
            ) {
                Text("🚀 Boost & Buka Game", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🏆 E-Sports Ultimate Pro & Graphic Optimization Suite") {
        Text(
            text = "1. Pilih Mode Performa (Kinerja · Kontrol · Kualitas Grafik · E-Sports Ultimate Pro):",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "⚡ Kinerja",
                selected = perfMode == "kinerja",
                onClick = { perfMode = "kinerja" }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🎯 Kontrol",
                selected = perfMode == "kontrol",
                onClick = { perfMode = "kontrol" }
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🎨 Kualitas Grafik",
                selected = perfMode == "kualitas_grafik",
                onClick = { perfMode = "kualitas_grafik" }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🏆 E-Sports Pro",
                selected = perfMode == "esport_ultimate",
                onClick = { perfMode = "esport_ultimate" }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "2. Parameter Optimasi Grafis & Jaringan Game (Ketuk untuk ON/OFF):",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        GraphicOptionToggleRow(
            title = "Penyaring Anisotropik (Anisotropic Filtering 16x)",
            subtitle = "Pertajam tekstur tanah, dinding & objek miring di kejauhan tanpa drop FPS",
            checked = anisotropicOn,
            onToggle = { anisotropicOn = !anisotropicOn }
        )
        GraphicOptionToggleRow(
            title = "Filter Tekstur (Texture Filtering SkiaGL Pro)",
            subtitle = "Optimalkan sampling tekstur GPU agar gambar jernih dan bebas pecah",
            checked = textureFilterOn,
            onToggle = { textureFilterOn = !textureFilterOn }
        )
        GraphicOptionToggleRow(
            title = "Offset Mipmap LOD (Level of Detail Calibration)",
            subtitle = "Seimbangkan ketajaman objek jarak jauh & efisiensi memori VRAM",
            checked = mipmapLodOn,
            onToggle = { mipmapLodOn = !mipmapLodOn }
        )
        GraphicOptionToggleRow(
            title = "Penstabilan Bingkai (Frame Rate Stabilizer 120Hz)",
            subtitle = "Kunci pacing bingkai SurfaceFlinger agar FPS tidak naik-turun saat war",
            checked = frameStabilizerOn,
            onToggle = { frameStabilizerOn = !frameStabilizerOn }
        )
        GraphicOptionToggleRow(
            title = "Akselerasi Saluran Ganda & Akselerasi Jaringan Game",
            subtitle = "Gabungkan kesiagaan Wi-Fi + Data Seluler & matikan Wi-Fi scan lag",
            checked = dualChannelNetOn,
            onToggle = { dualChannelNetOn = !dualChannelNetOn }
        )

        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = {
                onApplyEsportsGraphics(
                    perfMode,
                    anisotropicOn,
                    textureFilterOn,
                    mipmapLodOn,
                    frameStabilizerOn,
                    dualChannelNetOn
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "🏆 Terapkan E-Sports Ultimate Pro + Graphic Optimization",
                color = Color(0xFF1A0F00),
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🎮 Mode Resolusi & Pendingin Game ($selectedGameName)") {
        Text("Refresh Rate Fisik Layar Saat Ini: ${telemetry?.currentRefreshRateHz ?: 60f} Hz", color = QuantumEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "potato_075", false) },
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🥔 Mode Penyelamat HP Kentang (Downscale 0.75x + Animasi 0.0x)", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "balanced_085", false) },
            colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("⚖️ Mode Smart Cool-Boost (CPU + GPU + Pendingin Seimbang 0.85x)", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = { onApplyGamingMode(selectedGamePkg, selectedGameName, "thermal_080", false) },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("❄️ Mode Thermal Guard Anti-Panas (Downscale 0.80x + 120Hz)", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "📱 Booster Kelancaran Harian & Sosmed (TikTok, IG, WA, Shopee, YouTube)") {
        Text(
            text = "Mengompilasi ulang kode mesin aplikasi (speed-profile), membersihkan cache korup, mengaktifkan Dual-Channel Network Boost, dan mematikan blur jendela agar scroll TikTok & IG Reels mulus.",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onDailyBoost(false) },
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚡ Boost TikTok/WA/IG", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            Button(
                onClick = { onDailyBoost(true) },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("🔥 Full System Dexopt", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun SelectableChipButton(
    modifier: Modifier,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(if (selected) 6.dp else 2.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) Brush.verticalGradient(listOf(QuantumEmerald.copy(alpha = 0.28f), CardInnerBottom))
                else Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
            )
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) QuantumEmerald else IceCyan.copy(alpha = 0.25f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (selected) "✓ $title" else title,
            color = if (selected) QuantumEmerald else TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun GraphicOptionToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
            .border(
                width = 1.dp,
                color = if (checked) QuantumEmerald.copy(alpha = 0.65f) else IceCyan.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onToggle() }
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            Text(text = subtitle, color = TextSecondary, fontSize = 10.5.sp)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (checked) QuantumEmerald else Color(0xFF263248))
                .padding(horizontal = 11.dp, vertical = 5.dp)
        ) {
            Text(
                text = if (checked) "ON" else "OFF",
                color = if (checked) Color(0xFF031A10) else TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
        }
    }
}

@Composable
private fun ShizukuCenterPane(
    diag: ShizukuDiagnostics,
    onRefresh: () -> Unit,
    onRequestPermission: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 05: Shizuku Center & Persistensi Tanpa Wi-Fi",
        guideText = "Shizuku hanya butuh Wi-Fi selama beberapa detik saat mengetuk tombol 'Start' di Wireless Debugging. Begitu skrip diaktifkan di AETHERIA, seluruh pengaturannya tetap berjalan 100% meskipun Wi-Fi dimatikan!"
    )
    SectionCard(title = "🔗 Shizuku Center — Status Layanan & Izin Resmi") {
        Text("Status Saat Ini: ${diag.state.displayTitle} [${diag.state.code}]", color = if (diag.isReady) QuantumEmerald else AlertRose, fontWeight = FontWeight.Bold)
        Text("Aplikasi Terpasang: ${if (diag.shizukuAppInstalled) "Ya" else "Tidak"} · Binder Hidup: ${if (diag.binderAlive) "Ya" else "Tidak"} · Izin: ${if (diag.permissionGranted) "Diberikan" else "Belum"}", color = TextSecondary, fontSize = 12.sp)
        Text("Waktu Pemeriksaan Terakhir: ${diag.lastCheckedTime}", color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text(diag.diagnosticMessage, color = TextPrimary, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        diag.recoverySteps.forEach { step ->
            Text(step, color = SovereignGold, fontSize = 11.5.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onRefresh,
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("↻ Periksa Ulang", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            if (diag.binderAlive && !diag.permissionGranted) {
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("🔑 Minta Izin Shizuku", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun StorageResourcePane(
    telemetry: DeviceTelemetry?,
    onScanAndPurgeMalware: (Boolean) -> Unit,
    onConfigureAdblockJudol: (String, Boolean) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 06: Anti-Malware Auto-Purge, Blokir Iklan HP & Anti-Judol",
        guideText = "Melindungi HP 100% dari (1) Virus APK Penipuan (Undangan/Kurir/Tilang) yang menyamar jadi PDF/Foto dengan fitur Hapus Otomatis, (2) Iklan Bawaan Pabrik HP (Xiaomi MSA, Infinix, Realme, Vivo, Samsung), serta (3) Situs Judi Online (Judol) & Phishing."
    )
    SectionCard(title = "🛡️ Perisai Anti-Malware 4-Lapis + Auto-Purge (Hapus Otomatis APK Penipuan)") {
        Text(
            text = "Memeriksa header biner (PK\\x03\\x04) di folder Download, WhatsApp & Telegram. Bila ditemukan file APK berbahaya yang menyamar jadi .pdf/.jpg/.doc atau APK penipuan kurir/undangan, file berbahaya tersebut langsung dihapus otomatis!",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { onScanAndPurgeMalware(true) },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🔍 Pindai & Hapus Otomatis Malware / APK Penipuan", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
    }
    Spacer(modifier = Modifier.height(12.dp))
    SectionCard(title = "🚫 Pemblokir Iklan Bawaan HP (OEM) & Perisai DNS Anti-Judol / Phishing") {
        Text(
            text = "Membekukan layanan iklan bawaan HP (Xiaomi MSA, Infinix PalmStore/AHA, Realme/OPPO HeyTap, Vivo, Samsung) sekaligus mengaktifkan Private DNS Terenkripsi untuk memblokir iklan aplikasi, situs judol, dan web phishing.",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { onConfigureAdblockJudol("adguard_family", true) },
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🛡️ Aktifkan Blokir Iklan HP + Perisai Anti-Judol", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onConfigureAdblockJudol("adguard_ads", true) },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("🚫 Blokir Iklan Saja", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
            Button(
                onClick = { onConfigureAdblockJudol("off", false) },
                colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚪ Reset DNS Standar", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
    Spacer(modifier = Modifier.height(12.dp))
    SectionCard(title = "💾 Analisis Penyimpanan & Memori RAM") {
        Text("Penyimpanan Internal: Bebas ${telemetry?.storageFreeGb ?: 0.0} GB dari ${telemetry?.storageTotalGb ?: 0.0} GB (${telemetry?.storageUsedPercent ?: 0}% Terpakai)", color = TextPrimary, fontWeight = FontWeight.Bold)
        Text("Memori RAM: Bebas ${telemetry?.ramAvailMb ?: 0} MB dari ${telemetry?.ramTotalMb ?: 0} MB (${telemetry?.ramUsedPercent ?: 0}% Terpakai)", color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun AutomationProfilesPane(
    activeProfile: SystemProfile,
    onSelectProfile: (SystemProfile) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 07: Automation & System Profiles",
        guideText = "Pilih karakter sistem dengan 1 klik: Balanced (Harian), Gaming, E-Sports Ultimate Pro, Smart Cool-Boost (Boost CPU + GPU + Pendingin Otomatis Seimbang), Battery Saver, atau Ultra Potato Rescue."
    )
    SectionCard(title = "🔄 Automation & System Profiles (Aktif: ${activeProfile.id})") {
        SystemProfile.values().forEach { prof ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .shadow(6.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                    .border(
                        width = if (prof == activeProfile) 1.5.dp else 1.dp,
                        color = if (prof == activeProfile) QuantumEmerald else IceCyan.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(13.dp)
            ) {
                Text(prof.title, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(prof.subtitle, color = TextSecondary, fontSize = 11.5.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onSelectProfile(prof) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (prof == activeProfile) QuantumEmerald else SovereignGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (prof == activeProfile) "🟢 Sedang Aktif: ${prof.id}" else "⚡ Terapkan ${prof.id}",
                        color = Color(0xFF04140C),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsLogsPane(
    verifications: List<VerificationRecord>,
    auditLog: List<String>
) {
    MenuGuideBanner(
        title = "Panduan Menu 08: Diagnostics & Logs",
        guideText = "Menampilkan buku besar bukti verifikasi setiap tindakan (Nilai Sebelum -> Target -> Aktual Hasil Pembacaan Ulang) secara transparan dan jujur."
    )
    SectionCard(title = "📋 Riwayat Verifikasi & Log Diagnostik") {
        VerificationListView(verifications = verifications)
        Spacer(modifier = Modifier.height(10.dp))
        auditLog.forEach { ln ->
            Text(ln, color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingsRecoveryQrisPane(
    telemetry: DeviceTelemetry?,
    snapshots: Map<String, String>,
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit,
    onRestore: () -> Unit
) {
    val context = LocalContext.current

    MenuGuideBanner(
        title = "Panduan Menu 09: Cek Update APK, Statistik Jujur & QRIS Resmi",
        guideText = "Tempat memeriksa pembaruan APK otomatis (tanpa hapus aplikasi lama), memantau jumlah unduhan jujur dari GitHub, mengembalikan pengaturan ke Standar Pabrik, serta Barcode QRIS Resmi kreator Rangga Winata."
    )

    OtaUpdateCard(
        updateStatus = updateStatus,
        isCheckingUpdate = isCheckingUpdate,
        onCheckUpdate = onCheckUpdate
    )

    Spacer(modifier = Modifier.height(12.dp))

    CommunityStatsBannerCard(
        activeUsers = telemetry?.communityActiveUsers ?: 1,
        totalDownloads = telemetry?.communityTotalDownloads ?: 1,
        localOptCount = telemetry?.localOptimizationCount ?: 1,
        installedGamesCount = telemetry?.detectedGames?.count { it.isInstalled } ?: 0,
        onOpenQris = {}
    )

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "👑 Architect & QRIS Apresiasi Resmi — Rangga Winata") {
        Text(
            text = "AETHERIA dibuat dengan niat tulus untuk membantu sesama agar HP kentang maupun flagship bisa lancar dipakai harian & main game. Bagi kawan-kawan yang ingin memberikan apresiasi sukarela untuk mendukung pengembangan modul ini, silakan scan QRIS resmi di bawah:",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(10.dp, RoundedCornerShape(18.dp))
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White)
                .border(2.5.dp, SovereignGold, RoundedCornerShape(18.dp))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.qris_rangga),
                contentDescription = "QRIS Resmi Rangga Winata (NMID: ID1026619104999)",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 260.dp, max = 420.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "RANGGA WINATA · NMID: ID1026619104999 · A01",
                color = Color(0xFF0A1629),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Menerima GoPay, OVO, DANA, ShopeePay, LinkAja & Seluruh Mobile Banking (QRIS)",
                color = Color(0xFF334155),
                fontSize = 10.5.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("Merchant: ${AetheriaIdentity.QRIS_MERCHANT}", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text("NMID: ${AetheriaIdentity.QRIS_NMID} · TID: ${AetheriaIdentity.QRIS_TID} · Dicetak oleh: ${AetheriaIdentity.QRIS_PRINTED_BY}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AetheriaIdentity.WA_CHANNEL_URL)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Throwable) {
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("💬 Gabung Saluran Resmi WhatsApp Rangga Winata", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🛡️ Restore Point Snapshot (${snapshots.size} Parameter Tersimpan)") {
        if (snapshots.isEmpty()) {
            Text("Belum ada parameter sistem yang diubah.", color = TextSecondary, fontSize = 12.sp)
        } else {
            snapshots.forEach { (k, v) ->
                Text("$k = $v", color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onRestore,
            colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🛡️ Pulihkan ke Snapshot Asli / Standar Pabrik", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
    }
}

@Composable
private fun LiveScriptExecutionConsoleCard(
    summaryText: String,
    isSuccess: Boolean,
    terminalLines: List<String>,
    verifications: List<VerificationRecord>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF03060E))
            .border(
                width = 1.6.dp,
                color = if (isSuccess) QuantumEmerald.copy(alpha = 0.75f) else AlertRose.copy(alpha = 0.85f),
                shape = RoundedCornerShape(20.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(listOf(Color(0xFF0C1830), Color(0xFF070E1E)))
                )
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("🔴 🟡 🟢", fontSize = 10.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "AETHERIA // RW-14 3D LIVE LOG & BUKTI SKRIP",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 10.5.sp
                )
            }
            Text(
                text = if (isSuccess) "TERVERIFIKASI" else "CEK STATUS",
                color = if (isSuccess) QuantumEmerald else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }

        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isSuccess) QuantumEmerald.copy(alpha = 0.14f)
                        else AlertRose.copy(alpha = 0.16f)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSuccess) QuantumEmerald else AlertRose,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(11.dp)
            ) {
                Text(
                    text = summaryText,
                    color = if (isSuccess) QuantumEmerald else AlertRose,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            terminalLines.forEach { line ->
                val lineColor = when {
                    line.startsWith("✅") || line.startsWith("✓") || line.startsWith("📶") -> QuantumEmerald
                    line.startsWith("❌") -> AlertRose
                    line.startsWith("💡") || line.startsWith("🟡") -> SovereignGold
                    else -> IceCyan
                }
                Text(
                    text = line,
                    color = lineColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }

            if (verifications.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "🔬 TABEL BUKTI PEMBACAAN ULANG (BEFORE → TARGET → ACTUAL):",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                VerificationListView(verifications = verifications)
            }
        }
    }
}

@Composable
private fun VerificationListView(verifications: List<VerificationRecord>) {
    if (verifications.isEmpty()) {
        Text("Belum ada operasi yang diverifikasi pada sesi ini.", color = TextSecondary, fontSize = 12.sp)
        return
    }
    verifications.forEach { v ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                .border(1.dp, IceCyan.copy(alpha = 0.22f), RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Text("${v.feature} (${v.parameter}) — ${v.badge}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Sebelum: ${v.beforeValue} | Target: ${v.targetValue} | Aktual (Readback): ${v.actualValue}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(MidnightPanel, MidnightPanelBottom)
                )
            )
            .border(
                width = 1.4.dp,
                brush = Brush.linearGradient(
                    colors = listOf(SovereignGold.copy(alpha = 0.65f), IceCyan.copy(alpha = 0.45f), Color(0xFF16284C))
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(16.dp)
    ) {
        Text(
            text = title,
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun StatusBadge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(999.dp))
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.16f))
            .border(1.2.dp, color, RoundedCornerShape(999.dp))
            .padding(horizontal = 11.dp, vertical = 5.dp)
    ) {
        Text(text = text, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 10.sp)
    }
}

@Composable
private fun BottomNavigationDock(
    currentPage: AetheriaPage,
    onSelect: (AetheriaPage) -> Unit
) {
    val dockItems = listOf(
        AetheriaPage.HOME to "❄️ 3D Home",
        AetheriaPage.PERF_LAB to "🎧 Audio/Net",
        AetheriaPage.GAMING to "🏆 E-Sports",
        AetheriaPage.SHIZUKU to "🔗 Shizuku",
        AetheriaPage.SETTINGS to "🔄 Update/QR"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp)
            .background(
                Brush.verticalGradient(listOf(Color(0xFF0D1830), Color(0xFF040812)))
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold.copy(alpha = 0.55f), IceCyan.copy(alpha = 0.55f))),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(vertical = 9.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        dockItems.forEach { (page, label) ->
            val active = (currentPage == page)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (active) Brush.horizontalGradient(listOf(SovereignGold.copy(alpha = 0.25f), IceCyan.copy(alpha = 0.20f)))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .border(
                        width = if (active) 1.dp else 0.dp,
                        color = if (active) SovereignGold else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onSelect(page) }
                    .padding(horizontal = 9.dp, vertical = 6.dp)
            ) {
                Text(
                    text = label,
                    color = if (active) SovereignGold else TextSecondary,
                    fontWeight = FontWeight.Black,
                    fontSize = 10.5.sp,
                    maxLines = 1
                )
            }
        }
    }
}
