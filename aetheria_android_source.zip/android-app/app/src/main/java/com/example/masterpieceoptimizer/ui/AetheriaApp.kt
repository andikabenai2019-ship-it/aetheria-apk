package com.example.masterpieceoptimizer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.masterpieceoptimizer.core.AetheriaIdentity
import com.example.masterpieceoptimizer.core.DeviceTelemetry
import com.example.masterpieceoptimizer.core.DeviceTelemetryRepository
import com.example.masterpieceoptimizer.core.DeviceTierAdvisor
import com.example.masterpieceoptimizer.core.FeatureCapability
import com.example.masterpieceoptimizer.core.SettingSpec
import com.example.masterpieceoptimizer.core.ShizukuDiagnostics
import com.example.masterpieceoptimizer.core.SystemProfile
import com.example.masterpieceoptimizer.core.VerificationRecord
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.theme.AlertRose
import com.example.masterpieceoptimizer.ui.theme.CardInnerBg
import com.example.masterpieceoptimizer.ui.theme.CircularRingGauge
import com.example.masterpieceoptimizer.ui.theme.CyberViolet
import com.example.masterpieceoptimizer.ui.theme.IceCyan
import com.example.masterpieceoptimizer.ui.theme.MidnightPanel
import com.example.masterpieceoptimizer.ui.theme.ObsidianBg
import com.example.masterpieceoptimizer.ui.theme.QuantumEmerald
import com.example.masterpieceoptimizer.ui.theme.Rw14QuantumEmblem
import com.example.masterpieceoptimizer.ui.theme.SovereignGold
import com.example.masterpieceoptimizer.ui.theme.TextPrimary
import com.example.masterpieceoptimizer.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AetheriaPage(val index: Int, val chipLabel: String) {
    HOME(1, "01. Overview & Anti-Panas"),
    DEVICE(2, "02. Device Intel"),
    PERF_LAB(3, "03. Perf Lab"),
    GAMING(4, "04. Gaming & Daily Booster"),
    SHIZUKU(5, "05. Shizuku Center"),
    STORAGE(6, "06. Anti-Malware, Iklan & Judol"),
    PROFILES(7, "07. Profiles"),
    LOGS(8, "08. Diagnostics"),
    SETTINGS(9, "09. Kreator & QRIS")
}

@Composable
fun AetheriaRootScreen(
    shizukuManager: ShizukuBridgeManager,
    telemetryRepo: DeviceTelemetryRepository
) {
    val scope = rememberCoroutineScope()
    val shizukuDiag by shizukuManager.diagnostics.collectAsState()
    var currentPage by remember { mutableStateOf(AetheriaPage.HOME) }
    var telemetry by remember { mutableStateOf<DeviceTelemetry?>(null) }
    var activeProfile by remember { mutableStateOf(SystemProfile.BALANCED) }
    var lastVerifications by remember { mutableStateOf<List<VerificationRecord>>(emptyList()) }
    var auditLog by remember {
        mutableStateOf(
            listOf(
                "✓ ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION}) Initialized",
                "✓ Architect: ${AetheriaIdentity.ARCHITECT} (NMID: ${AetheriaIdentity.QRIS_NMID})"
            )
        )
    }

    LaunchedEffect(shizukuDiag.isReady) {
        while (true) {
            telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
            delay(5000L)
        }
    }

    fun appendLog(msg: String) {
        auditLog = (listOf(msg) + auditLog).take(40)
    }

    Scaffold(
        containerColor = ObsidianBg,
        bottomBar = {
            BottomNavigationDock(currentPage = currentPage, onSelect = { currentPage = it })
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            // Horizontal 9-Page Selector Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AetheriaPage.values().forEach { page ->
                    val selected = (page == currentPage)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (selected) SovereignGold.copy(alpha = 0.22f) else MidnightPanel)
                            .border(
                                width = 1.dp,
                                color = if (selected) SovereignGold else IceCyan.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(999.dp)
                            )
                            .clickable { currentPage = page }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = page.chipLabel,
                            color = if (selected) TextPrimary else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            when (currentPage) {
                AetheriaPage.HOME -> HomeOverviewPane(
                    telemetry = telemetry,
                    shizukuDiag = shizukuDiag,
                    activeProfile = activeProfile,
                    onCleanRam = {
                        System.gc()
                        scope.launch {
                            telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                            appendLog("[RAM Cleaner] Runtime GC & pembersihan standby selesai.")
                        }
                    },
                    onDailyBoost = {
                        scope.launch {
                            val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = false)
                            lastVerifications = res
                            appendLog("[Daily Booster] TikTok/IG/WA/Shopee/YT dioptimasi (${res.size} item).")
                        }
                    },
                    onOpenGaming = { currentPage = AetheriaPage.GAMING },
                    onOpenShizuku = { currentPage = AetheriaPage.SHIZUKU },
                    onRestore = {
                        scope.launch {
                            val res = shizukuManager.restoreFromSnapshots()
                            lastVerifications = res
                            activeProfile = SystemProfile.BALANCED
                            appendLog("[Restore Point] Dipulihkan (${res.count { it.verified }}/${res.size} parameter).")
                        }
                    }
                )

                AetheriaPage.DEVICE -> DeviceIntelligencePane(
                    telemetry = telemetry,
                    capabilities = telemetryRepo.buildCapabilityMatrix(shizukuDiag.isReady)
                )

                AetheriaPage.PERF_LAB -> PerformanceLabPane(
                    shizukuDiag = shizukuDiag,
                    verifications = lastVerifications,
                    onRunSpecs = { title, specs ->
                        scope.launch {
                            val res = shizukuManager.applyAndVerifySpecs(specs)
                            lastVerifications = res
                            appendLog("[$title] ${res.count { it.verified }}/${res.size} parameter terverifikasi.")
                        }
                    }
                )

                AetheriaPage.GAMING -> GamingCenterPane(
                    telemetry = telemetry,
                    onDailyBoost = { fullDex ->
                        scope.launch {
                            val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = fullDex)
                            lastVerifications = res
                            appendLog("[Daily & Sosmed Booster] Selesai (${res.size} langkah).")
                        }
                    },
                    onApplyGamingMode = { mode ->
                        scope.launch {
                            val res = shizukuManager.applyUniversalGamingMode("com.mobile.legends", mode)
                            lastVerifications = res
                            activeProfile = if (mode == "potato_075") SystemProfile.POTATO_RESCUE else SystemProfile.GAMING
                            appendLog("[Gaming Mode $mode] ${res.count { it.verified }}/${res.size} langkah selesai.")
                        }
                    }
                )

                AetheriaPage.SHIZUKU -> ShizukuCenterPane(
                    diag = shizukuDiag,
                    onRefresh = { shizukuManager.refreshDiagnostics() },
                    onRequestPermission = { shizukuManager.requestPermissionSafely() }
                )

                AetheriaPage.STORAGE -> StorageResourcePane(
                    telemetry = telemetry,
                    onScanAndPurgeMalware = { autoPurge ->
                        scope.launch {
                            val res = shizukuManager.scanAndAutoPurgeMalware(autoPurge = autoPurge)
                            lastVerifications = res
                            appendLog("[Anti-Malware & Auto-Purge] ${res.firstOrNull()?.actualValue ?: "Selesai"}")
                        }
                    },
                    onConfigureAdblockJudol = { dnsMode, freezeOem ->
                        scope.launch {
                            val res = shizukuManager.configureAdblockAndJudolShield(dnsMode, freezeOem)
                            lastVerifications = res
                            appendLog("[AdBlock & Anti-Judol] Mode DNS=$dnsMode diterapkan.")
                        }
                    }
                )

                AetheriaPage.PROFILES -> AutomationProfilesPane(
                    activeProfile = activeProfile,
                    onSelectProfile = { profile ->
                        scope.launch {
                            val res = shizukuManager.applyAndVerifySpecs(profile.specs)
                            lastVerifications = res
                            activeProfile = profile
                            appendLog("[Profile ${profile.id}] ${res.count { it.verified }}/${res.size} parameter terverifikasi.")
                        }
                    }
                )

                AetheriaPage.LOGS -> DiagnosticsLogsPane(
                    verifications = lastVerifications,
                    auditLog = auditLog
                )

                AetheriaPage.SETTINGS -> SettingsRecoveryQrisPane(
                    snapshots = shizukuManager.getSavedSnapshots(),
                    onRestore = {
                        scope.launch {
                            val res = shizukuManager.restoreFromSnapshots()
                            lastVerifications = res
                            activeProfile = SystemProfile.BALANCED
                            appendLog("[Restore Point] Snapshot asli dipulihkan.")
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun MenuGuideBanner(title: String, guideText: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0A1629))
            .border(1.dp, SovereignGold.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Text(
            text = "📘 $title",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = guideText,
            color = TextPrimary,
            fontSize = 11.5.sp
        )
    }
}

@Composable
private fun HomeOverviewPane(
    telemetry: DeviceTelemetry?,
    shizukuDiag: ShizukuDiagnostics,
    activeProfile: SystemProfile,
    onCleanRam: () -> Unit,
    onDailyBoost: () -> Unit,
    onOpenGaming: () -> Unit,
    onOpenShizuku: () -> Unit,
    onRestore: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 01: Overview & Anti-Panas",
        guideText = "Pusat kendali utama untuk memantau RAM, Baterai, Suhu, dan Penyimpanan secara langsung. Klik 'Booster Harian (TikTok/WA)' bila buka sosmed patah-patah, atau 'Dinginkan RAM' saat HP terasa berat."
    )
    // Sovereign Hero Card
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightPanel)
            .border(1.5.dp, SovereignGold.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(15.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Rw14QuantumEmblem()
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "AETHERIA // RW-14 QUANTUM v27.5",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
                Text(
                    text = "UNIVERSAL ALL-ANDROID · GAME + TIKTOK + ANTI-MALWARE/JUDOL · ${AetheriaIdentity.LAUNCHER_CODE}",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                Text(
                    text = "Architect: ${AetheriaIdentity.ARCHITECT} · NMID: ${AetheriaIdentity.QRIS_NMID}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        val (tierTitle, tierAdvice) = DeviceTierAdvisor.classifyTier(
            telemetry?.ramTotalMb ?: 4096L,
            telemetry?.cpuCores ?: 8
        )
        Text(
            text = "🎯 $tierTitle — $tierAdvice",
            color = IceCyan,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusBadge(
                text = if (shizukuDiag.isReady) "🟢 SHIZUKU: READY" else "🔴 ${shizukuDiag.state.code}",
                color = if (shizukuDiag.isReady) QuantumEmerald else AlertRose,
                modifier = Modifier.clickable { onOpenShizuku() }
            )
            StatusBadge(
                text = "PROFIL: ${activeProfile.id.uppercase()}",
                color = SovereignGold
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Adaptive Thermal Guard Banner
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardInnerBg)
            .border(1.5.dp, QuantumEmerald.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            .padding(15.dp)
    ) {
        Text(
            text = "🟢 STATUS MESIN SKRIP: ON — ADAPTIVE THERMAL GUARD (${telemetry?.batteryTempC ?: 35.0}°C)",
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onCleanRam,
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald)
            ) {
                Text("🧊 Dinginkan RAM", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Button(
                onClick = onDailyBoost,
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan)
            ) {
                Text("📱 Booster TikTok/WA", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Button(
                onClick = onOpenGaming,
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold)
            ) {
                Text("🎮 Mode Game", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = onRestore,
            colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("⚪ Matikan Semua / Restore Standar Pabrik", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 2x2 Circular Ring Gauges
    val ramPct = telemetry?.ramUsedPercent ?: 0
    val batPct = telemetry?.batteryPercent ?: 0
    val tempC = telemetry?.batteryTempC ?: 35.0
    val romPct = telemetry?.storageUsedPercent ?: 0

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ramPct.toFloat(),
            centerValue = "$ramPct%",
            unitLabel = "LPDDR",
            title = "MEMORI RAM",
            subtitle = "Bebas ${telemetry?.ramAvailMb ?: 0} MB",
            color = IceCyan
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = batPct.toFloat(),
            centerValue = "$batPct%",
            unitLabel = "${telemetry?.batteryVoltageMv ?: 0}mV",
            title = "BATERAI AKTUAL",
            subtitle = if (telemetry?.isCharging == true) "CHARGING" else "DISCHARGING",
            color = QuantumEmerald
        )
    }
    Spacer(modifier = Modifier.height(10.dp))
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ((tempC - 20.0) * 2.5).toFloat().coerceIn(10f, 100f),
            centerValue = "${tempC}°C",
            unitLabel = "THERMAL",
            title = "SUHU & GUARD",
            subtitle = if (tempC >= 40.0) "PANAS (COOLING)" else "ADEM (OPTIMAL)",
            color = SovereignGold
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = romPct.toFloat(),
            centerValue = "$romPct%",
            unitLabel = "UFS ROM",
            title = "PARTISI ROM",
            subtitle = "Bebas ${telemetry?.storageFreeGb ?: 0.0} GB",
            color = CyberViolet
        )
    }
}

@Composable
private fun GaugeCard(
    modifier: Modifier,
    percent: Float,
    centerValue: String,
    unitLabel: String,
    title: String,
    subtitle: String,
    color: Color
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightPanel)
            .border(1.dp, IceCyan.copy(alpha = 0.25f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularRingGauge(
            percent = percent,
            centerValue = centerValue,
            unitLabel = unitLabel,
            ringColor = color
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = title, color = SovereignGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun DeviceIntelligencePane(
    telemetry: DeviceTelemetry?,
    capabilities: List<FeatureCapability>
) {
    MenuGuideBanner(
        title = "Panduan Menu 02: Device Intelligence",
        guideText = "Menampilkan spesifikasi asli perangkat keras HP Anda (Chipset SoC, GPU, RAM, versi Android 7 s/d 15+) serta matriks kapabilitas fitur Native vs Shizuku."
    )
    SectionCard(title = "📱 Spesifikasi Perangkat & Sensor Native") {
        Text("Perangkat: ${telemetry?.brand ?: "-"} ${telemetry?.model ?: "-"} (Android ${telemetry?.androidRelease ?: "-"} · SDK ${telemetry?.sdkInt ?: "-"})", color = TextPrimary, fontWeight = FontWeight.Bold)
        Text("SoC / Hardware: ${telemetry?.socHardware ?: "-"} (${telemetry?.cpuCores ?: 8} Cores · ${telemetry?.cpuCurrentMhz ?: "-"} MHz)", color = TextSecondary, fontSize = 12.sp)
        Text("Refresh Rate Layar Aktif: ${telemetry?.currentRefreshRateHz ?: 60f} Hz (Mode Didukung: ${telemetry?.supportedRefreshRatesHz?.joinToString(", ") ?: "60"} Hz)", color = IceCyan, fontSize = 12.sp)
        Text("Termux Localhost Bridge (127.0.0.1:8080): ${if (telemetry?.termuxEngineConnected == true) "🟢 TERHUBUNG" else "⚪ STANDALONE APK MODE"}", color = SovereignGold, fontSize = 12.sp)
    }
    Spacer(modifier = Modifier.height(10.dp))
    SectionCard(title = "🔐 Matriks Kapabilitas (Native vs Shizuku vs Unsupported)") {
        capabilities.forEach { cap ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardInnerBg)
                    .padding(10.dp)
            ) {
                Text("${cap.title} [${cap.tier.label}]", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(cap.reason, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PerformanceLabPane(
    shizukuDiag: ShizukuDiagnostics,
    verifications: List<VerificationRecord>,
    onRunSpecs: (String, List<SettingSpec>) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 03: Performance Lab",
        guideText = "Sakelar manual untuk menyalakan optimasi GPU Zero-Blur, Animasi Cepat, dan Kunci Refresh Rate 120Hz Multi-Merek (Infinix, Xiaomi, Samsung, Realme/OPPO, Vivo) lengkap dengan bukti baca-ulang (Readback)."
    )
    SectionCard(title = "⚡ Modul Optimasi Terverifikasi (Before → Target → Actual Readback)") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onRunSpecs(
                        "GPU Zero-Blur & Animasi 0.5x",
                        listOf(
                            SettingSpec("global", "disable_window_blurs", "1", "Zero-Blur GPU", "Matikan blur kompositor"),
                            SettingSpec("global", "window_animation_scale", "0.5", "Animasi Jendela 0.5x", "Transisi cepat")
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan)
            ) {
                Text("Aktifkan GPU Zero-Blur", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Button(
                onClick = {
                    onRunSpecs(
                        "Target 120Hz Multi-Brand",
                        listOf(
                            SettingSpec("system", "min_refresh_rate", "120.0", "Min Refresh Rate 120Hz", "Kunci bawah 120Hz"),
                            SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate 120Hz", "Kunci atas 120Hz"),
                            SettingSpec("system", "tran_refresh_mode", "120", "Infinix/TECNO 120Hz", "Mode 120Hz"),
                            SettingSpec("system", "user_refresh_rate", "120", "Xiaomi/HyperOS 120Hz", "Mode 120Hz")
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold)
            ) {
                Text("Kunci Layar 120Hz", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        VerificationListView(verifications = verifications)
    }
}

@Composable
private fun GamingCenterPane(
    telemetry: DeviceTelemetry?,
    onDailyBoost: (Boolean) -> Unit,
    onApplyGamingMode: (String) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 04: Gaming & Daily Booster (TikTok/WA/IG Anti Patah-Patah)",
        guideText = "Memiliki 2 fungsi: (1) Booster Harian & Sosmed agar buka TikTok, IG Reels, WA, Shopee, dan YouTube lancar tanpa lag, serta (2) Peluncur Mode Gaming termasuk Mode Penyelamat HP Kentang (Ultra Potato 0.75x)."
    )
    SectionCard(title = "📱 Booster Kelancaran Harian & Sosmed (TikTok, IG, WA, Shopee, YouTube)") {
        Text(
            text = "Mengompilasi ulang kode mesin aplikasi (cmd package compile -m speed-profile), membersihkan cache korup (pm trim-caches), dan mematikan blur jendela agar scroll TikTok & IG Reels mulus di HP kentang maupun flagship.",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onDailyBoost(false) },
                colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚡ Boost TikTok/WA/IG Cepat", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Button(
                onClick = { onDailyBoost(true) },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("🔥 Full System Dexopt", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
    SectionCard(title = "🎮 Peluncur Mode Gaming Universal (Android 7 s/d 15+)") {
        Text("Refresh Rate Fisik Layar Saat Ini: ${telemetry?.currentRefreshRateHz ?: 60f} Hz", color = QuantumEmerald, fontWeight = FontWeight.Bold)
        Text("Pilih mode intervensi sesuai kelas HP Anda (dilengkapi kompilasi ART speed-profile + GPU Game Driver):", color = TextSecondary, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = { onApplyGamingMode("potato_075") },
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🥔 Mode Penyelamat HP Kentang (Downscale 0.75x + Animasi 0.0x)", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = { onApplyGamingMode("thermal_080") },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("❄️ Mode Thermal Guard Anti-Panas (Downscale 0.80x + 120Hz)", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
    }
}

@Composable
private fun ShizukuCenterPane(
    diag: ShizukuDiagnostics,
    onRefresh: () -> Unit,
    onRequestPermission: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 05: Shizuku Center",
        guideText = "Jembatan izin sistem resmi agar AETHERIA dapat mengubah Refresh Rate, Kompilasi TikTok/Game, dan DNS Anti-Judol tanpa Root. Jika belum aktif, nyalakan Shizuku lewat Wireless Debugging lalu klik 'Minta Izin Shizuku Resmi'."
    )
    SectionCard(title = "🔗 Shizuku Center — Status Layanan & Izin Resmi") {
        Text("Status Saat Ini: ${diag.state.displayTitle} [${diag.state.code}]", color = if (diag.isReady) QuantumEmerald else AlertRose, fontWeight = FontWeight.Bold)
        Text("Aplikasi Terpasang: ${if (diag.shizukuAppInstalled) "Ya" else "Tidak"} · Binder Hidup: ${if (diag.binderAlive) "Ya" else "Tidak"} · Izin: ${if (diag.permissionGranted) "Diberikan" else "Belum"}", color = TextSecondary, fontSize = 12.sp)
        Text("Waktu Pemeriksaan Terakhir: ${diag.lastCheckedTime}", color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text(diag.diagnosticMessage, color = TextPrimary, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(8.dp))
        diag.recoverySteps.forEach { step ->
            Text(step, color = SovereignGold, fontSize = 11.5.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onRefresh, colors = ButtonDefaults.buttonColors(containerColor = IceCyan)) {
                Text("↻ Periksa Ulang", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            if (diag.binderAlive && !diag.permissionGranted) {
                Button(onClick = onRequestPermission, colors = ButtonDefaults.buttonColors(containerColor = SovereignGold)) {
                    Text("🔑 Minta Izin Shizuku Resmi", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun StorageResourcePane(
    telemetry: DeviceTelemetry?,
    onScanAndPurgeMalware: (Boolean) -> Unit,
    onConfigureAdblockJudol: (String, Boolean) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 06: Anti-Malware Auto-Purge, Blokir Iklan HP & Anti-Judol",
        guideText = "Melindungi HP 100% dari (1) Virus APK Penipuan (Undangan/Kurir/Tilang) yang menyamar jadi PDF/Foto dengan fitur Hapus Otomatis, (2) Iklan Bawaan Pabrik HP (Xiaomi MSA, Infinix, Realme, Vivo, Samsung), serta (3) Situs Judi Online (Judol) & Phishing."
    )
    SectionCard(title = "🛡️ Perisai Anti-Malware 4-Lapis + Auto-Purge (Hapus Otomatis APK Penipuan)") {
        Text(
            text = "Memeriksa header biner (PK\\x03\\x04) di folder Download, WhatsApp & Telegram. Bila ditemukan file APK berbahaya yang menyamar jadi .pdf/.jpg/.doc atau APK penipuan kurir/undangan, file berbahaya tersebut langsung dihapus otomatis!",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { onScanAndPurgeMalware(true) },
            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🔍 Pindai & Hapus Otomatis Malware / APK Penipuan Sekarang", color = Color(0xFF1A0F00), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
    SectionCard(title = "🚫 Pemblokir Iklan Bawaan HP (OEM) & Perisai DNS Anti-Judol / Phishing") {
        Text(
            text = "Membekukan layanan iklan bawaan HP (Xiaomi MSA, Infinix PalmStore/AHA, Realme/OPPO HeyTap, Vivo, Samsung) sekaligus mengaktifkan Private DNS Terenkripsi untuk memblokir iklan aplikasi, situs judol, dan web phishing.",
            color = TextSecondary,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { onConfigureAdblockJudol("adguard_family", true) },
            colors = ButtonDefaults.buttonColors(containerColor = QuantumEmerald),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🛡️ Aktifkan Blokir Iklan HP + Perisai Anti-Judol (AdGuard Family)", color = Color(0xFF031A10), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onConfigureAdblockJudol("adguard_ads", true) },
                colors = ButtonDefaults.buttonColors(containerColor = IceCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("🚫 Blokir Iklan Saja", color = Color(0xFF03101A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Button(
                onClick = { onConfigureAdblockJudol("off", false) },
                colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
                modifier = Modifier.weight(1f)
            ) {
                Text("⚪ Reset DNS Standar", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
    SectionCard(title = "💾 Analisis Penyimpanan & Memori RAM") {
        Text("Penyimpanan Internal: Bebas ${telemetry?.storageFreeGb ?: 0.0} GB dari ${telemetry?.storageTotalGb ?: 0.0} GB (${telemetry?.storageUsedPercent ?: 0}% Terpakai)", color = TextPrimary, fontWeight = FontWeight.Bold)
        Text("Memori RAM: Bebas ${telemetry?.ramAvailMb ?: 0} MB dari ${telemetry?.ramTotalMb ?: 0} MB (${telemetry?.ramUsedPercent ?: 0}% Terpakai)", color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun AutomationProfilesPane(
    activeProfile: SystemProfile,
    onSelectProfile: (SystemProfile) -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 07: Automation & System Profiles",
        guideText = "Pilih karakter sistem dengan 1 klik: Balanced (Harian), Gaming (Performa Tinggi), Battery Saver (Hemat Daya), atau Ultra Potato Rescue (Penyelamat HP Kentang RAM <= 4GB)."
    )
    SectionCard(title = "🔄 Automation & System Profiles (Aktif: ${activeProfile.id})") {
        SystemProfile.values().forEach { prof ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardInnerBg)
                    .padding(12.dp)
            ) {
                Text(prof.title, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(prof.subtitle, color = TextSecondary, fontSize = 11.5.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = { onSelectProfile(prof) },
                    colors = ButtonDefaults.buttonColors(containerColor = if (prof == activeProfile) QuantumEmerald else SovereignGold)
                ) {
                    Text("Terapkan ${prof.id}", color = Color(0xFF04140C), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun DiagnosticsLogsPane(
    verifications: List<VerificationRecord>,
    auditLog: List<String>
) {
    MenuGuideBanner(
        title = "Panduan Menu 08: Diagnostics & Logs",
        guideText = "Menampilkan buku besar bukti verifikasi setiap tindakan (Nilai Sebelum -> Target -> Aktual Hasil Pembacaan Ulang) secara transparan dan jujur."
    )
    SectionCard(title = "📋 Riwayat Verifikasi & Log Diagnostik") {
        VerificationListView(verifications = verifications)
        Spacer(modifier = Modifier.height(10.dp))
        auditLog.forEach { ln ->
            Text(ln, color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingsRecoveryQrisPane(
    snapshots: Map<String, String>,
    onRestore: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 09: Recovery Pabrik & Kreator QRIS Resmi",
        guideText = "Tempat paling aman untuk mengembalikan seluruh pengaturan HP ke kondisi semula (Standar Pabrik / Snapshot Asli) kapan saja dengan 1 klik, serta informasi resmi kreator Rangga Winata."
    )
    SectionCard(title = "🛡️ Restore Point Snapshot (${snapshots.size} Parameter Tersimpan)") {
        if (snapshots.isEmpty()) {
            Text("Belum ada parameter sistem yang diubah.", color = TextSecondary, fontSize = 12.sp)
        } else {
            snapshots.forEach { (k, v) ->
                Text("$k = $v", color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = onRestore,
            colors = ButtonDefaults.buttonColors(containerColor = AlertRose),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🛡️ Pulihkan ke Snapshot Asli / Standar Pabrik", color = TextPrimary, fontWeight = FontWeight.Bold)
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
    SectionCard(title = "👑 Architect & QRIS Resmi Rangga Winata") {
        Text("Merchant: ${AetheriaIdentity.QRIS_MERCHANT}", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text("NMID: ${AetheriaIdentity.QRIS_NMID} · TID: ${AetheriaIdentity.QRIS_TID} · Dicetak oleh: ${AetheriaIdentity.QRIS_PRINTED_BY}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        Text("Saluran Resmi WhatsApp: ${AetheriaIdentity.WA_CHANNEL_URL}", color = IceCyan, fontSize = 11.5.sp)
    }
}

@Composable
private fun VerificationListView(verifications: List<VerificationRecord>) {
    if (verifications.isEmpty()) {
        Text("Belum ada operasi yang diverifikasi pada sesi ini.", color = TextSecondary, fontSize = 12.sp)
        return
    }
    verifications.forEach { v ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(CardInnerBg)
                .padding(10.dp)
        ) {
            Text("${v.feature} (${v.parameter}) — ${v.badge}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Sebelum: ${v.beforeValue} | Target: ${v.targetValue} | Aktual (Readback): ${v.actualValue}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightPanel)
            .border(1.dp, IceCyan.copy(alpha = 0.28f), RoundedCornerShape(18.dp))
            .padding(15.dp)
    ) {
        Text(
            text = title,
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun StatusBadge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color, RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text = text, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp)
    }
}

@Composable
private fun BottomNavigationDock(
    currentPage: AetheriaPage,
    onSelect: (AetheriaPage) -> Unit
) {
    val dockItems = listOf(
        AetheriaPage.HOME to "❄️ Anti-Panas",
        AetheriaPage.PERF_LAB to "🔒 Manual",
        AetheriaPage.SHIZUKU to "🔗 Shizuku",
        AetheriaPage.STORAGE to "🛡️ Malware",
        AetheriaPage.SETTINGS to "👑 Kreator"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF070D1B))
            .border(1.dp, SovereignGold.copy(alpha = 0.4f))
            .padding(vertical = 8.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        dockItems.forEach { (page, label) ->
            val active = (currentPage == page)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (active) SovereignGold.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { onSelect(page) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = label,
                    color = if (active) TextPrimary else TextSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }
}
