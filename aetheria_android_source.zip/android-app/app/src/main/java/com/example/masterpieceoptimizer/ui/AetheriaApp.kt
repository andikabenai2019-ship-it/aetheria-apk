package com.example.masterpieceoptimizer.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.masterpieceoptimizer.R
import com.example.masterpieceoptimizer.core.ActiveProfileMode
import com.example.masterpieceoptimizer.core.AetheriaIdentity
import com.example.masterpieceoptimizer.core.DeviceTelemetry
import com.example.masterpieceoptimizer.core.DeviceTelemetryRepository
import com.example.masterpieceoptimizer.core.DeviceTierAdvisor
import com.example.masterpieceoptimizer.core.FeatureCapability
import com.example.masterpieceoptimizer.core.OemGameBoosterInfo
import com.example.masterpieceoptimizer.core.OemPhoneMasterInfo
import com.example.masterpieceoptimizer.core.PingServerResult
import com.example.masterpieceoptimizer.core.SettingSpec
import com.example.masterpieceoptimizer.core.ShellBridgeMode
import com.example.masterpieceoptimizer.core.ShizukuDiagnostics
import com.example.masterpieceoptimizer.core.SystemProfile
import com.example.masterpieceoptimizer.core.UpdateCheckResult
import com.example.masterpieceoptimizer.core.VerificationRecord
import com.example.masterpieceoptimizer.data.DebloatPackageItem
import com.example.masterpieceoptimizer.data.DebloatRiskLevel
import com.example.masterpieceoptimizer.data.OemDebloatDatabase
import com.example.masterpieceoptimizer.service.AutoSwitchEngineService
import com.example.masterpieceoptimizer.service.FloatingHudOverlayService
import com.example.masterpieceoptimizer.service.GameDetectionRepository
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import com.example.masterpieceoptimizer.ui.theme.AetheriaSplashBootScreen
import com.example.masterpieceoptimizer.ui.theme.AlertRose
import com.example.masterpieceoptimizer.ui.theme.AlertRoseDeep
import com.example.masterpieceoptimizer.ui.theme.CardInnerBg
import com.example.masterpieceoptimizer.ui.theme.CardInnerBottom
import com.example.masterpieceoptimizer.ui.theme.CircularRingGauge
import com.example.masterpieceoptimizer.ui.theme.Cyber3dPerspectiveGridBackground
import com.example.masterpieceoptimizer.ui.theme.CyberViolet
import com.example.masterpieceoptimizer.ui.theme.CyberVioletDeep
import com.example.masterpieceoptimizer.ui.theme.Extruded3dConsoleCard
import com.example.masterpieceoptimizer.ui.theme.IceCyan
import com.example.masterpieceoptimizer.ui.theme.IceCyanDeep
import com.example.masterpieceoptimizer.ui.theme.MidnightPanel
import com.example.masterpieceoptimizer.ui.theme.MidnightPanelBottom
import com.example.masterpieceoptimizer.ui.theme.ObsidianBg
import com.example.masterpieceoptimizer.ui.theme.QuantumEmerald
import com.example.masterpieceoptimizer.ui.theme.QuantumEmeraldDeep
import com.example.masterpieceoptimizer.ui.theme.Rw14QuantumEmblem
import com.example.masterpieceoptimizer.ui.theme.SovereignGold
import com.example.masterpieceoptimizer.ui.theme.SovereignGoldDeep
import com.example.masterpieceoptimizer.ui.theme.Tactile3dPushButton
import com.example.masterpieceoptimizer.ui.theme.TextPrimary
import com.example.masterpieceoptimizer.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

enum class AetheriaPage(val index: Int, val chipLabel: String) {
    HOME(1, "01. 3D Cockpit"),
    DEVICE(2, "02. Hardware & Baterai"),
    PERF_LAB(3, "03. 8-Sektor Pro & Audio"),
    GAMING(4, "04. Quad-Combo & HUD"),
    SHIZUKU(5, "05. Shizuku + Brevent"),
    STORAGE(6, "06. Debloat & Malware"),
    PROFILES(7, "07. Whitelist WA/IG & Boot"),
    LOGS(8, "08. Diagnostics"),
    SETTINGS(9, "09. Update & QRIS")
}

@Composable
fun AetheriaRootScreen(
    shizukuManager: ShizukuBridgeManager,
    telemetryRepo: DeviceTelemetryRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizukuDiag by shizukuManager.diagnostics.collectAsState()
    val gameDetectionRepo = remember { GameDetectionRepository(context.applicationContext) }

    var showSplash by remember { mutableStateOf(true) }
    var currentPage by remember { mutableStateOf(AetheriaPage.HOME) }
    var telemetry by remember { mutableStateOf<DeviceTelemetry?>(null) }
    var showOnboardingWizard by remember {
        mutableStateOf(!shizukuManager.refreshDiagnostics().isReady && !shizukuManager.isOnboardingDismissed())
    }
    var pendingSafeDpiLabel by remember { mutableStateOf<String?>(null) }

    // Persistent UI state within same boot session (automatically resets to Factory Default on HP Restart / Power-Off!)
    var activeProfile by remember {
        val savedId = shizukuManager.loadUiStateString("active_profile", SystemProfile.BALANCED.id)
        val matched = SystemProfile.values().firstOrNull { it.id == savedId } ?: SystemProfile.BALANCED
        mutableStateOf(matched)
    }
    var adaptiveMode by remember {
        val saved = shizukuManager.loadUiStateString("adaptive_mode_v300", ActiveProfileMode.NONE.name)
        mutableStateOf(runCatching { ActiveProfileMode.valueOf(saved) }.getOrDefault(ActiveProfileMode.NONE))
    }

    var lastVerifications by remember { mutableStateOf<List<VerificationRecord>>(emptyList()) }
    var updateStatus by remember { mutableStateOf<UpdateCheckResult?>(null) }
    var isCheckingUpdate by remember { mutableStateOf(false) }

    var lastActionSummary by remember {
        mutableStateOf(
            shizukuManager.loadUiStateString(
                "last_summary",
                "🟢 SISTEM 3D OMNI v30.0 SIAGA — Dual-Jalur (Shizuku + Brevent), Quad-Combo Phone Master & Auto-Reset Saat HP Restart Aktif!"
            )
        )
    }
    var lastActionSuccess by remember { mutableStateOf(true) }

    val moduleStates = remember {
        mutableStateMapOf(
            "cpu" to shizukuManager.loadUiStateBool("mod_cpu", false),
            "gpu" to shizukuManager.loadUiStateBool("mod_gpu", false),
            "net" to shizukuManager.loadUiStateBool("mod_net", false),
            "touch" to shizukuManager.loadUiStateBool("mod_touch", false),
            "hz" to shizukuManager.loadUiStateBool("mod_hz", false),
            "focus" to shizukuManager.loadUiStateBool("mod_focus", false)
        )
    }
    var iphoneAudioEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("iphone_audio", false)) }
    var dualNetEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("dual_net", false)) }
    var smartCoolBoostEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("smart_cool_boost", false)) }
    var tripleComboEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("triple_combo", false)) }
    var adblockShieldEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("adblock_shield", false)) }
    var adSdkBlockerEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("adsdk_blocker", false)) }
    var bypassChargingEnabled by remember { mutableStateOf(shizukuManager.loadUiStateBool("bypass_charging", false)) }
    var autoResetOnReboot by remember { mutableStateOf(shizukuManager.isAutoResetOnRebootEnabled()) }
    var autoSwitchServiceOn by remember { mutableStateOf(gameDetectionRepo.isAutoSwitchEnabledPref()) }
    var overnightMaintOn by remember { mutableStateOf(gameDetectionRepo.isOvernightMaintEnabledPref()) }
    var floatingHudOn by remember { mutableStateOf(gameDetectionRepo.isFloatingHudEnabledPref()) }
    var pingResults by remember { mutableStateOf<List<PingServerResult>>(emptyList()) }
    var isTestingPing by remember { mutableStateOf(false) }

    var terminalLines by remember {
        mutableStateOf(
            listOf(
                "> Initializing ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION})...",
                "✓ Architect Seal: ${AetheriaIdentity.ARCHITECT} (QRIS NMID: ${AetheriaIdentity.QRIS_NMID} · ${AetheriaIdentity.QRIS_TID})",
                "✓ Dual-Path Shell Engine Ready: JALUR 1 (Shizuku) + JALUR 2 (Brevent Bridge 1-Klik) + JALUR 3 (Mandiri)",
                "✓ Kernel Boot-ID Guard Ready: Tetap ON walau hapus Recent Apps, OTOMATIS RESET saat HP Restart / Mati!",
                "✓ Perisai Immortal WA & IG Aktif: WhatsApp & Instagram dikunci agar TIDAK PERNAH dimatikan",
                "> Menunggu perintah eksekusi skrip dari pengguna..."
            )
        )
    }
    var auditLog by remember {
        mutableStateOf(
            listOf(
                "✓ ${AetheriaIdentity.APP_NAME} (${AetheriaIdentity.VERSION}) Initialized",
                "✓ Architect: ${AetheriaIdentity.ARCHITECT} (NMID: ${AetheriaIdentity.QRIS_NMID})"
            )
        )
    }

    LaunchedEffect(shizukuDiag.isReady) {
        val healedDns = shizukuManager.autoHealMobileDataDnsIfNeeded()
        if (healedDns) {
            lastActionSummary = "🟢 AUTO-HEAL AKTIF: Kunci DNS Port 853 yang menghambat Kuota Data Seluler telah diperbaiki otomatis!"
            shizukuManager.saveUiStateString("last_summary", lastActionSummary)
        }
        if (iphoneAudioEnabled) {
            shizukuManager.applyIphoneAudioEnhancer(true)
        }
        while (true) {
            shizukuManager.refreshDiagnostics()
            telemetry = telemetryRepo.collectTelemetry(shizukuManager.diagnostics.value.isReady)
            delay(4500L)
        }
    }

    if (showSplash) {
        val detectedBoosterLabel = remember { telemetryRepo.detectOemGameBooster().boosterName }
        val detectedPhoneMasterLabel = remember { telemetryRepo.detectOemPhoneMaster().managerName }
        AetheriaSplashBootScreen(
            detectedBoosterName = detectedBoosterLabel,
            detectedPhoneMasterName = detectedPhoneMasterLabel,
            onBootFinished = { showSplash = false }
        )
        return
    }

    fun appendLog(msg: String) {
        auditLog = (listOf(msg) + auditLog).take(80)
    }

    fun markImmediateFeedback(actionTitle: String) {
        lastActionSuccess = true
        lastActionSummary = "⚡ MENJALANKAN SKRIP 3D INSTAN: $actionTitle..."
    }

    fun recordExecutionResult(actionTitle: String, records: List<VerificationRecord>) {
        telemetryRepo.incrementOptimizationCounter()
        lastVerifications = records
        val nowStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        val okCount = records.count { it.verified }
        val total = records.size
        val activeBridge = shizukuManager.refreshDiagnostics().activeBridgeMode.badgeLabel

        val lines = mutableListOf<String>()
        lines.add("> [$nowStr] MENJALANKAN SKRIP: $actionTitle")
        lines.add("> Jalur Aktif: $activeBridge")
        lines.add("--------------------------------------------------")
        records.forEachIndexed { idx, r ->
            lines.add("[${idx + 1}] ${r.feature} (${r.parameter})")
            lines.add("    Sebelum: ${r.beforeValue} -> Target: ${r.targetValue} -> Aktual: ${r.actualValue} [${r.badge}]")
        }
        lines.add("--------------------------------------------------")

        if (okCount > 0) {
            lastActionSuccess = true
            lastActionSummary = "✅ SKRIP BERHASIL ($actionTitle): $okCount/$total Parameter Aktif via ${shizukuDiag.activeBridgeMode.name}!"
            lines.add("✅ KESIMPULAN SKRIP: BERHASIL DITERAPKAN ($okCount/$total Parameter Aktif)!")
            lines.add("🔄 BOOT-ID GUARD: Aman dari hapus Recent Apps & otomatis kembali ke Standar Pabrik saat HP Restart.")
        } else {
            lastActionSuccess = false
            lastActionSummary = "🟡 INFO ($actionTitle): $okCount/$total terverifikasi — buka Panduan Shizuku / Brevent bila butuh akses UID 2000."
            lines.add("🟡 KESIMPULAN SKRIP: DIEKSEKUSI ($okCount/$total Terverifikasi).")
        }

        shizukuManager.saveUiStateString("last_summary", lastActionSummary)
        terminalLines = lines
        appendLog("[$nowStr] [$actionTitle] $okCount/$total parameter berhasil diverifikasi.")
    }

    fun triggerPanicFactoryReset() {
        iphoneAudioEnabled = false
        dualNetEnabled = false
        smartCoolBoostEnabled = false
        tripleComboEnabled = false
        adblockShieldEnabled = false
        adSdkBlockerEnabled = false
        bypassChargingEnabled = false
        adaptiveMode = ActiveProfileMode.NONE
        moduleStates.keys.toList().forEach { moduleStates[it] = false }
        if (autoSwitchServiceOn) {
            AutoSwitchEngineService.stop(context)
            autoSwitchServiceOn = false
        }
        if (floatingHudOn) {
            FloatingHudOverlayService.stop(context)
            floatingHudOn = false
        }
        shizukuManager.clearAllUiStates()
        markImmediateFeedback("🚨 1-CLICK PANIC RESET (Kembalikan Semua Tweaks & DPI ke Standar Pabrik)")
        scope.launch {
            shizukuManager.applyIphoneAudioEnhancer(false)
            shizukuManager.fixMobileDataInternetDns()
            val res = shizukuManager.restoreFromSnapshots()
            activeProfile = SystemProfile.BALANCED
            recordExecutionResult("🚨 1-Click Panic Factory Restore (100% Standar Pabrik)", res)
        }
    }

    fun triggerFixMobileDataDns() {
        markImmediateFeedback("📶 Memperbaiki Koneksi Internet Data Seluler (Kuota 4G/5G)")
        scope.launch {
            val res = shizukuManager.fixMobileDataInternetDns()
            telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
            recordExecutionResult("📶 Perbaiki Internet Data Seluler (Kuota & Wi-Fi Lancar)", res)
        }
    }

    fun triggerUpdateCheck() {
        isCheckingUpdate = true
        markImmediateFeedback("🔄 Memeriksa Update APK Terbaru di Server GitHub")
        scope.launch {
            val res = telemetryRepo.checkForApkUpdate()
            updateStatus = res
            isCheckingUpdate = false
            val rec = VerificationRecord(
                feature = "Pemeriksaan Update OTA GitHub",
                parameter = AetheriaIdentity.GITHUB_REPO,
                beforeValue = res.currentVersion,
                targetValue = res.latestVersion,
                actualValue = if (res.hasNewerRelease) "Tersedia Update Baru!" else "Sudah Paling Baru",
                exitCode = 0,
                verified = true,
                badge = if (res.hasNewerRelease) "🚀 UPDATE TERSEDIA" else "🟢 VERSI TERBARU",
                detail = res.statusMessage
            )
            recordExecutionResult("🔄 Cek Update APK Resmi", listOf(rec))
        }
    }

    fun triggerQuadCombo(enable: Boolean, targetGamePkg: String? = null) {
        tripleComboEnabled = enable
        shizukuManager.saveUiStateBool("triple_combo", enable)
        if (enable) {
            activeProfile = SystemProfile.TRIPLE_COMBO
            shizukuManager.saveUiStateString("active_profile", activeProfile.id)
        }
        val boosterInfo = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster()
        val masterInfo = telemetry?.oemPhoneMaster ?: telemetryRepo.detectOemPhoneMaster()
        val label = if (enable) {
            "🔥 QUAD-COMBO 4X ON (AETHERIA + ${boosterInfo.boosterName} + ${masterInfo.managerName})"
        } else {
            "⚪ QUAD-COMBO 4X OFF (Standar)"
        }
        markImmediateFeedback(label)
        scope.launch {
            val res = shizukuManager.applyTripleComboOemGameBoost(
                boosterInfo = boosterInfo,
                targetGamePkg = targetGamePkg,
                enable = enable,
                phoneMasterInfo = masterInfo
            )
            recordExecutionResult(label, res)
        }
    }

    fun triggerAdaptiveMode(mode: ActiveProfileMode, targetGamePkg: String? = null) {
        adaptiveMode = mode
        shizukuManager.saveUiStateString("adaptive_mode_v300", mode.name)
        markImmediateFeedback("⚡ Mode Adaptif 1-Klik: ${mode.title}")
        scope.launch {
            val res = shizukuManager.commandRegistry.applyAdaptiveProfile(
                mode = mode,
                specs = telemetry?.hardwareSpecs,
                targetGamePkg = targetGamePkg
            )
            recordExecutionResult("⚡ Mode Adaptif: ${mode.title}", res)
        }
    }

    // Modal 1: Dual-Path Shizuku + Brevent Onboarding Wizard
    if (showOnboardingWizard) {
        DualPathOnboardingWizardDialog(
            diag = shizukuDiag,
            shizukuManager = shizukuManager,
            onRefreshStatus = { shizukuManager.refreshDiagnostics() },
            onDismiss = {
                shizukuManager.setOnboardingDismissed(true)
                showOnboardingWizard = false
            }
        )
    }

    // Modal 2: 15-Second Safe Display Guard for Custom DPI
    pendingSafeDpiLabel?.let { dpiLabel ->
        SafeDisplayConfirmDialog(
            appliedDpiLabel = dpiLabel,
            timeoutSeconds = 15,
            onKeepChanges = {
                pendingSafeDpiLabel = null
                appendLog("✓ Pengaturan layar ($dpiLabel) dikonfirmasi aman oleh pengguna.")
            },
            onAutoOrManualRevert = {
                pendingSafeDpiLabel = null
                markImmediateFeedback("↩️ Mengembalikan Resolusi & DPI Layar ke Ukuran Pabrik")
                scope.launch {
                    val res = shizukuManager.commandRegistry.revertDisplaySizeAndDpi()
                    recordExecutionResult("↩️ Fail-Safe Auto-Revert DPI & Resolusi Pabrik", res)
                }
            }
        )
    }

    Scaffold(
        containerColor = ObsidianBg,
        bottomBar = {
            BottomNavigationDock(currentPage = currentPage, onSelect = { currentPage = it })
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBg)
                .padding(innerPadding)
        ) {
            // 3D Animated Holographic Perspective Cockpit Grid Floor
            Cyber3dPerspectiveGridBackground()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp)
            ) {
                // ALWAYS-VISIBLE 3D TOP COCKPIT BAR (Dual-Bridge Pill + Permission Guide + Panic Reset)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val bridgeColor = when (shizukuDiag.activeBridgeMode) {
                        ShellBridgeMode.SHIZUKU_UID2000 -> QuantumEmerald
                        ShellBridgeMode.BREVENT_UID2000 -> CyberViolet
                        ShellBridgeMode.WRITE_SECURE_DIRECT -> IceCyan
                        ShellBridgeMode.LOCAL_MANDIRI -> SovereignGold
                    }
                    Tactile3dPushButton(
                        text = when (shizukuDiag.activeBridgeMode) {
                            ShellBridgeMode.SHIZUKU_UID2000 -> "🟢 SHIZUKU AKTIF"
                            ShellBridgeMode.BREVENT_UID2000 -> "🟣 BREVENT AKTIF"
                            ShellBridgeMode.WRITE_SECURE_DIRECT -> "🔵 BREVENT DIRECT"
                            ShellBridgeMode.LOCAL_MANDIRI -> "🔗 HUBUNGKAN SHIZUKU / BREVENT"
                        },
                        onClick = { showOnboardingWizard = true },
                        modifier = Modifier.weight(1.35f),
                        faceColor = bridgeColor,
                        deepBaseColor = when (shizukuDiag.activeBridgeMode) {
                            ShellBridgeMode.SHIZUKU_UID2000 -> QuantumEmeraldDeep
                            ShellBridgeMode.BREVENT_UID2000 -> CyberVioletDeep
                            ShellBridgeMode.WRITE_SECURE_DIRECT -> IceCyanDeep
                            ShellBridgeMode.LOCAL_MANDIRI -> SovereignGoldDeep
                        },
                        textColor = if (shizukuDiag.activeBridgeMode == ShellBridgeMode.BREVENT_UID2000) Color.White else Color(0xFF031410),
                        fontSizeSp = 10f
                    )

                    Tactile3dPushButton(
                        text = "🚨 PANIC RESET",
                        onClick = { triggerPanicFactoryReset() },
                        modifier = Modifier.weight(0.95f),
                        faceColor = AlertRose,
                        deepBaseColor = AlertRoseDeep,
                        textColor = Color.White,
                        fontSizeSp = 10f
                    )
                }

                // 3D Extruded Horizontal 9-Page Selector Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AetheriaPage.values().forEach { page ->
                        val selected = (page == currentPage)
                        Box(
                            modifier = Modifier
                                .shadow(if (selected) 10.dp else 4.dp, RoundedCornerShape(14.dp))
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selected) SovereignGoldDeep else Color(0xFF040914))
                                .clickable { currentPage = page }
                                .padding(bottom = 3.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (selected) {
                                            Brush.horizontalGradient(
                                                listOf(Color(0xFF28200A), Color(0xFF0E2936))
                                            )
                                        } else {
                                            Brush.verticalGradient(listOf(MidnightPanel, MidnightPanelBottom))
                                        }
                                    )
                                    .border(
                                        width = if (selected) 1.6.dp else 1.dp,
                                        brush = if (selected) {
                                            Brush.horizontalGradient(listOf(SovereignGold, IceCyan))
                                        } else {
                                            Brush.horizontalGradient(listOf(IceCyan.copy(alpha = 0.35f), Color(0xFF1E293B)))
                                        },
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = page.chipLabel,
                                    color = if (selected) SovereignGold else TextSecondary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                when (currentPage) {
                    AetheriaPage.HOME -> HomeOverviewPane(
                        telemetry = telemetry,
                        shizukuDiag = shizukuDiag,
                        activeProfile = activeProfile,
                        adaptiveMode = adaptiveMode,
                        autoResetOnReboot = autoResetOnReboot,
                        iphoneAudioEnabled = iphoneAudioEnabled,
                        dualNetEnabled = dualNetEnabled,
                        smartCoolBoostEnabled = smartCoolBoostEnabled,
                        tripleComboEnabled = tripleComboEnabled,
                        updateStatus = updateStatus,
                        isCheckingUpdate = isCheckingUpdate,
                        onOpenWizard = { showOnboardingWizard = true },
                        onSelectAdaptiveMode = { triggerAdaptiveMode(it) },
                        onCheckUpdate = { triggerUpdateCheck() },
                        onFixMobileDataDns = { triggerFixMobileDataDns() },
                        onToggleQuadCombo = { enable -> triggerQuadCombo(enable) },
                        onOpenOemBooster = {
                            val b = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster()
                            shizukuManager.launchOemGameBooster(b)
                        },
                        onOpenOemPhoneMaster = {
                            val m = telemetry?.oemPhoneMaster ?: telemetryRepo.detectOemPhoneMaster()
                            shizukuManager.launchOemPhoneMaster(m)
                        },
                        onCleanRam = {
                            markImmediateFeedback("🧊 Dinginkan & Bersihkan Standby RAM (WA & IG Aman)")
                            val beforeAvail = telemetry?.ramAvailMb ?: 0L
                            shizukuManager.runLocalNativeCleanup()
                            scope.launch {
                                val updated = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                                telemetry = updated
                                val afterAvail = updated.ramAvailMb
                                val rec = VerificationRecord(
                                    feature = "Pembersihan Standby RAM & Bloatware Latar",
                                    parameter = "MemoryTrim (WA & IG Dilindungi Immortal)",
                                    beforeValue = "Bebas $beforeAvail MB",
                                    targetValue = "Optimalisasi RAM",
                                    actualValue = "Bebas $afterAvail MB (${updated.ramUsedPercent}% Terpakai)",
                                    exitCode = 0,
                                    verified = true,
                                    badge = "🟢 BERHASIL",
                                    detail = "WhatsApp & Instagram tetap aktif 100%"
                                )
                                recordExecutionResult("🧊 Dinginkan & Bersihkan Standby RAM", listOf(rec))
                            }
                        },
                        onSmartCoolBoost = {
                            smartCoolBoostEnabled = !smartCoolBoostEnabled
                            shizukuManager.saveUiStateBool("smart_cool_boost", smartCoolBoostEnabled)
                            if (smartCoolBoostEnabled) {
                                activeProfile = SystemProfile.SMART_COOL_BOOST
                                shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                                markImmediateFeedback("⚖️ Smart Cool-Boost [ON] (CPU + GPU + Pendingin Seimbang)")
                                scope.launch {
                                    val res = shizukuManager.applySmartCoolBoostBalance()
                                    recordExecutionResult("⚖️ Smart Cool-Boost [ON]", res)
                                }
                            } else {
                                activeProfile = SystemProfile.BALANCED
                                shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                                markImmediateFeedback("⚖️ Smart Cool-Boost [OFF]")
                                scope.launch {
                                    val res = shizukuManager.applyAndVerifySpecs(SystemProfile.BALANCED.specs)
                                    recordExecutionResult("⚖️ Smart Cool-Boost [OFF]", res)
                                }
                            }
                        },
                        onDailyBoost = {
                            markImmediateFeedback("📱 Booster Harian SystemUI + TikTok/WA/IG Anti-Lag")
                            scope.launch {
                                val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = false)
                                recordExecutionResult("📱 Booster Harian SystemUI + TikTok/WA/IG", res)
                            }
                        },
                        onToggleIphoneAudio = { enable ->
                            iphoneAudioEnabled = enable
                            shizukuManager.saveUiStateBool("iphone_audio", enable)
                            markImmediateFeedback("🎧 Audio Speaker & Headset Setara iPhone [${if (enable) "ON" else "OFF"}]")
                            scope.launch {
                                val res = shizukuManager.applyIphoneAudioEnhancer(enable)
                                recordExecutionResult("🎧 Audio Speaker & Headset iPhone [${if (enable) "ON" else "OFF"}]", res)
                            }
                        },
                        onToggleDualNet = { enable ->
                            dualNetEnabled = enable
                            shizukuManager.saveUiStateBool("dual_net", enable)
                            markImmediateFeedback("🌐 Akselerasi Saluran Ganda Wi-Fi + Data [${if (enable) "ON" else "OFF"}]")
                            scope.launch {
                                val res = shizukuManager.applyDualChannelNetworkBoost(enable)
                                recordExecutionResult("🌐 Boost Jaringan Wi-Fi + Data [${if (enable) "ON" else "OFF"}]", res)
                            }
                        },
                        onOpenGaming = { currentPage = AetheriaPage.GAMING },
                        onOpenQris = { currentPage = AetheriaPage.SETTINGS },
                        onRestore = { triggerPanicFactoryReset() }
                    )

                    AetheriaPage.DEVICE -> DeviceIntelligencePane(
                        telemetry = telemetry,
                        bypassChargingEnabled = bypassChargingEnabled,
                        capabilities = telemetryRepo.buildCapabilityMatrix(shizukuDiag.isReady),
                        onToggleBypassCharging = { enable ->
                            bypassChargingEnabled = enable
                            shizukuManager.saveUiStateBool("bypass_charging", enable)
                            markImmediateFeedback("🔌 Smart Bypass Charging [${if (enable) "ON" else "OFF"}]")
                            scope.launch {
                                val res = shizukuManager.commandRegistry.setSmartBypassCharging(
                                    enable = enable,
                                    specs = telemetry?.hardwareSpecs
                                )
                                recordExecutionResult("🔌 Smart Bypass Charging [${if (enable) "ON" else "OFF"}]", res)
                            }
                        },
                        onOpenPhoneMaster = {
                            shizukuManager.launchOemPhoneMaster(telemetry?.oemPhoneMaster)
                        }
                    )

                    AetheriaPage.PERF_LAB -> PerformanceLabPane(
                        moduleStates = moduleStates,
                        iphoneAudioEnabled = iphoneAudioEnabled,
                        dualNetEnabled = dualNetEnabled,
                        smartCoolBoostEnabled = smartCoolBoostEnabled,
                        tripleComboEnabled = tripleComboEnabled,
                        oemBooster = telemetry?.oemGameBooster,
                        oemPhoneMaster = telemetry?.oemPhoneMaster,
                        telemetry = telemetry,
                        shizukuManager = shizukuManager,
                        pingResults = pingResults,
                        isTestingPing = isTestingPing,
                        onTestPing = {
                            isTestingPing = true
                            markImmediateFeedback("📡 Menguji Latensi Ping Real-Time ke Server Game")
                            scope.launch {
                                pingResults = telemetryRepo.testGameServersPing()
                                isTestingPing = false
                                val best = pingResults.filter { it.latencyMs > 0 }.minByOrNull { it.latencyMs }
                                val rec = VerificationRecord(
                                    feature = "Real-Time Game Server Ping Tester",
                                    parameter = "${pingResults.size} Server Game",
                                    beforeValue = "TCP Probe",
                                    targetValue = "< 50ms",
                                    actualValue = best?.let { "${it.serverName}: ${it.latencyMs}ms" } ?: "Cek Koneksi Internet",
                                    exitCode = 0,
                                    verified = best != null,
                                    badge = best?.statusBadge ?: "🔴 OFFLINE",
                                    detail = "Pengukuran latensi TCP nyata ke server game Asia Tenggara"
                                )
                                recordExecutionResult("📡 Tes Ping Server Game Real-Time", listOf(rec))
                            }
                        },
                        onFixMobileDataDns = { triggerFixMobileDataDns() },
                        onToggleQuadCombo = { enable -> triggerQuadCombo(enable) },
                        onToggleIphoneAudio = { enable ->
                            iphoneAudioEnabled = enable
                            shizukuManager.saveUiStateBool("iphone_audio", enable)
                            markImmediateFeedback("🎧 Audio Speaker & Headset iPhone [${if (enable) "ON" else "OFF"}]")
                            scope.launch {
                                val res = shizukuManager.commandRegistry.setFineVolumeAndSoundUnlocker(enable)
                                recordExecutionResult("🎧 Audio iPhone & 30-Step Fine Volume [${if (enable) "ON" else "OFF"}]", res)
                            }
                        },
                        onToggleDualNet = { enable ->
                            dualNetEnabled = enable
                            shizukuManager.saveUiStateBool("dual_net", enable)
                            markImmediateFeedback("🌐 Boost Jaringan Saluran Ganda [${if (enable) "ON" else "OFF"}]")
                            scope.launch {
                                val res = shizukuManager.applyDualChannelNetworkBoost(enable)
                                recordExecutionResult("🌐 Boost Jaringan Wi-Fi + Data [${if (enable) "ON" else "OFF"}]", res)
                            }
                        },
                        onToggleSmartCoolBoost = { enable ->
                            smartCoolBoostEnabled = enable
                            shizukuManager.saveUiStateBool("smart_cool_boost", enable)
                            markImmediateFeedback("⚖️ Smart Cool-Boost [${if (enable) "ON" else "OFF"}]")
                            scope.launch {
                                val res = if (enable) shizukuManager.applySmartCoolBoostBalance()
                                else shizukuManager.applyAndVerifySpecs(SystemProfile.BALANCED.specs)
                                recordExecutionResult("⚖️ Smart Cool-Boost [${if (enable) "ON" else "OFF"}]", res)
                            }
                        },
                        onRunSpecs = { moduleId, isTurnOn, title, specs ->
                            moduleStates[moduleId] = isTurnOn
                            shizukuManager.saveUiStateBool("mod_$moduleId", isTurnOn)
                            markImmediateFeedback(title)
                            scope.launch {
                                val res = shizukuManager.applyAndVerifySpecs(specs)
                                recordExecutionResult(title, res)
                            }
                        },
                        onRunRegistryAction = { title, block ->
                            markImmediateFeedback(title)
                            scope.launch {
                                val res = block()
                                recordExecutionResult(title, res)
                            }
                        },
                        onApplySafeDpi = { dpi ->
                            markImmediateFeedback("🖥️ Menguji Custom DPI $dpi (Dilindungi Timer Aman 15 Detik)")
                            scope.launch {
                                val res = shizukuManager.commandRegistry.applyCustomDpi(dpi)
                                recordExecutionResult("🖥️ Custom DPI ($dpi)", res)
                                if (res.any { it.verified }) {
                                    pendingSafeDpiLabel = "$dpi DPI"
                                }
                            }
                        }
                    )

                    AetheriaPage.GAMING -> GamingCenterPane(
                        telemetry = telemetry,
                        tripleComboEnabled = tripleComboEnabled,
                        autoSwitchServiceOn = autoSwitchServiceOn,
                        floatingHudOn = floatingHudOn,
                        shizukuManager = shizukuManager,
                        onToggleQuadCombo = { enable, pkg -> triggerQuadCombo(enable, pkg) },
                        onOpenOemBooster = {
                            val b = telemetry?.oemGameBooster ?: telemetryRepo.detectOemGameBooster()
                            shizukuManager.launchOemGameBooster(b)
                        },
                        onOpenOemPhoneMaster = {
                            val m = telemetry?.oemPhoneMaster ?: telemetryRepo.detectOemPhoneMaster()
                            shizukuManager.launchOemPhoneMaster(m)
                        },
                        onToggleAutoSwitch = { enable ->
                            if (enable) {
                                AutoSwitchEngineService.start(context)
                                autoSwitchServiceOn = true
                                recordExecutionResult(
                                    "🤖 Auto-Switch Game Service [ON]",
                                    listOf(
                                        VerificationRecord(
                                            feature = "Deteksi Game Otomatis (Foreground Service)",
                                            parameter = "UsageStatsEvents + ScreenOff Sleep",
                                            beforeValue = "OFF",
                                            targetValue = "Auto GAMING_MAX saat buka game",
                                            actualValue = "Berjalan di Latar Belakang (Hemat Baterai)",
                                            exitCode = 0,
                                            verified = true,
                                            badge = "🤖 AUTO-SWITCH ON",
                                            detail = "Otomatis masuk Mode Gaming Maksimal saat game dibuka & kembali ke Daily Smooth saat keluar"
                                        )
                                    )
                                )
                            } else {
                                AutoSwitchEngineService.stop(context)
                                autoSwitchServiceOn = false
                                recordExecutionResult(
                                    "🤖 Auto-Switch Game Service [OFF]",
                                    listOf(
                                        VerificationRecord(
                                            feature = "Deteksi Game Otomatis",
                                            parameter = "AutoSwitchEngineService",
                                            beforeValue = "ON",
                                            targetValue = "OFF",
                                            actualValue = "Dihentikan",
                                            exitCode = 0,
                                            verified = true,
                                            badge = "⭕ OFF",
                                            detail = "Pemantau otomatis dimatikan"
                                        )
                                    )
                                )
                            }
                        },
                        onToggleFloatingHud = { enable ->
                            scope.launch {
                                if (enable) {
                                    val granted = FloatingHudOverlayService.ensureOverlayPermissionOrOpenSettings(
                                        context,
                                        shizukuManager
                                    )
                                    if (granted) {
                                        FloatingHudOverlayService.start(context)
                                        floatingHudOn = true
                                        recordExecutionResult(
                                            "🎯 3D Floating Gaming HUD & Crosshair [ON]",
                                            listOf(
                                                VerificationRecord(
                                                    feature = "Floating Gaming HUD (Live FPS · ms · Suhu · Boost · Aim)",
                                                    parameter = "WindowManager Overlay",
                                                    beforeValue = "OFF",
                                                    targetValue = "Tampil Melayang di Atas Game",
                                                    actualValue = "HUD Aktif (Bisa Digeser & Ketuk 🎯Aim untuk Crosshair)",
                                                    exitCode = 0,
                                                    verified = true,
                                                    badge = "🎯 HUD AKTIF",
                                                    detail = "Menampilkan FPS nyata, Frame-Time ms, Suhu Baterai, 1-Tap RAM Boost & Crosshair"
                                                )
                                            )
                                        )
                                    } else {
                                        recordExecutionResult(
                                            "🔑 Izin Tampil di Atas Aplikasi Diperlukan",
                                            listOf(
                                                VerificationRecord(
                                                    feature = "Izin Floating HUD Overlay",
                                                    parameter = "SYSTEM_ALERT_WINDOW",
                                                    beforeValue = "Belum Diizinkan",
                                                    targetValue = "Izinkan AETHERIA Tampil di Atas Aplikasi Lain",
                                                    actualValue = "Silakan aktifkan sakelar izin di layar yang terbuka lalu ketuk ON lagi",
                                                    exitCode = 0,
                                                    verified = true,
                                                    badge = "🔑 IZINKAN OVERLAY",
                                                    detail = "Jika Shizuku/Brevent aktif, izin ini diberikan otomatis!"
                                                )
                                            )
                                        )
                                    }
                                } else {
                                    FloatingHudOverlayService.stop(context)
                                    floatingHudOn = false
                                }
                            }
                        },
                        onApplyDownscaleSlider = { pkg, ratio ->
                            markImmediateFeedback("📐 Mengatur Resolusi Render Game ($pkg -> ${String.format(Locale.US, "%.2f", ratio)}x)")
                            scope.launch {
                                val res = shizukuManager.commandRegistry.setGameDownscale(pkg, ratio, enablePerfMode = true)
                                recordExecutionResult("📐 Downscale Resolusi Game (${String.format(Locale.US, "%.2f", ratio)}x)", res)
                            }
                        },
                        onCompileGameArt = { pkg, mode ->
                            markImmediateFeedback("🚀 Kompilasi AOT Mesin Game ($pkg · Mode: $mode)")
                            scope.launch {
                                val res = shizukuManager.commandRegistry.compileAppPackage(pkg, mode)
                                recordExecutionResult("🚀 ART Compiler Game ($mode)", res)
                            }
                        },
                        onCleanShaderAndTrim = { pkg ->
                            markImmediateFeedback("🧹 Membersihkan Shader Cache Game & NAND FSTRIM")
                            scope.launch {
                                val res = shizukuManager.commandRegistry.cleanGameShaderAndTrimStorage(pkg)
                                recordExecutionResult("🧹 Bersihkan Shader Cache & FSTRIM", res)
                            }
                        },
                        onDailyBoost = { fullDex ->
                            val title = if (fullDex) "🔥 Full System Dexopt" else "⚡ Booster Cepat SystemUI + TikTok/WA/IG"
                            markImmediateFeedback(title)
                            scope.launch {
                                val res = shizukuManager.boostDailyAndSocialApps(fullDexopt = fullDex)
                                recordExecutionResult(title, res)
                            }
                        },
                        onApplyGamingMode = { gamePkg, gameName, mode, launchAfter ->
                            val modeLabel = "🎮 Mode Game ($mode · $gameName)"
                            markImmediateFeedback(modeLabel)
                            scope.launch {
                                val res = shizukuManager.applyUniversalGamingMode(gamePkg, mode)
                                recordExecutionResult(modeLabel, res)
                                if (launchAfter) {
                                    shizukuManager.launchGamePackage(gamePkg)
                                }
                            }
                        },
                        onApplyEsportsGraphics = { perfMode, aniso, tex, mipmap, frameStab, dualNet ->
                            val title = "🏆 E-Sports Ultimate Pro & Vulkan SkiaVK ($perfMode)"
                            markImmediateFeedback(title)
                            scope.launch {
                                val res = shizukuManager.applyEsportsProGraphics(
                                    performanceMode = perfMode,
                                    anisotropicOn = aniso,
                                    textureFilterOn = tex,
                                    mipmapLodOn = mipmap,
                                    frameStabilizerOn = frameStab,
                                    dualChannelNetOn = dualNet
                                )
                                activeProfile = SystemProfile.ESPORT_ULTIMATE_PRO
                                shizukuManager.saveUiStateString("active_profile", activeProfile.id)
                                recordExecutionResult(title, res)
                            }
                        }
                    )

                    AetheriaPage.SHIZUKU -> DualBridgeCenterPane(
                        diag = shizukuDiag,
                        shizukuManager = shizukuManager,
                        onOpenWizard = { showOnboardingWizard = true },
                        onRefresh = {
                            val d = shizukuManager.refreshDiagnostics()
                            val rec = VerificationRecord(
                                feature = "Pemeriksaan Dual-Jalur (Shizuku + Brevent Bridge)",
                                parameter = "Shizuku Binder + Brevent UID-2000 Heartbeat + WRITE_SECURE",
                                beforeValue = "Probe",
                                targetValue = "SHIZUKU ATAU BREVENT READY",
                                actualValue = d.activeBridgeMode.badgeLabel,
                                exitCode = if (d.isReady) 0 else -1,
                                verified = d.isReady,
                                badge = if (d.isReady) "🟢 TERHUBUNG" else "⚡ MODE MANDIRI",
                                detail = d.diagnosticMessage
                            )
                            recordExecutionResult("🔗 Cek Koneksi Dual-Jalur (Shizuku + Brevent)", listOf(rec))
                        },
                        onRequestPermission = { shizukuManager.requestPermissionSafely() }
                    )

                    AetheriaPage.STORAGE -> StorageDebloatSecurityPane(
                        telemetry = telemetry,
                        quadComboActive = tripleComboEnabled,
                        adblockShieldEnabled = adblockShieldEnabled,
                        adSdkBlockerEnabled = adSdkBlockerEnabled,
                        shizukuManager = shizukuManager,
                        onFixMobileDataDns = { triggerFixMobileDataDns() },
                        onScanAndPurgeMalware = { autoPurge ->
                            markImmediateFeedback("🛡️ Pemindaian Anti-Malware & Auto-Purge APK Penipuan")
                            scope.launch {
                                val res = shizukuManager.scanAndAutoPurgeMalware(autoPurge = autoPurge)
                                recordExecutionResult("🛡️ Pemindaian Anti-Malware & Auto-Purge", res)
                            }
                        },
                        onConfigureAdblockJudol = { dnsMode, freezeOem ->
                            adblockShieldEnabled = (dnsMode != "off")
                            shizukuManager.saveUiStateBool("adblock_shield", adblockShieldEnabled)
                            markImmediateFeedback("🚫 Pemblokir Iklan OEM & Anti-Judol Aman Kuota ($dnsMode)")
                            scope.launch {
                                val res = shizukuManager.configureAdblockAndJudolShield(dnsMode, freezeOem)
                                telemetry = telemetryRepo.collectTelemetry(shizukuDiag.isReady)
                                recordExecutionResult("🚫 Pemblokir Iklan OEM Aman Kuota", res)
                            }
                        },
                        onToggleAdSdkBlocker = { enable ->
                            adSdkBlockerEnabled = enable
                            shizukuManager.saveUiStateBool("adsdk_blocker", enable)
                            markImmediateFeedback("🚫 Pemutus Komponen Iklan Tanam (Ad-SDK) & Logd [${if (enable) "ON" else "OFF"}]")
                            scope.launch {
                                val res = shizukuManager.commandRegistry.disableEmbeddedAdSdkComponents(enable)
                                recordExecutionResult("🚫 Ad-SDK Component Blocker [${if (enable) "ON" else "OFF"}]", res)
                            }
                        },
                        onRecordResult = { title, recs -> recordExecutionResult(title, recs) }
                    )

                    AetheriaPage.PROFILES -> ProfilesWhitelistBootPane(
                        activeProfile = activeProfile,
                        autoResetOnReboot = autoResetOnReboot,
                        overnightMaintOn = overnightMaintOn,
                        shizukuManager = shizukuManager,
                        onToggleAutoResetOnReboot = { enabled ->
                            autoResetOnReboot = enabled
                            shizukuManager.setAutoResetOnRebootEnabled(enabled)
                            recordExecutionResult(
                                "🔄 Auto-Reset Standar Pabrik Saat HP Restart [${if (enabled) "ON" else "OFF"}]",
                                listOf(
                                    VerificationRecord(
                                        feature = "Kernel Boot-ID Auto-Reset Guard",
                                        parameter = "/proc/sys/kernel/random/boot_id",
                                        beforeValue = if (enabled) "OFF" else "ON",
                                        targetValue = if (enabled) "Otomatis Reset Saat HP Restart/Mati" else "Pertahankan Setelah Restart",
                                        actualValue = if (enabled) "AKTIF (Hapus Recent Apps tetap ON, Restart HP kembali Default!)" else "NONAKTIF",
                                        exitCode = 0,
                                        verified = true,
                                        badge = if (enabled) "🔄 BOOT RESET ON" else "🔒 TETAP ON",
                                        detail = "Membedakan secara presisi antara hapus Recent Apps vs HP Restart / Mati Daya"
                                    )
                                )
                            )
                        },
                        onToggleOvernightMaint = { enabled ->
                            overnightMaintOn = enabled
                            gameDetectionRepo.setOvernightMaintEnabledPref(enabled)
                            if (enabled && !autoSwitchServiceOn) {
                                AutoSwitchEngineService.start(context)
                                autoSwitchServiceOn = true
                            }
                        },
                        onSelectProfile = { profile ->
                            activeProfile = profile
                            shizukuManager.saveUiStateString("active_profile", profile.id)
                            markImmediateFeedback("🔄 Terapkan Profil Sistem: ${profile.title}")
                            scope.launch {
                                val res = shizukuManager.applyAndVerifySpecs(profile.specs)
                                recordExecutionResult("🔄 Terapkan Profil Sistem: ${profile.title}", res)
                            }
                        }
                    )

                    AetheriaPage.LOGS -> DiagnosticsLogsPane(
                        verifications = lastVerifications,
                        auditLog = auditLog
                    )

                    AetheriaPage.SETTINGS -> SettingsRecoveryQrisPane(
                        telemetry = telemetry,
                        snapshots = shizukuManager.getSavedSnapshots(),
                        updateStatus = updateStatus,
                        isCheckingUpdate = isCheckingUpdate,
                        onCheckUpdate = { triggerUpdateCheck() },
                        onRestore = { triggerPanicFactoryReset() }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                LiveScriptExecutionConsoleCard(
                    summaryText = lastActionSummary,
                    isSuccess = lastActionSuccess,
                    terminalLines = terminalLines,
                    verifications = lastVerifications
                )
            }
        }
    }
}

/**
 * Quad-Combo 4X Engine Card:
 * Connects AETHERIA + Built-In OEM Game Booster (XArena/Game Turbo/HyperBoost/Ultra Game/Game Booster)
 * + Built-In OEM Phone Master Across ALL Brands (Phone Master/Mi Security/Phone Manager/iManager/Device Care)
 * + Shizuku OR Brevent!
 */
@Composable
private fun QuadComboOemCard(
    oemBooster: OemGameBoosterInfo?,
    oemPhoneMaster: OemPhoneMasterInfo?,
    quadComboEnabled: Boolean,
    onToggleQuadCombo: (Boolean) -> Unit,
    onOpenOemBooster: () -> Unit,
    onOpenOemPhoneMaster: () -> Unit
) {
    val boosterTitle = oemBooster?.boosterName ?: "XArena / Game Booster Bawaan HP"
    val masterTitle = oemPhoneMaster?.managerName ?: "Phone Master Bawaan Semua HP"

    Extruded3dConsoleCard(
        accentColor = SovereignGold,
        secondaryAccent = CyberViolet,
        isHighlightedActive = quadComboEnabled
    ) {
        Text(
            text = "🔥 QUAD-COMBO 4X (AETHERIA + GAME BOOST + PHONE MASTER + SHIZUKU/BREVENT)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.8.sp
        )
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = "🎮 Game Boost Terhubung: $boosterTitle",
            color = QuantumEmerald,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.8.sp
        )
        Text(
            text = "🧹 Phone Master Terhubung: $masterTitle",
            color = IceCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.8.sp
        )
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = "Menyatukan 4 mesin sekaligus di semua merek HP tanpa bentrok — sementara WhatsApp & Instagram tetap dilindungi 100% agar tidak pernah mati!",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        ClearStatusSwitchBanner(
            isOn = quadComboEnabled,
            activeLabel = "QUAD-COMBO 4 MESIN AKTIF [ON]",
            inactiveLabel = "QUAD-COMBO BELUM AKTIF [OFF]",
            onToggle = { onToggleQuadCombo(!quadComboEnabled) }
        )

        Spacer(modifier = Modifier.height(8.dp))

        ClearOnOffButtonRow(
            isOn = quadComboEnabled,
            turnOnLabel = "🔥 Aktifkan Quad-Combo 4X",
            activeOnLabel = "✅ Quad-Combo 4X: ON",
            turnOffLabel = "📴 Matikan Combo",
            activeOffLabel = "⭕ Posisi: OFF",
            onTurnOn = { onToggleQuadCombo(true) },
            onTurnOff = { onToggleQuadCombo(false) }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Tactile3dPushButton(
                text = "🎮 Buka Game Boost HP",
                onClick = onOpenOemBooster,
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                textColor = Color(0xFF1A0F00),
                fontSizeSp = 10.2f
            )
            Tactile3dPushButton(
                text = "🧹 Buka Phone Master HP",
                onClick = onOpenOemPhoneMaster,
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                textColor = Color(0xFF02131C),
                fontSizeSp = 10.2f
            )
        }
    }
}

@Composable
private fun HomeOverviewPane(
    telemetry: DeviceTelemetry?,
    shizukuDiag: ShizukuDiagnostics,
    activeProfile: SystemProfile,
    adaptiveMode: ActiveProfileMode,
    autoResetOnReboot: Boolean,
    iphoneAudioEnabled: Boolean,
    dualNetEnabled: Boolean,
    smartCoolBoostEnabled: Boolean,
    tripleComboEnabled: Boolean,
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onOpenWizard: () -> Unit,
    onSelectAdaptiveMode: (ActiveProfileMode) -> Unit,
    onCheckUpdate: () -> Unit,
    onFixMobileDataDns: () -> Unit,
    onToggleQuadCombo: (Boolean) -> Unit,
    onOpenOemBooster: () -> Unit,
    onOpenOemPhoneMaster: () -> Unit,
    onCleanRam: () -> Unit,
    onSmartCoolBoost: () -> Unit,
    onDailyBoost: () -> Unit,
    onToggleIphoneAudio: (Boolean) -> Unit,
    onToggleDualNet: (Boolean) -> Unit,
    onOpenGaming: () -> Unit,
    onOpenQris: () -> Unit,
    onRestore: () -> Unit
) {
    MenuGuideBanner(
        title = "Panduan Menu 01: 3D Cockpit v30.0 · Shizuku + Brevent · Quad-Combo Phone Master",
        guideText = "Tampilan 3D Extruded Cockpit generasi baru! Mendukung 2 jalur (Shizuku & Brevent), terhubung ke Game Boost + Phone Master bawaan semua HP, melindungi WA & IG 100%, tetap ON saat hapus Recent Apps, dan OTOMATIS kembali ke Standar Pabrik saat HP di-restart atau dimatikan!"
    )

    // 3D OMNI Sovereign Hero Card
    Extruded3dConsoleCard(
        accentColor = IceCyan,
        secondaryAccent = SovereignGold,
        isHighlightedActive = shizukuDiag.isReady
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Rw14QuantumEmblem()
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = "AETHERIA // RW-14 3D OMNI",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.5.sp
                )
                Text(
                    text = "v30.0 SHIZUKU + BREVENT · PHONE MASTER · ${AetheriaIdentity.LAUNCHER_CODE}",
                    color = SovereignGold,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp
                )
                Text(
                    text = "Architect: ${AetheriaIdentity.ARCHITECT} · NMID: ${AetheriaIdentity.QRIS_NMID}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = telemetry?.networkTransportLabel ?: "🌐 MODE ONLINE / OFFLINE HYBRID AKTIF",
            color = if (telemetry?.isInternetOnline == false) SovereignGold else QuantumEmerald,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp
        )
        val hw = telemetry?.hardwareSpecs
        if (hw != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "⚙️ ${hw.recommendedTier.badgeTitle} · RAM ${hw.totalRamGb}GB · ${hw.storageType.label} · Baterai ${hw.batteryHealth.healthPercent}% (${hw.batteryHealth.realTimeWattageW}W)",
                color = IceCyan,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp
            )
        } else {
            val (tierTitle, tierAdvice) = DeviceTierAdvisor.classifyTier(
                telemetry?.ramTotalMb ?: 4096L,
                telemetry?.cpuCores ?: 8
            )
            Text(text = "🎯 $tierTitle — $tierAdvice", color = IceCyan, fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusBadge(
                text = shizukuDiag.activeBridgeMode.badgeLabel,
                color = if (shizukuDiag.isReady) QuantumEmerald else SovereignGold,
                modifier = Modifier.clickable { onOpenWizard() }
            )
            StatusBadge(
                text = if (autoResetOnReboot) "🔄 AUTO-RESET SAAT RESTART: ON" else "🔒 TETAP ON SAAT RESTART",
                color = IceCyan
            )
            StatusBadge(
                text = "🛡️ WA & IG IMMORTAL SAFE",
                color = QuantumEmerald
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusBadge(
                text = "PROFIL: ${activeProfile.id.uppercase(Locale.ROOT)}",
                color = SovereignGold
            )
            StatusBadge(
                text = "📶 PERBAIKI DATA/KUOTA",
                color = QuantumEmerald,
                modifier = Modifier.clickable { onFixMobileDataDns() }
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 1-Click 3-Mode Adaptive Hardware Selector (Daily Smooth / Gaming Max / Battery Saver)
    Extruded3dConsoleCard(accentColor = QuantumEmerald, secondaryAccent = IceCyan) {
        Text(
            text = "⚡ MODE ADAPTIF CERDAS 1-KLIK (MENYESUAIKAN TIER HP & STORAGE UFS/eMMC)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Otomatis menyesuaikan rumus optimasi dengan kapasitas RAM & tipe memori internal HP Anda (100% Aman Kuota Data & WA/IG):",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Tactile3dPushButton(
                text = if (adaptiveMode == ActiveProfileMode.DAILY_SMOOTH) "✓ 🌿 Harian" else "🌿 Harian",
                onClick = { onSelectAdaptiveMode(ActiveProfileMode.DAILY_SMOOTH) },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                textColor = Color(0xFF02141E),
                fontSizeSp = 10.5f
            )
            Tactile3dPushButton(
                text = if (adaptiveMode == ActiveProfileMode.GAMING_MAX) "✓ 🔥 Gaming" else "🔥 Gaming",
                onClick = { onSelectAdaptiveMode(ActiveProfileMode.GAMING_MAX) },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                textColor = Color(0xFF1A0F00),
                fontSizeSp = 10.5f
            )
            Tactile3dPushButton(
                text = if (adaptiveMode == ActiveProfileMode.BATTERY_SAVER) "✓ 🔋 Hemat" else "🔋 Hemat",
                onClick = { onSelectAdaptiveMode(ActiveProfileMode.BATTERY_SAVER) },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                textColor = Color(0xFF021A10),
                fontSizeSp = 10.5f
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Quad-Combo Card (AETHERIA + Game Boost HP + Phone Master HP + Shizuku/Brevent)
    QuadComboOemCard(
        oemBooster = telemetry?.oemGameBooster,
        oemPhoneMaster = telemetry?.oemPhoneMaster,
        quadComboEnabled = tripleComboEnabled,
        onToggleQuadCombo = onToggleQuadCombo,
        onOpenOemBooster = onOpenOemBooster,
        onOpenOemPhoneMaster = onOpenOemPhoneMaster
    )

    Spacer(modifier = Modifier.height(12.dp))

    CommunityStatsBannerCard(
        activeUsers = telemetry?.communityActiveUsers ?: 1,
        totalDownloads = telemetry?.communityTotalDownloads ?: 1,
        localOptCount = telemetry?.localOptimizationCount ?: 1,
        installedGamesCount = telemetry?.detectedGames?.count { it.isInstalled } ?: 0,
        onOpenQris = onOpenQris
    )

    Spacer(modifier = Modifier.height(12.dp))

    // 3D Quick Control Console
    Extruded3dConsoleCard(accentColor = QuantumEmerald, secondaryAccent = SovereignGold) {
        Text(
            text = "🎛️ KONSOL TOMBOL TAKTIL 3D & SUHU (${telemetry?.batteryTempC ?: 35.0}°C)",
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        ClearStatusSwitchBanner(
            isOn = smartCoolBoostEnabled,
            activeLabel = "SMART COOL-BOOST: AKTIF [ON]",
            inactiveLabel = "SMART COOL-BOOST: MATI [OFF]",
            onToggle = onSmartCoolBoost
        )
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = iphoneAudioEnabled,
            activeLabel = "AUDIO SPEAKER/HEADSET IPHONE: AKTIF [ON]",
            inactiveLabel = "AUDIO SPEAKER/HEADSET IPHONE: MATI [OFF]",
            onToggle = { onToggleIphoneAudio(!iphoneAudioEnabled) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = dualNetEnabled,
            activeLabel = "DUAL-NET BOOST (WI-FI + DATA): AKTIF [ON]",
            inactiveLabel = "DUAL-NET BOOST (WI-FI + DATA): MATI [OFF]",
            onToggle = { onToggleDualNet(!dualNetEnabled) }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "🧊 Dinginkan RAM",
                onClick = onCleanRam,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                textColor = Color(0xFF031A10)
            )
            Tactile3dPushButton(
                text = "📱 Boost TikTok/WA",
                onClick = onDailyBoost,
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                textColor = Color(0xFF03101A)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "🎮 Menu Quad-Combo",
                onClick = onOpenGaming,
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                textColor = Color(0xFF1A0F00)
            )
            Tactile3dPushButton(
                text = "🚨 Standar Pabrik",
                onClick = onRestore,
                modifier = Modifier.weight(1f),
                faceColor = AlertRose,
                deepBaseColor = AlertRoseDeep,
                textColor = Color.White
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    OtaUpdateCard(
        updateStatus = updateStatus,
        isCheckingUpdate = isCheckingUpdate,
        onCheckUpdate = onCheckUpdate
    )

    Spacer(modifier = Modifier.height(12.dp))

    // 2x2 3D Extruded Ring Gauges
    val ramPct = telemetry?.ramUsedPercent ?: 0
    val batPct = telemetry?.batteryPercent ?: 0
    val tempC = telemetry?.batteryTempC ?: 35.0
    val romPct = telemetry?.storageUsedPercent ?: 0
    val watt = telemetry?.hardwareSpecs?.batteryHealth?.realTimeWattageW ?: 0.0

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ramPct.toFloat(),
            centerValue = "$ramPct%",
            unitLabel = "LPDDR",
            title = "MEMORI RAM",
            subtitle = "Bebas ${telemetry?.ramAvailMb ?: 0} MB",
            color = IceCyan
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = batPct.toFloat(),
            centerValue = "$batPct%",
            unitLabel = "${watt}W",
            title = "BATERAI & DAYA",
            subtitle = if (telemetry?.isCharging == true) "CHARGING" else "DISCHARGING",
            color = QuantumEmerald
        )
    }
    Spacer(modifier = Modifier.height(10.dp))
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = ((tempC - 20.0) * 2.5).toFloat().coerceIn(10f, 100f),
            centerValue = "${tempC}°C",
            unitLabel = "THERMAL",
            title = "SUHU & GUARD",
            subtitle = if (tempC >= 43.0) "⚠️ PANAS >=43°C" else "ADEM (OPTIMAL)",
            color = SovereignGold
        )
        GaugeCard(
            modifier = Modifier.weight(1f),
            percent = romPct.toFloat(),
            centerValue = "$romPct%",
            unitLabel = telemetry?.hardwareSpecs?.storageType?.name ?: "FLASH",
            title = "STORAGE ${telemetry?.hardwareSpecs?.storageType?.name ?: "ROM"}",
            subtitle = "Bebas ${telemetry?.storageFreeGb ?: 0.0} GB",
            color = CyberViolet
        )
    }
}

@Composable
private fun DeviceIntelligencePane(
    telemetry: DeviceTelemetry?,
    bypassChargingEnabled: Boolean,
    capabilities: List<FeatureCapability>,
    onToggleBypassCharging: (Boolean) -> Unit,
    onOpenPhoneMaster: () -> Unit
) {
    val hw = telemetry?.hardwareSpecs
    val bh = hw?.batteryHealth

    MenuGuideBanner(
        title = "Panduan Menu 02: Deteksi Hardware UFS/eMMC, Battery Health % & Bypass Charging",
        guideText = "Mendeteksi otomatis tipe chip penyimpanan (UFS vs eMMC — aman dari salah deteksi kartu MicroSD!), Kesehatan Baterai asli (Battery Health %), Siklus Cas, Arus Watt real-time, serta Game Boost & Phone Master bawaan HP."
    )

    SectionCard(title = "📱 Spesifikasi Kernel, Tier Otomatis & Phone Master") {
        Text("Perangkat: ${telemetry?.brand ?: "-"} ${telemetry?.model ?: "-"} (Android ${telemetry?.androidRelease ?: "-"} · SDK ${telemetry?.sdkInt ?: "-"})", color = TextPrimary, fontWeight = FontWeight.Bold)
        Text("SoC / CPU: ${telemetry?.socHardware ?: "-"} (${telemetry?.cpuCores ?: 8} Cores · Max ${(hw?.maxCpuFreqKhz ?: 2000000L) / 1000} MHz)", color = TextSecondary, fontSize = 12.sp)
        Text("Tipe Memori Internal: ${hw?.storageType?.label ?: "Auto-Detect"} · RAM Komersial: ${hw?.totalRamGb ?: 4} GB", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("Klasifikasi Tier: ${hw?.recommendedTier?.badgeTitle ?: "-"}", color = SovereignGold, fontWeight = FontWeight.Black, fontSize = 12.sp)
        Text("Rekomendasi Mesin: ${hw?.recommendedTier?.focusSummary ?: "-"}", color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text("🎮 Game Booster Bawaan: ${telemetry?.oemGameBooster?.boosterName ?: "-"}", color = QuantumEmerald, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        Text("🧹 Phone Master Bawaan: ${telemetry?.oemPhoneMaster?.managerName ?: "-"}", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "🧹 Buka Phone Master Bawaan HP (${telemetry?.oemPhoneMaster?.managerName ?: "System Manager"})",
            onClick = onOpenPhoneMaster,
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep,
            textColor = Color(0xFF02131C)
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(
        title = "🔋 Kesehatan Baterai (Battery Health %), Wattage & Smart Bypass Charging",
        isHighlightedActive = bypassChargingEnabled
    ) {
        Text(
            text = "Kesehatan Kimia Baterai: ${bh?.healthPercent ?: 96}% — ${bh?.healthLabel ?: "PRIMA"}",
            color = QuantumEmerald,
            fontWeight = FontWeight.Black,
            fontSize = 13.sp
        )
        Text(
            text = "Kapasitas Penuh Saat Ini: ${bh?.currentFullCapacityMah?.let { "$it mAh" } ?: "Terkunci Kernel OEM"} / Desain Pabrik: ${bh?.designCapacityMah?.let { "$it mAh" } ?: "Standar"}",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Text(
            text = "Cycle Count (Siklus Cas): ${bh?.cycleCount?.toString() ?: "Android 14+ / BMS"} · Arus Real-Time: ${bh?.currentNowMa ?: 0} mA · Daya: ${bh?.realTimeWattageW ?: 0.0} Watt",
            color = IceCyan,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
        if (bh?.thermalDangerAlert == true) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "⚠️ PERINGATAN TERMAL (${bh.temperatureC}°C >= 43°C): Suhu baterai tinggi! Segera aktifkan Smart Cool-Boost atau gunakan Fan Cooler.",
                color = AlertRose,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        ClearStatusSwitchBanner(
            isOn = bypassChargingEnabled,
            activeLabel = "SMART BYPASS CHARGING: AKTIF [ON]",
            inactiveLabel = "SMART BYPASS CHARGING: MATI [OFF]",
            onToggle = { onToggleBypassCharging(!bypassChargingEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Mengaktifkan kunci Direct Power / Bypass Charging OEM (${bh?.bypassChargingCandidateKey ?: "bypass_charging_enable / pass_through"}) pada HP yang mendukung agar listrik charger mengalir langsung ke mesin tanpa memanaskan baterai.",
            color = TextSecondary,
            fontSize = 11.sp
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🔐 Matriks Kapabilitas (Native vs Shizuku / Brevent)") {
        capabilities.forEach { cap ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                    .border(1.dp, IceCyan.copy(alpha = 0.28f), RoundedCornerShape(12.dp))
                    .padding(11.dp)
            ) {
                Text("${cap.title} [${cap.tier.label}]", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(cap.reason, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PerformanceLabPane(
    moduleStates: Map<String, Boolean>,
    iphoneAudioEnabled: Boolean,
    dualNetEnabled: Boolean,
    smartCoolBoostEnabled: Boolean,
    tripleComboEnabled: Boolean,
    oemBooster: OemGameBoosterInfo?,
    oemPhoneMaster: OemPhoneMasterInfo?,
    telemetry: DeviceTelemetry?,
    shizukuManager: ShizukuBridgeManager,
    pingResults: List<PingServerResult>,
    isTestingPing: Boolean,
    onTestPing: () -> Unit,
    onFixMobileDataDns: () -> Unit,
    onToggleQuadCombo: (Boolean) -> Unit,
    onToggleIphoneAudio: (Boolean) -> Unit,
    onToggleDualNet: (Boolean) -> Unit,
    onToggleSmartCoolBoost: (Boolean) -> Unit,
    onRunSpecs: (String, Boolean, String, List<SettingSpec>) -> Unit,
    onRunRegistryAction: (String, suspend () -> List<VerificationRecord>) -> Unit,
    onApplySafeDpi: (Int) -> Unit
) {
    var expandedSector by remember { mutableStateOf(1) }
    var customDpiInput by remember { mutableStateOf("420") }
    var firewallOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("game_firewall_on", false)) }
    var vulkanOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec1_vulkan", false)) }
    var framePacingOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec1_pacing", false)) }
    var brightGuardOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec1_bright", false)) }
    var fixedPerfOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec2_powerhal", false)) }
    var vramOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec2_vram", false)) }
    var gyroOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec3_gyro", false)) }
    var controllerOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec3_ctrl", false)) }
    var btGamingOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec5_bt_lowlat", false)) }
    var deepDozeOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec6_doze", false)) }
    var freeformOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec8_freeform", false)) }
    var cleanStatusOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("sec8_statusbar", false)) }

    MenuGuideBanner(
        title = "Panduan Menu 03: 8-Sektor (34 Fitur Non-Root), Audio iPhone & Tes Ping Server Game",
        guideText = "Seluruh 34 fitur Non-Root (tanpa duplikat!) dikelompokkan rapi ke dalam panel 3D di bawah. Semua fitur berjalan melalui Shizuku MAUPUN Brevent, dengan perlindungan otomatis Kuota Data 4G/5G serta WA & IG!"
    )

    // 1. iPhone Audio + 30-Step Fine Volume
    SectionCard(
        title = "🎧 Audio Speaker & Headset Setara iPhone + 30-Step Fine Volume",
        isHighlightedActive = iphoneAudioEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = iphoneAudioEnabled,
            activeLabel = "AUDIO IPHONE & 30-STEP VOLUME AKTIF [ON]",
            inactiveLabel = "AUDIO IPHONE MATI / STANDAR [OFF]",
            onToggle = { onToggleIphoneAudio(!iphoneAudioEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Mengaktifkan Hardware AudioFX (LoudnessEnhancer +4.5dB, Warm BassBoost 65%, Spatial 3D Virtualizer 75%), K2HD, Tube Amp, Dirac Spatial & membuka 30 tingkat presisi tombol volume.",
            color = TextSecondary,
            fontSize = 11.2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        ClearOnOffButtonRow(
            isOn = iphoneAudioEnabled,
            turnOnLabel = "▶️ Nyalakan Audio iPhone",
            activeOnLabel = "✅ Audio iPhone: ON",
            turnOffLabel = "📴 Matikan (Standar)",
            activeOffLabel = "⭕ Posisi: Standar",
            onTurnOn = { onToggleIphoneAudio(true) },
            onTurnOff = { onToggleIphoneAudio(false) }
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 2. Network, Ping Tester, 4G/5G Lock & Game Firewall (WA/IG Safe)
    SectionCard(
        title = "🌐 Dual-Net Boost, Tes Ping Game, Kunci 4G/5G & Firewall (WA/IG Aman)",
        isHighlightedActive = dualNetEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = dualNetEnabled,
            activeLabel = "DUAL-NET & WI-FI LOW-LATENCY LOCK [ON]",
            inactiveLabel = "DUAL-NET BOOST MATI / STANDAR [OFF]",
            onToggle = { onToggleDualNet(!dualNetEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = if (isTestingPing) "⏳ Mengukur Ping..." else "📡 Tes Ping Server Game",
                onClick = onTestPing,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                textColor = Color(0xFF021A10),
                fontSizeSp = 10f
            )
            Tactile3dPushButton(
                text = "📶 Kunci 4G LTE / 5G NR",
                onClick = {
                    onRunRegistryAction("📡 Buka Menu Kunci Jaringan 4G LTE / 5G NR") {
                        listOf(shizukuManager.commandRegistry.openRadioNetworkLockMenu())
                    }
                },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                textColor = Color(0xFF02131C),
                fontSizeSp = 10f
            )
        }

        if (pingResults.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            pingResults.forEach { pr ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardInnerBottom)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(pr.serverName, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(pr.statusBadge, color = QuantumEmerald, fontFamily = FontFamily.Monospace, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        GraphicOptionToggleRow(
            title = "🛡️ Firewall Bandwith Game (WA & IG Bebas Blokir 100%)",
            subtitle = "Hentikan sedotan kuota aplikasi latar saat main game; Game, WhatsApp & Instagram tetap lancar penuh!",
            checked = firewallOn,
            onToggle = {
                firewallOn = !firewallOn
                shizukuManager.saveUiStateBool("game_firewall_on", firewallOn)
                val targetGame = shizukuManager.loadUiStateString("selected_game_pkg", "com.mobile.legends")
                onRunRegistryAction("🛡️ Firewall Bandwith Game [${if (firewallOn) "ON" else "OFF"}]") {
                    shizukuManager.commandRegistry.setBackgroundDataFirewall(firewallOn, targetGame)
                }
            }
        )

        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "📶 Perbaiki Internet Data Seluler (Reset DNS agar Kuota 4G/5G Lancar)",
            onClick = onFixMobileDataDns,
            modifier = Modifier.fillMaxWidth(),
            faceColor = SovereignGold,
            deepBaseColor = SovereignGoldDeep,
            textColor = Color(0xFF1A0F00),
            fontSizeSp = 10.2f
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 3. 8-SECTOR ACCORDION PRO TWEAKS CONSOLE
    SectionCard(title = "🧬 KONSOL 8-SEKTOR PRO TWEAKS (34 FITUR NON-ROOT LENGKAP)") {
        Text(
            text = "Ketuk tab sektor di bawah untuk membuka kontrol mendalam setiap sektor perangkat keras:",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        val sectors = listOf(
            1 to "1. Layar/GPU",
            2 to "2. CPU/ART/RAM",
            3 to "3. Touch/Gyro",
            5 to "5. BT/Audio",
            6 to "6. Doze/Daya",
            8 to "8. MultiWindow"
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            sectors.forEach { (id, title) ->
                SelectableChipButton(
                    modifier = Modifier,
                    title = title,
                    selected = expandedSector == id,
                    onClick = { expandedSector = id }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (expandedSector) {
            1 -> {
                // SEKTOR 1: DISPLAY & GPU
                GraphicOptionToggleRow(
                    title = "Engine Renderer Vulkan (SkiaVK) + 100% GPU Overlay",
                    subtitle = "Alihkan OpenGL ke Vulkan multi-thread & pindahkan komposisi UI ke GPU (SurfaceFlinger 1008)",
                    checked = vulkanOn,
                    onToggle = {
                        vulkanOn = !vulkanOn
                        shizukuManager.saveUiStateBool("sec1_vulkan", vulkanOn)
                        onRunRegistryAction("🌋 Vulkan SkiaVK & GPU Overlay [${if (vulkanOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.setVulkanRenderer(vulkanOn)
                        }
                    }
                )
                GraphicOptionToggleRow(
                    title = "SurfaceFlinger Zero-Delay Frame Pacing",
                    subtitle = "Pangkas antrean VSync (latch_unsignaled) agar frame tampil detik itu juga tanpa input lag",
                    checked = framePacingOn,
                    onToggle = {
                        framePacingOn = !framePacingOn
                        shizukuManager.saveUiStateBool("sec1_pacing", framePacingOn)
                        onRunRegistryAction("⚡ SurfaceFlinger Frame Pacing [${if (framePacingOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.optimizeFramePacing(framePacingOn)
                        }
                    }
                )
                GraphicOptionToggleRow(
                    title = "Kunci Kecerahan Anti-Redup, Anti-Layar Kuning & Mistouch Guard",
                    subtitle = "Cegah layar tiba-tiba gelap saat HP hangat & cegah salah pencet notifikasi saat war",
                    checked = brightGuardOn,
                    onToggle = {
                        brightGuardOn = !brightGuardOn
                        shizukuManager.saveUiStateBool("sec1_bright", brightGuardOn)
                        onRunRegistryAction("☀️ Anti Auto-Dimming & Touch Guard [${if (brightGuardOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.setInGameBrightnessAndTouchGuard(brightGuardOn)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("🎨 Saturasi Warna Layar SurfaceFlinger (Visibilitas Musuh):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(5.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Tactile3dPushButton(
                        text = "Natural sRGB",
                        onClick = { onRunRegistryAction("🎨 Warna Natural sRGB") { shizukuManager.commandRegistry.setSurfaceFlingerColorMode(0) } },
                        modifier = Modifier.weight(1f),
                        faceColor = IceCyan,
                        deepBaseColor = IceCyanDeep,
                        fontSizeSp = 9.8f
                    )
                    Tactile3dPushButton(
                        text = "Vivid AMOLED",
                        onClick = { onRunRegistryAction("🎨 Warna Vivid AMOLED") { shizukuManager.commandRegistry.setSurfaceFlingerColorMode(1) } },
                        modifier = Modifier.weight(1f),
                        faceColor = QuantumEmerald,
                        deepBaseColor = QuantumEmeraldDeep,
                        fontSizeSp = 9.8f
                    )
                    Tactile3dPushButton(
                        text = "Pro Contrast",
                        onClick = { onRunRegistryAction("🎨 Warna Pro Gamer Contrast") { shizukuManager.commandRegistry.setSurfaceFlingerColorMode(2) } },
                        modifier = Modifier.weight(1f),
                        faceColor = SovereignGold,
                        deepBaseColor = SovereignGoldDeep,
                        fontSizeSp = 9.8f
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("⚙️ Pengunci Refresh Rate Multi-Merek & LTPO Unlocker:", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(5.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0 to "Adaptif", 1 to "LTPO Max", 60 to "60Hz", 90 to "90Hz", 120 to "120Hz", 144 to "144Hz").forEach { (hz, lbl) ->
                        SelectableChipButton(
                            modifier = Modifier,
                            title = lbl,
                            selected = false,
                            onClick = {
                                onRunRegistryAction("⚙️ Kunci Layar $lbl") {
                                    shizukuManager.commandRegistry.lockRefreshRate(hz)
                                }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text("🖥️ Safe Custom DPI Tweaker (Dilindungi Timer Auto-Revert 15 Detik):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text("Mengubah sensitivitas sudut pandang & keleluasaan layar (aman 280–600 DPI):", color = TextSecondary, fontSize = 10.5.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF040914))
                            .border(1.2.dp, IceCyan, RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        BasicTextField(
                            value = customDpiInput,
                            onValueChange = { next -> customDpiInput = next.filter { it.isDigit() }.take(3) },
                            singleLine = true,
                            cursorBrush = SolidColor(IceCyan),
                            textStyle = TextStyle(
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Tactile3dPushButton(
                        text = "🖥️ Uji DPI (15s)",
                        onClick = {
                            val dpi = customDpiInput.toIntOrNull() ?: 420
                            onApplySafeDpi(dpi)
                        },
                        modifier = Modifier.weight(1.1f),
                        faceColor = SovereignGold,
                        deepBaseColor = SovereignGoldDeep,
                        textColor = Color(0xFF1A0F00)
                    )
                    Tactile3dPushButton(
                        text = "↩️ Reset",
                        onClick = {
                            onRunRegistryAction("↩️ Reset DPI & Resolusi Pabrik") {
                                shizukuManager.commandRegistry.revertDisplaySizeAndDpi()
                            }
                        },
                        modifier = Modifier.weight(0.8f),
                        faceColor = AlertRose,
                        deepBaseColor = AlertRoseDeep,
                        textColor = Color.White
                    )
                }
            }

            2 -> {
                // SEKTOR 2: CPU, ART & RAM
                GraphicOptionToggleRow(
                    title = "Fixed Performance Mode (Kunci Clock CPU/GPU via Power HAL)",
                    subtitle = "Tahan frekuensi Big Cores prosesor di batas atas saat bermain game berat",
                    checked = fixedPerfOn,
                    onToggle = {
                        fixedPerfOn = !fixedPerfOn
                        shizukuManager.saveUiStateBool("sec2_powerhal", fixedPerfOn)
                        onRunRegistryAction("⚡ Power HAL Fixed Performance [${if (fixedPerfOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.setFixedPerformanceMode(fixedPerfOn)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))
                Tactile3dPushButton(
                    text = "🚀 Kompilasi Speed SystemUI & Home Launcher (Bar Notifikasi Anti-Lag)",
                    onClick = {
                        onRunRegistryAction("🚀 Kompilasi Speed SystemUI & Launcher") {
                            shizukuManager.commandRegistry.compileSystemUiAndLauncher()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    faceColor = QuantumEmerald,
                    deepBaseColor = QuantumEmeraldDeep,
                    textColor = Color(0xFF021A10),
                    fontSizeSp = 10.5f
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("🧠 Batas Cached Processes RAM & Matikan Phantom Killer (WA/IG Anti-Reload):", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(6 to "6 (Fokus Game)", 16 to "16 (Hemat)", 32 to "32 (Multi)", 48 to "48 (Flagship)").forEach { (limit, lbl) ->
                        Tactile3dPushButton(
                            text = lbl,
                            onClick = {
                                onRunRegistryAction("🧠 Batas RAM $lbl + Anti-Reload WA/IG") {
                                    shizukuManager.commandRegistry.configureMultitaskingLimits(limit, disablePhantomKiller = true)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            faceColor = IceCyan,
                            deepBaseColor = IceCyanDeep,
                            fontSizeSp = 9.2f
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                val storLabel = telemetry?.hardwareSpecs?.storageType?.label ?: "Storage"
                GraphicOptionToggleRow(
                    title = "Virtual RAM / MemFusion / RAM Plus ($storLabel)",
                    subtitle = "TIPS PENTING: Matikan (OFF) jika HP memakai memori eMMC agar CPU tidak lag akibat swap lambat!",
                    checked = vramOn,
                    onToggle = {
                        vramOn = !vramOn
                        shizukuManager.saveUiStateBool("sec2_vram", vramOn)
                        onRunRegistryAction("💾 Virtual RAM / MemFusion [${if (vramOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.setVirtualRamEnabled(vramOn)
                        }
                    }
                )
            }

            3 -> {
                // SEKTOR 3: TOUCH, DECIMAL ANIMATION, GYRO & HAPTIC
                Text("✨ Skala Animasi Desimal Presisi (Rahasia UI Snappy Ala Flagship):", color = SovereignGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0.0f, 0.25f, 0.35f, 0.5f, 0.7f, 1.0f).forEach { sc ->
                        SelectableChipButton(
                            modifier = Modifier,
                            title = "${sc}x",
                            selected = false,
                            onClick = {
                                onRunRegistryAction("✨ Skala Animasi Desimal ${sc}x") {
                                    shizukuManager.commandRegistry.setDecimalAnimationScale(sc)
                                }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Tactile3dPushButton(
                    text = "👆 Aktifkan Touch Polling 240Hz + Kinetic Scroll Licin + Flick 150ms",
                    onClick = {
                        onRunRegistryAction("👆 Touch Polling 240Hz & Kinetic Scroll") {
                            shizukuManager.commandRegistry.tuneTouchAndScrolling(240, 5, 150)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    faceColor = QuantumEmerald,
                    deepBaseColor = QuantumEmeraldDeep,
                    fontSizeSp = 10.2f
                )

                Spacer(modifier = Modifier.height(8.dp))
                GraphicOptionToggleRow(
                    title = "🎯 Gyroscope High-Polling 200Hz (PUBG Mobile / CODM / FPS)",
                    subtitle = "Pangkas delay sensor kemiringan HP agar kontrol recoil gyro instan & presisi",
                    checked = gyroOn,
                    onToggle = {
                        gyroOn = !gyroOn
                        shizukuManager.saveUiStateBool("sec3_gyro", gyroOn)
                        onRunRegistryAction("🎯 Gyroscope 200Hz Fast-Polling [${if (gyroOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.boostGyroscopePolling(gyroOn)
                        }
                    }
                )

                GraphicOptionToggleRow(
                    title = "🎮 Optimasi Gamepad Bluetooth & Mouse USB OTG 1:1",
                    subtitle = "Matikan akselerasi kursor acak untuk bidikan presisi memakai kontroler/mouse",
                    checked = controllerOn,
                    onToggle = {
                        controllerOn = !controllerOn
                        shizukuManager.saveUiStateBool("sec3_ctrl", controllerOn)
                        onRunRegistryAction("🎮 Raw Input Gamepad & Mouse [${if (controllerOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.optimizeExternalControllerMouse(controllerOn)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text("📳 Intensitas Getar Haptic Motor:", color = IceCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(5.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "0 (Mati)", 1 to "1 (Halus)", 2 to "2 (Tegas)", 3 to "3 (Maks)").forEach { (lvl, lbl) ->
                        Tactile3dPushButton(
                            text = lbl,
                            onClick = {
                                onRunRegistryAction("📳 Haptic Feedback $lbl") {
                                    shizukuManager.commandRegistry.setHapticIntensity(lvl)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            faceColor = SovereignGold,
                            deepBaseColor = SovereignGoldDeep,
                            fontSizeSp = 9.5f
                        )
                    }
                }
            }

            5 -> {
                // SEKTOR 5: BLUETOOTH LOW-LATENCY VS LDAC HI-RES
                GraphicOptionToggleRow(
                    title = "🎧 Mode TWS Bluetooth Gaming Low-Latency (Anti-Delay Langkah Kaki)",
                    subtitle = "ON = Latensi rendah untuk game kompetitif · OFF = Mode Musik Hi-Res LDAC 990kbps",
                    checked = btGamingOn,
                    onToggle = {
                        btGamingOn = !btGamingOn
                        shizukuManager.saveUiStateBool("sec5_bt_lowlat", btGamingOn)
                        onRunRegistryAction("🎧 Bluetooth Audio [${if (btGamingOn) "Gaming Low-Latency" else "Hi-Res LDAC 990kbps"}]") {
                            shizukuManager.commandRegistry.setBluetoothAudioMode(btGamingOn)
                        }
                    }
                )
            }

            6 -> {
                // SEKTOR 6: DEEP DOZE BATTERY SAVER (WA & IG SAFE)
                GraphicOptionToggleRow(
                    title = "🔋 Smart Deep Doze 60 Detik Saat Layar Mati (WA & IG Bebas Tidur!)",
                    subtitle = "Bikin baterai super irit semalaman, sementara WhatsApp & Instagram tetap masuk detik itu juga!",
                    checked = deepDozeOn,
                    onToggle = {
                        deepDozeOn = !deepDozeOn
                        shizukuManager.saveUiStateBool("sec6_doze", deepDozeOn)
                        onRunRegistryAction("🔋 Smart Deep Doze Aman WA/IG [${if (deepDozeOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.enableAggressiveDoze(deepDozeOn)
                        }
                    }
                )
            }

            8 -> {
                // SEKTOR 8: FREEFORM MULTI-WINDOW & CLEAN STATUS BAR
                GraphicOptionToggleRow(
                    title = "🪟 Buka Kunci Freeform Floating Window & Paksa Semua App Bisa Split-Screen",
                    subtitle = "Jalankan game & aplikasi apa saja dalam mode jendela melayang ala PC",
                    checked = freeformOn,
                    onToggle = {
                        freeformOn = !freeformOn
                        shizukuManager.saveUiStateBool("sec8_freeform", freeformOn)
                        onRunRegistryAction("🪟 Freeform Multi-Window [${if (freeformOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.unlockFreeformWindows(freeformOn)
                        }
                    }
                )
                GraphicOptionToggleRow(
                    title = "✨ Pembersih Ikon Status Bar (Anti Burn-In Layar AMOLED)",
                    subtitle = "Sembunyikan ikon statis VoLTE/NFC/Alarm/Headset agar status bar rapi & bersih",
                    checked = cleanStatusOn,
                    onToggle = {
                        cleanStatusOn = !cleanStatusOn
                        shizukuManager.saveUiStateBool("sec8_statusbar", cleanStatusOn)
                        onRunRegistryAction("✨ Clean Status Bar [${if (cleanStatusOn) "ON" else "OFF"}]") {
                            shizukuManager.commandRegistry.setStatusBarCleaner(cleanStatusOn)
                        }
                    }
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 4. Smart Cool-Boost & Quad-Combo Quick Access + 6 Classic Manual Modules
    SectionCard(
        title = "⚖️ Smart Cool-Boost & Quad-Combo (${oemBooster?.boosterName ?: "Game Boost"} + ${oemPhoneMaster?.managerName ?: "Phone Master"})",
        isHighlightedActive = smartCoolBoostEnabled || tripleComboEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = smartCoolBoostEnabled,
            activeLabel = "SMART COOL-BOOST AKTIF [ON]",
            inactiveLabel = "SMART COOL-BOOST MATI [OFF]",
            onToggle = { onToggleSmartCoolBoost(!smartCoolBoostEnabled) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = tripleComboEnabled,
            activeLabel = "QUAD-COMBO 4X AKTIF [ON]",
            inactiveLabel = "QUAD-COMBO 4X MATI [OFF]",
            onToggle = { onToggleQuadCombo(!tripleComboEnabled) }
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🔒 Zona Kontrol Manual Cepat (Respon Instan ON/OFF)") {
        ManualModuleRow(
            title = "⚡ 1. CPU Speed Mode & Cached Apps Freezer",
            desc = "Responsivitas frekuensi CPU & bekukan aplikasi pasif di memori cached (WA & IG Aman).",
            isOn = moduleStates["cpu"] == true,
            onTurnOn = {
                onRunSpecs(
                    "cpu",
                    true,
                    "CPU Speed Mode & Freezer [ON]",
                    listOf(
                        SettingSpec("global", "cached_apps_freezer", "enabled", "Cached Apps Freezer", "Bekukan aplikasi pasif"),
                        SettingSpec("global", "activity_manager_constants", "max_cached_processes=24", "Limit Cached Process", "Hemat RAM latar")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "cpu",
                    false,
                    "CPU Speed Mode & Freezer [OFF]",
                    listOf(SettingSpec("global", "cached_apps_freezer", "default", "Reset Cached Freezer", "Standar sistem"))
                )
            }
        )

        ManualModuleRow(
            title = "🎮 2. GPU Zero-Blur & Skala Animasi 0.5x",
            desc = "Matikan efek blur kompositor Android 12–16 dan percepat transisi jendela ke 0.5x.",
            isOn = moduleStates["gpu"] == true,
            onTurnOn = {
                onRunSpecs(
                    "gpu",
                    true,
                    "GPU Zero-Blur & Animasi 0.5x [ON]",
                    listOf(
                        SettingSpec("global", "disable_window_blurs", "1", "Zero-Blur GPU", "Matikan blur kompositor"),
                        SettingSpec("global", "window_animation_scale", "0.5", "Animasi Jendela 0.5x", "Transisi cepat"),
                        SettingSpec("global", "transition_animation_scale", "0.5", "Animasi Transisi 0.5x", "Perpindahan cepat"),
                        SettingSpec("global", "animator_duration_scale", "0.5", "Durasi Animator 0.5x", "Respons cepat")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "gpu",
                    false,
                    "GPU Zero-Blur & Animasi [OFF]",
                    listOf(
                        SettingSpec("global", "disable_window_blurs", "0", "Blur Standar", "Aktifkan kembali blur"),
                        SettingSpec("global", "window_animation_scale", "1.0", "Animasi Standar 1.0x", "Normal"),
                        SettingSpec("global", "transition_animation_scale", "1.0", "Transisi Standar 1.0x", "Normal"),
                        SettingSpec("global", "animator_duration_scale", "1.0", "Animator Standar 1.0x", "Normal")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "🌐 3. Network Low-Latency & Stop Wi-Fi Scan Lag",
            desc = "Kurangi lonjakan ping akibat pemindaian Wi-Fi/BLE di latar belakang saat main game.",
            isOn = moduleStates["net"] == true,
            onTurnOn = {
                onRunSpecs(
                    "net",
                    true,
                    "Network Low-Latency [ON]",
                    listOf(
                        SettingSpec("global", "wifi_scan_throttle_enabled", "0", "Stop Wi-Fi Scan Lag", "Stabilkan ping"),
                        SettingSpec("global", "ble_scan_always_enabled", "0", "Stop BLE Scan Latar", "Kurangi interferensi")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "net",
                    false,
                    "Network Low-Latency [OFF]",
                    listOf(SettingSpec("global", "wifi_scan_throttle_enabled", "1", "Wi-Fi Scan Standar", "Standar"))
                )
            }
        )

        ManualModuleRow(
            title = "👆 4. Touch Responsiveness 180ms & Pointer Speed",
            desc = "Pangkas jeda tekan-lama dari 400ms ke 180ms dan tingkatkan kecepatan sentuhan layar.",
            isOn = moduleStates["touch"] == true,
            onTurnOn = {
                onRunSpecs(
                    "touch",
                    true,
                    "Touch Responsiveness 180ms [ON]",
                    listOf(
                        SettingSpec("secure", "long_press_timeout", "180", "Touch Timeout 180ms", "Respons sentuh instan"),
                        SettingSpec("system", "pointer_speed", "5", "Pointer Speed +5", "Kecepatan geser tinggi")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "touch",
                    false,
                    "Touch Responsiveness [OFF]",
                    listOf(
                        SettingSpec("secure", "long_press_timeout", "400", "Touch Timeout 400ms", "Standar pabrik"),
                        SettingSpec("system", "pointer_speed", "0", "Pointer Speed 0", "Standar pabrik")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "⚙️ 5. Target Refresh Rate 120Hz Multi-Brand",
            desc = "Kunci min/peak refresh rate 120Hz (AOSP, Infinix/TECNO XArena, Xiaomi/POCO, Samsung, Realme/OPPO, Vivo).",
            isOn = moduleStates["hz"] == true,
            onTurnOn = {
                onRunSpecs(
                    "hz",
                    true,
                    "Target Refresh Rate 120Hz [ON]",
                    listOf(
                        SettingSpec("system", "min_refresh_rate", "120.0", "Min Refresh Rate 120Hz", "Kunci bawah 120Hz"),
                        SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate 120Hz", "Kunci atas 120Hz"),
                        SettingSpec("system", "tran_refresh_mode", "120", "Infinix/TECNO 120Hz", "Mode 120Hz"),
                        SettingSpec("system", "user_refresh_rate", "120", "Xiaomi/HyperOS 120Hz", "Mode 120Hz")
                    )
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "hz",
                    false,
                    "Target Refresh Rate 60Hz Standar [OFF]",
                    listOf(
                        SettingSpec("system", "min_refresh_rate", "60.0", "Min Refresh Rate 60Hz", "Adaptif 60Hz"),
                        SettingSpec("system", "peak_refresh_rate", "120.0", "Peak Refresh Rate Adaptif", "Adaptif")
                    )
                )
            }
        )

        ManualModuleRow(
            title = "📸 6. Fokus Game Anti Pop-Up (Heads-Up OFF)",
            desc = "Cegah notifikasi mengambang menutupi layar saat bertanding game kompetitif.",
            isOn = moduleStates["focus"] == true,
            onTurnOn = {
                onRunSpecs(
                    "focus",
                    true,
                    "Fokus Game Anti Pop-Up [ON]",
                    listOf(SettingSpec("global", "heads_up_notifications_enabled", "0", "Blokir Pop-Up Mengambang", "Fokus penuh"))
                )
            },
            onTurnOff = {
                onRunSpecs(
                    "focus",
                    false,
                    "Fokus Game Anti Pop-Up [OFF]",
                    listOf(SettingSpec("global", "heads_up_notifications_enabled", "1", "Notifikasi Pop-Up Normal", "Standar"))
                )
            }
        )
    }
}

@Composable
private fun GamingCenterPane(
    telemetry: DeviceTelemetry?,
    tripleComboEnabled: Boolean,
    autoSwitchServiceOn: Boolean,
    floatingHudOn: Boolean,
    shizukuManager: ShizukuBridgeManager,
    onToggleQuadCombo: (Boolean, String?) -> Unit,
    onOpenOemBooster: () -> Unit,
    onOpenOemPhoneMaster: () -> Unit,
    onToggleAutoSwitch: (Boolean) -> Unit,
    onToggleFloatingHud: (Boolean) -> Unit,
    onApplyDownscaleSlider: (String, Float) -> Unit,
    onCompileGameArt: (String, String) -> Unit,
    onCleanShaderAndTrim: (String) -> Unit,
    onDailyBoost: (Boolean) -> Unit,
    onApplyGamingMode: (String, String, String, Boolean) -> Unit,
    onApplyEsportsGraphics: (String, Boolean, Boolean, Boolean, Boolean, Boolean) -> Unit
) {
    val games = telemetry?.detectedGames ?: emptyList()
    val firstInstalled = games.firstOrNull { it.isInstalled } ?: games.firstOrNull()
    var selectedGamePkg by remember(firstInstalled?.packageName) {
        mutableStateOf(
            shizukuManager.loadUiStateString(
                "selected_game_pkg",
                firstInstalled?.packageName ?: "com.mobile.legends"
            )
        )
    }
    var selectedGameName by remember(firstInstalled?.appName) {
        mutableStateOf(
            shizukuManager.loadUiStateString(
                "selected_game_name",
                firstInstalled?.appName ?: "Mobile Legends: Bang Bang"
            )
        )
    }
    var downscaleRatio by remember(selectedGamePkg) {
        mutableStateOf(shizukuManager.loadUiStateFloat("downscale_$selectedGamePkg", 0.85f))
    }

    var perfMode by remember { mutableStateOf(shizukuManager.loadUiStateString("esports_perf_mode", "esport_ultimate")) }
    var anisotropicOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("esports_anisotropic", true)) }
    var textureFilterOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("esports_texture_filter", true)) }
    var mipmapLodOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("esports_mipmap_lod", true)) }
    var frameStabilizerOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("esports_frame_stab", true)) }
    var dualChannelNetOn by remember { mutableStateOf(shizukuManager.loadUiStateBool("esports_dual_net", true)) }

    MenuGuideBanner(
        title = "Panduan Menu 04: Quad-Combo (Game Boost + Phone Master), Auto-Switch & Floating HUD FPS",
        guideText = "Kini menggabungkan 4 mesin sekaligus (AETHERIA + Game Boost HP + Phone Master Bawaan Semua HP + Shizuku/Brevent), ditambah Auto-Switch Game otomatis, Floating HUD FPS + Crosshair Aim, Slider Resolusi Game, dan ART Compiler!"
    )

    QuadComboOemCard(
        oemBooster = telemetry?.oemGameBooster,
        oemPhoneMaster = telemetry?.oemPhoneMaster,
        quadComboEnabled = tripleComboEnabled,
        onToggleQuadCombo = { enable -> onToggleQuadCombo(enable, selectedGamePkg) },
        onOpenOemBooster = onOpenOemBooster,
        onOpenOemPhoneMaster = onOpenOemPhoneMaster
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Auto-Switch Background Service & Floating Gaming HUD + Crosshair Card
    SectionCard(
        title = "🤖 Otomasi Game Background & 🎯 3D Floating HUD (FPS · Suhu · Crosshair)",
        isHighlightedActive = autoSwitchServiceOn || floatingHudOn
    ) {
        ClearStatusSwitchBanner(
            isOn = autoSwitchServiceOn,
            activeLabel = "AUTO-SWITCH GAME OTOMATIS: AKTIF [ON]",
            inactiveLabel = "AUTO-SWITCH GAME OTOMATIS: MATI [OFF]",
            onToggle = { onToggleAutoSwitch(!autoSwitchServiceOn) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        ClearStatusSwitchBanner(
            isOn = floatingHudOn,
            activeLabel = "3D FLOATING HUD FPS + CROSSHAIR AIM: AKTIF [ON]",
            inactiveLabel = "3D FLOATING HUD FPS + CROSSHAIR AIM: MATI [OFF]",
            onToggle = { onToggleFloatingHud(!floatingHudOn) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "• Auto-Switch otomatis mengaktifkan Mode Gaming Maksimal begitu Anda membuka game, dan kembali ke Daily Smooth saat keluar ke Home.\n" +
                "• Floating HUD melayang di atas layar game menampilkan FPS nyata, ms, Suhu °C, tombol ⚡Boost RAM (WA/IG aman), dan tombol 🎯Aim Crosshair!",
            color = TextSecondary,
            fontSize = 11.sp
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    val installedCount = games.count { it.isInstalled }
    SectionCard(title = "🎯 Pilih Game Target & Slider Resolusi / ART Compiler ($installedCount Terpasang)") {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            games.forEach { game ->
                val isSelected = (game.packageName == selectedGamePkg)
                Box(
                    modifier = Modifier
                        .shadow(if (isSelected) 8.dp else 3.dp, RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            when {
                                isSelected -> Brush.verticalGradient(listOf(SovereignGold.copy(alpha = 0.30f), Color(0xFF1A1405)))
                                game.isInstalled -> Brush.verticalGradient(listOf(QuantumEmerald.copy(alpha = 0.18f), CardInnerBottom))
                                else -> Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
                            }
                        )
                        .border(
                            width = if (isSelected) 1.6.dp else 1.dp,
                            color = when {
                                isSelected -> SovereignGold
                                game.isInstalled -> QuantumEmerald
                                else -> IceCyan.copy(alpha = 0.25f)
                            },
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            selectedGamePkg = game.packageName
                            selectedGameName = game.appName
                            shizukuManager.saveUiStateString("selected_game_pkg", game.packageName)
                            shizukuManager.saveUiStateString("selected_game_name", game.appName)
                        }
                        .padding(horizontal = 13.dp, vertical = 9.dp)
                ) {
                    Column {
                        Text(
                            text = "${if (game.isInstalled) "🟢 " else "🎮 "}${game.appName}",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Text(
                            text = "${game.packageName} · ${game.categoryLabel}",
                            color = if (game.isInstalled) QuantumEmerald else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "🎯 Target: $selectedGameName ($selectedGamePkg)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(8.dp))
        val ratioFormatted = String.format(Locale.US, "%.2f", downscaleRatio)
        Text(
            text = "📐 Adaptive Game Downscaling: ${ratioFormatted}x (${if (downscaleRatio >= 0.99f) "Resolusi Native Penuh" else "FPS Naik & Suhu Dingin"})",
            color = IceCyan,
            fontWeight = FontWeight.Bold,
            fontSize = 11.5.sp
        )
        Slider(
            value = downscaleRatio,
            onValueChange = { downscaleRatio = (kotlin.math.round(it * 20f) / 20f).coerceIn(0.50f, 1.00f) },
            valueRange = 0.50f..1.00f,
            steps = 9
        )
        Tactile3dPushButton(
            text = "📐 Terapkan Resolusi ${ratioFormatted}x ke $selectedGameName",
            onClick = {
                shizukuManager.saveUiStateFloat("downscale_$selectedGamePkg", downscaleRatio)
                onApplyDownscaleSlider(selectedGamePkg, downscaleRatio)
            },
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep,
            textColor = Color(0xFF02131C)
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text("🚀 Ahead-Of-Time ART Compiler & Shader Cache Cleaner:", color = QuantumEmerald, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Tactile3dPushButton(
                text = "⚡ Speed-Profile",
                onClick = { onCompileGameArt(selectedGamePkg, "speed-profile") },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                fontSizeSp = 9.5f
            )
            Tactile3dPushButton(
                text = "🚀 Full Speed",
                onClick = { onCompileGameArt(selectedGamePkg, "speed") },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep,
                fontSizeSp = 9.5f
            )
            Tactile3dPushButton(
                text = "🧹 Shader+TRIM",
                onClick = { onCleanShaderAndTrim(selectedGamePkg) },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                fontSizeSp = 9.5f
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "🔥 Quad-Combo Game Ini",
                onClick = { onToggleQuadCombo(true, selectedGamePkg) },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
            Tactile3dPushButton(
                text = "🚀 Combo & Buka Game",
                onClick = {
                    onToggleQuadCombo(true, selectedGamePkg)
                    onApplyGamingMode(selectedGamePkg, selectedGameName, "esports_pro", true)
                },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🏆 E-Sports Ultimate Pro & Vulkan SkiaVK Suite") {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "⚡ Kinerja",
                selected = perfMode == "kinerja",
                onClick = { perfMode = "kinerja"; shizukuManager.saveUiStateString("esports_perf_mode", "kinerja") }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🎯 Kontrol",
                selected = perfMode == "kontrol",
                onClick = { perfMode = "kontrol"; shizukuManager.saveUiStateString("esports_perf_mode", "kontrol") }
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🎨 Kualitas Grafik",
                selected = perfMode == "kualitas_grafik",
                onClick = { perfMode = "kualitas_grafik"; shizukuManager.saveUiStateString("esports_perf_mode", "kualitas_grafik") }
            )
            SelectableChipButton(
                modifier = Modifier.weight(1f),
                title = "🏆 E-Sports Pro",
                selected = perfMode == "esport_ultimate",
                onClick = { perfMode = "esport_ultimate"; shizukuManager.saveUiStateString("esports_perf_mode", "esport_ultimate") }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        GraphicOptionToggleRow(
            title = "Penyaring Anisotropik (Anisotropic Filtering 16x)",
            subtitle = "Pertajam tekstur tanah & objek miring di kejauhan tanpa drop FPS",
            checked = anisotropicOn,
            onToggle = { anisotropicOn = !anisotropicOn; shizukuManager.saveUiStateBool("esports_anisotropic", anisotropicOn) }
        )
        GraphicOptionToggleRow(
            title = "Filter Tekstur (Texture Filtering SkiaVK Pro)",
            subtitle = "Optimalkan sampling tekstur GPU agar gambar jernih",
            checked = textureFilterOn,
            onToggle = { textureFilterOn = !textureFilterOn; shizukuManager.saveUiStateBool("esports_texture_filter", textureFilterOn) }
        )
        GraphicOptionToggleRow(
            title = "Offset Mipmap LOD (Level of Detail Calibration)",
            subtitle = "Seimbangkan ketajaman objek jarak jauh & efisiensi memori VRAM",
            checked = mipmapLodOn,
            onToggle = { mipmapLodOn = !mipmapLodOn; shizukuManager.saveUiStateBool("esports_mipmap_lod", mipmapLodOn) }
        )
        GraphicOptionToggleRow(
            title = "Penstabilan Bingkai (Frame Rate Stabilizer 120Hz)",
            subtitle = "Kunci pacing bingkai SurfaceFlinger agar FPS tidak drop saat war",
            checked = frameStabilizerOn,
            onToggle = { frameStabilizerOn = !frameStabilizerOn; shizukuManager.saveUiStateBool("esports_frame_stab", frameStabilizerOn) }
        )
        GraphicOptionToggleRow(
            title = "Akselerasi Saluran Ganda & Low-Latency Wi-Fi Lock",
            subtitle = "Gabungkan kesiagaan Wi-Fi + Data Seluler & kunci chip Wi-Fi anti-lag",
            checked = dualChannelNetOn,
            onToggle = { dualChannelNetOn = !dualChannelNetOn; shizukuManager.saveUiStateBool("esports_dual_net", dualChannelNetOn) }
        )

        Spacer(modifier = Modifier.height(10.dp))
        Tactile3dPushButton(
            text = "🏆 Terapkan E-Sports Ultimate Pro + Vulkan SkiaVK",
            onClick = {
                onApplyEsportsGraphics(perfMode, anisotropicOn, textureFilterOn, mipmapLodOn, frameStabilizerOn, dualChannelNetOn)
            },
            modifier = Modifier.fillMaxWidth(),
            faceColor = SovereignGold,
            deepBaseColor = SovereignGoldDeep
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "📱 Booster Kelancaran Harian & Sosmed (SystemUI + TikTok, IG, WA, YT)") {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "⚡ Boost TikTok/WA/IG",
                onClick = { onDailyBoost(false) },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
            Tactile3dPushButton(
                text = "🔥 Full System Dexopt",
                onClick = { onDailyBoost(true) },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
        }
    }
}

@Composable
private fun DualBridgeCenterPane(
    diag: ShizukuDiagnostics,
    shizukuManager: ShizukuBridgeManager,
    onOpenWizard: () -> Unit,
    onRefresh: () -> Unit,
    onRequestPermission: () -> Unit
) {
    var copiedBrevent by remember { mutableStateOf(false) }

    MenuGuideBanner(
        title = "Panduan Menu 05: Dual-Jalur ADB Shell (Jalur 1 Shizuku + Jalur 2 Brevent 1-Klik)",
        guideText = "Solusi tuntas jika di HP teman Shizuku gagal nyambung! Di v30.0 Anda bebas memakai JALUR 1 (Shizuku) ATAU JALUR 2 (Brevent / LADB / Qute). Begitu salah satu tersambung, AETHERIA otomatis mengunci izin WRITE_SECURE_SETTINGS agar tetap jalan walau Wi-Fi dimatikan!"
    )

    SectionCard(
        title = "🔗 Status Dual-Jalur Saat Ini: ${diag.activeBridgeMode.badgeLabel}",
        isHighlightedActive = diag.isReady
    ) {
        Text("• Jalur 1 (Shizuku): ${if (diag.isShizukuReady) "🟢 TERHUBUNG PENUH (UID ${diag.uid})" else "${diag.state.displayTitle} (Terpasang: ${if (diag.shizukuAppInstalled) "Ya" else "Tidak"})"}", color = if (diag.isShizukuReady) QuantumEmerald else TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("• Jalur 2 (Brevent Worker UID 2000): ${if (diag.breventBridgeActive) "🟣 AKTIF PENUH (UID 2000)" else "Siaga (Aplikasi Brevent/LADB: ${if (diag.breventAppInstalled) "Terpasang" else "Belum Terpasang"})"}", color = if (diag.breventBridgeActive) CyberViolet else TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("• Izin Permanen WRITE_SECURE_SETTINGS: ${if (diag.writeSecureSettingsGranted) "🔵 AKTIF (Bisa Tulis Pengaturan Sistem Tanpa Wi-Fi!)" else "Otomatis aktif begitu Shizuku atau Brevent tersambung 1x"}", color = IceCyan, fontSize = 11.5.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text(diag.diagnosticMessage, color = SovereignGold, fontSize = 11.5.sp)

        Spacer(modifier = Modifier.height(10.dp))
        Tactile3dPushButton(
            text = "📘 Buka Panduan Interaktif Step-by-Step (Shizuku & Brevent)",
            onClick = onOpenWizard,
            modifier = Modifier.fillMaxWidth(),
            faceColor = SovereignGold,
            deepBaseColor = SovereignGoldDeep
        )

        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "↻ Cek Ulang Koneksi",
                onClick = onRefresh,
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
            Tactile3dPushButton(
                text = if (diag.binderAlive && !diag.permissionGranted) "🔑 Minta Izin Shizuku" else "🚀 Buka Shizuku",
                onClick = {
                    if (diag.binderAlive && !diag.permissionGranted) onRequestPermission()
                    else shizukuManager.openShizukuOrPlayStore()
                },
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Dedicated Brevent 1-Click Card
    SectionCard(
        title = "🟣 JALUR 2: BREVENT BRIDGE 1-KLIK (SOLUSI AMPUH JIKA SHIZUKU GAGAL)",
        isHighlightedActive = diag.breventBridgeActive
    ) {
        Text(
            text = "Jika Shizuku di HP teman terus berputar atau menolak tersambung, cukup buka aplikasi Brevent -> ketuk menu garis tiga (≡) -> pilih 'Exec Command' -> tempel kode 1 baris di bawah:",
            color = TextSecondary,
            fontSize = 11.2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF040914))
                .border(1.dp, CyberViolet, RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Text(
                text = shizukuManager.getBreventActivationCommand(),
                color = QuantumEmerald,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.5.sp
            )
        }
        if (copiedBrevent) {
            Spacer(modifier = Modifier.height(6.dp))
            Text("✅ Kode Brevent tersalin! Tempel di Brevent -> Exec Command.", color = QuantumEmerald, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = "📋 Salin & Buka Brevent",
                onClick = {
                    copiedBrevent = true
                    shizukuManager.copyBreventCommandAndOpenApp(openAppAfterCopy = true)
                },
                modifier = Modifier.weight(1.2f),
                faceColor = CyberViolet,
                deepBaseColor = CyberVioletDeep,
                textColor = Color.White
            )
            Tactile3dPushButton(
                text = "⚙️ Opsi Pengembang",
                onClick = { shizukuManager.openDeveloperOptions() },
                modifier = Modifier.weight(0.9f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
        }
    }
}

@Composable
private fun StorageDebloatSecurityPane(
    telemetry: DeviceTelemetry?,
    quadComboActive: Boolean,
    adblockShieldEnabled: Boolean,
    adSdkBlockerEnabled: Boolean,
    shizukuManager: ShizukuBridgeManager,
    onFixMobileDataDns: () -> Unit,
    onScanAndPurgeMalware: (Boolean) -> Unit,
    onConfigureAdblockJudol: (String, Boolean) -> Unit,
    onToggleAdSdkBlocker: (Boolean) -> Unit,
    onRecordResult: (String, List<VerificationRecord>) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var debloatItems by remember { mutableStateOf<List<DebloatPackageItem>>(emptyList()) }
    var showOnlyInstalled by remember { mutableStateOf(true) }
    var apkPathInput by remember { mutableStateOf("/sdcard/Download/") }

    LaunchedEffect(quadComboActive) {
        debloatItems = OemDebloatDatabase.scanInstalledPackages(context.packageManager, quadComboActive)
    }

    MenuGuideBanner(
        title = "Panduan Menu 06: Multi-OEM Safe Debloater, Ad-SDK Blocker, Malware & Power Installer",
        guideText = "Dilengkapi Pemutus Iklan Tanam (Ad-SDK), Multi-OEM Debloater dengan 1-Click Restore, Perbaikan Kuota Data 4G/5G, serta Power APK Installer. WhatsApp & Instagram dikunci IMMORTAL sehingga mustahil terbekukan!"
    )

    // 1. Mobile Data Kuota Repair
    SectionCard(title = "📶 Solusi Cepat: Perbaiki Internet Data Seluler (Kuota 4G/5G)") {
        Text(
            text = "Status DNS Saat Ini: ${telemetry?.privateDnsModeCurrent ?: "opportunistic"} · ${telemetry?.networkTransportLabel ?: "Hybrid"}\n" +
                "Melepas kunci DNS Port 853 agar internet Kuota Data Seluler maupun Wi-Fi langsung lancar kembali:",
            color = TextSecondary,
            fontSize = 11.2.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "📶 Perbaiki Internet Data Seluler Sekarang (Kuota & Wi-Fi Lancar)",
            onClick = onFixMobileDataDns,
            modifier = Modifier.fillMaxWidth(),
            faceColor = QuantumEmerald,
            deepBaseColor = QuantumEmeraldDeep
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 2. OEM AdBlock + In-App Ad-SDK Component Blocker + Malware Scanner
    SectionCard(
        title = "🚫 Blokir Iklan OEM, Pemutus Ad-SDK Tanam & Anti-Malware Auto-Purge",
        isHighlightedActive = adblockShieldEnabled || adSdkBlockerEnabled
    ) {
        ClearStatusSwitchBanner(
            isOn = adblockShieldEnabled,
            activeLabel = "BLOKIR IKLAN OEM (AMAN KUOTA): AKTIF [ON]",
            inactiveLabel = "BLOKIR IKLAN OEM: MATI [OFF]",
            onToggle = {
                if (adblockShieldEnabled) onConfigureAdblockJudol("off", false)
                else onConfigureAdblockJudol("adguard_family", true)
            }
        )
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = adSdkBlockerEnabled,
            activeLabel = "PEMUTUS KOMPONEN IKLAN TANAM (AD-SDK): AKTIF [ON]",
            inactiveLabel = "PEMUTUS KOMPONEN IKLAN TANAM (AD-SDK): MATI [OFF]",
            onToggle = { onToggleAdSdkBlocker(!adSdkBlockerEnabled) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "🔍 Pindai Header Biner (PK\\x03\\x04) & Hapus APK Penipuan / Undangan",
            onClick = { onScanAndPurgeMalware(true) },
            modifier = Modifier.fillMaxWidth(),
            faceColor = SovereignGold,
            deepBaseColor = SovereignGoldDeep
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 3. Categorized Multi-OEM Debloater with Immortal WA/IG Protection & 1-Click Restore
    val installedBloatCount = debloatItems.count { it.isInstalled }
    val frozenCount = debloatItems.count { it.isInstalled && it.isDisabled }
    SectionCard(title = "❄️ Multi-OEM Safe Debloater ($installedBloatCount Terdeteksi · $frozenCount Dibekukan)") {
        Text(
            text = "🛡️ PERISAI IMMORTAL AKTIF: WhatsApp, WA Business & Instagram dikunci permanen dan TIDAK ADA di daftar beku. Aplikasi Phone Master juga otomatis dilindungi saat Quad-Combo aktif!",
            color = QuantumEmerald,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = if (showOnlyInstalled) "👁️ Tampil: Ada di HP ($installedBloatCount)" else "👁️ Tampil: Semua (${debloatItems.size})",
                onClick = { showOnlyInstalled = !showOnlyInstalled },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep,
                fontSizeSp = 9.8f
            )
            Tactile3dPushButton(
                text = "↩️ Pulihkan Semua ($frozenCount)",
                onClick = {
                    scope.launch {
                        val res = shizukuManager.commandRegistry.restoreAllDebloatedPackages(debloatItems)
                        debloatItems = OemDebloatDatabase.scanInstalledPackages(context.packageManager, quadComboActive)
                        onRecordResult("↩️ 1-Click Restore Seluruh Bloatware", res)
                    }
                },
                modifier = Modifier.weight(1f),
                faceColor = SovereignGold,
                deepBaseColor = SovereignGoldDeep,
                fontSizeSp = 9.8f
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        val displayedList = if (showOnlyInstalled) {
            debloatItems.filter { it.isInstalled }.ifEmpty { debloatItems.take(8) }
        } else {
            debloatItems
        }

        displayedList.forEach { item ->
            val riskColor = if (item.riskLevel == DebloatRiskLevel.SAFE) QuantumEmerald else SovereignGold
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                    .border(1.dp, riskColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${item.appName} ${if (item.isDisabled) "[❄️ BEKU]" else if (item.isInstalled) "[🟢 AKTIF]" else "[⚪ TIDAK ADA]"}",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                        Text(
                            text = "${item.packageName} · ${item.category}",
                            color = riskColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp
                        )
                    }
                    if (item.isInstalled) {
                        Spacer(modifier = Modifier.width(8.dp))
                        if (item.isProtectedByCombo) {
                            StatusBadge(text = "🔥 COMBO SAFE", color = SovereignGold)
                        } else {
                            Tactile3dPushButton(
                                text = if (item.isDisabled) "↩️ Pulihkan" else "❄️ Bekukan",
                                onClick = {
                                    scope.launch {
                                        val enableNext = item.isDisabled
                                        val res = shizukuManager.commandRegistry.setSystemAppEnabled(item.packageName, enableNext)
                                        debloatItems = OemDebloatDatabase.scanInstalledPackages(context.packageManager, quadComboActive)
                                        onRecordResult("${if (enableNext) "Pulihkan" else "Bekukan"} ${item.appName}", res)
                                    }
                                },
                                faceColor = if (item.isDisabled) QuantumEmerald else AlertRose,
                                deepBaseColor = if (item.isDisabled) QuantumEmeraldDeep else AlertRoseDeep,
                                textColor = if (item.isDisabled) Color(0xFF021A10) else Color.White,
                                fontSizeSp = 9.8f
                            )
                        }
                    }
                }
                Text(text = item.description, color = TextSecondary, fontSize = 10.2.sp)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Tactile3dPushButton(
            text = "📋 Salin Database Debloat JSON ke Clipboard",
            onClick = {
                runCatching {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("AetheriaDebloatJson", OemDebloatDatabase.exportDatabaseToJson()))
                }
            },
            modifier = Modifier.fillMaxWidth(),
            faceColor = IceCyan,
            deepBaseColor = IceCyanDeep,
            fontSizeSp = 10f
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 4. Power APK Installer
    SectionCard(title = "📦 Power APK Installer (Izinkan Downgrade -d & Bypass Blokir Android 14–16)") {
        Text(
            text = "Masukkan lokasi file .apk di penyimpanan HP (contoh: /sdcard/Download/game_lama.apk) untuk menginstal dengan atribusi Play Store & bypass blokir TargetSDK rendah:",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF040914))
                .border(1.2.dp, IceCyan, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            BasicTextField(
                value = apkPathInput,
                onValueChange = { apkPathInput = it },
                singleLine = true,
                cursorBrush = SolidColor(IceCyan),
                textStyle = TextStyle(
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "📦 Jalankan Power APK Installer Sekarang",
            onClick = {
                scope.launch {
                    val res = shizukuManager.commandRegistry.executePowerApkInstaller(apkPathInput)
                    onRecordResult("📦 Power APK Installer", res)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            faceColor = SovereignGold,
            deepBaseColor = SovereignGoldDeep
        )
    }
}

@Composable
private fun ProfilesWhitelistBootPane(
    activeProfile: SystemProfile,
    autoResetOnReboot: Boolean,
    overnightMaintOn: Boolean,
    shizukuManager: ShizukuBridgeManager,
    onToggleAutoResetOnReboot: (Boolean) -> Unit,
    onToggleOvernightMaint: (Boolean) -> Unit,
    onSelectProfile: (SystemProfile) -> Unit
) {
    var whitelistSet by remember { mutableStateOf(shizukuManager.getWhitelistedPackages()) }
    val bootIdPreview = remember { shizukuManager.readKernelBootId().take(18).ifBlank { "Kernel-Boot-Active" } }

    MenuGuideBanner(
        title = "Panduan Menu 07: Auto-Reset Saat HP Restart, Perisai Immortal WA/IG & Profil Sistem",
        guideText = "Memenuhi permintaan Anda 100%: Semua tweaks tetap menyala saat AETHERIA dihapus dari Recent Apps, NAMUN begitu HP di-restart atau dimatikan, Kernel Boot-ID Detector otomatis mengembalikan seluruh tweaks & tombol ke Standar Pabrik!"
    )

    // 1. Kernel Reboot Auto-Reset Guard Card
    SectionCard(
        title = "🔄 Kernel Reboot & Power-Off Auto-Reset Guard (Boot ID: $bootIdPreview)",
        isHighlightedActive = autoResetOnReboot
    ) {
        ClearStatusSwitchBanner(
            isOn = autoResetOnReboot,
            activeLabel = "OTOMATIS KEMBALI DEFAULT SAAT HP RESTART: AKTIF [ON]",
            inactiveLabel = "PERTAHANKAN TWEAKS SETELAH HP RESTART [OFF]",
            onToggle = { onToggleAutoResetOnReboot(!autoResetOnReboot) }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "• Saat sakelar ini ON (Rekomendasi Utama): Menghapus AETHERIA dari Recent Apps TIDAK akan mematikan tweaks, tetapi jika HP di-restart atau mati daya, seluruh pengaturan sistem (animasi, refresh rate, DPI, blur, tombol UI) langsung dikembalikan bersih ke Standar Pabrik!\n" +
                "• Dilengkapi juga Overnight Maintenance saat HP di-cas tengah malam:",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        GraphicOptionToggleRow(
            title = "🌙 Overnight Idle Auto-Maintenance (Jam 01:00–04:00 Saat Cas)",
            subtitle = "Jalankan bg-dexopt-job & sm fstrim otomatis semalam sekali saat layar mati & mengisi daya",
            checked = overnightMaintOn,
            onToggle = { onToggleOvernightMaint(!overnightMaintOn) }
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 2. Immortal Whitelist Manager (WhatsApp & Instagram Permanently Locked ON!)
    SectionCard(
        title = "🛡️ Perisai Immortal Whitelist (Khusus WA & IG Wajib Selalu Aktif!)",
        isHighlightedActive = true
    ) {
        Text(
            text = "Aplikasi di bawah ini DIKECUALIKAN dari pembekuan RAM, Deep Doze, Debloater, maupun Firewall Game. Khusus WhatsApp & Instagram dikunci permanen sesuai permintaan Anda:",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        AetheriaIdentity.DEFAULT_WHITELIST_OPTIONS.forEach { (pkg, title) ->
            val isImmortal = OemDebloatDatabase.isImmortalProtected(pkg)
            val isChecked = isImmortal || (pkg in whitelistSet)
            GraphicOptionToggleRow(
                title = if (isImmortal) "🔒 $title" else title,
                subtitle = if (isImmortal) "$pkg — Dikunci Permanen (Tidak pernah di-off-kan di mode apa pun!)" else "$pkg — Ketuk untuk melindungi/melepas dari pembersihan latar",
                checked = isChecked,
                onToggle = {
                    if (!isImmortal) {
                        val next = !isChecked
                        shizukuManager.toggleUserWhitelistPackage(pkg, next)
                        whitelistSet = shizukuManager.getWhitelistedPackages()
                    }
                }
            )
        }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 3. 7 System Profiles
    SectionCard(title = "🔄 7 Profil Karakter Sistem (Aktif: ${activeProfile.id})") {
        SystemProfile.values().forEach { prof ->
            val isSelected = (prof == activeProfile)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .shadow(6.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.verticalGradient(
                            if (isSelected) listOf(Color(0xFF08291E), CardInnerBottom)
                            else listOf(CardInnerBg, CardInnerBottom)
                        )
                    )
                    .border(
                        width = if (isSelected) 1.8.dp else 1.dp,
                        color = if (isSelected) QuantumEmerald else IceCyan.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(13.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(prof.title, color = TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(
                        text = if (isSelected) "● AKTIF [ON]" else "○ SIAGA [OFF]",
                        color = if (isSelected) QuantumEmerald else TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 10.sp
                    )
                }
                Text(prof.subtitle, color = TextSecondary, fontSize = 11.2.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Tactile3dPushButton(
                    text = if (isSelected) "✅ Sedang Aktif: ${prof.id}" else "▶️ Aktifkan ${prof.id}",
                    onClick = { onSelectProfile(prof) },
                    modifier = Modifier.fillMaxWidth(),
                    faceColor = if (isSelected) QuantumEmerald else SovereignGold,
                    deepBaseColor = if (isSelected) QuantumEmeraldDeep else SovereignGoldDeep
                )
            }
        }
    }
}

@Composable
private fun DiagnosticsLogsPane(
    verifications: List<VerificationRecord>,
    auditLog: List<String>
) {
    MenuGuideBanner(
        title = "Panduan Menu 08: Diagnostics & Readback Verification Ledger",
        guideText = "Menampilkan buku besar bukti verifikasi setiap tindakan (Nilai Sebelum -> Target -> Aktual Hasil Pembacaan Ulang) secara transparan dan jujur."
    )
    SectionCard(title = "📋 Riwayat Verifikasi & Log Diagnostik") {
        VerificationListView(verifications = verifications)
        Spacer(modifier = Modifier.height(10.dp))
        auditLog.forEach { ln ->
            Text(ln, color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingsRecoveryQrisPane(
    telemetry: DeviceTelemetry?,
    snapshots: Map<String, String>,
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit,
    onRestore: () -> Unit
) {
    val context = LocalContext.current

    MenuGuideBanner(
        title = "Panduan Menu 09: Cek Update APK, Trik Anti-Blokir WA/Play Protect & QRIS Resmi",
        guideText = "Tempat memeriksa pembaruan APK otomatis (tanpa hapus aplikasi lama), panduan mengatasi peringatan WhatsApp/Play Protect, serta Barcode QRIS Resmi kreator Rangga Winata."
    )

    OtaUpdateCard(
        updateStatus = updateStatus,
        isCheckingUpdate = isCheckingUpdate,
        onCheckUpdate = onCheckUpdate
    )

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🛡️ Cara Akalin Peringatan WhatsApp & Google Play Protect") {
        Text(
            text = "1️⃣ Trik Agar Tidak Muncul 'File ini mungkin berbahaya' di WhatsApp:\n" +
                "• Bagikan menggunakan LINK GitHub Releases / Google Drive, atau kirim file dalam bentuk .zip! Jika dibuka dari Link atau .zip, peringatan WhatsApp 100% hilang.\n\n" +
                "2️⃣ Trik Mengatasi Pop-up Google Play Protect:\n" +
                "• Saat muncul pop-up Play Protect, ketuk tulisan 'Detail lainnya' -> 'Tetap instal'.",
            color = TextPrimary,
            fontSize = 11.5.sp
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    CommunityStatsBannerCard(
        activeUsers = telemetry?.communityActiveUsers ?: 1,
        totalDownloads = telemetry?.communityTotalDownloads ?: 1,
        localOptCount = telemetry?.localOptimizationCount ?: 1,
        installedGamesCount = telemetry?.detectedGames?.count { it.isInstalled } ?: 0,
        onOpenQris = {}
    )

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "👑 Architect & QRIS Apresiasi Resmi — Rangga Winata") {
        Text(
            text = "AETHERIA dibuat dengan niat tulus untuk membantu sesama agar HP kentang maupun flagship bisa lancar dipakai harian & main game. Bagi kawan-kawan yang ingin memberikan apresiasi sukarela, silakan scan QRIS resmi di bawah:",
            color = TextSecondary,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(18.dp))
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White)
                .border(2.5.dp, SovereignGold, RoundedCornerShape(18.dp))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.qris_rangga),
                contentDescription = "QRIS Resmi Rangga Winata (NMID: ID1026619104999)",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 260.dp, max = 420.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "RANGGA WINATA · NMID: ID1026619104999 · A01",
                color = Color(0xFF0A1629),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 11.5.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Menerima GoPay, OVO, DANA, ShopeePay, LinkAja & Seluruh Mobile Banking (QRIS)",
                color = Color(0xFF334155),
                fontSize = 10.5.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text("Merchant: ${AetheriaIdentity.QRIS_MERCHANT}", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text("NMID: ${AetheriaIdentity.QRIS_NMID} · TID: ${AetheriaIdentity.QRIS_TID} · Dicetak oleh: ${AetheriaIdentity.QRIS_PRINTED_BY}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 11.5.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "💬 Gabung Saluran Resmi WhatsApp Rangga Winata",
            onClick = {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AetheriaIdentity.WA_CHANNEL_URL)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Throwable) {
                }
            },
            modifier = Modifier.fillMaxWidth(),
            faceColor = QuantumEmerald,
            deepBaseColor = QuantumEmeraldDeep
        )
    }

    Spacer(modifier = Modifier.height(12.dp))

    SectionCard(title = "🛡️ Restore Point Snapshot (${snapshots.size} Parameter Tersimpan)") {
        if (snapshots.isEmpty()) {
            Text("Belum ada parameter sistem yang diubah pada sesi boot ini.", color = TextSecondary, fontSize = 12.sp)
        } else {
            snapshots.forEach { (k, v) ->
                Text("$k = $v", color = IceCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Tactile3dPushButton(
            text = "🚨 Pulihkan Semua ke Snapshot Asli / Standar Pabrik",
            onClick = onRestore,
            modifier = Modifier.fillMaxWidth(),
            faceColor = AlertRose,
            deepBaseColor = AlertRoseDeep,
            textColor = Color.White
        )
    }
}

// =============================================================================
// REUSABLE 3D EXTRUDED COCKPIT COMPONENTS
// =============================================================================

@Composable
private fun MenuGuideBanner(title: String, guideText: String) {
    Extruded3dConsoleCard(
        modifier = Modifier.padding(bottom = 12.dp),
        accentColor = SovereignGold,
        secondaryAccent = IceCyan,
        cornerRadius = 18.dp,
        lipDepth = 4.dp
    ) {
        Text(
            text = "📘 $title",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = guideText,
            color = TextPrimary,
            fontSize = 11.2.sp
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    isHighlightedActive: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Extruded3dConsoleCard(
        accentColor = IceCyan,
        secondaryAccent = SovereignGold,
        isHighlightedActive = isHighlightedActive
    ) {
        Text(
            text = title,
            color = if (isHighlightedActive) QuantumEmerald else SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 12.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun GaugeCard(
    modifier: Modifier,
    percent: Float,
    centerValue: String,
    unitLabel: String,
    title: String,
    subtitle: String,
    color: Color
) {
    Extruded3dConsoleCard(
        modifier = modifier,
        accentColor = color,
        secondaryAccent = color,
        cornerRadius = 20.dp,
        lipDepth = 5.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularRingGauge(
                percent = percent,
                centerValue = centerValue,
                unitLabel = unitLabel,
                ringColor = color
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = title, color = SovereignGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Text(text = subtitle, color = TextSecondary, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun OtaUpdateCard(
    updateStatus: UpdateCheckResult?,
    isCheckingUpdate: Boolean,
    onCheckUpdate: () -> Unit
) {
    val context = LocalContext.current
    Extruded3dConsoleCard(accentColor = QuantumEmerald, secondaryAccent = SovereignGold) {
        Text(
            text = "🔄 PEMBARUAN APK OTOMATIS (TANPA HAPUS APLIKASI LAMA)",
            color = SovereignGold,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = updateStatus?.statusMessage
                ?: "APK v30.0 menggunakan Sertifikat Kriptografi Permanen RW-14 yang sama. Cukup klik 'Instal / Update' langsung menimpa APK lama tanpa kehilangan data!",
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tactile3dPushButton(
                text = if (isCheckingUpdate) "⏳ Memeriksa..." else "🔄 Cek Update",
                onClick = onCheckUpdate,
                modifier = Modifier.weight(1f),
                faceColor = QuantumEmerald,
                deepBaseColor = QuantumEmeraldDeep
            )
            Tactile3dPushButton(
                text = "📥 Halaman Rilis",
                onClick = {
                    try {
                        val url = updateStatus?.downloadUrl ?: AetheriaIdentity.GITHUB_ACTIONS_URL
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } catch (_: Throwable) {
                    }
                },
                modifier = Modifier.weight(1f),
                faceColor = IceCyan,
                deepBaseColor = IceCyanDeep
            )
        }
    }
}

@Composable
private fun CommunityStatsBannerCard(
    activeUsers: Int,
    totalDownloads: Int,
    localOptCount: Int,
    installedGamesCount: Int,
    onOpenQris: () -> Unit
) {
    Extruded3dConsoleCard(accentColor = IceCyan, secondaryAccent = SovereignGold, cornerRadius = 18.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📊 STATISTIK JUJUR REAL-TIME (GITHUB & HP INI)",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
            Text(
                text = "👑 QRIS →",
                color = QuantumEmerald,
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                modifier = Modifier.clickable { onOpenQris() }
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatMiniBox(modifier = Modifier.weight(1f), value = "$activeUsers", label = "Komunitas", color = QuantumEmerald)
            StatMiniBox(modifier = Modifier.weight(1f), value = "$totalDownloads", label = "Unduhan", color = IceCyan)
            StatMiniBox(modifier = Modifier.weight(1f), value = "$installedGamesCount Game", label = "Di HP Ini", color = SovereignGold)
            StatMiniBox(modifier = Modifier.weight(1f), value = "${localOptCount}x", label = "Boost Aktif", color = CyberViolet)
        }
    }
}

@Composable
private fun StatMiniBox(
    modifier: Modifier,
    value: String,
    label: String,
    color: Color
) {
    Column(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = value, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 12.sp, maxLines = 1)
        Text(text = label, color = TextSecondary, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ClearStatusSwitchBanner(
    isOn: Boolean,
    activeLabel: String = "SEDANG AKTIF [ON]",
    inactiveLabel: String = "MATI / STANDAR [OFF]",
    onToggle: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(if (isOn) QuantumEmeraldDeep else Color(0xFF0A0612))
            .clickable { onToggle() }
            .padding(bottom = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (isOn) Color(0xFF062C1E) else Color(0xFF181124))
                .border(
                    width = 1.5.dp,
                    color = if (isOn) QuantumEmerald else AlertRose.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 12.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isOn) "✅ $activeLabel" else "⭕ $inactiveLabel",
                    color = if (isOn) QuantumEmerald else AlertRose,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp
                )
                Text(
                    text = if (isOn) "Sedang menyala aktif di sistem HP" else "Masih mati (ketuk sakelar 3D untuk menyalakan)",
                    color = TextSecondary,
                    fontSize = 9.8.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(if (isOn) QuantumEmerald else Color(0xFF2B3548))
                    .border(
                        width = 1.5.dp,
                        color = if (isOn) Color.White.copy(alpha = 0.85f) else AlertRose.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(999.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isOn) "● ON" else "OFF ○",
                    color = if (isOn) Color(0xFF021A10) else TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun ClearOnOffButtonRow(
    isOn: Boolean,
    turnOnLabel: String = "▶️ NYALAKAN (ON)",
    activeOnLabel: String = "✅ SEDANG AKTIF (ON)",
    turnOffLabel: String = "📴 MATIKAN (OFF)",
    activeOffLabel: String = "⭕ POSISI MATI (OFF)",
    onTurnOn: () -> Unit,
    onTurnOff: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Tactile3dPushButton(
            text = if (isOn) activeOnLabel else turnOnLabel,
            onClick = onTurnOn,
            modifier = Modifier.weight(1f),
            faceColor = if (isOn) QuantumEmerald else Color(0xFF172D4E),
            deepBaseColor = if (isOn) QuantumEmeraldDeep else Color(0xFF091326),
            textColor = if (isOn) Color(0xFF021A10) else IceCyan,
            fontSizeSp = 10.5f
        )
        Tactile3dPushButton(
            text = if (!isOn) activeOffLabel else turnOffLabel,
            onClick = onTurnOff,
            modifier = Modifier.weight(1f),
            faceColor = if (!isOn) AlertRose else Color(0xFF182236),
            deepBaseColor = if (!isOn) AlertRoseDeep else Color(0xFF090E1A),
            textColor = if (!isOn) Color.White else TextSecondary,
            fontSizeSp = 10.5f
        )
    }
}

@Composable
private fun ManualModuleRow(
    title: String,
    desc: String,
    isOn: Boolean,
    onTurnOn: () -> Unit,
    onTurnOff: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .shadow(8.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    if (isOn) listOf(Color(0xFF0A2922), CardInnerBottom)
                    else listOf(CardInnerBg, CardInnerBottom)
                )
            )
            .border(
                width = if (isOn) 1.8.dp else 1.dp,
                color = if (isOn) QuantumEmerald else IceCyan.copy(alpha = 0.28f),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(12.dp)
    ) {
        Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(6.dp))
        ClearStatusSwitchBanner(
            isOn = isOn,
            activeLabel = "MODUL SEDANG AKTIF [ON]",
            inactiveLabel = "MODUL MATI / SIAGA [OFF]",
            onToggle = { if (isOn) onTurnOff() else onTurnOn() }
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = desc, color = TextSecondary, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(8.dp))
        ClearOnOffButtonRow(
            isOn = isOn,
            turnOnLabel = "▶️ Nyalakan (ON)",
            activeOnLabel = "✅ Sedang ON",
            turnOffLabel = "📴 Matikan (OFF)",
            activeOffLabel = "⭕ Posisi OFF",
            onTurnOn = onTurnOn,
            onTurnOff = onTurnOff
        )
    }
}

@Composable
private fun SelectableChipButton(
    modifier: Modifier,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(if (selected) 6.dp else 2.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) QuantumEmeraldDeep else Color(0xFF050B16))
            .clickable { onClick() }
            .padding(bottom = 2.5.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (selected) Brush.verticalGradient(listOf(Color(0xFF0E382C), CardInnerBottom))
                    else Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom))
                )
                .border(
                    width = if (selected) 1.5.dp else 1.dp,
                    color = if (selected) QuantumEmerald else IceCyan.copy(alpha = 0.28f),
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(vertical = 9.dp, horizontal = 11.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (selected) "✓ $title" else title,
                color = if (selected) QuantumEmerald else TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun GraphicOptionToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.5.dp)
            .shadow(4.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    if (checked) listOf(Color(0xFF08271E), CardInnerBottom)
                    else listOf(CardInnerBg, CardInnerBottom)
                )
            )
            .border(
                width = if (checked) 1.5.dp else 1.dp,
                color = if (checked) QuantumEmerald else AlertRose.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onToggle() }
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            Text(text = subtitle, color = TextSecondary, fontSize = 10.3.sp)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (checked) QuantumEmerald else Color(0xFF2B1624))
                .border(
                    width = 1.dp,
                    color = if (checked) Color.White else AlertRose,
                    shape = RoundedCornerShape(999.dp)
                )
                .padding(horizontal = 11.dp, vertical = 5.dp)
        ) {
            Text(
                text = if (checked) "● ON" else "OFF ○",
                color = if (checked) Color(0xFF031A10) else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
        }
    }
}

@Composable
private fun LiveScriptExecutionConsoleCard(
    summaryText: String,
    isSuccess: Boolean,
    terminalLines: List<String>,
    verifications: List<VerificationRecord>
) {
    Extruded3dConsoleCard(
        accentColor = if (isSuccess) QuantumEmerald else AlertRose,
        secondaryAccent = SovereignGold,
        isHighlightedActive = isSuccess
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "🔴 🟡 🟢  AETHERIA // RW-14 3D LIVE LOG & BUKTI SKRIP",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.5.sp
            )
            Text(
                text = if (isSuccess) "TERVERIFIKASI" else "CEK STATUS",
                color = if (isSuccess) QuantumEmerald else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (isSuccess) QuantumEmerald.copy(alpha = 0.14f)
                    else AlertRose.copy(alpha = 0.16f)
                )
                .border(
                    width = 1.dp,
                    color = if (isSuccess) QuantumEmerald else AlertRose,
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(11.dp)
        ) {
            Text(
                text = summaryText,
                color = if (isSuccess) QuantumEmerald else AlertRose,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.2.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        terminalLines.forEach { line ->
            val lineColor = when {
                line.startsWith("✅") || line.startsWith("✓") || line.startsWith("📶") -> QuantumEmerald
                line.startsWith("❌") -> AlertRose
                line.startsWith("💡") || line.startsWith("🟡") || line.startsWith("🔄") -> SovereignGold
                else -> IceCyan
            }
            Text(text = line, color = lineColor, fontFamily = FontFamily.Monospace, fontSize = 10.8.sp)
        }

        if (verifications.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "🔬 TABEL BUKTI PEMBACAAN ULANG (BEFORE → TARGET → ACTUAL):",
                color = SovereignGold,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 10.8.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            VerificationListView(verifications = verifications)
        }
    }
}

@Composable
private fun VerificationListView(verifications: List<VerificationRecord>) {
    if (verifications.isEmpty()) {
        Text("Belum ada operasi yang diverifikasi pada sesi ini.", color = TextSecondary, fontSize = 12.sp)
        return
    }
    verifications.forEach { v ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.verticalGradient(listOf(CardInnerBg, CardInnerBottom)))
                .border(1.dp, IceCyan.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Text("${v.feature} (${v.parameter}) — ${v.badge}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
            Text("Sebelum: ${v.beforeValue} | Target: ${v.targetValue} | Aktual: ${v.actualValue}", color = SovereignGold, fontFamily = FontFamily.Monospace, fontSize = 10.8.sp)
        }
    }
}

@Composable
private fun StatusBadge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(999.dp))
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.16f))
            .border(1.2.dp, color, RoundedCornerShape(999.dp))
            .padding(horizontal = 11.dp, vertical = 5.dp)
    ) {
        Text(text = text, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 10.sp)
    }
}

@Composable
private fun BottomNavigationDock(
    currentPage: AetheriaPage,
    onSelect: (AetheriaPage) -> Unit
) {
    val dockItems = listOf(
        AetheriaPage.HOME to "❄️ 3D Home",
        AetheriaPage.PERF_LAB to "🧬 8-Sektor",
        AetheriaPage.GAMING to "🔥 Quad-Combo",
        AetheriaPage.SHIZUKU to "🔗 Dual-Jalur",
        AetheriaPage.SETTINGS to "🔄 Update/QR"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(20.dp)
            .background(
                Brush.verticalGradient(listOf(Color(0xFF102042), Color(0xFF040812)))
            )
            .border(
                width = 1.4.dp,
                brush = Brush.horizontalGradient(listOf(SovereignGold.copy(alpha = 0.65f), IceCyan.copy(alpha = 0.65f))),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(vertical = 9.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        dockItems.forEach { (page, label) ->
            val active = (currentPage == page)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (active) SovereignGoldDeep else Color.Transparent)
                    .clickable { onSelect(page) }
                    .padding(bottom = if (active) 2.5.dp else 0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (active) Brush.horizontalGradient(listOf(Color(0xFF282008), Color(0xFF0B2736)))
                            else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .border(
                            width = if (active) 1.2.dp else 0.dp,
                            color = if (active) SovereignGold else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 9.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        color = if (active) SovereignGold else TextSecondary,
                        fontWeight = FontWeight.Black,
                        fontSize = 10.2.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
