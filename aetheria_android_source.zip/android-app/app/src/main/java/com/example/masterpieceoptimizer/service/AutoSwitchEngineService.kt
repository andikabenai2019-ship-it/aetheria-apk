package com.example.masterpieceoptimizer.service

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.masterpieceoptimizer.MainActivity
import com.example.masterpieceoptimizer.core.ActiveProfileMode
import com.example.masterpieceoptimizer.hardware.DeviceSpecs
import com.example.masterpieceoptimizer.hardware.HardwareDetector
import com.example.masterpieceoptimizer.shizuku.ShizukuBridgeManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * AETHERIA AUTO-SWITCH GAME FOREGROUND SERVICE & OVERNIGHT MAINTENANCE DAEMON (v30.0)
 * - Supports BOTH Shizuku (Path 1) AND Brevent Bridge (Path 2)!
 * - Fixes Android 14–16 SecurityException using ContextCompat.RECEIVER_NOT_EXPORTED
 *   and ForegroundServiceType SPECIAL_USE.
 * - Automatically switches to GAMING_MAX on game launch and reverts to Kuota-Safe DAILY_SMOOTH on exit.
 */
class AutoSwitchEngineService : Service() {

    companion object {
        const val CHANNEL_ID = "aetheria_autoswitch_channel_v300"
        const val NOTIFICATION_ID = 1430
        const val ACTION_START = "com.example.masterpieceoptimizer.action.START_AUTOSWITCH"
        const val ACTION_STOP = "com.example.masterpieceoptimizer.action.STOP_AUTOSWITCH"

        private const val POLL_INTERVAL_MS = 2_500L
        private const val EXIT_GAME_GRACE_MS = 6_000L

        fun start(context: Context) {
            val intent = Intent(context, AutoSwitchEngineService::class.java).apply {
                action = ACTION_START
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, AutoSwitchEngineService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching { context.startService(intent) }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null

    private lateinit var gameRepo: GameDetectionRepository
    private lateinit var bridgeManager: ShizukuBridgeManager
    private var cachedSpecs: DeviceSpecs? = null

    private var currentActiveGame: String? = null
    private var currentAppliedProfile: ActiveProfileMode = ActiveProfileMode.NONE
    private var nonGameDetectedSinceMs: Long = 0L
    private var lastOvernightMaintRunMs: Long = 0L

    @Volatile
    private var isScreenInteractive: Boolean = true
    private var receiverRegistered: Boolean = false

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> isScreenInteractive = false
                Intent.ACTION_SCREEN_ON -> isScreenInteractive = true
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        gameRepo = GameDetectionRepository(applicationContext)
        bridgeManager = ShizukuBridgeManager(applicationContext)
        createNotificationChannel()
        registerScreenReceiverSafely()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            gameRepo.setAutoSwitchEnabledPref(false)
            stopMonitoring()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
            return START_NOT_STICKY
        }

        gameRepo.setAutoSwitchEnabledPref(true)
        val initialNotif = buildNotification(
            title = "AETHERIA Auto-Switch Aktif",
            content = "Memantau peluncuran game secara otomatis (Hemat Baterai · Shizuku + Brevent)"
        )
        startForegroundCompat(initialNotif)

        if (monitorJob?.isActive != true) {
            startMonitoringLoop()
        }
        return START_STICKY
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startMonitoringLoop() {
        monitorJob = serviceScope.launch {
            cachedSpecs = runCatching { HardwareDetector.detectSpecs(applicationContext) }.getOrNull()
            ensureUsageStatsPermission()

            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            isScreenInteractive = pm.isInteractive

            while (isActive) {
                if (!isScreenInteractive) {
                    maybeRunOvernightMaintenance()
                    delay(8_000L)
                    continue
                }

                val topPackage = queryCurrentForegroundPackage()
                if (topPackage != null) {
                    handleForegroundTransition(topPackage)
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private suspend fun maybeRunOvernightMaintenance() {
        if (!gameRepo.isOvernightMaintEnabledPref()) return
        val now = System.currentTimeMillis()
        if (now - lastOvernightMaintRunMs < 18L * 3600_000L) return

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour !in 1..4) return

        val batt = runCatching {
            registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()
        val status = batt?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        if (isCharging) {
            lastOvernightMaintRunMs = now
            bridgeManager.commandRegistry.runOvernightIdleMaintenance()
            updateNotification(
                title = "🌙 Overnight Maintenance Selesai",
                content = "Dexopt & FSTRIM penyimpanan selesai dijalankan saat mengisi daya."
            )
        }
    }

    private suspend fun handleForegroundTransition(foregroundPkg: String) {
        if (gameRepo.isTransientOverlay(foregroundPkg)) {
            return
        }

        val isGame = gameRepo.isGamePackage(foregroundPkg)
        if (isGame) {
            nonGameDetectedSinceMs = 0L
            if (currentAppliedProfile != ActiveProfileMode.GAMING_MAX || currentActiveGame != foregroundPkg) {
                currentActiveGame = foregroundPkg
                currentAppliedProfile = ActiveProfileMode.GAMING_MAX
                val specs = cachedSpecs ?: HardwareDetector.detectSpecs(applicationContext)
                bridgeManager.commandRegistry.applyAdaptiveProfile(
                    mode = ActiveProfileMode.GAMING_MAX,
                    specs = specs,
                    targetGamePkg = foregroundPkg
                )
                val appLabel = resolveAppName(foregroundPkg)
                updateNotification(
                    title = "🔥 Mode Gaming Maksimal: $appLabel",
                    content = "Vulkan SkiaVK + Power HAL + Low-Latency Wi-Fi Aktif (WA & IG Aman)"
                )
            }
        } else {
            if (currentAppliedProfile == ActiveProfileMode.GAMING_MAX) {
                val now = System.currentTimeMillis()
                if (nonGameDetectedSinceMs == 0L) {
                    nonGameDetectedSinceMs = now
                } else if (now - nonGameDetectedSinceMs >= EXIT_GAME_GRACE_MS) {
                    val exitedGame = currentActiveGame
                    if (exitedGame != null) {
                        bridgeManager.commandRegistry.setGameDownscale(exitedGame, 1.00f, enablePerfMode = false)
                    }
                    val specs = cachedSpecs ?: HardwareDetector.detectSpecs(applicationContext)
                    bridgeManager.commandRegistry.applyAdaptiveProfile(
                        mode = ActiveProfileMode.DAILY_SMOOTH,
                        specs = specs,
                        targetGamePkg = null
                    )
                    currentActiveGame = null
                    currentAppliedProfile = ActiveProfileMode.DAILY_SMOOTH
                    nonGameDetectedSinceMs = 0L
                    updateNotification(
                        title = "🌿 Mode Harian (Daily Smooth)",
                        content = "Game ditutup — sistem kembali adem, mulus & hemat baterai (Kuota Aman)"
                    )
                }
            }
        }
    }

    private fun queryCurrentForegroundPackage(): String? {
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val endTime = System.currentTimeMillis()
            val startTime = endTime - 10_000L
            val usageEvents = usm.queryEvents(startTime, endTime)
            val event = UsageEvents.Event()
            var latestResumedPkg: String? = null
            var latestTimestamp = 0L

            while (usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED && event.timeStamp >= latestTimestamp) {
                    latestTimestamp = event.timeStamp
                    latestResumedPkg = event.packageName
                }
            }
            latestResumedPkg
        } catch (_: Throwable) {
            null
        }
    }

    private suspend fun ensureUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        if (mode == AppOpsManager.MODE_ALLOWED) return true

        bridgeManager.autoGrantPermissionsViaShellIfPossible()

        val recheck = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return recheck == AppOpsManager.MODE_ALLOWED
    }

    private fun resolveAppName(pkg: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Throwable) {
            pkg.substringAfterLast('.')
        }
    }

    private fun registerScreenReceiverSafely() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(
            this,
            screenStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        receiverRegistered = true
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AETHERIA Auto-Switch Game Engine",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Deteksi otomatis saat game dibuka & ditutup"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, content: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AutoSwitchEngineService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan Auto", pendingStop)
            .build()
    }

    private fun updateNotification(title: String, content: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(title, content))
    }

    private fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
    }

    override fun onDestroy() {
        stopMonitoring()
        serviceScope.cancel()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(screenStateReceiver) }
            receiverRegistered = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
