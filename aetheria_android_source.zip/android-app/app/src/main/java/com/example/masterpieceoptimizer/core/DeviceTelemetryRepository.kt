package com.example.masterpieceoptimizer.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/**
 * AETHERIA NATIVE TELEMETRY REPOSITORY
 * Works 100% natively without Shizuku and optionally probes the Termux Engine on 127.0.0.1:8080.
 */
class DeviceTelemetryRepository(private val context: Context) {

    suspend fun collectTelemetry(shizukuReady: Boolean): DeviceTelemetry = withContext(Dispatchers.IO) {
        // 1. Memory via ActivityManager
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val totalMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(1L)
        val availMb = (memInfo.availMem / (1024L * 1024L)).coerceAtLeast(0L)
        val usedPct = (((totalMb - availMb).toDouble() / totalMb.toDouble()) * 100.0).roundToInt().coerceIn(0, 100)

        // 2. Storage via StatFs
        val statFs = StatFs(Environment.getDataDirectory().path)
        val totalBytes = statFs.blockCountLong * statFs.blockSizeLong
        val freeBytes = statFs.availableBlocksLong * statFs.blockSizeLong
        val totalGb = ((totalBytes.toDouble() / 1073741824.0) * 10.0).roundToInt() / 10.0
        val freeGb = ((freeBytes.toDouble() / 1073741824.0) * 10.0).roundToInt() / 10.0
        val storPct = if (totalBytes > 0) {
            (((totalBytes - freeBytes).toDouble() / totalBytes.toDouble()) * 100.0).roundToInt().coerceIn(0, 100)
        } else 0

        // 3. Battery & Thermal via Sticky Broadcast
        val battIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val battPct = if (level >= 0 && scale > 0) ((level * 100f) / scale).roundToInt() else 0
        val tempTenths = battIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350) ?: 350
        val tempC = (tempTenths / 10.0)
        val voltageMv = battIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val status = battIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        // 4. Display Refresh Rate via DisplayManager
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val currentHz = display?.refreshRate ?: 60f
        val supportedHz = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && display != null) {
            display.supportedModes.map { it.refreshRate.roundToInt() }.distinct().sorted()
        } else {
            listOf(currentHz.roundToInt())
        }

        // 5. Sensors via SensorManager
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensors = sm.getSensorList(Sensor.TYPE_ALL).take(12).map { it.name }

        // 6. CPU Frequency via sysfs
        val cpuMhz = readCpuScalingMhz()

        // 7. Termux Localhost Engine Probe
        val termuxAlive = probeTermuxEngine()

        DeviceTelemetry(
            brand = Build.MANUFACTURER ?: Build.BRAND ?: "Android",
            model = Build.MODEL ?: "Smartphone",
            androidRelease = Build.VERSION.RELEASE ?: "14",
            sdkInt = Build.VERSION.SDK_INT,
            socHardware = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Build.SOC_MODEL.takeIf { it.isNotBlank() && it != Build.UNKNOWN } ?: Build.HARDWARE
            } else {
                Build.HARDWARE ?: Build.BOARD
            },
            cpuCores = Runtime.getRuntime().availableProcessors(),
            cpuCurrentMhz = cpuMhz,
            ramTotalMb = totalMb,
            ramAvailMb = availMb,
            ramUsedPercent = usedPct,
            storageTotalGb = totalGb,
            storageFreeGb = freeGb,
            storageUsedPercent = storPct,
            batteryPercent = battPct,
            batteryTempC = tempC,
            batteryVoltageMv = voltageMv,
            isCharging = isCharging,
            currentRefreshRateHz = currentHz,
            supportedRefreshRatesHz = supportedHz,
            sensorNames = sensors,
            termuxEngineConnected = termuxAlive
        )
    }

    fun buildCapabilityMatrix(shizukuReady: Boolean): List<FeatureCapability> {
        return listOf(
            FeatureCapability(
                id = "native_telemetry",
                title = "Inspeksi RAM, Storage, Baterai, Sensor & Refresh Rate Aktif",
                tier = CapabilityTier.NATIVE,
                available = true,
                reason = "Menggunakan ActivityManager, StatFs, BatteryManager, dan DisplayManager secara native."
            ),
            FeatureCapability(
                id = "native_apk_scanner",
                title = "Pemindai Anti-Malware Header Biner (PK\\x03\\x04)",
                tier = CapabilityTier.NATIVE,
                available = true,
                reason = "Memeriksa header file secara lokal untuk mendeteksi APK yang menyamar."
            ),
            FeatureCapability(
                id = "shizuku_display_hz",
                title = "Penguncian Min/Peak Refresh Rate (60Hz / 90Hz / 120Hz)",
                tier = CapabilityTier.SHIZUKU_REQUIRED,
                available = shizukuReady,
                reason = if (shizukuReady) "Siap dijalankan melalui Shizuku (uid=2000)."
                else "Membutuhkan layanan & izin Shizuku untuk mengubah system.min_refresh_rate."
            ),
            FeatureCapability(
                id = "shizuku_gpu_blur",
                title = "Optimasi GPU Zero-Blur & Skala Animasi 0.5x",
                tier = CapabilityTier.SHIZUKU_REQUIRED,
                available = shizukuReady,
                reason = if (shizukuReady) "Siap dijalankan melalui Shizuku."
                else "Membutuhkan izin Shizuku untuk menulis global.disable_window_blurs."
            ),
            FeatureCapability(
                id = "shizuku_touch_net",
                title = "Kalibrasi Touch 180ms & Reduksi Wi-Fi Scan Lag",
                tier = CapabilityTier.SHIZUKU_REQUIRED,
                available = shizukuReady,
                reason = if (shizukuReady) "Siap dijalankan melalui Shizuku."
                else "Membutuhkan izin Shizuku untuk menulis tabel secure/global settings."
            ),
            FeatureCapability(
                id = "unsupported_kernel_oc",
                title = "Overclock Kernel Di Luar Batas & Menonaktifkan Thermal Protection",
                tier = CapabilityTier.UNSUPPORTED,
                available = false,
                reason = "Diblokir demi keselamatan perangkat keras dan batasan keamanan Android."
            )
        )
    }

    private fun readCpuScalingMhz(): Int? {
        val paths = listOf(
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq",
            "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"
        )
        for (p in paths) {
            try {
                val f = File(p)
                if (f.canRead()) {
                    val khz = f.readText().trim().toIntOrNull()
                    if (khz != null && khz > 0) return khz / 1000
                }
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun probeTermuxEngine(): Boolean {
        return try {
            val conn = (URL("http://127.0.0.1:8080/api/status").openConnection() as HttpURLConnection).apply {
                connectTimeout = 450
                readTimeout = 450
                requestMethod = "GET"
            }
            conn.responseCode == 200
        } catch (_: Throwable) {
            false
        }
    }
}
