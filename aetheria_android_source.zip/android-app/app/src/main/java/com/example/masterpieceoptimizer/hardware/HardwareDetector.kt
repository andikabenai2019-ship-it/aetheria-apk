package com.example.masterpieceoptimizer.hardware

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt

enum class StorageType(val label: String) {
    UFS("UFS High-Speed Flash"),
    EMMC("eMMC Legacy Flash"),
    UNKNOWN("Auto-Detected Flash")
}

enum class DeviceTier(val badgeTitle: String, val focusSummary: String) {
    LOW_END(
        "TIER 1: LOW-END / HP KENTANG RESCUE",
        "Matikan Virtual RAM eMMC, animasi 0.35x & Zero-Blur, Vulkan SkiaVK, Downscale Game 0.75x, max_cached_processes 4–6."
    ),
    MID_RANGE(
        "TIER 2: MID-RANGE / DAILY & E-SPORTS",
        "Kunci 90Hz/120Hz, Downscale 0.85x–0.90x / Native, Matikan Phantom Process Killer (WA/IG Anti-Reload), Stabilkan Ping & Gyro."
    ),
    FLAGSHIP(
        "TIER 3: FLAGSHIP / ULTRA UNLOCKER",
        "Buka 120Hz–144Hz & LTPO, Native Resolution 1.00x, Multitasking 64+ Apps, ART Compile Speed/Everything, LDAC Hi-Res & Bypass Charging."
    )
}

enum class OemBrand(val displayName: String) {
    INFINIX_TECNO_ITEL("Infinix / TECNO / Itel (XOS / HiOS)"),
    XIAOMI_POCO_REDMI("Xiaomi / POCO / Redmi (MIUI / HyperOS)"),
    SAMSUNG("Samsung Galaxy (OneUI)"),
    OPPO_REALME_ONEPLUS("OPPO / Realme / OnePlus (ColorOS / RealmeUI)"),
    VIVO_IQOO("Vivo / iQOO (FuntouchOS / OriginOS)"),
    ASUS_ROG("ASUS ROG / Zenfone"),
    OTHER("Universal Android / Pixel / Motorola")
}

data class BatteryHealthReport(
    val healthPercent: Int,
    val healthLabel: String,
    val cycleCount: Int?,
    val designCapacityMah: Int?,
    val currentFullCapacityMah: Int?,
    val currentNowMa: Int,
    val realTimeWattageW: Double,
    val temperatureC: Double,
    val voltageMv: Int,
    val isCharging: Boolean,
    val bypassChargingCandidateKey: String?,
    val thermalDangerAlert: Boolean
)

data class DeviceSpecs(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val sdkInt: Int,
    val totalRamGb: Int,
    val availableRamMb: Long,
    val cpuCores: Int,
    val maxCpuFreqKhz: Long,
    val storageType: StorageType,
    val oemBrand: OemBrand,
    val recommendedTier: DeviceTier,
    val batteryHealth: BatteryHealthReport
)

/**
 * AETHERIA HARDWARE & BATTERY KERNEL DETECTOR (v30.0 QUANTUM 3D OMNI)
 * Fixes MicroSD-on-UFS false eMMC detection, bounded getprop timeout,
 * and reads real Battery Health %, Cycle Count, and Live Wattage without root.
 */
object HardwareDetector {

    suspend fun detectSpecs(context: Context): DeviceSpecs = withContext(Dispatchers.IO) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        // Commercial GB rounding (e.g. 3.7GB -> 4GB, 7.4GB -> 8GB, 11.3GB -> 12GB)
        val rawRamGb = memInfo.totalMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
        val totalRamGb = ceil(rawRamGb).toInt().coerceAtLeast(1)
        val availableRamMb = memInfo.availMem / (1024L * 1024L)

        val cpuCores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val maxCpuFreqKhz = getMaxCpuFrequencyKhz(cpuCores)
        val storageType = detectStorageType()
        val manufacturer = Build.MANUFACTURER ?: "Android"
        val brand = Build.BRAND ?: manufacturer
        val oemBrand = classifyOem(manufacturer, brand)
        val tier = determineTier(totalRamGb, storageType, maxCpuFreqKhz)
        val batteryHealth = inspectBatteryHealth(context, oemBrand)

        DeviceSpecs(
            manufacturer = manufacturer,
            brand = brand,
            model = Build.MODEL ?: "Smartphone",
            sdkInt = Build.VERSION.SDK_INT,
            totalRamGb = totalRamGb,
            availableRamMb = availableRamMb,
            cpuCores = cpuCores,
            maxCpuFreqKhz = maxCpuFreqKhz,
            storageType = storageType,
            oemBrand = oemBrand,
            recommendedTier = tier,
            batteryHealth = batteryHealth
        )
    }

    /**
     * SD-Card-Safe UFS vs eMMC Detection:
     * On MediaTek/Infinix/Realme UFS phones, root LUNs often live on `/sys/class/block/sdc` (or `sda`),
     * while inserting a MicroSD card creates `/sys/class/block/mmcblk0` (`removable == "1"`).
     * Checking `ufshcd`, `sda`, and `sdc` FIRST + verifying `mmcblk0/removable == "0"` prevents
     * misclassifying UFS phones with MicroSD cards as eMMC!
     */
    fun detectStorageType(): StorageType {
        val bootDevice = getSystemProperty("ro.boot.bootdevice").lowercase(Locale.ROOT)
        if (bootDevice.contains("ufshc") || bootDevice.contains("ufs")) {
            return StorageType.UFS
        }
        if (bootDevice.contains("sdhci") || bootDevice.contains("mmc") || bootDevice.contains("emmc")) {
            return StorageType.EMMC
        }

        // Check UFS SCSI block & UFS host controller drivers first (covers Qualcomm sda + MediaTek sdc)
        if (File("/sys/bus/platform/drivers/ufshcd").exists() ||
            File("/sys/bus/platform/drivers/ufshcd-pltfrm").exists() ||
            File("/sys/class/block/sda").exists() ||
            File("/sys/class/block/sdc").exists()
        ) {
            return StorageType.UFS
        }

        // Only classify mmcblk0 as internal eMMC if it is non-removable (not an external MicroSD card!)
        val mmc0 = File("/sys/class/block/mmcblk0")
        if (mmc0.exists()) {
            val removableFlag = runCatching {
                File("/sys/class/block/mmcblk0/removable").takeIf { it.canRead() }?.readText()?.trim()
            }.getOrNull()
            val hasBootPartition = File("/sys/class/block/mmcblk0boot0").exists()
            if (hasBootPartition || removableFlag == "0") {
                return StorageType.EMMC
            }
        }

        return StorageType.UNKNOWN
    }

    fun inspectBatteryHealth(context: Context, oemBrand: OemBrand): BatteryHealthReport {
        val battIntent = runCatching {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()

        val tempTenths = battIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320) ?: 320
        val tempC = ((tempTenths / 10.0) * 10.0).roundToInt() / 10.0
        val voltageMv = battIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 3900) ?: 3900
        val status = battIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val healthCode = battIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_GOOD)
            ?: BatteryManager.BATTERY_HEALTH_GOOD

        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val rawCurrentUa = runCatching {
            bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
        }.getOrDefault(0)
        // Some OEM kernels report uA (e.g. 1_500_000) while others report mA (e.g. 1500)
        val currentMa = when {
            abs(rawCurrentUa) > 25_000 -> rawCurrentUa / 1000
            else -> rawCurrentUa
        }
        val watts = ((abs(currentMa).toDouble() * voltageMv.toDouble()) / 1_000_000.0 * 100.0).roundToInt() / 100.0

        val fullRaw = readFirstLongFromSysfs(
            listOf(
                "/sys/class/power_supply/battery/charge_full",
                "/sys/class/power_supply/battery/energy_full",
                "/sys/class/power_supply/bms/charge_full"
            )
        )
        val designRaw = readFirstLongFromSysfs(
            listOf(
                "/sys/class/power_supply/battery/charge_full_design",
                "/sys/class/power_supply/battery/energy_full_design",
                "/sys/class/power_supply/bms/charge_full_design"
            )
        )
        val cycleSysfs = readFirstLongFromSysfs(
            listOf(
                "/sys/class/power_supply/battery/cycle_count",
                "/sys/class/power_supply/bms/cycle_count"
            )
        )?.toInt()

        val cycleApi = if (Build.VERSION.SDK_INT >= 34) {
            runCatching { battIntent?.getIntExtra("android.os.extra.CYCLE_COUNT", -1)?.takeIf { it >= 0 } }.getOrNull()
        } else null
        val cycleCount = cycleSysfs ?: cycleApi

        val fullMah = fullRaw?.let { if (it > 100_000L) (it / 1000L).toInt() else it.toInt() }
        val designMah = designRaw?.let { if (it > 100_000L) (it / 1000L).toInt() else it.toInt() }

        val calculatedPct = if (fullMah != null && designMah != null && designMah > 500) {
            ((fullMah.toDouble() / designMah.toDouble()) * 100.0).roundToInt().coerceIn(40, 100)
        } else {
            when (healthCode) {
                BatteryManager.BATTERY_HEALTH_GOOD -> 96
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> 88
                BatteryManager.BATTERY_HEALTH_DEAD -> 50
                else -> 90
            }
        }

        val healthLabel = when {
            calculatedPct >= 90 -> "SANGAT SEHAT (PRIMA)"
            calculatedPct >= 80 -> "BAIK / NORMAL"
            calculatedPct >= 70 -> "MULAI MENURUN (DISARANKAN HEMAT SUHU)"
            else -> "PERLU SERVIS / GANTI BATERAI"
        }

        val bypassKey = when (oemBrand) {
            OemBrand.INFINIX_TECNO_ITEL -> "bypass_charging_enable"
            OemBrand.SAMSUNG -> "pass_through"
            OemBrand.ASUS_ROG -> "asus_bypass_charging"
            OemBrand.XIAOMI_POCO_REDMI -> "night_charging_ bypass_enable".replace(" ", "")
            else -> null
        }

        return BatteryHealthReport(
            healthPercent = calculatedPct,
            healthLabel = healthLabel,
            cycleCount = cycleCount,
            designCapacityMah = designMah,
            currentFullCapacityMah = fullMah,
            currentNowMa = currentMa,
            realTimeWattageW = watts,
            temperatureC = tempC,
            voltageMv = voltageMv,
            isCharging = isCharging,
            bypassChargingCandidateKey = bypassKey,
            thermalDangerAlert = (tempC >= 43.0)
        )
    }

    private fun readFirstLongFromSysfs(paths: List<String>): Long? {
        for (p in paths) {
            try {
                val f = File(p)
                if (f.exists() && f.canRead()) {
                    val v = f.readText().trim().toLongOrNull()
                    if (v != null && v > 0L) return v
                }
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun getMaxCpuFrequencyKhz(coreCount: Int): Long {
        var maxFreq = 0L
        for (i in 0 until coreCount) {
            try {
                val freqFile = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
                if (freqFile.exists() && freqFile.canRead()) {
                    val freq = freqFile.readText().trim().toLongOrNull() ?: 0L
                    if (freq > maxFreq) {
                        maxFreq = freq
                    }
                }
            } catch (_: Throwable) {
            }
        }
        return if (maxFreq > 0L) maxFreq else 2_000_000L
    }

    fun classifyOem(manufacturer: String, brand: String): OemBrand {
        val combined = "$manufacturer $brand".lowercase(Locale.ROOT)
        return when {
            combined.contains("infinix") || combined.contains("tecno") ||
                combined.contains("itel") || combined.contains("transsion") -> OemBrand.INFINIX_TECNO_ITEL
            combined.contains("xiaomi") || combined.contains("poco") ||
                combined.contains("redmi") -> OemBrand.XIAOMI_POCO_REDMI
            combined.contains("samsung") -> OemBrand.SAMSUNG
            combined.contains("oppo") || combined.contains("realme") ||
                combined.contains("oneplus") -> OemBrand.OPPO_REALME_ONEPLUS
            combined.contains("vivo") || combined.contains("iqoo") -> OemBrand.VIVO_IQOO
            combined.contains("asus") || combined.contains("rog") -> OemBrand.ASUS_ROG
            else -> OemBrand.OTHER
        }
    }

    fun determineTier(
        totalRamGb: Int,
        storageType: StorageType,
        maxCpuFreqKhz: Long
    ): DeviceTier {
        if (totalRamGb <= 4 || storageType == StorageType.EMMC) {
            return DeviceTier.LOW_END
        }
        if (totalRamGb > 8 && maxCpuFreqKhz >= 2_750_000L && storageType == StorageType.UFS) {
            return DeviceTier.FLAGSHIP
        }
        return DeviceTier.MID_RANGE
    }

    private fun getSystemProperty(key: String): String {
        return try {
            val process = ProcessBuilder("getprop", key).redirectErrorStream(true).start()
            val finished = process.waitFor(800L, TimeUnit.MILLISECONDS)
            if (!finished) {
                runCatching { process.destroyForcibly() }
                return ""
            }
            BufferedReader(InputStreamReader(process.inputStream)).use { it.readLine()?.trim() ?: "" }
        } catch (_: Throwable) {
            ""
        }
    }
}
