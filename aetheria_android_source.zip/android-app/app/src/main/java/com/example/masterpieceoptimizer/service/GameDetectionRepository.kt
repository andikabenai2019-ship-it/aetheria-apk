package com.example.masterpieceoptimizer.service

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.masterpieceoptimizer.core.AetheriaIdentity
import java.util.Locale

/**
 * AETHERIA GAME DETECTION & AUTO-SWITCH PREFERENCE REPOSITORY (v30.0)
 * Fixes wrong Shizuku package name & transient overlay false-exit bugs.
 */
class GameDetectionRepository(private val context: Context) {

    companion object {
        private const val PREF_NAME = "aetheria_autoswitch_prefs_v300"
        private const val KEY_CUSTOM_GAMES = "custom_game_packages"
        private const val KEY_AUTOSWITCH_ENABLED = "auto_switch_enabled"
        private const val KEY_OVERNIGHT_MAINT_ENABLED = "overnight_maint_enabled"
        private const val KEY_FLOATING_HUD_ENABLED = "floating_hud_enabled"
    }

    private val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private val builtInPopularGames: Set<String> =
        AetheriaIdentity.KNOWN_POPULAR_GAMES.map { it.first }.toSet()

    /**
     * Transient overlays & system packages that briefly appear on top of a game
     * (notification shade, volume dialog, Shizuku, Brevent, XArena Game Space, Phone Master).
     * Ignoring these prevents Auto-Switch from prematurely exiting GAMING_MAX mid-match!
     */
    val transientSystemPackages: Set<String> = setOf(
        "android",
        "com.android.systemui",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "com.miui.securitycenter",
        "com.transsion.gamespace",
        "com.transsion.gamespace.app",
        "com.transsion.smartpanel",
        "com.transsion.phonemaster",
        "com.coloros.gamespace",
        "com.oplus.games",
        "com.vivo.gamemode",
        "com.samsung.android.game.gametools",
        AetheriaIdentity.SHIZUKU_PACKAGE, // Fixed: moe.shizuku.privileged.api
        AetheriaIdentity.BREVENT_PACKAGE, // Added: me.piebridge.brevent
        context.packageName
    )

    fun isGamePackage(packageName: String): Boolean {
        if (packageName.isBlank() || isTransientOverlay(packageName)) return false
        if (packageName in builtInPopularGames) return true
        if (packageName in getCustomGames()) return true

        return try {
            val pm = context.packageManager
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            val isCategoryGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else false
            @Suppress("DEPRECATION")
            val isLegacyFlagGame = (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            isCategoryGame || isLegacyFlagGame
        } catch (_: Throwable) {
            false
        }
    }

    fun isTransientOverlay(packageName: String): Boolean {
        if (packageName in transientSystemPackages) return true
        val low = packageName.lowercase(Locale.ROOT)
        return low.contains("inputmethod") ||
            low.contains("keyboard") ||
            low.contains("gboard") ||
            low.contains("screenshot")
    }

    fun getCustomGames(): Set<String> =
        prefs.getStringSet(KEY_CUSTOM_GAMES, emptySet()) ?: emptySet()

    fun addCustomGame(packageName: String) {
        val updated = getCustomGames().toMutableSet().apply { add(packageName.trim()) }
        prefs.edit().putStringSet(KEY_CUSTOM_GAMES, updated).apply()
    }

    fun removeCustomGame(packageName: String) {
        val updated = getCustomGames().toMutableSet().apply { remove(packageName.trim()) }
        prefs.edit().putStringSet(KEY_CUSTOM_GAMES, updated).apply()
    }

    fun setAutoSwitchEnabledPref(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTOSWITCH_ENABLED, enabled).apply()
    }

    fun isAutoSwitchEnabledPref(): Boolean =
        prefs.getBoolean(KEY_AUTOSWITCH_ENABLED, false)

    fun setOvernightMaintEnabledPref(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_OVERNIGHT_MAINT_ENABLED, enabled).apply()
    }

    fun isOvernightMaintEnabledPref(): Boolean =
        prefs.getBoolean(KEY_OVERNIGHT_MAINT_ENABLED, false)

    fun setFloatingHudEnabledPref(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_FLOATING_HUD_ENABLED, enabled).apply()
    }

    fun isFloatingHudEnabledPref(): Boolean =
        prefs.getBoolean(KEY_FLOATING_HUD_ENABLED, false)

    fun resetAutomationPrefsOnReboot() {
        prefs.edit()
            .putBoolean(KEY_AUTOSWITCH_ENABLED, false)
            .putBoolean(KEY_FLOATING_HUD_ENABLED, false)
            .apply()
    }
}
