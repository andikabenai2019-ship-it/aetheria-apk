package com.example.masterpieceoptimizer

import com.example.masterpieceoptimizer.core.AetheriaIdentity
import com.example.masterpieceoptimizer.core.CommandValidator
import com.example.masterpieceoptimizer.core.DeviceTierAdvisor
import com.example.masterpieceoptimizer.core.ShizukuConnectionState
import com.example.masterpieceoptimizer.core.SystemProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AetheriaCoreTest {

    @Test
    fun testPackageNameValidation_blocksCommandInjection() {
        assertTrue(CommandValidator.isValidPackageName("com.mobile.legends"))
        assertTrue(CommandValidator.isValidPackageName("moe.shizuku.privileged.api"))
        assertFalse(CommandValidator.isValidPackageName("com.mobile.legends; rm -rf /"))
        assertFalse(CommandValidator.isValidPackageName("$(id)"))
        assertFalse(CommandValidator.isValidPackageName("invalid_single_segment"))
        assertFalse(CommandValidator.isValidPackageName(""))
    }

    @Test
    fun testSettingSpecValidation_enforcesAllowedNamespaces() {
        assertTrue(CommandValidator.isValidSettingSpec("system", "min_refresh_rate", "120.0"))
        assertTrue(CommandValidator.isValidSettingSpec("global", "disable_window_blurs", "1"))
        assertTrue(CommandValidator.isValidSettingSpec("secure", "long_press_timeout", "180"))
        assertTrue(CommandValidator.isValidSettingSpec("global", "private_dns_specifier", "family.adguard-dns.com"))
        assertFalse(CommandValidator.isValidSettingSpec("root", "min_refresh_rate", "120.0"))
        assertFalse(CommandValidator.isValidSettingSpec("system", "min_refresh_rate;id", "120.0"))
        assertFalse(CommandValidator.isValidSettingSpec("system", "min_refresh_rate", "120.0 && reboot"))
    }

    @Test
    fun testValueEquivalence_handlesNumericRefreshRates() {
        assertTrue(CommandValidator.isValuesEquivalent("120.0", "120"))
        assertTrue(CommandValidator.isValuesEquivalent("60.0", "60.00"))
        assertTrue(CommandValidator.isValuesEquivalent("0.5", "0.5"))
        assertFalse(CommandValidator.isValuesEquivalent("120.0", "60.0"))
        assertFalse(CommandValidator.isValuesEquivalent("1", "null"))
    }

    @Test
    fun testSystemProfiles_haveDistinctRealDefinitions() {
        val balanced = SystemProfile.BALANCED.specs
        val gaming = SystemProfile.GAMING.specs
        val battery = SystemProfile.BATTERY_SAVER.specs
        val potato = SystemProfile.POTATO_RESCUE.specs

        assertTrue(balanced.isNotEmpty())
        assertTrue(gaming.isNotEmpty())
        assertTrue(battery.isNotEmpty())
        assertTrue(potato.isNotEmpty())

        val gamingMinHz = gaming.first { it.key == "min_refresh_rate" }.targetValue
        val batteryPeakHz = battery.first { it.key == "peak_refresh_rate" }.targetValue
        val potatoAnim = potato.first { it.key == "window_animation_scale" }.targetValue
        assertEquals("120.0", gamingMinHz)
        assertEquals("60.0", batteryPeakHz)
        assertEquals("0.0", potatoAnim)
    }

    @Test
    fun testDeviceTierAdvisor_classifiesEntryMidFlagship() {
        val (tier1, _) = DeviceTierAdvisor.classifyTier(3072L, 4)
        val (tier2, _) = DeviceTierAdvisor.classifyTier(8192L, 8)
        val (tier3, _) = DeviceTierAdvisor.classifyTier(12288L, 8)

        assertTrue(tier1.contains("TIER 1"))
        assertTrue(tier2.contains("TIER 2"))
        assertTrue(tier3.contains("TIER 3"))
    }

    @Test
    fun testUniversalLists_containDailySocialAndAntiScamTargets() {
        assertTrue(AetheriaIdentity.DAILY_SOCIAL_PACKAGES.any { it.first == "com.zhiliaoapp.musically" })
        assertTrue(AetheriaIdentity.OEM_AD_BLOAT_PACKAGES.contains("com.miui.msa.global"))
        assertTrue(AetheriaIdentity.SCAM_APK_KEYWORDS.contains("undangan"))
    }

    @Test
    fun testShizukuConnectionStates_areDistinct() {
        val states = listOf(
            ShizukuConnectionState.NotInstalled,
            ShizukuConnectionState.ServiceNotRunning,
            ShizukuConnectionState.PermissionRequired,
            ShizukuConnectionState.PermissionDenied(true),
            ShizukuConnectionState.Ready(uid = 2000, serviceVersion = 13, isRoot = false)
        )
        assertEquals(5, states.map { it.code }.distinct().size)
        assertEquals("Rangga Winata", AetheriaIdentity.ARCHITECT)
        assertEquals("ID1026619104999", AetheriaIdentity.QRIS_NMID)
    }
}
