package com.example.masterpieceoptimizer

import com.example.masterpieceoptimizer.core.ActiveProfileMode
import com.example.masterpieceoptimizer.core.AetheriaIdentity
import com.example.masterpieceoptimizer.core.CommandValidator
import com.example.masterpieceoptimizer.core.DeviceTierAdvisor
import com.example.masterpieceoptimizer.core.ShellBridgeMode
import com.example.masterpieceoptimizer.core.ShizukuConnectionState
import com.example.masterpieceoptimizer.core.ShizukuDiagnostics
import com.example.masterpieceoptimizer.core.SystemProfile
import com.example.masterpieceoptimizer.data.OemDebloatDatabase
import com.example.masterpieceoptimizer.hardware.DeviceTier
import com.example.masterpieceoptimizer.hardware.HardwareDetector
import com.example.masterpieceoptimizer.hardware.OemBrand
import com.example.masterpieceoptimizer.hardware.StorageType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AetheriaCoreTest {

    @Test
    fun testPackageNameValidation_blocksCommandInjection() {
        assertTrue(CommandValidator.isValidPackageName("com.mobile.legends"))
        assertTrue(CommandValidator.isValidPackageName("moe.shizuku.privileged.api"))
        assertTrue(CommandValidator.isValidPackageName("me.piebridge.brevent"))
        assertFalse(CommandValidator.isValidPackageName("com.mobile.legends; rm -rf /"))
        assertFalse(CommandValidator.isValidPackageName("$(id)"))
        assertFalse(CommandValidator.isValidPackageName("invalid_single_segment"))
        assertFalse(CommandValidator.isValidPackageName(""))
    }

    @Test
    fun testSettingSpecValidation_enforcesAllowedNamespaces() {
        assertTrue(CommandValidator.isValidSettingSpec("system", "min_refresh_rate", "120.0"))
        assertTrue(CommandValidator.isValidSettingSpec("global", "disable_window_blurs", "1"))
        assertTrue(CommandValidator.isValidSettingSpec("secure", "long_press_timeout", "180"))
        assertTrue(CommandValidator.isValidSettingSpec("global", "private_dns_mode", "opportunistic"))
        assertFalse(CommandValidator.isValidSettingSpec("root", "min_refresh_rate", "120.0"))
        assertFalse(CommandValidator.isValidSettingSpec("system", "min_refresh_rate;id", "120.0"))
        assertFalse(CommandValidator.isValidSettingSpec("system", "min_refresh_rate", "120.0 && reboot"))
    }

    @Test
    fun testValueEquivalence_handlesNumericRefreshRates() {
        assertTrue(CommandValidator.isValuesEquivalent("120.0", "120"))
        assertTrue(CommandValidator.isValuesEquivalent("60.0", "60.00"))
        assertTrue(CommandValidator.isValuesEquivalent("0.5", "0.5"))
        assertFalse(CommandValidator.isValuesEquivalent("120.0", "60.0"))
        assertFalse(CommandValidator.isValuesEquivalent("1", "null"))
    }

    @Test
    fun testSystemProfiles_haveDistinctRealDefinitionsIncludingQuadCombo() {
        val balanced = SystemProfile.BALANCED.specs
        val gaming = SystemProfile.GAMING.specs
        val esports = SystemProfile.ESPORT_ULTIMATE_PRO.specs
        val coolBoost = SystemProfile.SMART_COOL_BOOST.specs
        val battery = SystemProfile.BATTERY_SAVER.specs
        val potato = SystemProfile.POTATO_RESCUE.specs
        val quadCombo = SystemProfile.TRIPLE_COMBO.specs

        assertTrue(balanced.isNotEmpty())
        assertTrue(gaming.isNotEmpty())
        assertTrue(esports.isNotEmpty())
        assertTrue(coolBoost.isNotEmpty())
        assertTrue(battery.isNotEmpty())
        assertTrue(potato.isNotEmpty())
        assertTrue(quadCombo.isNotEmpty())
        assertTrue(AetheriaIdentity.KNOWN_POPULAR_GAMES.size >= 20)
        assertEquals(4, ActiveProfileMode.values().size)

        val gamingMinHz = gaming.first { it.key == "min_refresh_rate" }.targetValue
        val batteryPeakHz = battery.first { it.key == "peak_refresh_rate" }.targetValue
        val potatoAnim = potato.first { it.key == "window_animation_scale" }.targetValue
        assertEquals("120.0", gamingMinHz)
        assertEquals("60.0", batteryPeakHz)
        assertEquals("0.0", potatoAnim)
    }

    @Test
    fun testImmortalProtection_neverAllowsWhatsAppOrInstagramToBeDisabled() {
        assertTrue(OemDebloatDatabase.isImmortalProtected("com.whatsapp"))
        assertTrue(OemDebloatDatabase.isImmortalProtected("com.whatsapp.w4b"))
        assertTrue(OemDebloatDatabase.isImmortalProtected("com.instagram.android"))
        assertTrue(OemDebloatDatabase.isImmortalProtected("  COM.WHATSAPP  "))
        assertFalse(OemDebloatDatabase.isImmortalProtected("com.miui.msa.global"))

        // Built-in debloat database & OEM ad-bloat list must contain ZERO immortal WA/IG apps
        assertTrue(OemDebloatDatabase.builtInPackages.none { OemDebloatDatabase.isImmortalProtected(it.packageName) })
        assertTrue(AetheriaIdentity.OEM_AD_BLOAT_PACKAGES.none { OemDebloatDatabase.isImmortalProtected(it) })
    }

    @Test
    fun testQuadComboPhoneMasterPackages_coverAllMajorPhoneBrands() {
        val masters = OemDebloatDatabase.PHONE_MASTER_PACKAGES
        assertTrue(masters.contains("com.transsion.phonemaster"))
        assertTrue(masters.contains("com.miui.securitycenter"))
        assertTrue(masters.contains("com.coloros.phonemanager"))
        assertTrue(masters.contains("com.oplus.phonemanager"))
        assertTrue(masters.contains("com.iqoo.secure"))
        assertTrue(masters.contains("com.samsung.android.lool"))
        assertTrue(masters.contains("com.asus.mobilemanager"))
    }

    @Test
    fun testHardwareDetector_classifiesOemBrandsAndHardwareTiers() {
        assertEquals(OemBrand.INFINIX_TECNO_ITEL, HardwareDetector.classifyOem("INFINIX", "Infinix"))
        assertEquals(OemBrand.INFINIX_TECNO_ITEL, HardwareDetector.classifyOem("TECNO", "TECNO"))
        assertEquals(OemBrand.XIAOMI_POCO_REDMI, HardwareDetector.classifyOem("Xiaomi", "POCO"))
        assertEquals(OemBrand.SAMSUNG, HardwareDetector.classifyOem("samsung", "samsung"))
        assertEquals(OemBrand.OPPO_REALME_ONEPLUS, HardwareDetector.classifyOem("realme", "realme"))
        assertEquals(OemBrand.VIVO_IQOO, HardwareDetector.classifyOem("vivo", "iQOO"))
        assertEquals(OemBrand.ASUS_ROG, HardwareDetector.classifyOem("asus", "ASUS_AI2201"))
        assertEquals(OemBrand.OTHER, HardwareDetector.classifyOem("Google", "Pixel"))

        // eMMC even with 8GB RAM should be guarded as LOW_END to avoid swap/I/O lag
        assertEquals(DeviceTier.LOW_END, HardwareDetector.determineTier(4, StorageType.UFS, 2_000_000L))
        assertEquals(DeviceTier.LOW_END, HardwareDetector.determineTier(8, StorageType.EMMC, 2_200_000L))
        assertEquals(DeviceTier.MID_RANGE, HardwareDetector.determineTier(8, StorageType.UFS, 2_400_000L))
        assertEquals(DeviceTier.FLAGSHIP, HardwareDetector.determineTier(12, StorageType.UFS, 3_200_000L))
    }

    @Test
    fun testDualBridgeDiagnostics_readyViaShizukuOrBrevent() {
        val states = listOf(
            ShizukuConnectionState.NotInstalled,
            ShizukuConnectionState.ServiceNotRunning,
            ShizukuConnectionState.PermissionRequired,
            ShizukuConnectionState.PermissionDenied(true),
            ShizukuConnectionState.Ready(uid = 2000, serviceVersion = 13, isRoot = false)
        )
        assertEquals(5, states.map { it.code }.distinct().size)

        val breventOnlyDiag = ShizukuDiagnostics(
            state = ShizukuConnectionState.NotInstalled,
            shizukuAppInstalled = false,
            binderAlive = false,
            permissionGranted = false,
            uid = 2000,
            serviceVersion = null,
            lastCheckedTime = "12:00:00",
            diagnosticMessage = "Brevent Ready",
            recoverySteps = emptyList(),
            breventAppInstalled = true,
            breventBridgeActive = true,
            writeSecureSettingsGranted = true,
            activeBridgeMode = ShellBridgeMode.BREVENT_UID2000
        )
        assertFalse(breventOnlyDiag.isShizukuReady)
        assertTrue(breventOnlyDiag.isShellUid2000Ready)
        assertTrue(breventOnlyDiag.isReady)

        assertEquals("30.0.0-QUANTUM-3D-OMNI", AetheriaIdentity.VERSION)
        assertEquals(300, AetheriaIdentity.VERSION_CODE)
        assertEquals("moe.shizuku.privileged.api", AetheriaIdentity.SHIZUKU_PACKAGE)
        assertEquals("me.piebridge.brevent", AetheriaIdentity.BREVENT_PACKAGE)
        assertEquals("Rangga Winata", AetheriaIdentity.ARCHITECT)
        assertEquals("ID1026619104999", AetheriaIdentity.QRIS_NMID)

        val (tier1, _) = DeviceTierAdvisor.classifyTier(3072L, 4)
        val (tier2, _) = DeviceTierAdvisor.classifyTier(8192L, 8)
        val (tier3, _) = DeviceTierAdvisor.classifyTier(12288L, 8)
        assertTrue(tier1.contains("TIER 1"))
        assertTrue(tier2.contains("TIER 2"))
        assertTrue(tier3.contains("TIER 3"))
    }
}
